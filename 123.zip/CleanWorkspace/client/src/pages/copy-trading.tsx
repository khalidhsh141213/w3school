import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Users, 
  TrendingUp, 
  Search, 
  Filter, 
  Star, 
  User, 
  CheckCircle2, 
  AlertCircle,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Award,
  LineChart
} from 'lucide-react';
import useWebSocketManager from '@/hooks/useWebSocketManager';
import { Trader, PortfolioItem, WebSocketMessage, TraderCardProps } from '../types/trader';

const TraderCard = ({ trader, updatedPrices }: TraderCardProps) => {
  // Calculate updated performance if we have real-time prices
  const calculatedPerformance = () => {
    if (!updatedPrices || !trader.portfolio || trader.portfolio.length === 0) {
      return trader.performance;
    }
    
    // Simple estimation - adjust performance based on portfolio weights and price changes
    const portfolioChange = trader.portfolio.reduce((acc, item) => {
      if (updatedPrices[item.symbol]) {
        const originalPrice = item.currentPrice || 0;
        const newPrice = updatedPrices[item.symbol];
        if (originalPrice > 0) {
          const changeContribution = ((newPrice - originalPrice) / originalPrice) * (item.percentage / 100);
          return acc + changeContribution;
        }
      }
      return acc;
    }, 0);
    
    // Add estimated change to performance (simplified calculation)
    return trader.performance + (portfolioChange * 100);
  };
  
  const performance = calculatedPerformance();
  
  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-4">
        <div className="flex items-start space-x-4">
          {/* Trader Avatar */}
          <div className="relative">
            <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-100">
              <img 
                src={trader.avatarUrl || `https://ui-avatars.com/api/?name=${trader.name}&background=0D8ABC&color=fff`} 
                alt={trader.name} 
                className="w-full h-full object-cover"
              />
            </div>
            {trader.verified && (
              <div className="absolute -bottom-1 -right-1 bg-primary rounded-full p-0.5">
                <CheckCircle2 className="h-4 w-4 text-white" />
              </div>
            )}
          </div>
          
          {/* Trader Info */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-semibold">{trader.name}</h3>
              {trader.featured && (
                <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                  <Star className="h-3 w-3 mr-1" /> Featured
                </Badge>
              )}
            </div>
            
            <div className="text-sm text-gray-500 mb-2">{trader.description}</div>
            
            {/* Performance Metrics */}
            <div className="grid grid-cols-3 gap-2 mt-3">
              <div className="bg-gray-50 rounded p-1 text-center">
                <div className={`text-sm font-medium ${performance >= 0 ? 'text-primary' : 'text-alertRed'}`}>
                  {performance >= 0 ? '+' : ''}{performance.toFixed(1)}%
                </div>
                <div className="text-xs text-gray-500">Return</div>
              </div>
              <div className="bg-gray-50 rounded p-1 text-center">
                <div className="text-sm font-medium">{trader.followers}</div>
                <div className="text-xs text-gray-500">Followers</div>
              </div>
              <div className="bg-gray-50 rounded p-1 text-center">
                <div className="text-sm font-medium">{trader.risk}</div>
                <div className="text-xs text-gray-500">Risk</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="mt-4 flex gap-2">
          <Button variant="default" className="flex-1">
            Copy Trader
          </Button>
          <Button variant="outline" className="flex-1">
            View Profile
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Performance Chart Card
const PerformanceChart = ({ trader, updatedPrices }: { trader: Trader, updatedPrices?: Record<string, number> }) => {
  // Calculate updated performance similar to TraderCard
  const calculatedPerformance = () => {
    if (!updatedPrices || !trader.portfolio || trader.portfolio.length === 0) {
      return trader.performance;
    }
    
    const portfolioChange = trader.portfolio.reduce((acc, item) => {
      if (updatedPrices[item.symbol]) {
        const originalPrice = item.currentPrice || 0;
        const newPrice = updatedPrices[item.symbol];
        if (originalPrice > 0) {
          const changeContribution = ((newPrice - originalPrice) / originalPrice) * (item.percentage / 100);
          return acc + changeContribution;
        }
      }
      return acc;
    }, 0);
    
    return trader.performance + (portfolioChange * 100);
  };
  
  const performance = calculatedPerformance();
  
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Performance History</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-sm text-gray-500">All time return</span>
            <div className={`text-2xl font-bold ${performance >= 0 ? 'text-primary' : 'text-alertRed'}`}>
              {performance >= 0 ? '+' : ''}{performance.toFixed(1)}%
            </div>
          </div>
          <div className="flex flex-col items-end">
            <div className="flex items-center">
              <div className={`px-2 py-1 rounded text-xs flex items-center mr-2 ${
                trader.lastMonthPerformance >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {trader.lastMonthPerformance >= 0 ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {Math.abs(trader.lastMonthPerformance)}%
              </div>
              <span className="text-xs text-gray-500">Last month</span>
            </div>
            <div className="flex items-center mt-1">
              <div className={`px-2 py-1 rounded text-xs flex items-center mr-2 ${
                trader.lastWeekPerformance >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {trader.lastWeekPerformance >= 0 ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {Math.abs(trader.lastWeekPerformance)}%
              </div>
              <span className="text-xs text-gray-500">Last week</span>
            </div>
          </div>
        </div>
        
        {/* Placeholder for chart - would use a real chart library in production */}
        <div className="h-40 w-full bg-gray-50 rounded-lg flex items-center justify-center">
          <LineChart className="h-20 w-20 text-gray-300" />
          <span className="text-sm text-gray-400">Performance chart would go here</span>
        </div>
      </CardContent>
    </Card>
  );
};

// Featured Trader Portfolio
const TraderPortfolio = ({ trader, updatedPrices }: { trader: Trader, updatedPrices?: Record<string, number> }) => {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Portfolio Allocation</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          {trader.portfolio.map((item, index) => {
            // Use real-time price if available
            const realTimeChange = updatedPrices && item.currentPrice 
              ? ((updatedPrices[item.symbol] - item.currentPrice) / item.currentPrice) * 100 
              : item.change;
            
            return (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                    <span className="text-xs font-semibold">{item.symbol.substring(0, 2)}</span>
                  </div>
                  <div className="ml-3">
                    <div className="font-medium">{item.symbol}</div>
                    <div className="text-xs text-gray-500">{item.name}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{item.percentage}%</div>
                  <div className={`text-xs ${realTimeChange >= 0 ? 'text-primary' : 'text-alertRed'}`}>
                    {realTimeChange >= 0 ? '+' : ''}{realTimeChange.toFixed(1)}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default function CopyTradingPage() {
  const [activeTab, setActiveTab] = useState('featured');
  const [searchTerm, setSearchTerm] = useState('');
  const [wsConnected, setWsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [realTimePrices, setRealTimePrices] = useState<Record<string, number>>({});
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const maxConnectionAttempts = 5;
  
  // Initialize WebSocketManager at component level
  const { 
    status: wsStatus, 
    subscribe: wsSubscribe, 
    send: wsSend,
    isConnected: wsIsConnected 
  } = useWebSocketManager();
  
  // Fetch traders
  const { data: traders, isLoading } = useQuery({
    queryKey: ['/api/traders'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/traders');
        if (!res.ok) throw new Error('Failed to fetch traders');
        return res.json();
      } catch (error) {
        console.error('Error fetching traders:', error);
        throw error;
      }
    }
  });
  
  // Fetch featured traders
  const { data: featuredTraders, isLoading: isFeaturedLoading } = useQuery({
    queryKey: ['/api/traders/featured'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/traders/featured');
        if (!res.ok) throw new Error('Failed to fetch featured traders');
        return res.json();
      } catch (error) {
        console.error('Error fetching featured traders:', error);
        throw error;
      }
    }
  });
  
  // Sample featured trader for detailed view
  const featuredTrader = {
    id: 1,
    name: "Alex Morgan",
    description: "Professional trader specializing in tech stocks and growth investment",
    avatarUrl: "",
    verified: true,
    featured: true,
    performance: 32.5,
    lastMonthPerformance: 4.2,
    lastWeekPerformance: -1.5,
    followers: 1254,
    risk: "Medium",
    portfolio: [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        percentage: 25,
        change: 2.3,
        currentPrice: 182.52
      },
      {
        symbol: "MSFT",
        name: "Microsoft Corp.",
        percentage: 20,
        change: 1.7,
        currentPrice: 372.65
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        percentage: 15,
        change: -3.2,
        currentPrice: 245.20
      },
      {
        symbol: "AMZN",
        name: "Amazon.com Inc.",
        percentage: 18,
        change: 0.8,
        currentPrice: 131.75
      },
      {
        symbol: "NVDA",
        name: "NVIDIA Corp.",
        percentage: 12,
        change: 4.5,
        currentPrice: 485.09
      }
    ]
  };
  
  // Get all portfolio symbols for WebSocket subscription
  const getPortfolioSymbols = (): string[] => {
    const allSymbols = new Set<string>();
    
    // Add featured trader symbols
    if (featuredTrader?.portfolio) {
      featuredTrader.portfolio.forEach((item: PortfolioItem) => {
        allSymbols.add(item.symbol);
      });
    }
    
    // Add symbols from all traders
    const allTraders = (activeTab === 'featured' ? featuredTraders : traders) || [];
    allTraders.forEach((trader: Trader) => {
      if (trader?.portfolio) {
        trader.portfolio.forEach((item: PortfolioItem) => {
          allSymbols.add(item.symbol);
        });
      }
    });
    
    return Array.from(allSymbols);
  };
  
  // Set up WebSocket connection for real-time price updates
  useEffect(() => {
    const symbols = getPortfolioSymbols();
    if (symbols.length === 0) return;
    
    // Use the WebSocketManager initialized at component level
    const connected = wsIsConnected();
    
    // Update connection status when component mounts or WebSocket status changes
    setWsConnected(connected);
    if (!connected) {
      setConnectionError('Disconnected from real-time data service');
    } else {
      setConnectionError(null);
      setConnectionAttempts(0);
      
      // Subscribe to all portfolio symbols
      wsSend('subscribe', { 
        symbols: symbols 
      });
      console.log(`Subscribed to ${symbols.length} portfolio symbols via WebSocketManager`);
    }
    
    // Subscribe to price updates
    const handler = (data: any) => {
      try {
        if (data.type === 'priceUpdate' && data.symbol && typeof data.price === 'number') {
          // Update our price map with the latest price
          setRealTimePrices(prev => {
            const newPrices = { ...prev };
            newPrices[data.symbol] = data.price;
            return newPrices;
          });
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    };
    
    // Subscribe using the component-level WebSocketManager
    const unsubscribe = wsSubscribe('message', handler);
    
    // Cleanup function
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [activeTab, featuredTraders, traders, wsIsConnected, wsSend, wsSubscribe]);
  
  // Filter traders based on search term
  const filteredTraders = (activeTab === 'featured' ? featuredTraders : traders)?.filter((trader: Trader) => {
    if (!trader) return false;
    
    const nameMatch = trader.name && searchTerm
      ? trader.name.toLowerCase().includes(searchTerm.toLowerCase())
      : true;
      
    const descriptionMatch = trader.description && searchTerm 
      ? trader.description.toLowerCase().includes(searchTerm.toLowerCase())
      : false;
      
    return nameMatch || descriptionMatch;
  });
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-textDark mb-4">Copy Trading</h1>
      
      {connectionError && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {connectionError} Using cached data instead.
          </AlertDescription>
        </Alert>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - Traders list */}
        <div className="lg:col-span-2 space-y-6">
          {/* Search and tabs */}
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-3">
              <div className="w-full md:w-auto relative">
                <Search className="absolute top-2.5 left-2.5 h-4 w-4 text-gray-400" />
                <Input 
                  className="pl-9 w-full" 
                  placeholder="Search traders" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex items-center space-x-2 w-full md:w-auto">
                <Filter className="h-4 w-4 text-gray-500" />
                <select className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50">
                  <option>All Traders</option>
                  <option>Highest Return</option>
                  <option>Most Popular</option>
                  <option>Lowest Risk</option>
                </select>
              </div>
            </div>
            
            <Tabs defaultValue="featured" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="featured">
                  <Star className="h-4 w-4 mr-1" /> Featured
                </TabsTrigger>
                <TabsTrigger value="all">
                  <Users className="h-4 w-4 mr-1" /> All Traders
                </TabsTrigger>
                <TabsTrigger value="following">
                  <CheckCircle2 className="h-4 w-4 mr-1" /> Following
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value={activeTab} className="mt-0">
                {/* Live data indicator */}
                {wsConnected && (
                  <div className="mb-3 text-xs text-primary flex items-center">
                    <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
                    Real-time performance data active
                  </div>
                )}
                
                {/* Traders Grid */}
                {isLoading || isFeaturedLoading ? (
                  <div className="grid grid-cols-1 gap-4">
                    {[1, 2, 3].map(i => (
                      <Card key={i} className="w-full h-[200px] animate-pulse">
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <div className="w-16 h-16 rounded-full bg-gray-200"></div>
                            <div className="flex-1">
                              <div className="bg-gray-200 h-5 w-1/3 rounded mb-2"></div>
                              <div className="bg-gray-200 h-4 w-2/3 rounded mb-3"></div>
                              <div className="grid grid-cols-3 gap-2">
                                <div className="bg-gray-200 h-8 rounded"></div>
                                <div className="bg-gray-200 h-8 rounded"></div>
                                <div className="bg-gray-200 h-8 rounded"></div>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-4">
                            <div className="bg-gray-200 h-9 rounded flex-1"></div>
                            <div className="bg-gray-200 h-9 rounded flex-1"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : filteredTraders?.length === 0 ? (
                  <div className="text-center py-12">
                    <User className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium mb-2">No traders found</h3>
                    <p className="text-gray-500 mb-4">Try adjusting your search criteria</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredTraders?.map((trader: Trader) => (
                      <TraderCard 
                        key={trader.id} 
                        trader={trader} 
                        updatedPrices={realTimePrices}
                      />
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        {/* Right column - Featured trader */}
        <div className="space-y-6">
          <Card className="bg-gray-50 p-4 border-dashed">
            <div className="flex items-center space-x-2 mb-2">
              <Award className="h-5 w-5 text-amber-500" />
              <h3 className="font-medium">How Copy Trading Works</h3>
            </div>
            <p className="text-sm text-gray-600 mb-2">
              Copy trading lets you automatically replicate the trading activity of experienced investors.
            </p>
            <ol className="text-sm text-gray-600 space-y-1 pl-5 list-decimal">
              <li>Choose a trader to copy</li>
              <li>Set your copy amount</li>
              <li>Their trades are copied to your account</li>
            </ol>
            <Button variant="link" className="text-primary p-0 h-auto mt-2 text-sm">
              Learn more about copy trading
              <ChevronRight className="h-3 w-3 ml-1" />
            </Button>
          </Card>
          
          <PerformanceChart 
            trader={featuredTrader} 
            updatedPrices={realTimePrices}
          />
          
          <TraderPortfolio 
            trader={featuredTrader} 
            updatedPrices={realTimePrices}
          />
        </div>
      </div>
    </div>
  );
}