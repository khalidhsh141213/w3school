`use client`;

import { getQueryFn } from '@/lib/queryClient';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useRef, useState } from 'react';
import WebSocketManagerSingleton, { ConnectionStatus } from '@/services/WebSocketManagerSingleton';

export interface PortfolioData {
  id: string;
  userId: string;
  totalValue: number;
  availableBalance: number;
  investedAmount: number;
  unrealizedPL: number;
  plPercentage: number;
  createdAt: string;
  updatedAt: string;
}

// Default portfolio data when none exists
export const defaultPortfolioData: PortfolioData = {
  id: "",
  userId: "",
  totalValue: 50000,
  availableBalance: 50000,
  investedAmount: 0,
  unrealizedPL: 0,
  plPercentage: 0,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
};

export interface OrderData {
  id: string;
  userId: string;
  assetId: string;
  assetSymbol?: string;
  assetType?: string;
  price: number;
  quantity: number;
  orderType: string;
  orderStatus: string;
  orderSide: string;
  orderDate: string;
}

export interface Trade {
  id: string;
  userId: string;
  assetId: string;
  assetSymbol?: string;
  assetType?: string;
  quantity: number;
  entryPrice: number;
  currentPrice?: number;
  exitPrice?: number;
  orderType?: string;
  orderSide: string;
  orderStatus: string;
  orderDate: string;
  pnl?: number;
  pnlPercentage?: number;
  leverage?: number;
  stopLoss?: number;
  takeProfit?: number;
}

export function usePortfolioData(userId?: string) {
  const queryClient = useQueryClient();
  const webSocketRef = useRef<WebSocket | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;
  const reconnectIntervalBase = 2000; // Starting at 2 seconds
  
  // Fetch portfolio data
  const portfolioQuery = useQuery<PortfolioData>({
    queryKey: userId ? ['/api/portfolio', userId] : ['/api/portfolio'],
    queryFn: userId 
      ? getQueryFn<PortfolioData>({ 
          on401: 'returnNull'
        })
      : () => Promise.resolve(defaultPortfolioData),
    enabled: !!userId,
    retry: 2,
    staleTime: 30000 // 30 seconds
  });

  // Fetch all trades (we'll filter them client-side)
  const tradesQuery = useQuery<Trade[]>({
    queryKey: userId ? ['/api/trades/user', userId] : ['/api/trades'],
    queryFn: userId 
      ? getQueryFn<Trade[]>({ 
          on401: 'returnNull'
        })
      : () => Promise.resolve([]),
    enabled: !!userId,
    retry: 2,
    staleTime: 30000, // 30 seconds
    initialData: [],
  });

  // Fetch portfolio summary
  const summaryQuery = useQuery({
    queryKey: userId ? ['/api/portfolio-summary', userId] : ['/api/portfolio-summary'],
    queryFn: userId 
      ? getQueryFn({ 
          on401: 'returnNull'
        })
      : () => Promise.resolve(null),
    enabled: !!userId,
    retry: 2,
    staleTime: 30000 // 30 seconds
  });
  
  // Split trades into orders (open) and completed trades (closed)
  const allTrades = tradesQuery.data || [];
  const orders = allTrades.filter(trade => trade.orderStatus === 'open' || trade.orderStatus === 'pending') as unknown as OrderData[];
  const trades = allTrades.filter(trade => trade.orderStatus === 'closed' || trade.orderStatus === 'executed');

  // Determine if we're in a loading state
  const isLoading = 
    (portfolioQuery.isLoading || tradesQuery.isLoading) && 
    (portfolioQuery.fetchStatus === 'fetching' || tradesQuery.fetchStatus === 'fetching');

  // Refetch all data
  const refetchAll = useCallback(async () => {
    await Promise.all([
      portfolioQuery.refetch(),
      tradesQuery.refetch(), 
      summaryQuery.refetch()
    ]);
  }, [portfolioQuery, tradesQuery, summaryQuery]);

  // Use the WebSocketManager hook for real-time updates
  useEffect(() => {
    if (!userId) {
      return;
    }

    // Setup WebSocket URL
    const wsUrl = "wss://" + window.location.host + "/ws";
    
    // Get the WebSocketManager instance
    const manager = WebSocketManagerSingleton.getInstance();
    
    // Handle messages
    const handleMessage = (data: any) => {
      if (!data) return;
      
      // Handle different types of updates
      if (data.type === 'trade_update') {
        // When a trade is updated, refetch trades
        queryClient.invalidateQueries({ queryKey: ['/api/trades/user', userId] });
        
        // Also invalidate portfolio data since balances might have changed
        queryClient.invalidateQueries({ queryKey: ['/api/portfolio', userId] });
        queryClient.invalidateQueries({ queryKey: ['/api/portfolio-summary', userId] });
      } else if (data.type === 'price_update' || data.type === 'marketUpdate') {
        // Only invalidate trades on price updates relevant to our open trades
        const openTrades = allTrades.filter(trade => 
          trade.orderStatus === 'open' || trade.orderStatus === 'pending'
        );
        
        const hasRelevantTrade = openTrades.some(trade => {
          return data.symbol === trade.assetSymbol;
        });
        
        if (hasRelevantTrade) {
          queryClient.invalidateQueries({ queryKey: ['/api/trades/user', userId] });
          queryClient.invalidateQueries({ queryKey: ['/api/portfolio-summary', userId] });
        }
      }
    };
    
    // Subscribe to messages
    manager.subscribe(wsUrl, handleMessage);
    
    // Update connection status when connection state changes
    const connectionStatusInterval = setInterval(() => {
      const status = manager.getStatus(wsUrl);
      setWsConnected(status === ConnectionStatus.CONNECTED);
    }, 2000);

    // Clean up subscription on unmount
    return () => {
      // Use unsubscribe method correctly
      manager.unsubscribe(wsUrl, handleMessage);
      clearInterval(connectionStatusInterval);
      
      // Note: No need to manually close the connection
      // WebSocketManager handles connection management
    };
  }, [userId, queryClient, allTrades]);

  // Setup a regular poll for price updates (backup for WebSocket)
  useEffect(() => {
    if (!userId) {
      return;
    }

    const interval = setInterval(() => {
      // Always refetch periodically to ensure data is fresh
      refetchAll();
    }, 15000); // Every 15 seconds

    return () => clearInterval(interval);
  }, [userId, refetchAll]);

  return {
    portfolio: portfolioQuery.data || defaultPortfolioData,
    orders,
    trades,
    summary: summaryQuery.data,
    isLoading,
    isFetching: portfolioQuery.isFetching || tradesQuery.isFetching,
    errors: {
      portfolio: portfolioQuery.error,
      orders: tradesQuery.error,
      trades: tradesQuery.error,
      summary: summaryQuery.error
    },
    refetch: refetchAll,
    wsConnected
  };
}