import React, { useState } from 'react';
import useEconomicEvents, { EventCategory } from '../../hooks/useEconomicEvents';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { DatePicker } from '../ui/calendar';
import { format } from 'date-fns';
import { ConnectionStatus } from '../../services/WebSocketService';

// Impact level badge component
const ImpactBadge = ({ impact }: { impact: 'low' | 'medium' | 'high' }) => {
  const colors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800'
  };
  
  return (
    <Badge className={colors[impact]}>
      {impact.charAt(0).toUpperCase() + impact.slice(1)}
    </Badge>
  );
};

// Economic event card component
const EventCard = ({ event }: { event: any }) => {
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-md">{event.title}</CardTitle>
          <ImpactBadge impact={event.impact} />
        </div>
        <CardDescription>
          {event.country} | {format(new Date(event.date), 'PPP')}
          {event.time && ` at ${event.time}`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {event.description && <p className="text-sm mb-2">{event.description}</p>}
        <div className="grid grid-cols-3 gap-2 mt-2">
          <div>
            <div className="text-xs text-muted-foreground">Previous</div>
            <div>{event.previous || 'N/A'}{event.unit ? ` ${event.unit}` : ''}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Forecast</div>
            <div>{event.forecast || 'N/A'}{event.unit ? ` ${event.unit}` : ''}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Actual</div>
            <div className="font-medium">
              {event.actual || 'Pending'}{event.unit ? ` ${event.unit}` : ''}
            </div>
          </div>
        </div>
      </CardContent>
      {event.source && (
        <CardFooter className="pt-0 text-xs text-muted-foreground">
          Source: {event.source}
        </CardFooter>
      )}
    </Card>
  );
};

// Connection status indicator
const ConnectionStatusIndicator = ({ status }: { status: ConnectionStatus }) => {
  const statusConfig = {
    [ConnectionStatus.CONNECTED]: { 
      color: 'bg-green-500', 
      text: 'Connected'
    },
    [ConnectionStatus.CONNECTING]: { 
      color: 'bg-yellow-500', 
      text: 'Connecting...'
    },
    [ConnectionStatus.DISCONNECTED]: { 
      color: 'bg-red-500', 
      text: 'Disconnected'
    },
    [ConnectionStatus.ERROR]: { 
      color: 'bg-red-500', 
      text: 'Error'
    },
    [ConnectionStatus.RECONNECTING]: { 
      color: 'bg-yellow-500', 
      text: 'Reconnecting...'
    },
  };
  
  const config = statusConfig[status];
  
  return (
    <div className="flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${config.color}`}></div>
      <span className="text-sm">{config.text}</span>
    </div>
  );
};

const CATEGORIES: { label: string; value: EventCategory }[] = [
  { label: 'All Events', value: 'all' },
  { label: 'High Impact', value: 'high_impact' },
  { label: 'Interest Rates', value: 'interest_rate' },
  { label: 'GDP', value: 'gdp' },
  { label: 'Employment', value: 'employment' },
  { label: 'Inflation', value: 'inflation' },
  { label: 'Trade', value: 'trade' },
  { label: 'Consumer', value: 'consumer' },
  { label: 'Housing', value: 'housing' },
  { label: 'Central Bank', value: 'central_bank' },
  { label: 'Earnings', value: 'earnings' },
];

const COUNTRIES = [
  { label: 'All Countries', value: 'all' },
  { label: 'United States', value: 'US' },
  { label: 'Eurozone', value: 'EU' },
  { label: 'United Kingdom', value: 'UK' },
  { label: 'Japan', value: 'JP' },
  { label: 'Canada', value: 'CA' },
  { label: 'Australia', value: 'AU' },
  { label: 'China', value: 'CN' },
];

export function EconomicEventsExample() {
  // State for filters
  const [category, setCategory] = useState<EventCategory>('all');
  const [country, setCountry] = useState('all');
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  
  // Use the economic events hook
  const {
    events,
    isLoading,
    error,
    isConnected,
    connectionStatus,
    lastUpdateTime,
    filterByCategory,
    filterByCountry,
    filterByDateRange,
    getUpcomingEvents,
    getHighImpactEvents,
    refresh
  } = useEconomicEvents({
    categories: [category],
    pollingInterval: 60000, // 1 minute
    throttleUpdates: 1000,
    cache: {
      enabled: true,
      maxAge: 300000 // 5 minutes
    },
    dateRange: {
      start: startDate,
      end: endDate
    },
    limit: 100
  });
  
  // Apply filters
  let filteredEvents = events;
  
  // If country filter is applied
  if (country !== 'all') {
    filteredEvents = filterByCountry(country);
  }
  
  // Handle errors and loading state
  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Economic Events</CardTitle>
          <CardDescription>Error loading economic events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 text-center">
            <div className="text-red-500 mb-4">Failed to load economic events: {error.message}</div>
            <button 
              className="px-4 py-2 bg-primary text-white rounded"
              onClick={() => refresh()}
            >
              Retry
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Economic Events</CardTitle>
            <CardDescription>Real-time economic indicators and events</CardDescription>
          </div>
          <ConnectionStatusIndicator status={connectionStatus} />
        </div>
      </CardHeader>
      
      <CardContent>
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div>
            <label className="text-sm font-medium">Category</label>
            <Select value={category} onValueChange={(value) => setCategory(value as EventCategory)}>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium">Country</label>
            <Select value={country} onValueChange={setCountry}>
              <SelectTrigger>
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                {COUNTRIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium">Start Date</label>
            <DatePicker
              selected={startDate}
              onSelect={setStartDate}
              mode="single"
              disabled={(date) => endDate ? date > endDate : false}
            />
          </div>
          
          <div>
            <label className="text-sm font-medium">End Date</label>
            <DatePicker
              selected={endDate}
              onSelect={setEndDate}
              mode="single"
              disabled={(date) => startDate ? date < startDate : false}
            />
          </div>
        </div>
        
        {/* Last updated text */}
        {lastUpdateTime > 0 && (
          <div className="text-xs text-muted-foreground mb-4">
            Last updated: {format(new Date(lastUpdateTime), 'PPpp')}
            <button 
              className="ml-2 text-primary underline"
              onClick={() => refresh()}
            >
              Refresh
            </button>
          </div>
        )}
        
        {/* Content tabs */}
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Events</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="high-impact">High Impact</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            {isLoading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : filteredEvents.length > 0 ? (
              <div className="space-y-4">
                {filteredEvents.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground">
                No economic events found matching your filters
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="upcoming">
            {isLoading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <div className="space-y-4">
                {getUpcomingEvents(5).map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
                
                {getUpcomingEvents(5).length === 0 && (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No upcoming economic events found
                  </div>
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="high-impact">
            {isLoading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <div className="space-y-4">
                {getHighImpactEvents().map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
                
                {getHighImpactEvents().length === 0 && (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No high impact economic events found
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default EconomicEventsExample;