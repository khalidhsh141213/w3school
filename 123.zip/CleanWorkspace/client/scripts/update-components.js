/**
 * Component Update Script
 * 
 * This script helps update components to use shared types and the WebSocket Manager.
 * It scans components and identifies candidates for updates.
 * 
 * Run with: node scripts/update-components.js
 */

const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const readFileAsync = promisify(fs.readFile);
const writeFileAsync = promisify(fs.writeFile);
const readdirAsync = promisify(fs.readdir);
const statAsync = promisify(fs.stat);

// Patterns to identify
const PATTERNS = {
  directWebSocket: /new WebSocket\(/g,
  customInterfaces: /interface\s+(\w+)\s*{/g,
  customTypes: /type\s+(\w+)\s*=/g,
  webSocketEventListener: /useEffect\(\s*\(\s*\)\s*=>\s*{[^}]*addEventListener\(['"](message|open|close|error)['"][^}]*}\s*,\s*\[[^\]]*\]\s*\)/g,
  hardcodedImports: /import\s+{\s*([^}]+)\s*}\s+from\s+(['"])([^'"]+)\2/g
};

// Shared type mapping (keep this updated with types in client/src/types/index.ts)
const SHARED_TYPES = [
  'User', 'UserRole', 'UserSettings', 'TradingPreferences',
  'Asset', 'AssetType', 'TradingHours', 'MarketData',
  'Portfolio', 'Position', 'PortfolioPerformance', 'Order',
  'OrderType', 'OrderStatus', 'ChartData', 'ChartOptions',
  'ChartInterval', 'ChartIndicator', 'ApiResponse', 'ApiError',
  'PaginatedResponse', 'WebSocketEvent', 'WebSocketEventType',
  'Notification', 'NotificationType', 'PortfolioSummaryProps',
  'OrderPlacementProps', 'OrderValidation', 'Size', 'Variant'
];

// Helper to check if a file should be processed
const shouldProcessFile = (filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  return ['.jsx', '.tsx'].includes(ext) &&
         !filePath.includes('node_modules') &&
         !filePath.includes('/dist/') &&
         !filePath.includes('/build/') &&
         !filePath.includes('/scripts/') &&
         !filePath.includes('/WebSocketManager.ts');
};

// Recursively get all component files
async function getAllComponentFiles(dir, fileList = []) {
  try {
    const files = await readdirAsync(dir);
    
    for (const file of files) {
      const filePath = path.join(dir, file);
      const stats = await statAsync(filePath);
      
      if (stats.isDirectory()) {
        fileList = await getAllComponentFiles(filePath, fileList);
      } else if (shouldProcessFile(filePath)) {
        fileList.push(filePath);
      }
    }
  } catch (error) {
    console.error(`Error reading directory ${dir}:`, error.message);
  }
  
  return fileList;
}

// Analyze a component file
async function analyzeComponent(filePath) {
  try {
    const content = await readFileAsync(filePath, 'utf8');
    
    const analysis = {
      filePath,
      fileName: path.basename(filePath),
      directWebSocket: (content.match(PATTERNS.directWebSocket) || []).length,
      customInterfaces: [],
      customTypes: [],
      webSocketEventListeners: (content.match(PATTERNS.webSocketEventListener) || []).length,
      potentialSharedTypeUsage: 0,
      recommendedChanges: []
    };
    
    // Find custom interfaces
    let match;
    while ((match = PATTERNS.customInterfaces.exec(content)) !== null) {
      const interfaceName = match[1];
      analysis.customInterfaces.push(interfaceName);
      
      // Check if interface could be replaced with a shared type
      if (SHARED_TYPES.some(type => 
          type === interfaceName || 
          type === interfaceName.replace('Props', '') ||
          type === interfaceName.replace('Interface', '') ||
          type === interfaceName.replace('Type', '')
      )) {
        analysis.potentialSharedTypeUsage++;
        analysis.recommendedChanges.push(`Interface ${interfaceName} could be replaced with shared type`);
      }
    }
    
    // Find custom types
    PATTERNS.customTypes.lastIndex = 0; // Reset regex state
    while ((match = PATTERNS.customTypes.exec(content)) !== null) {
      const typeName = match[1];
      analysis.customTypes.push(typeName);
      
      // Check if type could be replaced with a shared type
      if (SHARED_TYPES.some(type => 
          type === typeName || 
          type === typeName.replace('Props', '') ||
          type === typeName.replace('Type', '')
      )) {
        analysis.potentialSharedTypeUsage++;
        analysis.recommendedChanges.push(`Type ${typeName} could be replaced with shared type`);
      }
    }
    
    // Check for direct WebSocket usage
    if (analysis.directWebSocket > 0) {
      analysis.recommendedChanges.push('Component uses direct WebSocket connections, should be updated to use the WebSocket Manager');
    }
    
    // Check for WebSocket event listeners
    if (analysis.webSocketEventListeners > 0) {
      analysis.recommendedChanges.push('Component has WebSocket event listeners that should be replaced with the useWebSocket hook subscribe method');
    }
    
    return analysis;
  } catch (error) {
    console.error(`Error analyzing component ${filePath}:`, error.message);
    return {
      filePath,
      fileName: path.basename(filePath),
      error: error.message
    };
  }
}

// Generate a summary of all components with recommendations
async function analyzeComponents() {
  console.log('🔍 Scanning for components to update...');
  
  try {
    const sourceDir = path.resolve(__dirname, '../src');
    const componentFiles = await getAllComponentFiles(sourceDir);
    
    console.log(`Found ${componentFiles.length} component files for analysis.`);
    
    const analysisPromises = componentFiles.map(analyzeComponent);
    const analysisResults = await Promise.all(analysisPromises);
    
    // Filter results to only include components that need changes
    const componentsToUpdate = analysisResults.filter(result => 
      result.directWebSocket > 0 || 
      result.webSocketEventListeners > 0 || 
      result.potentialSharedTypeUsage > 0
    );
    
    console.log('\n📊 Analysis Results:');
    console.log(`${componentsToUpdate.length} components need updates.\n`);
    
    // Print detailed analysis
    componentsToUpdate.forEach((component, index) => {
      console.log(`${index + 1}. ${path.relative(sourceDir, component.filePath)}`);
      
      if (component.directWebSocket > 0) {
        console.log(`   - Found ${component.directWebSocket} direct WebSocket connections`);
      }
      
      if (component.webSocketEventListeners > 0) {
        console.log(`   - Found ${component.webSocketEventListeners} WebSocket event listeners`);
      }
      
      if (component.potentialSharedTypeUsage > 0) {
        console.log(`   - Found ${component.potentialSharedTypeUsage} potential shared type replacements`);
        component.customInterfaces.forEach(iface => {
          if (SHARED_TYPES.some(t => t === iface || t === iface.replace('Props', '') || t === iface.replace('Interface', ''))) {
            console.log(`     - Interface: ${iface}`);
          }
        });
        
        component.customTypes.forEach(type => {
          if (SHARED_TYPES.some(t => t === type || t === type.replace('Type', ''))) {
            console.log(`     - Type: ${type}`);
          }
        });
      }
      
      console.log('   Recommended changes:');
      component.recommendedChanges.forEach(change => {
        console.log(`   - ${change}`);
      });
      
      console.log('');
    });
    
    // Generate implementation plan
    console.log('\n📋 Implementation Plan:');
    console.log('1. Start by updating components with direct WebSocket connections:');
    const wsComponents = componentsToUpdate.filter(c => c.directWebSocket > 0);
    wsComponents.forEach((c, i) => {
      console.log(`   ${i+1}. ${path.relative(sourceDir, c.filePath)}`);
    });
    
    console.log('\n2. Then update components with shared type opportunities:');
    const typeComponents = componentsToUpdate.filter(c => 
      c.directWebSocket === 0 && c.potentialSharedTypeUsage > 0
    );
    typeComponents.forEach((c, i) => {
      console.log(`   ${i+1}. ${path.relative(sourceDir, c.filePath)}`);
    });
    
    console.log('\n💡 Tip: Start with the most critical components first.');
    console.log('   Use the WebSocket usage guide (WEBSOCKET_USAGE.md) as a reference.');
    
    return {
      total: componentFiles.length,
      needUpdates: componentsToUpdate.length,
      webSocketUpdates: wsComponents.length,
      typeUpdates: typeComponents.length,
      components: componentsToUpdate
    };
  } catch (error) {
    console.error('Error analyzing components:', error.message);
    return null;
  }
}

// Example function to update a component (limited automated changes - most will be manual)
async function updateComponent(filePath) {
  try {
    let content = await readFileAsync(filePath, 'utf8');
    let modified = false;
    
    // Add WebSocket Manager import if the component uses WebSockets directly
    if (PATTERNS.directWebSocket.test(content) && !content.includes("import { useWebSocket }")) {
      // Add import for WebSocket Manager
      content = `import { useWebSocket } from '@/services/WebSocketManager';\n${content}`;
      modified = true;
    }
    
    // Add types import if the component has potential shared type usage
    const hasCustomInterfaces = PATTERNS.customInterfaces.test(content);
    const hasCustomTypes = PATTERNS.customTypes.test(content);
    
    if ((hasCustomInterfaces || hasCustomTypes) && !content.includes("import { ") && !content.includes("from '@/types'")) {
      // Add placeholder import, developer will need to fill in specific types
      content = `import { /* TODO: Import specific types */ } from '@/types';\n${content}`;
      modified = true;
    }
    
    if (modified) {
      await writeFileAsync(filePath, content, 'utf8');
      console.log(`✅ Added initial imports to ${filePath}`);
      return true;
    }
    
    console.log(`⚠️ No automated changes made to ${filePath} - manual updates required`);
    return false;
  } catch (error) {
    console.error(`❌ Error updating component ${filePath}:`, error.message);
    return false;
  }
}

// Main function
async function main() {
  const analysis = await analyzeComponents();
  
  if (!analysis) {
    process.exit(1);
  }
  
  console.log('\n⚠️ This script identifies components that need updates but most changes must be done manually.');
  console.log('❓ Would you like to add initial import statements to components that need updates? (y/n)');
  
  // This would be interactive in a real script, but for simplicity let's just log instructions
  console.log('\n📝 Instructions for manual updates:');
  console.log('1. Replace direct WebSocket connections with the useWebSocket hook:');
  console.log('   - Remove: const ws = new WebSocket(url);');
  console.log('   - Add: const { subscribe, send, status } = useWebSocket(url);');
  
  console.log('\n2. Replace WebSocket event listeners:');
  console.log('   - Remove: ws.onmessage = event => { ... }');
  console.log('   - Add: subscribe(data => { ... })');
  
  console.log('\n3. Replace custom interfaces and types with shared ones:');
  console.log('   - Remove: interface UserProps { ... }');
  console.log('   - Add import: import { User } from \'@/types\';');
  
  console.log('\nRefer to the WEBSOCKET_USAGE.md and MIGRATION_GUIDE.md for detailed guidance.');
}

// Run the script
main(); 