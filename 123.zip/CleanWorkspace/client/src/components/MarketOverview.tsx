import { useEffect, useState } from 'react';
import { useTranslation } from '../lib/useTranslation';

interface MarketIndex {
  symbol: string;
  name: string;
  price: string;
  change: string;
  changePercent: string;
}

interface MarketOverviewProps {
  marketData: Record<string, any>;
}

const MarketOverview = ({ marketData }: MarketOverviewProps) => {
  const { t } = useTranslation();
  const [indices, setIndices] = useState<MarketIndex[]>([]);

  // Extract market indices from the market data
  useEffect(() => {
    if (Object.keys(marketData).length > 0) {
      const marketIndices = ['SPX', 'NDX', 'DJI']
        .map(symbol => {
          const data = marketData[symbol];
          if (!data) return null;
          
          return {
            symbol,
            name: getIndexName(symbol),
            price: parseFloat(data.price).toFixed(2),
            change: parseFloat(data.change).toFixed(2),
            changePercent: parseFloat(data.changePercent).toFixed(2)
          };
        })
        .filter(Boolean) as MarketIndex[];
      
      setIndices(marketIndices);
    }
  }, [marketData]);

  // Helper function to get display name for market index
  const getIndexName = (symbol: string): string => {
    switch (symbol) {
      case 'SPX': return 'S&P 500';
      case 'NDX': return 'NASDAQ';
      case 'DJI': return 'DOW';
      default: return symbol;
    }
  };

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <h2 className="text-lg font-condensed font-bold mb-3">{t('marketOverview')}</h2>
      <div className="space-y-3">
        {indices.length > 0 ? (
          indices.map((index) => (
            <div className="flex justify-between items-center" key={index.symbol}>
              <span>{index.name}</span>
              <div>
                <span className="font-semibold">{index.price}</span>
                <span 
                  className={`ml-2 ${parseFloat(index.changePercent) >= 0 ? 'text-secondary-light' : 'text-accent-light'}`}
                >
                  {parseFloat(index.changePercent) >= 0 ? '+' : ''}{index.changePercent}%
                </span>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-2 text-neutral">Loading market indices...</div>
        )}
      </div>
    </div>
  );
};

export default MarketOverview;
