import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';
import { useQuery } from '@tanstack/react-query';
import {
    AlertCircle,
    ArrowUpDown,
    BarChart4,
    ChevronDown,
    DollarSign,
    Heart,
    Loader2,
    Search
} from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'wouter';

// Define TypeScript interfaces
interface Asset {
  id: string;
  symbol: string;
  name: string;
  type: string;
  marketCap?: number;
  sector?: string;
  industry?: string;
  country?: string;
  exchange?: string;
  logo?: string;
}

interface AssetPrice {
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  timestamp: string;
}

interface WebSocketMessage {
  type: string;
  symbol: string;
  price: number;
  change?: number;
  changePercent?: number;
}

// Sort directions
type SortDirection = 'asc' | 'desc';

// Sort fields
type SortField = 'symbol' | 'name' | 'price' | 'changePercent' | 'marketCap' | 'sector';

export default function AssetsPage() {
  // State for search, filter, and sort
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortField, setSortField] = useState<SortField>('marketCap');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [assetSymbols, setAssetSymbols] = useState<string[]>([]);
  const [priceMap, setPriceMap] = useState<Record<string, AssetPrice>>({});
  const [favorites, setFavorites] = useState<string[]>([]);
  
  // Use dynamic WebSocket URL based on current window location
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = process.env.REACT_APP_WS_URL || `${protocol}//${host}/ws`;
  
  // Use WebSocketManager hook
  const { status: wsStatus, send, subscribe } = useWebSocket(wsUrl, {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });
  
  // Fetch all assets
  const { 
    data: assets, 
    isLoading: loadingAssets, 
    error: assetsError 
  } = useQuery<Asset[]>({
    queryKey: ['assets'],
    queryFn: async () => {
      const res = await fetch('/api/assets');
      if (!res.ok) throw new Error('Failed to fetch assets');
      return res.json();
    },
  });
  
  // Fetch user favorites
  const { 
    data: userFavorites, 
    isLoading: loadingFavorites,
    error: favoritesError
  } = useQuery<string[]>({
    queryKey: ['favorites'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/user/favorites');
        if (!res.ok) return []; // Not fatal, return empty array
        return res.json();
      } catch (error) {
        console.error('Error fetching favorites:', error);
        return [];
      }
    },
  });
  
  // Set favorites from API response
  useEffect(() => {
    if (userFavorites) {
      setFavorites(userFavorites);
    }
  }, [userFavorites]);
  
  // Extract symbols from assets for WebSocket subscription
  useEffect(() => {
    if (assets) {
      const symbols = assets.map(asset => asset.symbol);
      setAssetSymbols(symbols);
    }
  }, [assets]);
  
  // Subscribe to WebSocket updates for asset symbols
  useEffect(() => {
    if (assetSymbols.length === 0 || wsStatus !== ConnectionStatus.CONNECTED) return;
    
    // Set up message handler
    subscribe((data) => {
      try {
        console.log('WebSocket message received in assets:', data);
        
        // Handle different message types
        if (data.type === 'price' || data.type === 'priceUpdate') {
          if (data.symbol && assetSymbols.includes(data.symbol)) {
            setPriceMap(prev => ({
              ...prev,
              [data.symbol]: {
                price: data.price,
                change: data.change || 0,
                changePercent: data.changePercent || 0,
                volume: prev[data.symbol]?.volume || 0,
                timestamp: new Date().toISOString()
              }
            }));
          }
        } else if (data.type === 'assetList' && Array.isArray(data.data)) {
          // Handle asset list updates
          console.log('Received asset list update with', data.data.length, 'assets');
          
          // Process each asset in the list
          data.data.forEach(asset => {
            if (asset.symbol && assetSymbols.includes(asset.symbol)) {
              setPriceMap(prev => ({
                ...prev,
                [asset.symbol]: {
                  price: asset.price || asset.currentPrice,
                  change: asset.change || 0,
                  changePercent: asset.changePercent || 0,
                  volume: prev[asset.symbol]?.volume || 0,
                  timestamp: new Date().toISOString()
                }
              }));
            }
          });
        }
      } catch (error) {
        console.error('Error handling WebSocket message in assets:', error);
      }
    });
    
    // Subscribe to all asset symbols
    send({
      action: 'subscribe',
      symbols: assetSymbols
    });
    console.log(`Subscribed to ${assetSymbols.length} symbols in assets page`);
    
  }, [assetSymbols, wsStatus, subscribe, send]);
  
  // Toggle asset as favorite
  const toggleFavorite = async (symbol: string) => {
    try {
      const isFavorite = favorites.includes(symbol);
      const method = isFavorite ? 'DELETE' : 'POST';
      
      const res = await fetch(`/api/user/favorites/${symbol}`, { method });
      
      if (res.ok) {
        if (isFavorite) {
          setFavorites(favorites.filter(fav => fav !== symbol));
        } else {
          setFavorites([...favorites, symbol]);
        }
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };
  
  // Handle sort column click
  const handleSort = (field: SortField) => {
    if (field === sortField) {
      // Toggle direction if same field
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // Set new field and default to descending for most cases
      setSortField(field);
      setSortDirection(field === 'symbol' || field === 'name' ? 'asc' : 'desc');
    }
  };
  
  // Apply filtering logic
  const filteredAssets = assets
    ? assets.filter(asset => {
        // Filter by search term
        const matchesSearch = 
          asset.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
          asset.name.toLowerCase().includes(searchTerm.toLowerCase());
        
        // Filter by category (asset type)
        const matchesCategory = 
          activeCategory === 'all' || 
          asset.type === activeCategory ||
          (activeCategory === 'favorites' && favorites.includes(asset.symbol));
        
        return matchesSearch && matchesCategory;
      })
    : [];
  
  // Apply sorting logic
  const sortedAssets = [...filteredAssets].sort((a, b) => {
    let comparison = 0;
    
    switch (sortField) {
      case 'symbol':
        comparison = a.symbol.localeCompare(b.symbol);
        break;
      case 'name':
        comparison = a.name.localeCompare(b.name);
        break;
      case 'price':
        // Use priceMap for current prices
        const priceA = priceMap[a.symbol]?.price || 0;
        const priceB = priceMap[b.symbol]?.price || 0;
        comparison = priceA - priceB;
        break;
      case 'changePercent':
        // Use priceMap for change percentages
        const changeA = priceMap[a.symbol]?.changePercent || 0;
        const changeB = priceMap[b.symbol]?.changePercent || 0;
        comparison = changeA - changeB;
        break;
      case 'marketCap':
        comparison = (a.marketCap || 0) - (b.marketCap || 0);
        break;
      case 'sector':
        comparison = (a.sector || '').localeCompare(b.sector || '');
        break;
      default:
        comparison = 0;
    }
    
    // Apply sort direction
    return sortDirection === 'asc' ? comparison : -comparison;
  });
  
  // Error banner
  const hasError = assetsError || wsStatus === ConnectionStatus.ERROR;
  const errorMessage = 
    assetsError instanceof Error ? assetsError.message : 
    wsStatus === ConnectionStatus.ERROR ? 'Error connecting to real-time price feed' : 
    'An error occurred while loading asset data';
  
  // Format price with proper decimals
  const formatPrice = (price: number | undefined) => {
    if (price === undefined) return '-';
    return price < 1 ? price.toFixed(4) : price.toFixed(2);
  };
  
  // Format number with commas
  const formatNumber = (num: number | undefined) => {
    if (num === undefined) return '-';
    return num.toLocaleString();
  };
  
  // Format percent change
  const formatPercent = (percent: number | undefined) => {
    if (percent === undefined) return '-';
    return percent > 0 
      ? `+${percent.toFixed(2)}%` 
      : `${percent.toFixed(2)}%`;
  };
  
  // Get CSS class for change percent
  const getChangeClass = (change: number | undefined) => {
    if (change === undefined) return '';
    return change > 0 ? 'text-green-600' : change < 0 ? 'text-red-600' : '';
  };
  
  // Get display name for asset categories
  const getCategoryDisplayName = (category: string) => {
    switch (category) {
      case 'stock':
        return 'Stocks';
      case 'etf':
        return 'ETFs';
      case 'crypto':
        return 'Crypto';
      case 'forex':
        return 'Forex';
      case 'commodity':
        return 'Commodities';
      case 'favorites':
        return 'Favorites';
      case 'all':
      default:
        return 'All Assets';
    }
  };
  
  // Loading state
  if (loadingAssets) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Assets</h1>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2">Loading assets...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-textDark mb-6">Assets</h1>
      
      {/* Error Alert */}
      {hasError && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {errorMessage}
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2"
              onClick={() => window.location.reload()}
            >
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}
      
      {/* WebSocket Status Indicator */}
      {wsStatus !== ConnectionStatus.CONNECTED && !hasError && (
        <Alert className="mb-6 border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-600">
            {wsStatus === ConnectionStatus.CONNECTING 
              ? 'Connecting to real-time data feed...'
              : 'Real-time price updates unavailable. Using last known prices.'}
          </AlertDescription>
        </Alert>
      )}
      
      <div className="grid gap-6">
        {/* Search and Filter Bar */}
        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex flex-col space-y-3 md:flex-row md:space-y-0 md:space-x-4 items-start">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search assets by name or symbol"
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex space-x-2 w-full md:w-auto">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="flex-shrink-0">
                      <BarChart4 className="h-4 w-4 mr-2" />
                      <span>Sort</span>
                      <ChevronDown className="h-4 w-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleSort('symbol')}>
                      Symbol {sortField === 'symbol' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('name')}>
                      Name {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('price')}>
                      Price {sortField === 'price' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('changePercent')}>
                      Change % {sortField === 'changePercent' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('marketCap')}>
                      Market Cap {sortField === 'marketCap' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('sector')}>
                      Sector {sortField === 'sector' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <Button
                  variant={activeCategory === 'favorites' ? 'default' : 'outline'}
                  onClick={() => setActiveCategory(prev => prev === 'favorites' ? 'all' : 'favorites')}
                  className="flex-shrink-0"
                >
                  <Heart className="h-4 w-4 mr-2" />
                  <span>Favorites</span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Asset Categories */}
        <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
          <TabsList className="grid grid-cols-3 md:grid-cols-7 mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="stock">Stocks</TabsTrigger>
            <TabsTrigger value="etf">ETFs</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
            <TabsTrigger value="forex">Forex</TabsTrigger>
            <TabsTrigger value="commodity">Commodities</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>
          
          {/* Tab content for each category */}
          <TabsContent value={activeCategory} forceMount>
            <Card className="shadow-md">
              <CardHeader className="pb-2">
                <CardTitle>{getCategoryDisplayName(activeCategory)}</CardTitle>
              </CardHeader>
              
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[60px]"></TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort('symbol')}>
                        <div className="flex items-center">
                          Symbol
                          {sortField === 'symbol' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort('name')}>
                        <div className="flex items-center">
                          Name
                          {sortField === 'name' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="text-right cursor-pointer" onClick={() => handleSort('price')}>
                        <div className="flex items-center justify-end">
                          Price
                          {sortField === 'price' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="text-right cursor-pointer" onClick={() => handleSort('changePercent')}>
                        <div className="flex items-center justify-end">
                          Change %
                          {sortField === 'changePercent' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="text-right cursor-pointer hidden md:table-cell" onClick={() => handleSort('marketCap')}>
                        <div className="flex items-center justify-end">
                          Market Cap
                          {sortField === 'marketCap' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="hidden lg:table-cell cursor-pointer" onClick={() => handleSort('sector')}>
                        <div className="flex items-center">
                          Sector
                          {sortField === 'sector' && (
                            <ArrowUpDown className={`ml-2 h-3 w-3 ${sortDirection === 'asc' ? 'rotate-180' : ''}`} />
                          )}
                        </div>
                      </TableHead>
                      <TableHead className="w-[80px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  
                  <TableBody>
                    {sortedAssets.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No assets found matching your criteria
                        </TableCell>
                      </TableRow>
                    ) : (
                      sortedAssets.map((asset) => (
                        <TableRow key={asset.id}>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => toggleFavorite(asset.symbol)}
                              className="h-8 w-8"
                            >
                              <Heart 
                                className={`h-4 w-4 ${favorites.includes(asset.symbol) ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
                              />
                            </Button>
                          </TableCell>
                          <TableCell className="font-medium">{asset.symbol}</TableCell>
                          <TableCell>{asset.name}</TableCell>
                          <TableCell className="text-right font-medium">
                            ${formatPrice(priceMap[asset.symbol]?.price)}
                          </TableCell>
                          <TableCell className={`text-right ${getChangeClass(priceMap[asset.symbol]?.changePercent)}`}>
                            {formatPercent(priceMap[asset.symbol]?.changePercent)}
                          </TableCell>
                          <TableCell className="text-right hidden md:table-cell">
                            {asset.marketCap ? `$${formatNumber(asset.marketCap / 1000000)}M` : '-'}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {asset.sector ? (
                              <Badge variant="outline">{asset.sector}</Badge>
                            ) : (
                              '-'
                            )}
                          </TableCell>
                          <TableCell>
                            <Link to={`/trade/${asset.symbol}`}>
                              <Button size="sm">
                                <DollarSign className="h-4 w-4 mr-1" />
                                Trade
                              </Button>
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
} 