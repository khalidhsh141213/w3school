import { ReactNode, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/lib/authContext';
import { Loader2, ShieldAlert } from "lucide-react";
import { useToast } from '@/hooks/use-toast';

interface AdminProtectedRouteProps {
  children: ReactNode;
}

export default function AdminProtectedRoute({ children }: AdminProtectedRouteProps) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // If authentication check is complete
    if (!isLoading) {
      // If user is not authenticated, redirect to auth page
      if (!isAuthenticated) {
        navigate('/auth');
      } 
      // If user is authenticated but not an admin, redirect to dashboard
      else if (user && user.userRole !== 'admin') {
        toast({
          title: "غير مصرح به",
          description: "ليس لديك صلاحيات للوصول إلى لوحة تحكم المشرف.",
          variant: "destructive"
        });
        navigate('/dashboard');
      }
    }
  }, [isLoading, isAuthenticated, user, navigate, toast]);

  // Show loading screen while checking authentication status
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-lg text-muted-foreground">جاري تحميل لوحة المشرف...</p>
        </div>
      </div>
    );
  }

  // If not authenticated or not admin, don't render anything
  if (!isAuthenticated || (user && user.userRole !== 'admin')) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center space-y-4 text-center">
          <ShieldAlert className="h-16 w-16 text-destructive" />
          <h1 className="text-2xl font-bold">غير مصرح به</h1>
          <p className="text-lg text-muted-foreground max-w-md">
            ليس لديك صلاحيات الوصول إلى هذه الصفحة. هذه المنطقة مخصصة فقط للمشرفين.
          </p>
        </div>
      </div>
    );
  }

  // If authenticated and admin, render the children components
  return <>{children}</>;
} 