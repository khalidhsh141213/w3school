#!/usr/bin/env node

/**
 * Codebase Refactoring Script
 * 
 * This script orchestrates the entire codebase refactoring process by running
 * all automation scripts in the correct sequence.
 * 
 * Usage:
 *   node scripts/refactor-codebase.js
 * 
 * Options:
 *   --dry-run      Run without making changes (prints what would be changed)
 *   --components   Run only component-related transformations
 *   --validation   Run only validation-related transformations
 *   --imports      Run only import-related transformations
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const scripts = [
  {
    name: 'Identifying duplicate components',
    file: 'find-duplicates.js',
    category: 'components',
    description: 'Finds potentially duplicate components in the codebase'
  },
  {
    name: 'Identifying WebSocket usage',
    file: 'identify-websocket-usage.js',
    category: 'components', 
    description: 'Finds components using WebSockets that need to be updated'
  },
  {
    name: 'Identifying type issues',
    file: 'identify-type-issues.js',
    category: 'components',
    description: 'Finds components that need type improvements'
  },
  {
    name: 'Updating import references',
    file: 'update-imports.js',
    category: 'imports',
    description: 'Updates import paths to use consolidated components'
  },
  {
    name: 'Adding validation to API calls',
    file: 'add-validation.js',
    category: 'validation',
    description: 'Adds validation to components using the API client'
  }
];

// Parse command line arguments
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');
const onlyComponents = args.includes('--components');
const onlyValidation = args.includes('--validation');
const onlyImports = args.includes('--imports');

// Filter scripts based on command-line flags
let scriptsToRun = [...scripts];
if (onlyComponents) {
  scriptsToRun = scriptsToRun.filter(script => script.category === 'components');
} else if (onlyValidation) {
  scriptsToRun = scriptsToRun.filter(script => script.category === 'validation');
} else if (onlyImports) {
  scriptsToRun = scriptsToRun.filter(script => script.category === 'imports');
}

// Function to execute a script
function executeScript(scriptPath, scriptName) {
  return new Promise((resolve, reject) => {
    console.log(`\n\n${'-'.repeat(80)}`);
    console.log(`Running: ${scriptName}`);
    console.log(`${'-'.repeat(80)}\n`);
    
    const args = isDryRun ? ['--dry-run'] : [];
    const childProcess = spawn('node', [scriptPath, ...args], { stdio: 'inherit' });
    
    childProcess.on('close', (code) => {
      if (code === 0) {
        console.log(`\n✅ Completed: ${scriptName}`);
        resolve();
      } else {
        console.error(`\n❌ Failed: ${scriptName} with code ${code}`);
        reject(new Error(`Script ${scriptName} failed with code ${code}`));
      }
    });
    
    childProcess.on('error', (error) => {
      console.error(`\n❌ Error executing ${scriptName}: ${error.message}`);
      reject(error);
    });
  });
}

// Create a backup directory
async function createBackup() {
  const backupDir = path.resolve(__dirname, '../backup-' + new Date().toISOString().replace(/:/g, '-'));
  if (!isDryRun) {
    console.log(`\nCreating backup at: ${backupDir}`);
    fs.mkdirSync(backupDir, { recursive: true });
    
    // Copy source directory
    const srcDir = path.resolve(__dirname, '../src');
    fs.cpSync(srcDir, path.join(backupDir, 'src'), { recursive: true });
    
    console.log('✅ Backup created successfully');
  } else {
    console.log('\n[DRY RUN] Would create backup at:', backupDir);
  }
  return backupDir;
}

// Main function
async function main() {
  try {
    console.log('\nTrading App Codebase Refactoring');
    console.log('================================\n');
    
    if (isDryRun) {
      console.log('Running in DRY RUN mode (no changes will be made)\n');
    }
    
    // Print the list of scripts that will be run
    console.log('The following scripts will be executed:');
    scriptsToRun.forEach((script, index) => {
      console.log(`${index + 1}. ${script.name} - ${script.description}`);
    });
    
    // Create backup
    const backupDir = await createBackup();
    
    // Run each script sequentially
    for (const script of scriptsToRun) {
      const scriptPath = path.resolve(__dirname, script.file);
      
      // Check if script exists
      if (fs.existsSync(scriptPath)) {
        await executeScript(scriptPath, script.name);
      } else {
        console.warn(`⚠️ Script not found: ${scriptPath}`);
      }
    }
    
    console.log('\n\n' + '='.repeat(80));
    console.log('Refactoring completed successfully!');
    console.log('='.repeat(80));
    console.log(`\nA backup of the original codebase was created at: ${backupDir}`);
    console.log('\nNext steps:');
    console.log('1. Review the changes made to the codebase');
    console.log('2. Run tests to ensure everything works correctly');
    console.log('3. Fix any issues that may have been introduced');
    console.log('4. Remove the backup directory once satisfied with the changes');
    
  } catch (error) {
    console.error('\n\n' + '='.repeat(80));
    console.error('❌ Refactoring process failed!');
    console.error('='.repeat(80));
    console.error(`\nError: ${error.message}`);
    console.error('\nPlease fix the issues and try again.');
    process.exit(1);
  }
}

// Run the script
main(); 