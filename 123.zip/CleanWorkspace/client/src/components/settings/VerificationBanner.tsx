import React from 'react';
import { Button } from '@/components/ui/button';
import { Shield, ChevronRight } from 'lucide-react';

interface VerificationBannerProps {
  verificationLevel: number;
}

export default function VerificationBanner({ verificationLevel }: VerificationBannerProps) {
  // Maximum verification level is 3
  const maxLevel = 3;
  
  // Calculate progress percentage
  const progressPercentage = (verificationLevel / maxLevel) * 100;
  
  // Get verification message based on current level
  const getVerificationMessage = () => {
    switch (verificationLevel) {
      case 1:
        return 'Verify your identity to unlock higher deposit and withdrawal limits';
      case 2:
        return 'One more step to unlock all platform features';
      case 3:
        return 'Your account is fully verified. Enjoy all platform features!';
      default:
        return 'Start verification to unlock platform features';
    }
  };
  
  return (
    <div className="bg-gradient-to-r from-blue-500 to-primary rounded-lg p-4 text-white shadow-md">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="flex items-start space-x-3">
          <div className="bg-white bg-opacity-20 p-2 rounded-full">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-medium">Verification Level {verificationLevel} of {maxLevel}</h3>
            <p className="text-sm text-blue-100 mt-1">{getVerificationMessage()}</p>
            
            {/* Progress bar */}
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2 w-full max-w-xs">
              <div 
                className="bg-white rounded-full h-2" 
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>
        </div>
        
        {verificationLevel < maxLevel && (
          <Button 
            variant="secondary" 
            className="mt-4 md:mt-0 bg-white text-primary hover:bg-blue-50"
          >
            Continue Verification
            <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}