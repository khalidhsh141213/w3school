import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowRight, ArrowUp, ArrowDown, AlertCircle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Asset } from '@shared/schema';
import useWebSocketManager from '@/hooks/useWebSocketManager';
import { ConnectionStatus } from '@/services/WebSocketManager';

// FeaturedCard Component with proper TypeScript typing
interface FeaturedCardProps {
  title: string;
  subtitle: string;
  value: number | null | undefined;
  change: number | null | undefined;
  changePercent: number | null | undefined;
  imageUrl?: string;
}

const FeaturedCard = ({ 
  title, 
  subtitle, 
  value, 
  change, 
  changePercent, 
  imageUrl = 'https://via.placeholder.com/64'
}: FeaturedCardProps) => {
  // Add safety checks for undefined or null values
  const safeValue = typeof value === 'number' ? value : 0;
  const safeChange = typeof change === 'number' ? change : 0;
  const safeChangePercent = typeof changePercent === 'number' ? changePercent : 0;
  
  const isPositive = safeChangePercent >= 0;
  
  return (
    <Card className="w-full shadow-md hover:shadow-lg transition-shadow duration-200">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-lg">{title}</h3>
            <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
            
            <div className="mt-6">
              <div className="text-2xl font-bold">${safeValue.toLocaleString()}</div>
              
              <div className="flex items-center mt-2">
                <span className={`inline-flex items-center ${isPositive ? 'text-primary' : 'text-alertRed'}`}>
                  {isPositive ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
                  {Math.abs(safeChangePercent).toFixed(2)}%
                </span>
                <span className="text-gray-500 text-sm ml-2">
                  ${Math.abs(safeChange).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
          
          <div className="h-16 w-16 rounded-md overflow-hidden">
            <img src={imageUrl} alt={title || 'Stock image'} className="h-full w-full object-cover" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function DiscoverPage() {
  const [marketTab, setMarketTab] = useState('all');
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [realTimeData, setRealTimeData] = useState<Record<string, any>>({});
  
  // Use the WebSocketManager hook for WebSocket connection
  const { status, subscribe, send, isConnected } = useWebSocketManager();
  
  // Subscribe to WebSocket messages
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      console.log('WebSocket connected, subscribing to market data');
      // Clear any previous connection errors
      setConnectionError(null);
      
      // Subscribe to top assets
      send('subscribe', {
        symbols: ['BTC', 'ETH', 'AAPL', 'TSLA', 'MSFT']
      });
    } else if (status === ConnectionStatus.ERROR) {
      setConnectionError('Error connecting to real-time data service.');
    } else {
      // No CIRCUIT_OPEN in the current enum, use appropriate status check
      console.log('Current WebSocket status:', status);
    }
  }, [status, send]);
  
  // Set up message subscription
  useEffect(() => {
    // Subscribe to WebSocket messages and handle them
    const unsubscribe = subscribe('message', (data) => {
      try {
        console.log('Received WebSocket message:', data);
        if (data.type === 'priceUpdate') {
          setRealTimeData(prev => ({
            ...prev,
            [data.symbol]: data
          }));
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    // Return cleanup function
    return unsubscribe;
  }, [subscribe]);
  
  // Fetch featured investments
  const { data: featuredInvestments, isLoading: loadingFeatured, error: featuredError } = useQuery<Asset[]>({
    queryKey: ['/api/assets/featured'],
    queryFn: async () => {
      const res = await fetch('/api/assets/featured');
      if (!res.ok) throw new Error('Failed to fetch featured investments');
      return res.json();
    }
  });
  
  // Fetch daily movers
  const { data: dailyMovers, isLoading: loadingMovers, error: moversError } = useQuery<Asset[]>({
    queryKey: ['/api/assets/movers'],
    queryFn: async () => {
      const res = await fetch('/api/assets/movers');
      if (!res.ok) throw new Error('Failed to fetch market movers');
      return res.json();
    }
  });
  
  // Function to filter daily movers based on selected category
  const filterMovers = (movers: Asset[] | undefined, category: string): Asset[] => {
    if (!movers) return [];
    
    switch (category) {
      case 'gainers':
        return movers.filter(stock => 
          typeof stock.priceChangePercentage === 'number' && stock.priceChangePercentage > 0
        );
      case 'losers':
        return movers.filter(stock => 
          typeof stock.priceChangePercentage === 'number' && stock.priceChangePercentage < 0
        );
      default:
        return movers;
    }
  };
  
  // Get real-time price for an asset if available, otherwise use stored price
  const getAssetPrice = (asset: Asset): number => {
    if (realTimeData[asset.symbol]?.price) {
      return realTimeData[asset.symbol].price;
    }
    return parseFloat(asset.lastPrice?.toString() || '0');
  };
  
  // Get real-time price change for an asset if available
  const getAssetPriceChange = (asset: Asset): number => {
    if (realTimeData[asset.symbol]?.change) {
      return realTimeData[asset.symbol].change;
    }
    return parseFloat(asset.priceChange?.toString() || '0');
  };
  
  // Get real-time price change percent for an asset if available
  const getAssetPriceChangePercent = (asset: Asset): number => {
    if (realTimeData[asset.symbol]?.changePercent) {
      return realTimeData[asset.symbol].changePercent;
    }
    return parseFloat(asset.priceChangePercentage?.toString() || '0');
  };
  
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-textDark mb-6">Discover</h1>
      
      {connectionError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {connectionError} Using cached data instead.
          </AlertDescription>
        </Alert>
      )}
      
      {(featuredError || moversError) && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Error loading market data. Please try again later.
          </AlertDescription>
        </Alert>
      )}
      
      {/* Featured Investment Section */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Explore Global Markets</h2>
          <Button variant="ghost" className="text-primary">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
        
        {loadingFeatured ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <Card key={i} className="w-full h-[200px] animate-pulse">
                <CardContent className="p-6">
                  <div className="bg-gray-200 h-6 w-1/2 rounded mb-2"></div>
                  <div className="bg-gray-200 h-4 w-3/4 rounded mb-6"></div>
                  <div className="bg-gray-200 h-8 w-1/3 rounded mb-2"></div>
                  <div className="bg-gray-200 h-4 w-1/4 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredInvestments?.map((item) => (
              <FeaturedCard
                key={item.id}
                title={item.symbol}
                subtitle={item.name}
                value={getAssetPrice(item)}
                change={getAssetPriceChange(item)}
                changePercent={getAssetPriceChangePercent(item)}
                imageUrl={item.logoUrl || `https://picsum.photos/seed/${item.symbol}/200/200`}
              />
            ))}
          </div>
        )}
      </section>
      
      {/* Daily Movers Section */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Daily Movers</h2>
          {status === ConnectionStatus.CONNECTED && (
            <div className="text-xs text-primary flex items-center">
              <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
              Real-time data active
            </div>
          )}
        </div>
        
        <Card className="shadow-md">
          <CardContent className="p-4">
            <Tabs defaultValue="all" onValueChange={setMarketTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="gainers">Gainers</TabsTrigger>
                <TabsTrigger value="losers">Losers</TabsTrigger>
              </TabsList>
              
              <TabsContent value={marketTab} className="mt-0">
                {loadingMovers ? (
                  <div className="text-center py-8">Loading market movers...</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[80px]">Symbol</TableHead>
                          <TableHead>Company</TableHead>
                          <TableHead className="text-right">Price</TableHead>
                          <TableHead className="text-right">Change</TableHead>
                          <TableHead className="text-right">% Change</TableHead>
                          <TableHead className="text-center w-[100px]">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filterMovers(dailyMovers, marketTab)?.slice(0, 5).map((stock) => (
                          <TableRow key={stock.id}>
                            <TableCell className="font-medium">{stock.symbol}</TableCell>
                            <TableCell>{stock.name}</TableCell>
                            <TableCell className="text-right">${getAssetPrice(stock).toFixed(2)}</TableCell>
                            <TableCell className="text-right">
                              <span className={getAssetPriceChange(stock) >= 0 ? 'text-primary' : 'text-alertRed'}>
                                {getAssetPriceChange(stock) >= 0 ? '+' : ''}
                                {getAssetPriceChange(stock).toFixed(2)}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end">
                                {getAssetPriceChangePercent(stock) >= 0 ? (
                                  <ArrowUp className="h-4 w-4 text-primary mr-1" />
                                ) : (
                                  <ArrowDown className="h-4 w-4 text-alertRed mr-1" />
                                )}
                                <span className={getAssetPriceChangePercent(stock) >= 0 ? 'text-primary' : 'text-alertRed'}>
                                  {Math.abs(getAssetPriceChangePercent(stock)).toFixed(2)}%
                                </span>
                              </div>
                            </TableCell>
                            <TableCell className="text-center">
                              <Button variant="outline" size="sm">
                                Buy
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}