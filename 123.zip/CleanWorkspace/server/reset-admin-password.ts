import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import { db } from './db.js';
import { user } from '../shared/schema.js';
import { eq } from 'drizzle-orm';

const scryptAsync = promisify(scrypt);

/**
 * هذه الأداة تعيد تعيين كلمة مرور المستخدم المسؤول
 * وتضمن استخدام نفس طريقة التشفير المستخدمة في ملف auth.ts
 */

async function hashPassword(password: string) {
  // استخدام نفس طريقة التجزئة المستخدمة في auth.ts
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  const hashedPassword = `${buf.toString("hex")}.${salt}`;
  console.log(`طول كلمة المرور المشفرة: ${hashedPassword.length}`);
  return hashedPassword;
}

async function resetAdminPassword() {
  console.log('إعادة تعيين كلمة مرور المستخدم المسؤول...');
  
  try {
    // التحقق من وجود المستخدم المسؤول
    const targetUsername = 'admintest';
    const adminUser = await db.select().from(user).where(eq(user.username, targetUsername)).limit(1);
    
    if (adminUser.length === 0) {
      console.log(`المستخدم ${targetUsername} غير موجود`);
      return;
    }
    
    // إنشاء كلمة مرور جديدة مشفرة
    const plainPassword = '12345678';
    const hashedPassword = await hashPassword(plainPassword);
    
    // تحديث كلمة المرور
    await db.update(user)
      .set({ password: hashedPassword })
      .where(eq(user.id, adminUser[0].id));
    
    console.log(`تم تحديث كلمة مرور المستخدم ${targetUsername} (ID: ${adminUser[0].id}) بنجاح`);
    console.log(`كلمة المرور الجديدة هي: ${plainPassword}`);
    
  } catch (error) {
    console.error('خطأ في إعادة تعيين كلمة المرور:', error);
  }
}

resetAdminPassword();