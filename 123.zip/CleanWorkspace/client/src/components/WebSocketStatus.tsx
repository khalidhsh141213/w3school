import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CircuitState } from "@/services/CircuitBreaker";
import { ConnectionStatus, useWebSocket } from "@/services/WebSocketManager";
import { AlertCircle, CheckCircle, RefreshCw, XCircle } from "lucide-react";
import { useEffect, useState } from "react";

interface WebSocketStatusProps {
  url: string;
  onReconnect?: () => void;
  className?: string;
  showDebugInfo?: boolean;
  pollingInterval?: number; // ms to poll for status updates
  showDetails?: boolean; // whether to show detailed status information
}

export default function WebSocketStatus({
  url,
  onReconnect,
  className = "",
  showDebugInfo = false,
  pollingInterval = 1000,
  showDetails = false,
}: WebSocketStatusProps) {
  const [lastActivity, setLastActivity] = useState<Date | null>(null);
  const [healthInfo, setHealthInfo] = useState<any>(null);
  const [expanded, setExpanded] = useState(false);

  // Use the WebSocket hook with the provided URL
  const {
    status,
    send,
    subscribe,
    getHealth,
  } = useWebSocket(url, {
    reconnectAttempts: 5,
    reconnectInterval: 5000,
    heartbeatInterval: 30000,
    circuitBreaker: {
      enabled: true,
      failureThreshold: 3,
      resetTimeout: 30000, // 30 seconds
    }
  });

  // Update the health information periodically
  useEffect(() => {
    const updateHealth = () => {
      const health = getHealth();
      setHealthInfo(health);
    };

    // Initial update
    updateHealth();

    // Set up interval
    const interval = setInterval(updateHealth, 5000);

    // Listen for messages to track activity
    subscribe(() => {
      setLastActivity(new Date());
    });

    return () => {
      clearInterval(interval);
    };
  }, [getHealth, subscribe]);

  // Format the time since last activity
  const formatTimeSinceLastActivity = () => {
    if (!lastActivity) return "No activity yet";

    const seconds = Math.floor((new Date().getTime() - lastActivity.getTime()) / 1000);
    
    if (seconds < 60) return `${seconds} seconds ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
    return `${Math.floor(seconds / 3600)} hours ago`;
  };

  // Get status information
  const getStatusInfo = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return {
          color: "text-green-600",
          bgColor: "bg-green-100",
          icon: <CheckCircle className="h-5 w-5" />,
          text: "Connected",
        };
      case ConnectionStatus.CONNECTING:
        return {
          color: "text-amber-600",
          bgColor: "bg-amber-100",
          icon: <RefreshCw className="h-5 w-5 animate-spin" />,
          text: "Connecting...",
        };
      case ConnectionStatus.CIRCUIT_OPEN:
        return {
          color: "text-purple-600",
          bgColor: "bg-purple-100",
          icon: <AlertCircle className="h-5 w-5" />,
          text: "Circuit Open",
        };
      case ConnectionStatus.ERROR:
        return {
          color: "text-red-600",
          bgColor: "bg-red-100",
          icon: <XCircle className="h-5 w-5" />,
          text: "Error",
        };
      case ConnectionStatus.RATE_LIMITED:
        return {
          color: "text-orange-600",
          bgColor: "bg-orange-100",
          icon: <AlertCircle className="h-5 w-5" />,
          text: "Rate Limited",
        };
      default:
        return {
          color: "text-red-600",
          bgColor: "bg-red-100",
          icon: <XCircle className="h-5 w-5" />,
          text: "Disconnected",
        };
    }
  };

  const statusInfo = getStatusInfo();

  // Handle reconnect button click
  const handleReconnect = () => {
    // Try to reconnect
    send({ type: "ping" });
    
    // Call the onReconnect callback if provided
    if (onReconnect) {
      onReconnect();
    }
  };

  // Get circuit breaker state display
  const getCircuitBreakerDisplay = () => {
    if (!healthInfo || !healthInfo.circuitBreakerInfo) {
      return null;
    }
    
    const circuitInfo = healthInfo.circuitBreakerInfo;
    const stateColors = {
      [CircuitState.CLOSED]: "text-green-600",
      [CircuitState.HALF_OPEN]: "text-orange-600",
      [CircuitState.OPEN]: "text-red-600",
    };
    
    const stateLabels = {
      [CircuitState.CLOSED]: "Closed (Healthy)",
      [CircuitState.HALF_OPEN]: "Half-Open (Testing)",
      [CircuitState.OPEN]: "Open (Disabled)",
    };
    
    return (
      <div>
        <span style={{ color: stateColors[circuitInfo.state] }}>
          Circuit: {stateLabels[circuitInfo.state]}
        </span>
        {showDetails && (
          <div style={{ fontSize: '0.8em', marginLeft: '10px' }}>
            <div>Failures: {circuitInfo.failureCount}</div>
            {circuitInfo.state === CircuitState.OPEN && (
              <div>Reset in: {Math.ceil(circuitInfo.timeUntilReset / 1000)}s</div>
            )}
          </div>
        )}
      </div>
    );
  };
  
  // Update the getRateLimiterDisplay function to show priority queue information
  const getRateLimiterDisplay = () => {
    if (!healthInfo || !healthInfo.rateLimiterInfo) {
      return null;
    }
    
    const rateLimiterInfo = healthInfo.rateLimiterInfo;
    const isLimited = rateLimiterInfo.isRateLimited;
    
    return (
      <div>
        <span style={{ color: isLimited ? "text-orange-600" : "text-green-600" }}>
          Rate: {isLimited ? "Limited" : "Normal"}
        </span>
        {showDetails && (
          <div className="text-sm mt-1 space-y-1">
            <div>{rateLimiterInfo.remainingOperations}/{rateLimiterInfo.maxOperations} remaining</div>
            <div>Queue: {rateLimiterInfo.queueLength}/{rateLimiterInfo.maxQueueSize}</div>
            
            {rateLimiterInfo.priorityBasedQueue && rateLimiterInfo.queuedItemsByPriority && (
              <div>
                <div className="font-semibold">Queued by priority:</div>
                <div className="grid grid-cols-2 gap-x-2 pl-2">
                  <div>Critical: {rateLimiterInfo.queuedItemsByPriority[3] || 0}</div>
                  <div>High: {rateLimiterInfo.queuedItemsByPriority[2] || 0}</div>
                  <div>Normal: {rateLimiterInfo.queuedItemsByPriority[1] || 0}</div>
                  <div>Low: {rateLimiterInfo.queuedItemsByPriority[0] || 0}</div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };
  
  // Determine if we need to show a warning about slow message processing
  const getPerformanceWarning = () => {
    if (!healthInfo || !healthInfo.queueStats) {
      return null;
    }
    
    const queueSize = healthInfo.queueStats.size;
    let warningLevel = "none";
    
    if (queueSize > 1000) {
      warningLevel = "high";
    } else if (queueSize > 500) {
      warningLevel = "medium";
    } else if (queueSize > 100) {
      warningLevel = "low";
    }
    
    if (warningLevel === "none") {
      return null;
    }
    
    const warningColors = {
      low: "text-orange-600",
      medium: "text-darkorange",
      high: "text-red-600",
    };
    
    return (
      <div style={{ color: warningColors[warningLevel] }}>
        Message backlog: {queueSize} messages
      </div>
    );
  };

  // Render the component
  return (
    <div className={className}>
      {status === ConnectionStatus.ERROR || status === ConnectionStatus.DISCONNECTED || status === ConnectionStatus.CIRCUIT_OPEN ? (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Connection Problem</AlertTitle>
          <AlertDescription className="flex items-center justify-between">
            <span>
              {status === ConnectionStatus.CIRCUIT_OPEN 
                ? "Connection is temporarily disabled due to repeated failures." 
                : "WebSocket connection is unavailable. Data may be delayed."}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleReconnect}
              disabled={status === ConnectionStatus.CIRCUIT_OPEN && healthInfo?.circuitBreakerInfo?.timeUntilReset > 0}
            >
              <RefreshCw className="h-3 w-3 mr-2" />
              {status === ConnectionStatus.CIRCUIT_OPEN && healthInfo?.circuitBreakerInfo?.timeUntilReset > 0
                ? `Available in ${Math.ceil(healthInfo.circuitBreakerInfo.timeUntilReset / 1000)}s`
                : "Reconnect"
              }
            </Button>
          </AlertDescription>
        </Alert>
      ) : null}

      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">WebSocket Status</CardTitle>
            <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${statusInfo.bgColor} ${statusInfo.color}`}>
              {statusInfo.icon}
              <span className="ml-2">{statusInfo.text}</span>
            </div>
          </div>
          <CardDescription>
            Connection to {url.replace(/^wss?:\/\//, '')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Last Activity:</span>
              <span className="font-medium">{formatTimeSinceLastActivity()}</span>
            </div>
            
            {healthInfo?.circuitBreakerInfo && (
              <>
                <div className="flex justify-between text-sm">
                  <span>Circuit State:</span>
                  <span className="font-medium">
                    {healthInfo.circuitBreakerInfo.state === CircuitState.CLOSED && "Closed (Healthy)"}
                    {healthInfo.circuitBreakerInfo.state === CircuitState.OPEN && "Open (Disabled)"}
                    {healthInfo.circuitBreakerInfo.state === CircuitState.HALF_OPEN && "Half-Open (Testing)"}
                  </span>
                </div>
                
                {healthInfo.circuitBreakerInfo.state === CircuitState.OPEN && healthInfo.circuitBreakerInfo.timeUntilReset > 0 && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Reset in:</span>
                      <span className="font-medium">
                        {Math.ceil(healthInfo.circuitBreakerInfo.timeUntilReset / 1000)}s
                      </span>
                    </div>
                    <Progress value={100 - (healthInfo.circuitBreakerInfo.timeUntilReset / 300) * 100} />
                  </div>
                )}
                
                <div className="flex justify-between text-sm">
                  <span>Failure Count:</span>
                  <span className="font-medium">{healthInfo.circuitBreakerInfo.failureCount}</span>
                </div>
              </>
            )}
          </div>
          
          {showDebugInfo && expanded && healthInfo && (
            <div className="mt-4 p-3 bg-gray-100 rounded text-xs font-mono">
              <pre>{JSON.stringify(healthInfo, null, 2)}</pre>
            </div>
          )}
        </CardContent>
        
        {showDebugInfo && (
          <CardFooter className="pt-0">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs w-full"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? "Hide" : "Show"} Debug Info
            </Button>
          </CardFooter>
        )}
      </Card>

      {healthInfo && (
        <div style={{ fontSize: '0.9em', marginTop: '10px' }}>
          {getCircuitBreakerDisplay()}
          {getRateLimiterDisplay()}
          {getPerformanceWarning()}
          
          {showDetails && (
            <div style={{ fontSize: '0.8em', marginTop: '5px' }}>
              <div>Last message: {Math.floor(healthInfo.lastMessageReceivedTime / 1000)}s ago</div>
              <div>Reconnect attempts: {healthInfo.reconnectAttempts}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
} 