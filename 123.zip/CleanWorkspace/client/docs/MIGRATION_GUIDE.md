
# Migration Guide

## WebSocket Updates
1. Replace direct WebSocket usage with the WebSocket manager
2. Update event listeners to use subscription pattern
3. Use shared types for message handling

## Type System Updates
1. Replace local interfaces with shared types
2. Add validation to API responses
3. Update components to use type-safe props

## Component Updates
Follow the component update checklist in `COMPLETION_CHECKLIST.md`.
