import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { CalendarDays } from 'lucide-react';
import useEconomicEvents from '../../hooks/useEconomicEvents';
import { format } from 'date-fns';
import { Link } from 'wouter';

// Impact level badge component
const ImpactBadge = ({ impact }: { impact: 'low' | 'medium' | 'high' }) => {
  const colors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800'
  };
  
  return (
    <Badge className={colors[impact]}>
      {impact.charAt(0).toUpperCase() + impact.slice(1)}
    </Badge>
  );
};

interface EconomicEventsWidgetProps {
  limit?: number;
  showHighImpactOnly?: boolean;
}

export function EconomicEventsWidget({ 
  limit = 5, 
  showHighImpactOnly = true 
}: EconomicEventsWidgetProps) {
  const {
    events,
    isLoading,
    error,
    getUpcomingEvents,
    filterByCategory
  } = useEconomicEvents({
    categories: showHighImpactOnly ? ['high_impact'] : ['all'],
    pollingInterval: 300000, // 5 minutes
    throttleUpdates: 2000,
    limit: limit * 2, // Fetch more to allow for filtering
  });
  
  // Get events to display based on props
  const eventsToDisplay = showHighImpactOnly 
    ? getUpcomingEvents(limit).filter(event => event.impact === 'high')
    : getUpcomingEvents(limit);
  
  // If no events and not loading, show empty state
  if (eventsToDisplay.length === 0 && !isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center">
            <CalendarDays className="h-4 w-4 mr-2" />
            Economic Events
          </CardTitle>
          <CardDescription>
            Upcoming market-moving events
          </CardDescription>
        </CardHeader>
        <CardContent className="py-8">
          <div className="text-center text-muted-foreground text-sm">
            {error
              ? "Unable to load economic events at this time."
              : "No upcoming economic events found."
            }
          </div>
        </CardContent>
        <CardFooter>
          <Link href="/economic-calendar">
            <Button variant="outline" className="w-full">
              View Economic Calendar
            </Button>
          </Link>
        </CardFooter>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center">
          <CalendarDays className="h-4 w-4 mr-2" />
          Economic Events
        </CardTitle>
        <CardDescription>
          Upcoming market-moving events
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        {isLoading ? (
          <div className="h-40 flex items-center justify-center">
            <div className="animate-spin h-5 w-5 border-2 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : (
          eventsToDisplay.map((event) => (
            <div key={event.id} className="border-b border-border pb-2 mb-2 last:border-0 last:pb-0 last:mb-0">
              <div className="flex justify-between items-start mb-1">
                <div className="font-medium text-sm">
                  {event.title}
                </div>
                <ImpactBadge impact={event.impact} />
              </div>
              <div className="text-xs text-muted-foreground flex justify-between">
                <div>
                  {event.country} | {format(new Date(event.date), 'MMM d')}
                  {event.time && ` at ${event.time}`}
                </div>
                {event.forecast && (
                  <div>
                    Est: {event.forecast}{event.unit ? ` ${event.unit}` : ''}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </CardContent>
      <CardFooter>
        <Link href="/economic-calendar">
          <Button variant="outline" className="w-full">
            View Economic Calendar
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

export default EconomicEventsWidget;