# WebSocket Implementation for Financial Trading Platform

## Overview

This documentation provides a comprehensive guide to the WebSocket implementation in our financial trading platform. Our solution delivers real-time market data with different update strategies based on asset types and market hours.

## Key Features

- **Dual Update Strategy**: WebSocket for real-time assets (crypto, forex), REST API for less frequent updates (stocks, indices)
- **Market Hours Awareness**: Automatically adjusts updates based on market hours (e.g., no forex updates on Sunday)
- **Intelligent Reconnection**: Circuit breaker pattern prevents excessive reconnection attempts
- **Adaptive Rate Limiting**: Controls message flow to avoid overwhelming the server or client
- **Volatility-Based Updates**: More frequent updates for volatile assets

## Documentation

### For Developers
- [WebSocket Best Practices (English)](./client/docs/WEBSOCKET_BEST_PRACTICES_EN.md)
- [WebSocket Implementation Details (English)](./client/docs/WEBSOCKET_IMPLEMENTATION_EN.md)

### للمطورين العرب
- [أفضل ممارسات WebSocket](./client/docs/WEBSOCKET_BEST_PRACTICES.md)
- [تفاصيل تنفيذ WebSocket](./client/docs/WEBSOCKET_IMPLEMENTATION.md)

## Implementation Structure

### Server-Side Components
- `server/services/marketData.ts`: Central WebSocket server implementation
- `scripts/market-update.js`: Market data update script with asset-specific logic

### Client-Side Components
- `client/src/services/WebSocketManager.ts`: Client WebSocket manager (singleton pattern)
- `client/src/hooks/useWebSocket.ts`: React hook for WebSocket integration

## Testing Tools

- `test-websocket-connection.js`: Test WebSocket connection and subscription

## Usage Examples

### Subscribe to Symbols (Client)
```javascript
// Connect to WebSocket
const { status, send, subscribe } = useWebSocket('/api/market-data');

// Once connected, subscribe to symbols
if (status === ConnectionStatus.CONNECTED) {
  send({
    type: 'subscribe',
    symbols: ['BTC/USD', 'ETH/USD', 'EUR/USD']
  });
}
```

### Subscribe by Asset Type (Client)
```javascript
// Subscribe to all crypto assets
send({
  type: 'subscribe',
  assetTypes: ['crypto']
});
```

### Handling Updates (Client)
```javascript
// Subscribe to price updates
subscribe((message) => {
  if (message.type === 'priceUpdate' && message.data) {
    const { symbol, price, changePercent } = message.data;
    console.log(`${symbol}: $${price} (${changePercent}%)`);
    // Update UI with new price...
  }
});
```

## Update Schedule

| Asset Type | Update Method | When Markets Open | When Markets Closed |
|------------|---------------|-------------------|---------------------|
| Cryptocurrency | WebSocket | Every 5 seconds | Every 5 seconds (24/7) |
| Forex | WebSocket | Every 5 seconds | No updates (Sunday) |
| Stocks | REST API | Every 5 minutes | No updates (weekends) |
| Indices | REST API | Every 5 minutes | No updates (weekends) |

## Market Hours Logic

The system automatically detects market hours and adjusts update behavior:

```javascript
function areMarketsOpen(assetType) {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 is Sunday
  
  // Crypto markets always open
  if (assetType === 'crypto') {
    return true;
  }
  
  // Forex closed on Sunday
  if (assetType === 'forex') {
    return dayOfWeek !== 0;
  }
  
  // Stock & index markets closed on weekends
  if (assetType === 'stock' || assetType === 'index') {
    return dayOfWeek !== 0 && dayOfWeek !== 6;
  }
  
  return dayOfWeek !== 0; // Default
}
```

## Future Improvements

1. **Advanced Caching**: Implement more sophisticated caching strategies
2. **Compression**: Add WebSocket data compression to reduce bandwidth
3. **Market Holidays**: Account for official market holidays in addition to weekends
4. **Adaptive Intervals**: Dynamically adjust update frequency based on market volatility

## Running Tests

```bash
# Test WebSocket connection
node test-websocket-connection.js
```