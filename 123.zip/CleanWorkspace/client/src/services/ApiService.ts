/**
 * API Service
 * 
 * A service that defines API endpoints and methods for the application.
 */

import { z } from 'zod';
import { getAuthHeaders } from '../config/api';
import * as schemas from '../types/schemas';
import { getApiClient, RequestOptions } from './ApiClient';

// Base API endpoints
const ENDPOINTS = {
  // Authentication
  AUTH: {
    LOGIN: '/auth/login',
    SIGNUP: '/auth/signup',
    LOGOUT: '/auth/logout',
    REFRESH: '/auth/refresh',
    ME: '/auth/me',
  },
  
  // Assets
  ASSETS: {
    BASE: '/assets',
    DETAIL: (symbol: string) => `/assets/${symbol}`,
    SEARCH: '/assets/search',
    TRENDING: '/assets/trending',
  },
  
  // Market Data
  MARKET_DATA: {
    QUOTES: '/market-data/quotes',
    QUOTE: (symbol: string) => `/market-data/quotes/${symbol}`,
    CANDLES: '/market-data/candles',
    NEWS: '/market-data/news',
  },
  
  // Trading
  TRADING: {
    ORDERS: '/trading/orders',
    ORDER: (id: string) => `/trading/orders/${id}`,
    POSITIONS: '/trading/positions',
    POSITION: (symbol: string) => `/trading/positions/${symbol}`,
    TRANSACTIONS: '/trading/transactions',
  },
  
  // User
  USER: {
    PROFILE: '/user/profile',
    SETTINGS: '/user/settings',
    PREFERENCES: '/user/preferences',
  },
  
  // Portfolio
  PORTFOLIO: {
    SUMMARY: '/portfolio/summary',
    PERFORMANCE: '/portfolio/performance',
    HISTORY: '/portfolio/history',
    ALLOCATION: '/portfolio/allocation',
  },
  
  // Watchlist
  WATCHLIST: {
    LISTS: '/watchlists',
    LIST: (id: string) => `/watchlists/${id}`,
  },
};

/**
 * Get authenticated request options
 * @param options Additional request options
 * @returns Request options with authentication headers
 */
function getAuthOptions(options: RequestOptions = {}): RequestOptions {
  return {
    ...options,
    headers: {
      ...options.headers,
      ...getAuthHeaders(),
    },
  };
}

/**
 * API Authentication Service
 */
export const AuthApi = {
  /**
   * Log in a user
   * @param email User email
   * @param password User password
   * @param options Request options
   * @returns Authentication response
   */
  login: async (
    email: string,
    password: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.AuthResponse>(
      ENDPOINTS.AUTH.LOGIN,
      { email, password },
      {
        ...options,
        validation: {
          schema: schemas.authResponseValidator,
        },
      }
    );
  },
  
  /**
   * Sign up a new user
   * @param userData User registration data
   * @param options Request options
   * @returns Authentication response
   */
  signup: async (
    userData: schemas.UserRegistration,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.AuthResponse>(
      ENDPOINTS.AUTH.SIGNUP,
      userData,
      {
        ...options,
        validation: {
          schema: schemas.authResponseValidator,
        },
      }
    );
  },
  
  /**
   * Log out the current user
   * @param options Request options
   * @returns Success response
   */
  logout: async (options: RequestOptions = {}) => {
    return getApiClient().post<{ success: boolean }>(
      ENDPOINTS.AUTH.LOGOUT,
      undefined,
      getAuthOptions(options)
    );
  },
  
  /**
   * Refresh authentication token
   * @param refreshToken Refresh token
   * @param options Request options
   * @returns Authentication response
   */
  refresh: async (
    refreshToken: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.AuthResponse>(
      ENDPOINTS.AUTH.REFRESH,
      { refreshToken },
      {
        ...options,
        validation: {
          schema: schemas.authResponseValidator,
        },
      }
    );
  },
  
  /**
   * Get current user information
   * @param options Request options
   * @returns User data
   */
  me: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.User>(
      ENDPOINTS.AUTH.ME,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userValidator,
        },
      }
    );
  },
};

/**
 * API Assets Service
 */
export const AssetsApi = {
  /**
   * Get a list of assets
   * @param options Request options
   * @returns List of assets
   */
  getAll: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Asset[]>(
      ENDPOINTS.ASSETS.BASE,
      {
        ...options,
        validation: {
          schema: z.array(schemas.assetValidator),
        },
      }
    );
  },
  
  /**
   * Get a specific asset by symbol
   * @param symbol Asset symbol
   * @param options Request options
   * @returns Asset data
   */
  getBySymbol: async (
    symbol: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Asset>(
      ENDPOINTS.ASSETS.DETAIL(symbol),
      {
        ...options,
        validation: {
          schema: schemas.assetValidator,
        },
      }
    );
  },
  
  /**
   * Search for assets
   * @param query Search query
   * @param options Request options
   * @returns List of assets matching the query
   */
  search: async (
    query: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Asset[]>(
      ENDPOINTS.ASSETS.SEARCH,
      {
        ...options,
        headers: {
          ...options.headers,
          'X-Search-Query': query,
        },
        validation: {
          schema: z.array(schemas.assetValidator),
        },
      }
    );
  },
  
  /**
   * Get trending assets
   * @param options Request options
   * @returns List of trending assets
   */
  getTrending: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Asset[]>(
      ENDPOINTS.ASSETS.TRENDING,
      {
        ...options,
        validation: {
          schema: z.array(schemas.assetValidator),
        },
      }
    );
  },
};

/**
 * API Market Data Service
 */
export const MarketDataApi = {
  /**
   * Get quotes for multiple symbols
   * @param symbols List of asset symbols
   * @param options Request options
   * @returns Market data quotes
   */
  getQuotes: async (
    symbols: string[],
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.MarketData[]>(
      `${ENDPOINTS.MARKET_DATA.QUOTES}?symbols=${symbols.join(',')}`,
      {
        ...options,
        validation: {
          schema: z.array(schemas.marketDataValidator),
        },
      }
    );
  },
  
  /**
   * Get a single quote by symbol
   * @param symbol Asset symbol
   * @param options Request options
   * @returns Market data quote
   */
  getQuote: async (
    symbol: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.MarketData>(
      ENDPOINTS.MARKET_DATA.QUOTE(symbol),
      {
        ...options,
        validation: {
          schema: schemas.marketDataValidator,
        },
      }
    );
  },
  
  /**
   * Get candle data for a symbol
   * @param symbol Asset symbol
   * @param interval Candle interval (e.g., '1m', '5m', '1h', '1d')
   * @param from Start timestamp
   * @param to End timestamp
   * @param options Request options
   * @returns Candle data
   */
  getCandles: async (
    symbol: string,
    interval: string,
    from: number,
    to: number,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Candle[]>(
      `${ENDPOINTS.MARKET_DATA.CANDLES}?symbol=${symbol}&interval=${interval}&from=${from}&to=${to}`,
      {
        ...options,
        validation: {
          schema: z.array(schemas.candleValidator),
        },
      }
    );
  },
  
  /**
   * Get news for a symbol
   * @param symbol Asset symbol
   * @param limit Number of news items to return
   * @param options Request options
   * @returns News items
   */
  getNews: async (
    symbol: string,
    limit: number = 10,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.NewsItem[]>(
      `${ENDPOINTS.MARKET_DATA.NEWS}?symbol=${symbol}&limit=${limit}`,
      {
        ...options,
        validation: {
          schema: z.array(schemas.newsItemValidator),
        },
      }
    );
  },
};

/**
 * API Trading Service
 */
export const TradingApi = {
  /**
   * Get all orders
   * @param options Request options
   * @returns List of orders
   */
  getOrders: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Order[]>(
      ENDPOINTS.TRADING.ORDERS,
      {
        ...getAuthOptions(options),
        validation: {
          schema: z.array(schemas.orderValidator),
        },
      }
    );
  },
  
  /**
   * Create a new order
   * @param order Order data
   * @param options Request options
   * @returns Created order
   */
  createOrder: async (
    order: schemas.OrderInput,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.Order>(
      ENDPOINTS.TRADING.ORDERS,
      order,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.orderValidator,
        },
      }
    );
  },
  
  /**
   * Get an order by ID
   * @param id Order ID
   * @param options Request options
   * @returns Order data
   */
  getOrder: async (
    id: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Order>(
      ENDPOINTS.TRADING.ORDER(id),
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.orderValidator,
        },
      }
    );
  },
  
  /**
   * Cancel an order
   * @param id Order ID
   * @param options Request options
   * @returns Cancelled order
   */
  cancelOrder: async (
    id: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().delete<schemas.Order>(
      ENDPOINTS.TRADING.ORDER(id),
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.orderValidator,
        },
      }
    );
  },
  
  /**
   * Get all positions
   * @param options Request options
   * @returns List of positions
   */
  getPositions: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Position[]>(
      ENDPOINTS.TRADING.POSITIONS,
      {
        ...getAuthOptions(options),
        validation: {
          schema: z.array(schemas.positionValidator),
        },
      }
    );
  },
  
  /**
   * Get a position by symbol
   * @param symbol Asset symbol
   * @param options Request options
   * @returns Position data
   */
  getPosition: async (
    symbol: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Position>(
      ENDPOINTS.TRADING.POSITION(symbol),
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.positionValidator,
        },
      }
    );
  },
  
  /**
   * Get transaction history
   * @param limit Number of transactions to return
   * @param offset Offset for pagination
   * @param options Request options
   * @returns List of transactions
   */
  getTransactions: async (
    limit: number = 50,
    offset: number = 0,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Transaction[]>(
      `${ENDPOINTS.TRADING.TRANSACTIONS}?limit=${limit}&offset=${offset}`,
      {
        ...getAuthOptions(options),
        validation: {
          schema: z.array(schemas.transactionValidator),
        },
      }
    );
  },
};

/**
 * API User Service
 */
export const UserApi = {
  /**
   * Get user profile
   * @param options Request options
   * @returns User profile
   */
  getProfile: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.User>(
      ENDPOINTS.USER.PROFILE,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userValidator,
        },
      }
    );
  },
  
  /**
   * Update user profile
   * @param profile Profile data
   * @param options Request options
   * @returns Updated user profile
   */
  updateProfile: async (
    profile: Partial<schemas.User>,
    options: RequestOptions = {}
  ) => {
    return getApiClient().patch<schemas.User>(
      ENDPOINTS.USER.PROFILE,
      profile,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userValidator,
        },
      }
    );
  },
  
  /**
   * Get user settings
   * @param options Request options
   * @returns User settings
   */
  getSettings: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.UserSettings>(
      ENDPOINTS.USER.SETTINGS,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userSettingsValidator,
        },
      }
    );
  },
  
  /**
   * Update user settings
   * @param settings Settings data
   * @param options Request options
   * @returns Updated user settings
   */
  updateSettings: async (
    settings: Partial<schemas.UserSettings>,
    options: RequestOptions = {}
  ) => {
    return getApiClient().patch<schemas.UserSettings>(
      ENDPOINTS.USER.SETTINGS,
      settings,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userSettingsValidator,
        },
      }
    );
  },
  
  /**
   * Get user preferences
   * @param options Request options
   * @returns User preferences
   */
  getPreferences: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.UserPreferences>(
      ENDPOINTS.USER.PREFERENCES,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userPreferencesValidator,
        },
      }
    );
  },
  
  /**
   * Update user preferences
   * @param preferences Preferences data
   * @param options Request options
   * @returns Updated user preferences
   */
  updatePreferences: async (
    preferences: Partial<schemas.UserPreferences>,
    options: RequestOptions = {}
  ) => {
    return getApiClient().patch<schemas.UserPreferences>(
      ENDPOINTS.USER.PREFERENCES,
      preferences,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.userPreferencesValidator,
        },
      }
    );
  },
};

/**
 * API Portfolio Service
 */
export const PortfolioApi = {
  /**
   * Get portfolio summary
   * @param options Request options
   * @returns Portfolio summary
   */
  getSummary: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Portfolio>(
      ENDPOINTS.PORTFOLIO.SUMMARY,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.portfolioValidator,
        },
      }
    );
  },
  
  /**
   * Get portfolio performance
   * @param timeframe Timeframe (e.g., '1d', '1w', '1m', '3m', '1y', 'all')
   * @param options Request options
   * @returns Portfolio performance data
   */
  getPerformance: async (
    timeframe: string = '1m',
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.PortfolioPerformance>(
      `${ENDPOINTS.PORTFOLIO.PERFORMANCE}?timeframe=${timeframe}`,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.portfolioPerformanceValidator,
        },
      }
    );
  },
  
  /**
   * Get portfolio history
   * @param timeframe Timeframe (e.g., '1d', '1w', '1m', '3m', '1y', 'all')
   * @param interval Interval (e.g., '1m', '5m', '1h', '1d')
   * @param options Request options
   * @returns Portfolio history data
   */
  getHistory: async (
    timeframe: string = '1m',
    interval: string = '1d',
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.PortfolioHistoryPoint[]>(
      `${ENDPOINTS.PORTFOLIO.HISTORY}?timeframe=${timeframe}&interval=${interval}`,
      {
        ...getAuthOptions(options),
        validation: {
          schema: z.array(schemas.portfolioHistoryPointValidator),
        },
      }
    );
  },
  
  /**
   * Get portfolio allocation
   * @param options Request options
   * @returns Portfolio allocation data
   */
  getAllocation: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.PortfolioAllocation>(
      ENDPOINTS.PORTFOLIO.ALLOCATION,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.portfolioAllocationValidator,
        },
      }
    );
  },
};

/**
 * API Watchlist Service
 */
export const WatchlistApi = {
  /**
   * Get all watchlists
   * @param options Request options
   * @returns List of watchlists
   */
  getAll: async (options: RequestOptions = {}) => {
    return getApiClient().get<schemas.Watchlist[]>(
      ENDPOINTS.WATCHLIST.LISTS,
      {
        ...getAuthOptions(options),
        validation: {
          schema: z.array(schemas.watchlistValidator),
        },
      }
    );
  },
  
  /**
   * Get a watchlist by ID
   * @param id Watchlist ID
   * @param options Request options
   * @returns Watchlist data
   */
  getById: async (
    id: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().get<schemas.Watchlist>(
      ENDPOINTS.WATCHLIST.LIST(id),
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.watchlistValidator,
        },
      }
    );
  },
  
  /**
   * Create a new watchlist
   * @param watchlist Watchlist data
   * @param options Request options
   * @returns Created watchlist
   */
  create: async (
    watchlist: schemas.WatchlistInput,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.Watchlist>(
      ENDPOINTS.WATCHLIST.LISTS,
      watchlist,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.watchlistValidator,
        },
      }
    );
  },
  
  /**
   * Update a watchlist
   * @param id Watchlist ID
   * @param watchlist Watchlist data
   * @param options Request options
   * @returns Updated watchlist
   */
  update: async (
    id: string,
    watchlist: Partial<schemas.WatchlistInput>,
    options: RequestOptions = {}
  ) => {
    return getApiClient().patch<schemas.Watchlist>(
      ENDPOINTS.WATCHLIST.LIST(id),
      watchlist,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.watchlistValidator,
        },
      }
    );
  },
  
  /**
   * Delete a watchlist
   * @param id Watchlist ID
   * @param options Request options
   * @returns Success response
   */
  delete: async (
    id: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().delete<{ success: boolean }>(
      ENDPOINTS.WATCHLIST.LIST(id),
      getAuthOptions(options)
    );
  },
  
  /**
   * Add a symbol to a watchlist
   * @param id Watchlist ID
   * @param symbol Asset symbol
   * @param options Request options
   * @returns Updated watchlist
   */
  addSymbol: async (
    id: string,
    symbol: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().post<schemas.Watchlist>(
      `${ENDPOINTS.WATCHLIST.LIST(id)}/symbols`,
      { symbol },
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.watchlistValidator,
        },
      }
    );
  },
  
  /**
   * Remove a symbol from a watchlist
   * @param id Watchlist ID
   * @param symbol Asset symbol
   * @param options Request options
   * @returns Updated watchlist
   */
  removeSymbol: async (
    id: string,
    symbol: string,
    options: RequestOptions = {}
  ) => {
    return getApiClient().delete<schemas.Watchlist>(
      `${ENDPOINTS.WATCHLIST.LIST(id)}/symbols/${symbol}`,
      {
        ...getAuthOptions(options),
        validation: {
          schema: schemas.watchlistValidator,
        },
      }
    );
  },
}; 