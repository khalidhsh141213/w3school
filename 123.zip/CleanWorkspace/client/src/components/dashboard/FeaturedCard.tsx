import { Card, CardContent } from '@/components/ui/card';
import { ArrowUpRight, ArrowDownRight, TrendingUp, Info, ChevronDown, Clock, Landmark, Coins, DollarSign } from 'lucide-react';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useState, useEffect } from "react";
import { formatDistanceToNow } from "date-fns";

interface FeaturedCardProps {
  title: string;
  subtitle: string;
  value: number;
  change: number;
  changePercent: number;
  imageUrl: string;
  // New market data fields
  highPrice?: number | null;
  lowPrice?: number | null;
  closePrice?: number | null;
  volume?: number | null;
  marketCap?: number | null;
  priceChange24h?: number | null;
  volume24h?: number | null;
  high24h?: number | null;
  low24h?: number | null;
  lastUpdated?: string | null;
}

export default function FeaturedCard({
  title,
  subtitle,
  value,
  change,
  changePercent,
  imageUrl,
  highPrice,
  lowPrice,
  closePrice,
  volume,
  marketCap,
  priceChange24h,
  volume24h,
  high24h,
  low24h,
  lastUpdated
}: FeaturedCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  
  // Add default values and handle undefined/null
  const safeValue = typeof value === 'number' ? value : 0;
  const safeChange = typeof change === 'number' ? change : 0;
  const safeChangePercent = typeof changePercent === 'number' ? changePercent : 0;
  
  const isPositive = safeChangePercent >= 0;
  
  // Calculate percentage for the chart bar
  const chartPercentage = Math.min(Math.abs(safeChangePercent) * 2, 100);

  // Determine asset type icon based on symbol pattern
  useEffect(() => {
    // Reset image failed state if imageUrl changes
    setImageFailed(false);
  }, [imageUrl]);
  
  const getAssetTypeIcon = () => {
    if (subtitle.includes('USD') || subtitle.includes('EUR') || subtitle.includes('JPY')) {
      return <DollarSign className="h-5 w-5" />;
    } else if (subtitle.includes('BTC') || subtitle.includes('ETH') || subtitle.includes('USDT')) {
      return <Coins className="h-5 w-5" />;
    } else {
      return <Landmark className="h-5 w-5" />;
    }
  };

  // Format large numbers with appropriate suffixes
  const formatLargeNumber = (num?: number | null) => {
    if (num === undefined || num === null) return 'N/A';
    
    try {
      if (num >= 1_000_000_000) {
        return `$${(num / 1_000_000_000).toFixed(2)}B`;
      } else if (num >= 1_000_000) {
        return `$${(num / 1_000_000).toFixed(2)}M`;
      } else if (num >= 1_000) {
        return `$${(num / 1_000).toFixed(2)}K`;
      } else {
        return `$${num.toFixed(2)}`;
      }
    } catch (e) {
      console.error("Error formatting number:", num, e);
      return 'N/A';
    }
  };
  
  // Format price with safety check
  const formatPrice = (price?: number | null) => {
    if (price === undefined || price === null) return 'N/A';
    try {
      return `$${price.toFixed(2)}`;
    } catch (e) {
      console.error("Error formatting price:", price, e);
      return 'N/A';
    }
  };
  
  // Format date/time
  const formatLastUpdated = (dateString?: string | null) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      console.error("Error formatting date:", dateString, e);
      return 'N/A';
    }
  };
  
  return (
    <Collapsible 
      open={expanded} 
      onOpenChange={setExpanded}
      className="overflow-hidden group hover:shadow-md transition-all duration-300 cursor-pointer hover:border-primary/30 rounded-lg border border-border h-full"
    >
      <Card className="border-0 shadow-none bg-transparent">
        <CardContent className="p-0">
          <div className="relative">
            {/* Background gradient based on trend */}
            <div 
              className={`absolute h-1 top-0 left-0 right-0 ${
                isPositive ? 'bg-gradient-to-r from-primary/20 to-primary' : 'bg-gradient-to-r from-red-500/20 to-red-500'
              }`} 
            />
            
            {/* Card content */}
            <div className="p-5">
              <div className="flex items-start mb-4">
                <div className="flex-shrink-0 mr-4">
                  <div className="relative">
                    <div 
                      className={`w-14 h-14 rounded-lg ${
                        isPositive ? 'bg-primary/10' : 'bg-red-500/10'
                      } flex items-center justify-center overflow-hidden`}
                    >
                      {!imageFailed ? (
                        <img 
                          src={imageUrl} 
                          alt={title}
                          className="w-10 h-10 object-contain"
                          onError={() => setImageFailed(true)}
                        />
                      ) : (
                        <div className={`${isPositive ? 'text-primary' : 'text-red-500'}`}>
                          {getAssetTypeIcon()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-gray-800 truncate text-base tracking-tight">{title}</div>
                      <div className="text-sm text-gray-500 font-medium">{subtitle}</div>
                    </div>
                    
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-gray-100 rounded-full">
                            <Info className="h-4 w-4 text-gray-400" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>24hr price change</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex justify-between items-center mb-3">
                  <div className="font-bold text-gray-800 text-xl">
                    ${safeValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  
                  <div className={`flex items-center font-medium px-2.5 py-1.5 rounded-full text-sm ${
                    isPositive 
                      ? 'text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400' 
                      : 'text-red-600 bg-red-50 dark:bg-red-950 dark:text-red-400'
                  }`}>
                    {isPositive ? (
                      <ArrowUpRight className="h-3.5 w-3.5 mr-1.5" />
                    ) : (
                      <ArrowDownRight className="h-3.5 w-3.5 mr-1.5" />
                    )}
                    <span>{Math.abs(safeChangePercent).toFixed(2)}%</span>
                  </div>
                </div>
                
                {/* Price change visualization */}
                <div className="mt-3 h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${isPositive ? 'bg-primary' : 'bg-red-500'} transition-all duration-500 ease-out`}
                    style={{ width: `${chartPercentage}%` }}
                  />
                </div>
                
                <div className="mt-2.5 flex justify-between items-center text-xs text-gray-500">
                  <div>24h Change</div>
                  <div className={isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                    {isPositive ? '+' : ''}{safeChange.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                {/* Last updated indicator */}
                {lastUpdated && (
                  <div className="mt-3.5 flex items-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1.5" />
                    <span>Updated {formatLastUpdated(lastUpdated)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Collapsible trigger */}
      <CollapsibleTrigger className="w-full flex justify-center py-2 border-t border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors">
        <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`} />
      </CollapsibleTrigger>

      {/* Expanded details */}
      <CollapsibleContent>
        <div className="p-5 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800">
          <h4 className="text-sm font-semibold mb-4 text-gray-700 dark:text-gray-300">Market Data</h4>
          
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">Open</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatPrice(closePrice)}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">Market Cap</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatLargeNumber(marketCap)}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">24h High</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatPrice(high24h)}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">24h Low</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatPrice(low24h)}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">Volume</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatLargeNumber(volume)}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-gray-500 dark:text-gray-400 mb-1">24h Volume</span>
              <span className="font-medium text-gray-800 dark:text-gray-200">{formatLargeNumber(volume24h)}</span>
            </div>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
