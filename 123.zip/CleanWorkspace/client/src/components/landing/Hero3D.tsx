import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

// Sample stock data for visualization
const sampleStockData = [
  { open: 150, close: 154, high: 156, low: 149, volume: 1000000 },
  { open: 154, close: 158, high: 159, low: 153, volume: 1200000 },
  { open: 158, close: 155, high: 160, low: 154, volume: 900000 },
  { open: 155, close: 157, high: 158, low: 154, volume: 800000 },
  { open: 157, close: 161, high: 162, low: 156, volume: 1100000 },
  { open: 161, close: 159, high: 163, low: 158, volume: 950000 },
  { open: 159, close: 163, high: 164, low: 158, volume: 1050000 },
  { open: 163, close: 167, high: 168, low: 162, volume: 1300000 },
  { open: 167, close: 164, high: 169, low: 163, volume: 1000000 },
  { open: 164, close: 169, high: 170, low: 163, volume: 1150000 },
  { open: 169, close: 171, high: 173, low: 168, volume: 1250000 },
  { open: 171, close: 167, high: 172, low: 166, volume: 900000 },
  { open: 167, close: 162, high: 168, low: 161, volume: 850000 },
  { open: 162, close: 164, high: 166, low: 161, volume: 950000 },
  { open: 164, close: 168, high: 169, low: 163, volume: 1050000 },
  { open: 168, close: 172, high: 173, low: 167, volume: 1200000 },
  { open: 172, close: 176, high: 178, low: 171, volume: 1350000 },
  { open: 176, close: 178, high: 180, low: 175, volume: 1400000 },
  { open: 178, close: 174, high: 179, low: 173, volume: 1100000 },
  { open: 174, close: 177, high: 178, low: 173, volume: 1050000 },
  { open: 177, close: 182, high: 183, low: 176, volume: 1300000 },
  { open: 182, close: 185, high: 187, low: 181, volume: 1450000 },
  { open: 185, close: 183, high: 186, low: 182, volume: 1200000 },
  { open: 183, close: 187, high: 189, low: 182, volume: 1350000 },
  { open: 187, close: 190, high: 192, low: 186, volume: 1500000 },
];

// Define the cryptocurrency market data for the globe
const cryptoMarkets = [
  { name: 'BTC', long: 10, lat: 20, volume: 1.0, price: 84183.42 },
  { name: 'ETH', long: -80, lat: 35, volume: 0.8, price: 1982.67 },
  { name: 'BNB', long: 140, lat: 40, volume: 0.6, price: 582.34 },
  { name: 'SOL', long: -120, lat: -20, volume: 0.5, price: 156.78 },
  { name: 'ADA', long: 30, lat: -30, volume: 0.4, price: 0.45 },
  { name: 'XRP', long: -10, lat: 10, volume: 0.7, price: 0.84 },
  { name: 'DOT', long: 90, lat: 15, volume: 0.3, price: 7.23 },
  { name: 'DOGE', long: -40, lat: -15, volume: 0.5, price: 0.13 },
  { name: 'AVAX', long: 60, lat: -45, volume: 0.2, price: 34.12 },
  { name: 'LINK', long: 170, lat: 5, volume: 0.3, price: 17.89 },
];

// Types for the interactive elements
interface InteractiveElement {
  object: THREE.Object3D;
  update: (time: number, mousePosition: THREE.Vector2) => void;
}

export default function Hero3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2(0, 0));
  const interactiveElementsRef = useRef<InteractiveElement[]>([]);
  const timeRef = useRef<number>(0);
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize scene, camera, and renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0xf1f5f9, 0.01); // Ajustado para tema claro
    sceneRef.current = scene;

    // Create a perspective camera with better positioning
    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 15);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Create a high-quality renderer with post-processing support
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true,
      precision: 'highp',
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Mejor rendimiento
    renderer.setClearColor(0xf1f5f9, 0); // Ajustado para tema claro
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Advanced lighting setup - más intenso para el tema claro
    const hemisphereLight = new THREE.HemisphereLight(0xffffff, 0xd1d5e0, 0.8);
    hemisphereLight.position.set(0, 20, 0);
    scene.add(hemisphereLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    directionalLight.castShadow = true;
    directionalLight.shadow.camera.top = 10;
    directionalLight.shadow.camera.bottom = -10;
    directionalLight.shadow.camera.left = -10;
    directionalLight.shadow.camera.right = 10;
    directionalLight.shadow.camera.near = 0.1;
    directionalLight.shadow.camera.far = 40;
    scene.add(directionalLight);

    const ambientLight = new THREE.AmbientLight(0x404050, 0.5);
    scene.add(ambientLight);

    // Create a point light for highlighting
    const pointLight = new THREE.PointLight(0x00C06D, 1, 10);
    pointLight.position.set(2, 2, 2);
    scene.add(pointLight);

    // Create a sophisticated 3D candlestick chart
    const chartGroup = createCandlestickChart(sampleStockData);
    chartGroup.position.set(-5, 0, 0);
    chartGroup.rotation.y = Math.PI * 0.2;
    scene.add(chartGroup);
    interactiveElementsRef.current.push({
      object: chartGroup,
      update: (time, mousePosition) => {
        // Make chart responsive to mouse position
        const targetRotationY = Math.PI * 0.2 + mousePosition.x * 0.1;
        const targetRotationX = mousePosition.y * 0.1;
        chartGroup.rotation.y += (targetRotationY - chartGroup.rotation.y) * 0.05;
        chartGroup.rotation.x += (targetRotationX - chartGroup.rotation.x) * 0.05;
      }
    });

    // Create a 3D globe with market data
    const globeGroup = createGlobe();
    globeGroup.position.set(5, 0, 0);
    scene.add(globeGroup);
    interactiveElementsRef.current.push({
      object: globeGroup,
      update: (time, mousePosition) => {
        // Rotate globe continuously but also respond to mouse
        globeGroup.rotation.y = time * 0.1;
        
        // Tilt slightly based on mouse position
        const targetTiltX = mousePosition.y * 0.2;
        globeGroup.rotation.x += (targetTiltX - globeGroup.rotation.x) * 0.05;
      }
    });

    // Create a floating network of connected nodes (representing blockchain/trading network)
    const networkGroup = createNetworkVisualization();
    networkGroup.position.set(0, 5, -5);
    scene.add(networkGroup);
    interactiveElementsRef.current.push({
      object: networkGroup,
      update: (time, mousePosition) => {
        // Make nodes pulse and lines animate
        networkGroup.children.forEach((child, index) => {
          if (child instanceof THREE.Mesh) {
            // Pulsing effect for nodes
            const scale = 0.8 + 0.2 * Math.sin(time * 2 + index);
            child.scale.set(scale, scale, scale);
          } else if (child instanceof THREE.Line) {
            // Animate line material - use computeLineDistances to update the line
            // instead of trying to modify dashOffset directly
            if (child.material instanceof THREE.LineDashedMaterial) {
              // Recreate material with updated properties
              // Usar valores animados para dashSize y gapSize en lugar de los originales
              child.material = new THREE.LineDashedMaterial({
                color: child.material.color,
                opacity: child.material.opacity,
                transparent: child.material.transparent,
                // Valores animados basados en el tiempo
                dashSize: 0.1 + 0.05 * Math.sin(time * 0.5),
                gapSize: 0.05 + 0.05 * Math.cos(time * 0.5)
              });
              child.computeLineDistances();
            }
          }
        });
        
        // Rotate based on mouse
        const targetRotationY = mousePosition.x * 0.3;
        const targetRotationX = mousePosition.y * 0.3;
        networkGroup.rotation.y += (targetRotationY - networkGroup.rotation.y) * 0.03;
        networkGroup.rotation.x += (targetRotationX - networkGroup.rotation.x) * 0.03;
      }
    });

    // Create animated particles in the background
    const particleSystem = createParticleSystem();
    scene.add(particleSystem);
    interactiveElementsRef.current.push({
      object: particleSystem,
      update: (time, mousePosition) => {
        // Update particle positions
        const positions = particleSystem.geometry.attributes.position.array as Float32Array;
        for (let i = 0; i < positions.length; i += 3) {
          positions[i + 1] += 0.01; // Move particles upward
          
          // Reset particles when they go too high
          if (positions[i + 1] > 20) {
            positions[i + 1] = -20;
            positions[i] = (Math.random() - 0.5) * 40;
            positions[i + 2] = (Math.random() - 0.5) * 40;
          }
        }
        particleSystem.geometry.attributes.position.needsUpdate = true;
      }
    });

    // Mouse move event handler
    const handleMouseMove = (event: MouseEvent) => {
      // Normalize mouse position to -1 to 1
      mouseRef.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = -(event.clientY / window.innerHeight) * 2 + 1;
    };

    // Add mouse event listeners
    window.addEventListener('mousemove', handleMouseMove);
    
    // Track when user is hovering over the container
    containerRef.current.addEventListener('mouseenter', () => setIsHovering(true));
    containerRef.current.addEventListener('mouseleave', () => setIsHovering(false));

    // Animation loop
    const animate = () => {
      timeRef.current += 0.01;
      const animationId = requestAnimationFrame(animate);

      if (!sceneRef.current || !cameraRef.current || !rendererRef.current) {
        cancelAnimationFrame(animationId);
        return;
      }

      // Update all interactive elements
      interactiveElementsRef.current.forEach(element => {
        element.update(timeRef.current, mouseRef.current);
      });

      // Apply a subtle camera movement based on mouse position when hovering
      if (isHovering && cameraRef.current) {
        const targetX = mouseRef.current.x * 0.5;
        const targetY = mouseRef.current.y * 0.5;
        
        cameraRef.current.position.x += (targetX - cameraRef.current.position.x) * 0.05;
        cameraRef.current.position.y += (targetY - cameraRef.current.position.y) * 0.05;
        cameraRef.current.lookAt(0, 0, 0);
      }

      // Render the scene
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current) return;

      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      
      if (containerRef.current) {
        containerRef.current.removeEventListener('mouseenter', () => setIsHovering(true));
        containerRef.current.removeEventListener('mouseleave', () => setIsHovering(false));
      }
      
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      // Dispose of all resources
      scene.traverse((object: THREE.Object3D) => {
        if (object instanceof THREE.Mesh) {
          if (object.geometry) object.geometry.dispose();
          
          if (object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach((material: THREE.Material) => material.dispose());
            } else {
              object.material.dispose();
            }
          }
        }
      });
    };
  }, [isHovering]);

  // Function to create candlestick chart
  function createCandlestickChart(data: any[]): THREE.Group {
    const group = new THREE.Group();
    
    // Create base platform
    const baseGeometry = new THREE.BoxGeometry(6, 0.2, 3);
    const baseMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x333333,
      shininess: 100
    });
    const base = new THREE.Mesh(baseGeometry, baseMaterial);
    base.receiveShadow = true;
    group.add(base);
    
    // Create grid
    const gridHelper = new THREE.GridHelper(6, 12, 0x555555, 0x222222);
    gridHelper.position.y = 0.12;
    gridHelper.rotation.x = Math.PI / 2;
    gridHelper.rotation.z = Math.PI / 2;
    group.add(gridHelper);
    
    // Create axes
    const xAxisGeometry = new THREE.BoxGeometry(6, 0.05, 0.05);
    const yAxisGeometry = new THREE.BoxGeometry(0.05, 3, 0.05);
    const axisMaterial = new THREE.MeshBasicMaterial({ color: 0x666666 });
    
    const xAxis = new THREE.Mesh(xAxisGeometry, axisMaterial);
    xAxis.position.y = 0.12;
    xAxis.position.z = -1.5;
    
    const yAxis = new THREE.Mesh(yAxisGeometry, axisMaterial);
    yAxis.position.y = 0.12;
    yAxis.position.x = -3;
    
    group.add(xAxis, yAxis);
    
    // Scale factors to fit data within our visualization
    const xScale = 5 / data.length;
    const maxValue = Math.max(...data.map(d => d.high));
    const minValue = Math.min(...data.map(d => d.low));
    const valueRange = maxValue - minValue;
    const yScale = 3 / valueRange;
    
    // Create candlesticks
    data.forEach((candle, i) => {
      const x = (i * xScale) - 2.5;
      
      // Calculate positions
      const open = ((candle.open - minValue) * yScale) - 1.5;
      const close = ((candle.close - minValue) * yScale) - 1.5;
      const high = ((candle.high - minValue) * yScale) - 1.5;
      const low = ((candle.low - minValue) * yScale) - 1.5;
      
      // Create body
      const bodyHeight = Math.abs(close - open);
      const bodyGeometry = new THREE.BoxGeometry(xScale * 0.6, bodyHeight, xScale * 0.6);
      const isGreen = close > open;
      const bodyMaterial = new THREE.MeshPhongMaterial({
        color: isGreen ? 0x00C06D : 0xFF3B69,
        shininess: 100,
        emissive: isGreen ? 0x005030 : 0x500020,
        emissiveIntensity: 0.3
      });
      
      const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
      body.position.x = x;
      body.position.y = 0.12;
      body.position.z = (Math.max(open, close) - (bodyHeight / 2));
      body.castShadow = true;
      
      // Create wick
      const wickGeometry = new THREE.BoxGeometry(xScale * 0.1, high - low, xScale * 0.1);
      const wickMaterial = new THREE.MeshBasicMaterial({ color: 0xCCCCCC });
      const wick = new THREE.Mesh(wickGeometry, wickMaterial);
      wick.position.x = x;
      wick.position.y = 0.12;
      wick.position.z = low + ((high - low) / 2);
      
      group.add(body, wick);
    });
    
    return group;
  }

  // Function to create a 3D globe with market data
  function createGlobe(): THREE.Group {
    const group = new THREE.Group();
    
    // Create the globe sphere
    const radius = 3;
    const globeGeometry = new THREE.SphereGeometry(radius, 64, 64);
    const globeMaterial = new THREE.MeshStandardMaterial({
      color: 0x60A5FA, // Azul claro más suave
      metalness: 0.2,
      roughness: 0.7,
      transparent: true,
      opacity: 0.85,
      emissive: 0x93C5FD, // Emisión azul lavanda suave
      emissiveIntensity: 0.1
    });
    
    const globe = new THREE.Mesh(globeGeometry, globeMaterial);
    globe.castShadow = true;
    globe.receiveShadow = true;
    group.add(globe);
    
    // Add a wireframe overlay
    const wireframeGeometry = new THREE.SphereGeometry(radius * 1.001, 32, 32);
    const wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0xBAE6FD, // Azul celeste muy claro
      wireframe: true,
      transparent: true,
      opacity: 0.3
    });
    
    const wireframe = new THREE.Mesh(wireframeGeometry, wireframeMaterial);
    group.add(wireframe);
    
    // Add market points with labels
    cryptoMarkets.forEach(market => {
      // Convert lat/long to 3D coordinates
      const phi = (90 - market.lat) * (Math.PI / 180);
      const theta = (market.long + 180) * (Math.PI / 180);
      
      const x = -(radius * Math.sin(phi) * Math.cos(theta));
      const y = (radius * Math.cos(phi));
      const z = (radius * Math.sin(phi) * Math.sin(theta));
      
      // Create a point for the market
      const pointSize = 0.1 + (market.volume * 0.2);
      const pointGeometry = new THREE.SphereGeometry(pointSize, 16, 16);
      const pointMaterial = new THREE.MeshPhongMaterial({
        color: 0x10B981, // Un verde más azulado para combinar con el tema claro
        emissive: 0x059669,
        emissiveIntensity: 0.3,
        shininess: 90
      });
      
      const point = new THREE.Mesh(pointGeometry, pointMaterial);
      point.position.set(x, y, z);
      group.add(point);
      
      // Add a pulsing effect
      const pulse = new THREE.Mesh(
        new THREE.SphereGeometry(pointSize * 1.5, 16, 16),
        new THREE.MeshBasicMaterial({
          color: 0x34D399, // Verde más claro para el pulso
          transparent: true,
          opacity: 0.25
        })
      );
      pulse.position.copy(point.position);
      group.add(pulse);
      
      // Make the pulse animation
      interactiveElementsRef.current.push({
        object: pulse,
        update: (time) => {
          const scale = 1 + 0.5 * Math.sin(time * 3 + market.lat);
          pulse.scale.set(scale, scale, scale);
        }
      });
    });
    
    // Add arcs connecting major markets
    for (let i = 0; i < cryptoMarkets.length; i++) {
      for (let j = i + 1; j < cryptoMarkets.length; j++) {
        // Only connect some markets to avoid cluttering
        if (Math.random() > 0.7) continue;
        
        const market1 = cryptoMarkets[i];
        const market2 = cryptoMarkets[j];
        
        // Convert to 3D positions
        const phi1 = (90 - market1.lat) * (Math.PI / 180);
        const theta1 = (market1.long + 180) * (Math.PI / 180);
        const x1 = -(radius * Math.sin(phi1) * Math.cos(theta1));
        const y1 = (radius * Math.cos(phi1));
        const z1 = (radius * Math.sin(phi1) * Math.sin(theta1));
        
        const phi2 = (90 - market2.lat) * (Math.PI / 180);
        const theta2 = (market2.long + 180) * (Math.PI / 180);
        const x2 = -(radius * Math.sin(phi2) * Math.cos(theta2));
        const y2 = (radius * Math.cos(phi2));
        const z2 = (radius * Math.sin(phi2) * Math.sin(theta2));
        
        // Create a curved line between markets
        const curvePoints = [];
        for (let t = 0; t <= 20; t++) {
          // Linear interpolation
          const alpha = t / 20;
          let x = x1 * (1 - alpha) + x2 * alpha;
          let y = y1 * (1 - alpha) + y2 * alpha;
          let z = z1 * (1 - alpha) + z2 * alpha;
          
          // Add some arc height
          const mid = 0.5;
          const arcHeight = 0.5;
          const arcY = Math.sin(alpha * Math.PI) * arcHeight;
          
          // Normalize to keep on sphere surface, plus some arc height
          const distance = Math.sqrt(x * x + y * y + z * z);
          const normalizedRadius = radius + arcY;
          x = (x / distance) * normalizedRadius;
          y = (y / distance) * normalizedRadius;
          z = (z / distance) * normalizedRadius;
          
          curvePoints.push(new THREE.Vector3(x, y, z));
        }
        
        const curve = new THREE.CatmullRomCurve3(curvePoints);
        const lineGeometry = new THREE.TubeGeometry(curve, 20, 0.03, 8, false);
        const lineMaterial = new THREE.MeshBasicMaterial({
          color: 0x34D399, // Verde más claro para las líneas
          transparent: true,
          opacity: 0.4
        });
        
        const line = new THREE.Mesh(lineGeometry, lineMaterial);
        group.add(line);
        
        // Create data packets that travel along the lines
        const packetGeometry = new THREE.SphereGeometry(0.05, 8, 8);
        // Usar MeshStandardMaterial en lugar de MeshBasicMaterial para soportar emissive
        const packetMaterial = new THREE.MeshStandardMaterial({
          color: 0x059669, // Color verde principal
          emissive: 0x10B981, // Emisión verde más clara
          emissiveIntensity: 0.7,
          transparent: true,
          opacity: 0.9
        });
        
        const packet = new THREE.Mesh(packetGeometry, packetMaterial);
        group.add(packet);
        
        // Add animation for the packet
        let direction = 1;
        let progress = 0;
        
        interactiveElementsRef.current.push({
          object: packet,
          update: (time) => {
            // Update packet position along the curve
            progress += 0.01 * direction;
            
            // Reverse direction at the ends
            if (progress >= 1) {
              direction = -1;
              progress = 1;
            } else if (progress <= 0) {
              direction = 1;
              progress = 0;
            }
            
            const position = curve.getPoint(progress);
            packet.position.copy(position);
          }
        });
      }
    }
    
    return group;
  }

  // Function to create a network visualization
  function createNetworkVisualization(): THREE.Group {
    const group = new THREE.Group();
    const nodes: THREE.Mesh[] = [];
    const nodePositions: THREE.Vector3[] = [];
    const nodeCount = 15;
    
    // Create nodes
    for (let i = 0; i < nodeCount; i++) {
      const isSpecial = i < 3; // Some special/highlighted nodes
      
      const nodeGeometry = new THREE.SphereGeometry(isSpecial ? 0.15 : 0.1, 16, 16);
      const nodeMaterial = new THREE.MeshPhongMaterial({
        color: isSpecial ? 0x10B981 : 0x60A5FA,  // Colores más claros para el tema light
        shininess: 90,
        emissive: isSpecial ? 0x059669 : 0x3B82F6,
        emissiveIntensity: 0.3
      });
      
      const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
      
      // Position node randomly in 3D space
      const x = (Math.random() - 0.5) * 6;
      const y = (Math.random() - 0.5) * 6;
      const z = (Math.random() - 0.5) * 6;
      node.position.set(x, y, z);
      
      nodes.push(node);
      nodePositions.push(new THREE.Vector3(x, y, z));
      group.add(node);
    }
    
    // Connect nodes with lines
    for (let i = 0; i < nodeCount; i++) {
      for (let j = i + 1; j < nodeCount; j++) {
        // Don't connect every node to every other node
        if (Math.random() > 0.3) continue;
        
        const start = nodePositions[i];
        const end = nodePositions[j];
        
        // Skip if nodes are too far apart
        if (start.distanceTo(end) > 4) continue;
        
        // Create line material
        const isSpecialConnection = i < 3 || j < 3;
        const lineColor = isSpecialConnection ? 0x10B981 : 0x60A5FA;  // Colores más claros para el tema light
        
        const lineMaterial = new THREE.LineDashedMaterial({
          color: lineColor,
          dashSize: 0.1,
          gapSize: 0.05,
          opacity: 0.5,  // Reducir opacidad para efecto más sutil
          transparent: true
        });
        
        // Create line geometry
        const lineGeometry = new THREE.BufferGeometry().setFromPoints([start, end]);
        const line = new THREE.Line(lineGeometry, lineMaterial);
        line.computeLineDistances(); // Needed for dashed lines
        
        group.add(line);
      }
    }
    
    return group;
  }

  // Function to create particle system for background
  function createParticleSystem(): THREE.Points {
    const particleCount = 1000;
    const particleGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount * 3; i += 3) {
      // Position particles in a large cube
      positions[i] = (Math.random() - 0.5) * 40;
      positions[i + 1] = (Math.random() - 0.5) * 40;
      positions[i + 2] = (Math.random() - 0.5) * 40;
      
      // Color particles with pastel colors for light theme
      const ratio = Math.random();
      colors[i] = ratio * 0.2; // Red component (menor para tonos azules y verdes)
      colors[i + 1] = 0.4 + (ratio * 0.3); // Green component (verde más pronunciado)
      colors[i + 2] = 0.5 + ((1 - ratio) * 0.4); // Blue component (azul más pronunciado)
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.5 // Reducir opacidad para un efecto más sutil
    });
    
    return new THREE.Points(particleGeometry, particleMaterial);
  }

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]"
      style={{ zIndex: 0 }}
    />
  );
}