#!/usr/bin/env node

/**
 * Component Duplication Detection Script
 *
 * This script scans the codebase for potentially duplicate components
 * by analyzing component structure, imports, and functionality.
 */

const fs = require('fs');
const path = require('path');
const glob = require('glob');

// Configuration
const sourceDir = path.resolve(__dirname, '../src');
const componentsGlob = `${sourceDir}/**/*.{tsx,ts,jsx,js}`;

// Parse command line arguments
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');

// Component name patterns to check for duplicates
const targetComponents = [
  'PortfolioSummary',
  'OrderPlacement',
  'Chart',
  'PriceDisplay',
  'MarketData',
  'AssetList',
  'TransactionHistory',
  'TradingForm',
  'UserProfile',
  'Dashboard',
];

// Helper function to extract component name from file path
function getComponentNameFromPath(filePath) {
  const fileName = path.basename(filePath, path.extname(filePath));
  return fileName;
}

// Simple similarity check for component files
function calculateSimilarity(contentA, contentB) {
  // Count identical lines
  const linesA = contentA.split('\n');
  const linesB = contentB.split('\n');
  
  let identicalLines = 0;
  
  linesA.forEach(lineA => {
    if (linesB.includes(lineA)) {
      identicalLines++;
    }
  });
  
  // Calculate similarity percentage
  const maxLines = Math.max(linesA.length, linesB.length);
  return (identicalLines / maxLines) * 100;
}

// Main function
async function main() {
  try {
    // Find all component files
    const files = glob.sync(componentsGlob);
    console.log(`Scanning ${files.length} files for duplicate components...`);
    
    const componentsByName = {};
    const filesWithTargetNames = [];
    
    // First pass: collect files by component name patterns
    for (const file of files) {
      // Skip files in node_modules, test files, and utility files
      if (file.includes('node_modules') || 
          file.includes('.test.') || 
          file.includes('.spec.') || 
          file.includes('/lib/') || 
          file.includes('/utils/')) {
        continue;
      }
      
      const componentName = getComponentNameFromPath(file);
      
      // Check if component name matches any target pattern
      const matchesTarget = targetComponents.some(target => 
        componentName.includes(target) || file.includes(`/${target}`)
      );
      
      if (matchesTarget) {
        filesWithTargetNames.push(file);
        
        // Group by base component name
        const baseName = targetComponents.find(target => 
          componentName.includes(target) || file.includes(`/${target}`)
        );
        
        if (!componentsByName[baseName]) {
          componentsByName[baseName] = [];
        }
        
        componentsByName[baseName].push(file);
      }
    }
    
    // Find potential duplicates by content similarity
    const potentialDuplicates = [];
    
    // For each component group, check for similarity
    Object.entries(componentsByName).forEach(([baseName, componentFiles]) => {
      if (componentFiles.length > 1) {
        // Compare each pair of files
        for (let i = 0; i < componentFiles.length; i++) {
          for (let j = i + 1; j < componentFiles.length; j++) {
            const fileA = componentFiles[i];
            const fileB = componentFiles[j];
            
            const contentA = fs.readFileSync(fileA, 'utf8');
            const contentB = fs.readFileSync(fileB, 'utf8');
            
            const similarity = calculateSimilarity(contentA, contentB);
            
            // Consider files similar if they have > 30% similarity
            if (similarity > 30) {
              potentialDuplicates.push({
                baseName,
                fileA,
                fileB,
                similarity: Math.round(similarity),
              });
            }
          }
        }
      }
    });
    
    // Print results
    console.log('\n=== Duplicate Component Report ===\n');
    
    console.log(`Found ${filesWithTargetNames.length} files matching target component patterns.`);
    console.log(`Identified ${potentialDuplicates.length} potential duplicate pairs.\n`);
    
    if (potentialDuplicates.length > 0) {
      console.log('Potential duplicates:');
      potentialDuplicates.forEach(({ baseName, fileA, fileB, similarity }) => {
        const relativePathA = path.relative(process.cwd(), fileA);
        const relativePathB = path.relative(process.cwd(), fileB);
        
        console.log(`\n${baseName} components with ${similarity}% similarity:`);
        console.log(`- ${relativePathA}`);
        console.log(`- ${relativePathB}`);
      });
      console.log();
    }
    
    // Group components by base name
    console.log('Components by type:');
    Object.entries(componentsByName).forEach(([baseName, componentFiles]) => {
      console.log(`\n${baseName} (${componentFiles.length}):`);
      componentFiles.forEach(file => {
        const relativePath = path.relative(process.cwd(), file);
        console.log(`- ${relativePath}`);
      });
    });
    
    // Output actionable items
    console.log('\n=== Next Steps ===\n');
    
    if (potentialDuplicates.length > 0) {
      console.log('Consolidation recommendations:');
      
      // Group recommendations by base name
      const recommendations = {};
      potentialDuplicates.forEach(({ baseName, fileA, fileB, similarity }) => {
        if (!recommendations[baseName]) {
          recommendations[baseName] = [];
        }
        
        const relativePathA = path.relative(process.cwd(), fileA);
        const relativePathB = path.relative(process.cwd(), fileB);
        
        if (!recommendations[baseName].includes(relativePathA)) {
          recommendations[baseName].push(relativePathA);
        }
        
        if (!recommendations[baseName].includes(relativePathB)) {
          recommendations[baseName].push(relativePathB);
        }
      });
      
      Object.entries(recommendations).forEach(([baseName, files]) => {
        console.log(`\n${baseName}:`);
        console.log(`1. Create a consolidated ${baseName} component with variants`);
        console.log(`2. Replace these files with the consolidated version:`);
        files.forEach(file => {
          console.log(`   - ${file}`);
        });
      });
    } else {
      console.log('✅ No significant duplicates found for target components!');
    }
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Run the script
main(); 