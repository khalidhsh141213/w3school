import { useCallback, useMemo, useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNotifications, NotificationType, NotificationImportance } from './useNotifications';
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';

/**
 * Hook that combines WebSocket market data with notifications system
 * Provides a unified interface for trade-related real-time updates
 */
export const useTradeNotifications = (userId: number | null) => {
  const queryClient = useQueryClient();
  
  // Connect to WebSocket for market data
  const { 
    status: marketConnectionStatus,
    send,
    subscribe,
    websocket
  } = useWebSocket('/ws');
  
  // Track market data state
  const [marketData, setMarketData] = useState<any[]>([]);
  const [marketError, setMarketError] = useState<string | null>(null);
  const isMarketConnected = marketConnectionStatus === ConnectionStatus.CONNECTED;
  
  // Set up WebSocket subscription for market data
  useEffect(() => {
    if (!isMarketConnected) return;
    
    // Subscribe to market data updates
    const unsubscribe = subscribe((message: any) => {
      if (message && message.type === 'market_data') {
        setMarketData((prevData) => {
          // Update existing data or add new data
          const existingIndex = prevData.findIndex(
            (item) => item.symbol === message.symbol
          );
          
          if (existingIndex >= 0) {
            const newData = [...prevData];
            newData[existingIndex] = {
              ...newData[existingIndex],
              ...message,
              lastUpdated: new Date().toISOString()
            };
            return newData;
          } else {
            return [...prevData, {
              ...message,
              lastUpdated: new Date().toISOString()
            }];
          }
        });
      } else if (message && message.type === 'error') {
        setMarketError(message.message || 'Unknown market data error');
      }
    });
    
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isMarketConnected, subscribe]);
  
  // Connect to notifications system
  const {
    notifications,
    hasUnseenNotifications,
    unseenCount,
    markAsRead,
    markAllAsRead,
    refresh: refreshNotifications,
    connectionStatus: notificationConnectionStatus,
    error: notificationError
  } = useNotifications(userId);
  
  // Fetch user's economic events of interest
  const { data: economicEvents } = useQuery({
    queryKey: [userId ? `/api/economic-events/portfolio/${userId}` : null],
    enabled: !!userId,
    refetchInterval: 900000 // 15 minutes
  });
  
  // Fetch upcoming economic events
  const { data: upcomingEvents } = useQuery({
    queryKey: ['/api/economic-events/upcoming'],
    refetchInterval: 3600000 // 1 hour
  });
  
  // Get economic event notifications
  const economicEventNotifications = useMemo(() => {
    return notifications.filter(notification => 
      notification.type === NotificationType.ECONOMIC_EVENT
    );
  }, [notifications]);
  
  // Get price alert notifications
  const priceAlertNotifications = useMemo(() => {
    return notifications.filter(notification => 
      notification.type === NotificationType.PRICE_ALERT
    );
  }, [notifications]);
  
  // Get trade execution notifications
  const tradeNotifications = useMemo(() => {
    return notifications.filter(notification => 
      notification.type === NotificationType.TRADE_EXECUTION
    );
  }, [notifications]);
  
  // Get high importance notifications
  const highImportanceNotifications = useMemo(() => {
    return notifications.filter(notification => 
      notification.importance === NotificationImportance.HIGH
    );
  }, [notifications]);
  
  // Mark notifications as read and refresh relevant queries
  const markNotificationsRead = useCallback((notificationIds: string[]) => {
    markAsRead(notificationIds);
    
    // Invalidate relevant queries based on notification types
    const notificationsToMark = notifications.filter(n => notificationIds.includes(n.id));
    
    // Check if there are any economic event notifications
    if (notificationsToMark.some(n => n.type === NotificationType.ECONOMIC_EVENT)) {
      queryClient.invalidateQueries({ queryKey: ['/api/economic-events'] });
      if (userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/economic-events/portfolio/${userId}`] });
      }
    }
    
    // Check if there are any price alert notifications
    if (notificationsToMark.some(n => n.type === NotificationType.PRICE_ALERT)) {
      queryClient.invalidateQueries({ queryKey: ['/api/market-data'] });
      // Note: No longer invalidating WebSocket data directly as we now use central WebSocketManager
    }
    
    // Check if there are any trade execution notifications
    if (notificationsToMark.some(n => n.type === NotificationType.TRADE_EXECUTION) && userId) {
      queryClient.invalidateQueries({ queryKey: [`/api/portfolio/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/trades/${userId}`] });
    }
  }, [markAsRead, notifications, queryClient, userId]);
  
  // Methods for sending market data requests
  const requestMarketData = useCallback((symbols?: string[]) => {
    if (!isMarketConnected) return false;
    
    return send({
      type: 'request_market_data',
      symbols: symbols || [],
      timestamp: Date.now()
    });
  }, [isMarketConnected, send]);
  
  const requestAssetDetails = useCallback((symbol: string) => {
    if (!isMarketConnected) return false;
    
    return send({
      type: 'request_asset_details',
      symbol,
      timestamp: Date.now()
    });
  }, [isMarketConnected, send]);
  
  // Request initial market data when connection is established
  useEffect(() => {
    if (isMarketConnected) {
      requestMarketData();
    }
  }, [isMarketConnected, requestMarketData]);

  return {
    // Market data
    marketData,
    isMarketConnected,
    marketConnectionStatus,
    marketError,
    
    // Market data methods
    requestMarketData,
    requestAssetDetails,
    send,
    
    // Notifications
    notifications,
    hasUnseenNotifications,
    unseenCount,
    markAsRead: markNotificationsRead,
    markAllAsRead,
    refreshNotifications,
    notificationConnectionStatus,
    notificationError,
    
    // Filtered notifications
    economicEventNotifications,
    priceAlertNotifications,
    tradeNotifications,
    highImportanceNotifications,
    
    // Related data
    economicEvents,
    upcomingEvents,
    
    // Combined status
    isFullyConnected: isMarketConnected && notificationConnectionStatus === 'connected',
    hasError: !!marketError || !!notificationError
  };
};