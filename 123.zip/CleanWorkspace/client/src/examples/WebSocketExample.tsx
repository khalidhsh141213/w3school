import React, { useEffect, useState } from 'react';
import WebSocketStatus from '../components/WebSocketStatus';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Switch } from '../components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Priority } from '../services/RateLimiter';
import { ConnectionStatus, useWebSocket } from '../services/WebSocketManager';

/**
 * WebSocket Example Component
 * 
 * This example demonstrates all features of our WebSocketManager implementation:
 * - Connection management
 * - Circuit Breaker pattern
 * - Rate Limiting
 * - Message Queuing
 * - Status monitoring
 */
const WebSocketExample: React.FC = () => {
  // WebSocket URL state
  const [wsUrl, setWsUrl] = useState('wss://demo.websocket.me/echo');
  
  // Custom options state
  const [reconnectAttempts, setReconnectAttempts] = useState(5);
  const [reconnectInterval, setReconnectInterval] = useState(3000);
  const [heartbeatInterval, setHeartbeatInterval] = useState(30000);
  const [circuitBreakerEnabled, setCircuitBreakerEnabled] = useState(true);
  const [failureThreshold, setFailureThreshold] = useState(3);
  const [rateLimiterEnabled, setRateLimiterEnabled] = useState(true);
  const [maxOperations, setMaxOperations] = useState(10);
  const [windowMs, setWindowMs] = useState(1000);
  const [priorityBasedQueue, setPriorityBasedQueue] = useState(true);
  
  // Message state
  const [message, setMessage] = useState('Hello WebSocket!');
  const [receivedMessages, setReceivedMessages] = useState<string[]>([]);
  
  // Load test state
  const [messageCount, setMessageCount] = useState(20);
  const [messageDelay, setMessageDelay] = useState(50);
  const [isLoadTestRunning, setIsLoadTestRunning] = useState(false);
  
  // Add priority state to the component
  const [messagePriority, setMessagePriority] = useState<Priority>(Priority.NORMAL);
  
  // Use the WebSocket hook with the current URL and options
  const { status, subscribe, send, getHealth } = useWebSocket(
    wsUrl,
    {
      reconnectAttempts,
      reconnectInterval,
      heartbeatInterval,
      circuitBreaker: {
        enabled: circuitBreakerEnabled,
        failureThreshold
      },
      rateLimiter: {
        enabled: rateLimiterEnabled,
        maxOperations,
        windowMs,
        priorityBasedQueue
      }
    },
    // Re-connect when any of these options change
    [
      wsUrl, 
      reconnectAttempts, 
      reconnectInterval, 
      heartbeatInterval, 
      circuitBreakerEnabled,
      failureThreshold,
      rateLimiterEnabled,
      maxOperations,
      windowMs,
      priorityBasedQueue
    ]
  );
  
  // Subscribe to messages
  useEffect(() => {
    if (!wsUrl) return;
    
    const unsubscribe = subscribe((data) => {
      try {
        let messageText;
        if (typeof data === 'string') {
          messageText = data;
        } else if (typeof data === 'object') {
          messageText = JSON.stringify(data);
        } else {
          messageText = String(data);
        }
        
        setReceivedMessages(prev => [messageText, ...prev].slice(0, 50));
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    return unsubscribe;
  }, [wsUrl, subscribe]);
  
  // Connect to demo WebSocket
  const handleConnect = () => {
    // URL validation
    if (!wsUrl.startsWith('ws://') && !wsUrl.startsWith('wss://')) {
      alert('WebSocket URL must start with ws:// or wss://');
      return;
    }
    
    // Reset messages
    setReceivedMessages([]);
  };
  
  // Send a message
  const handleSendMessage = () => {
    if (status !== ConnectionStatus.CONNECTED) {
      alert('WebSocket is not connected');
      return;
    }
    
    const success = send({
      message,
      priority: messagePriority
    });
    
    if (success) {
      console.log(`Message sent with priority ${Priority[messagePriority]}:`, message);
    } else {
      console.error('Failed to send message');
    }
  };
  
  // Run a load test that sends many messages quickly
  const runLoadTest = async () => {
    if (status !== ConnectionStatus.CONNECTED) {
      alert('WebSocket is not connected');
      return;
    }
    
    setIsLoadTestRunning(true);
    
    // Send a batch of messages
    const count = parseInt(messageCount.toString(), 10);
    const delay = parseInt(messageDelay.toString(), 10);
    
    for (let i = 0; i < count; i++) {
      if (!isLoadTestRunning) break;
      
      // Calculate priority based on message number
      // Every 4th message is CRITICAL, every 3rd is HIGH, every 2nd is NORMAL, the rest are LOW
      let priority = Priority.LOW;
      if (i % 4 === 0) {
        priority = Priority.CRITICAL;
      } else if (i % 3 === 0) {
        priority = Priority.HIGH;
      } else if (i % 2 === 0) {
        priority = Priority.NORMAL;
      }
      
      const testMessage = `Test message ${i + 1}/${count} (${Priority[priority]})`;
      const success = send({
        message: testMessage,
        priority
      });
      
      console.log(`Message ${i + 1}/${count} with priority ${Priority[priority]} ${success ? 'sent' : 'queued/failed'}`);
      
      // Wait for the specified delay
      if (delay > 0 && i < count - 1) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    
    setIsLoadTestRunning(false);
  };
  
  // Stop the load test
  const stopLoadTest = () => {
    setIsLoadTestRunning(false);
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>WebSocket Example</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="connection">
            <TabsList className="mb-4">
              <TabsTrigger value="connection">Connection</TabsTrigger>
              <TabsTrigger value="messaging">Messaging</TabsTrigger>
              <TabsTrigger value="status">Status</TabsTrigger>
              <TabsTrigger value="advanced">Advanced Options</TabsTrigger>
            </TabsList>
            
            <TabsContent value="connection">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="ws-url">WebSocket URL</Label>
                  <Input
                    id="ws-url"
                    value={wsUrl}
                    onChange={(e) => setWsUrl(e.target.value)}
                    placeholder="Enter WebSocket URL (e.g., wss://demo.websocket.me/echo)"
                  />
                </div>
                
                <Button onClick={handleConnect}>
                  {status === ConnectionStatus.DISCONNECTED || status === ConnectionStatus.ERROR
                    ? 'Connect'
                    : 'Reconnect'}
                </Button>
                
                <div className="mt-4">
                  <h3 className="text-lg font-medium">Connection Status</h3>
                  <p className="text-md mt-2">
                    Current Status: <span className="font-bold">{status}</span>
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="messaging">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="message">Message</Label>
                  <Input
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Enter message to send"
                  />
                </div>
                
                <div>
                  <Label htmlFor="message-priority">Message Priority</Label>
                  <div className="flex space-x-2 mt-1">
                    <select
                      id="message-priority"
                      value={messagePriority}
                      onChange={(e) => setMessagePriority(parseInt(e.target.value, 10) as Priority)}
                      className="border rounded p-2 w-full"
                    >
                      <option value={Priority.LOW}>Low</option>
                      <option value={Priority.NORMAL}>Normal</option>
                      <option value={Priority.HIGH}>High</option>
                      <option value={Priority.CRITICAL}>Critical</option>
                    </select>
                  </div>
                </div>
                
                <Button onClick={handleSendMessage} disabled={status !== ConnectionStatus.CONNECTED}>
                  Send Message
                </Button>
                
                <div className="mt-4">
                  <h3 className="text-lg font-medium">Load Testing</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <Label htmlFor="message-count">Number of Messages</Label>
                      <Input
                        id="message-count"
                        type="number"
                        min="1"
                        max="1000"
                        value={messageCount}
                        onChange={(e) => setMessageCount(parseInt(e.target.value, 10))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="message-delay">Delay (ms)</Label>
                      <Input
                        id="message-delay"
                        type="number"
                        min="0"
                        max="1000"
                        value={messageDelay}
                        onChange={(e) => setMessageDelay(parseInt(e.target.value, 10))}
                      />
                    </div>
                  </div>
                  <div className="flex space-x-2 mt-2">
                    {isLoadTestRunning ? (
                      <Button variant="destructive" onClick={stopLoadTest}>
                        Stop Test
                      </Button>
                    ) : (
                      <Button
                        onClick={runLoadTest}
                        disabled={status !== ConnectionStatus.CONNECTED}
                      >
                        Run Load Test
                      </Button>
                    )}
                  </div>
                </div>
                
                <div className="mt-4">
                  <h3 className="text-lg font-medium">Received Messages</h3>
                  <div className="border rounded h-48 overflow-y-auto p-2 bg-gray-50 mt-2">
                    {receivedMessages.length === 0 ? (
                      <p className="text-gray-400 italic">No messages received yet</p>
                    ) : (
                      <ul className="space-y-1">
                        {receivedMessages.map((msg, i) => (
                          <li key={i} className="text-sm border-b pb-1">
                            {msg}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="status">
              <div className="space-y-4">
                <div className="p-4 border rounded">
                  <WebSocketStatus url={wsUrl} showDetails={true} pollingInterval={1000} />
                </div>
                
                <div className="mt-4">
                  <h3 className="text-lg font-medium">Technical Details</h3>
                  <pre className="text-xs bg-gray-100 p-2 rounded h-48 overflow-auto mt-2">
                    {JSON.stringify(getHealth(), null, 2)}
                  </pre>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="advanced">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Connection Options</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reconnect-attempts">Max Reconnect Attempts</Label>
                    <Input
                      id="reconnect-attempts"
                      type="number"
                      min="0"
                      max="20"
                      value={reconnectAttempts}
                      onChange={(e) => setReconnectAttempts(parseInt(e.target.value, 10))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reconnect-interval">Reconnect Interval (ms)</Label>
                    <Input
                      id="reconnect-interval"
                      type="number"
                      min="100"
                      max="10000"
                      value={reconnectInterval}
                      onChange={(e) => setReconnectInterval(parseInt(e.target.value, 10))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="heartbeat-interval">Heartbeat Interval (ms)</Label>
                    <Input
                      id="heartbeat-interval"
                      type="number"
                      min="1000"
                      max="60000"
                      value={heartbeatInterval}
                      onChange={(e) => setHeartbeatInterval(parseInt(e.target.value, 10))}
                    />
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mt-4">Circuit Breaker Options</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="circuit-breaker"
                      checked={circuitBreakerEnabled}
                      onCheckedChange={setCircuitBreakerEnabled}
                    />
                    <Label htmlFor="circuit-breaker">Enable Circuit Breaker</Label>
                  </div>
                  
                  {circuitBreakerEnabled && (
                    <div className="grid grid-cols-2 gap-4 mt-2">
                      <div>
                        <Label htmlFor="failure-threshold">Failure Threshold</Label>
                        <Input
                          id="failure-threshold"
                          type="number"
                          min="1"
                          max="10"
                          value={failureThreshold}
                          onChange={(e) => setFailureThreshold(parseInt(e.target.value, 10))}
                        />
                      </div>
                    </div>
                  )}
                </div>
                
                <h3 className="text-lg font-medium mt-4">Rate Limiter Options</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="rate-limiter"
                      checked={rateLimiterEnabled}
                      onCheckedChange={setRateLimiterEnabled}
                    />
                    <Label htmlFor="rate-limiter">Enable Rate Limiter</Label>
                  </div>
                  
                  {rateLimiterEnabled && (
                    <div className="space-y-4 mt-2">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="max-operations">Max Operations</Label>
                          <Input
                            id="max-operations"
                            type="number"
                            min="1"
                            max="100"
                            value={maxOperations}
                            onChange={(e) => setMaxOperations(parseInt(e.target.value, 10))}
                          />
                        </div>
                        <div>
                          <Label htmlFor="window-ms">Time Window (ms)</Label>
                          <Input
                            id="window-ms"
                            type="number"
                            min="100"
                            max="10000"
                            value={windowMs}
                            onChange={(e) => setWindowMs(parseInt(e.target.value, 10))}
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="priority-queue"
                          checked={priorityBasedQueue}
                          onCheckedChange={setPriorityBasedQueue}
                        />
                        <Label htmlFor="priority-queue">Use Priority-Based Queue</Label>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>How to Use This Example</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p>
              This example demonstrates the WebSocketManager's features including connection management,
              circuit breaker pattern, rate limiting, and message queuing.
            </p>
            
            <h3 className="text-md font-medium">Try the following:</h3>
            <ol className="list-decimal ml-6 space-y-2">
              <li>
                <strong>Test basic connectivity</strong> - Connect to the demo WebSocket and send a few messages
              </li>
              <li>
                <strong>Test rate limiting</strong> - Run a load test with many messages and low delay to
                see rate limiting in action (check the Status tab)
              </li>
              <li>
                <strong>Test circuit breaker</strong> - Enter an invalid WebSocket URL and try to connect
                multiple times to see the circuit breaker open
              </li>
              <li>
                <strong>Customize options</strong> - Modify the rate limiter and circuit breaker settings
                to see how they affect behavior
              </li>
            </ol>
            
            <p className="text-sm text-gray-600 mt-4">
              Note: For a proper load test, you may need a WebSocket server that can handle high message volumes.
              The demo server might disconnect you if you send too many messages too quickly.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WebSocketExample; 