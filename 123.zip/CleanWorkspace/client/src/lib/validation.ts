/**
 * Runtime Type Validation Utilities
 * 
 * This file provides utilities for validating data structures at runtime,
 * which is particularly useful for API responses and WebSocket messages.
 */


/**
 * Error thrown when validation fails
 */
export class ValidationError extends Error {
  path: string;
  expected: string;
  received: any;
  
  constructor(message: string, path: string, expected: string, received: any) {
    super(message);
    this.name = 'ValidationError';
    this.path = path;
    this.expected = expected;
    this.received = received;
  }
}

/**
 * Type for validation functions
 */
export type Validator<T> = (value: unknown, path?: string) => T;

/**
 * Creates a validator for an object with a specific shape
 */
export function object<T extends Record<string, any>>(
  shape: { [K in keyof T]: Validator<T[K]> }
): Validator<T> {
  return (value: unknown, path = ''): T => {
    if (typeof value !== 'object' || value === null) {
      throw new ValidationError(
        `Expected object at ${path}, received ${typeof value}`,
        path,
        'object',
        value
      );
    }
    
    const result: Record<string, any> = {};
    const valueObj = value as Record<string, unknown>;
    
    for (const key in shape) {
      const fieldPath = path ? `${path}.${key}` : key;
      try {
        result[key] = shape[key](valueObj[key], fieldPath);
      } catch (error) {
        if (error instanceof ValidationError) {
          throw error;
        }
        throw new ValidationError(
          `Invalid field ${fieldPath}: ${error.message}`,
          fieldPath,
          typeof shape[key],
          valueObj[key]
        );
      }
    }
    
    return result as T;
  };
}

/**
 * Creates a validator for an array of a specific type
 */
export function array<T>(itemValidator: Validator<T>): Validator<T[]> {
  return (value: unknown, path = ''): T[] => {
    if (!Array.isArray(value)) {
      throw new ValidationError(
        `Expected array at ${path}, received ${typeof value}`,
        path,
        'array',
        value
      );
    }
    
    return value.map((item, index) => {
      try {
        return itemValidator(item, `${path}[${index}]`);
      } catch (error) {
        if (error instanceof ValidationError) {
          throw error;
        }
        throw new ValidationError(
          `Invalid array item at ${path}[${index}]: ${error.message}`,
          `${path}[${index}]`,
          'valid item',
          item
        );
      }
    });
  };
}

/**
 * Creates an optional validator that returns undefined if the value is null or undefined
 */
export function optional<T>(validator: Validator<T>): Validator<T | undefined> {
  return (value: unknown, path = ''): T | undefined => {
    if (value === null || value === undefined) {
      return undefined;
    }
    return validator(value, path);
  };
}

/**
 * Basic validators for primitive types
 */
export const string = (value: unknown, path = ''): string => {
  if (typeof value !== 'string') {
    throw new ValidationError(
      `Expected string at ${path}, received ${typeof value}`,
      path,
      'string',
      value
    );
  }
  return value;
};

export const number = (value: unknown, path = ''): number => {
  if (typeof value !== 'number' || isNaN(value)) {
    throw new ValidationError(
      `Expected number at ${path}, received ${typeof value}`,
      path,
      'number',
      value
    );
  }
  return value;
};

export const boolean = (value: unknown, path = ''): boolean => {
  if (typeof value !== 'boolean') {
    throw new ValidationError(
      `Expected boolean at ${path}, received ${typeof value}`,
      path,
      'boolean',
      value
    );
  }
  return value;
};

export const date = (value: unknown, path = ''): Date => {
  if (typeof value === 'string') {
    const date = new Date(value);
    if (isNaN(date.getTime())) {
      throw new ValidationError(
        `Expected valid date string at ${path}, received invalid date string`,
        path,
        'valid date string',
        value
      );
    }
    return date;
  }
  
  if (value instanceof Date) {
    if (isNaN(value.getTime())) {
      throw new ValidationError(
        `Expected valid date at ${path}, received invalid date`,
        path,
        'valid date',
        value
      );
    }
    return value;
  }
  
  throw new ValidationError(
    `Expected date or date string at ${path}, received ${typeof value}`,
    path,
    'date',
    value
  );
};

/**
 * Union validator
 */
export function oneOf<T extends readonly any[]>(
  validators: { [K in keyof T]: Validator<T[K]> }
): Validator<T[number]> {
  return (value: unknown, path = ''): T[number] => {
    const errors: ValidationError[] = [];
    
    for (const validator of validators) {
      try {
        return validator(value, path);
      } catch (error) {
        if (error instanceof ValidationError) {
          errors.push(error);
          continue;
        }
        throw error;
      }
    }
    
    const expectedTypes = validators
      .map(v => (v as any).name || 'unknown')
      .join(' | ');
      
    throw new ValidationError(
      `Expected one of [${expectedTypes}] at ${path}, received incompatible value`,
      path,
      expectedTypes,
      value
    );
  };
}

/**
 * Literal validator
 */
export function literal<T extends string | number | boolean>(expectedValue: T): Validator<T> {
  return (value: unknown, path = ''): T => {
    if (value !== expectedValue) {
      throw new ValidationError(
        `Expected "${expectedValue}" at ${path}, received "${value}"`,
        path,
        String(expectedValue),
        value
      );
    }
    return expectedValue;
  };
}

/**
 * Creates an enum validator
 */
export function enumValue<T extends string>(
  enumValues: readonly T[] | { [key: string]: T }
): Validator<T> {
  const validValues = Array.isArray(enumValues)
    ? enumValues
    : Object.values(enumValues);
    
  return (value: unknown, path = ''): T => {
    if (typeof value !== 'string' || !validValues.includes(value as T)) {
      throw new ValidationError(
        `Expected one of [${validValues.join(', ')}] at ${path}, received "${value}"`,
        path,
        validValues.join(' | '),
        value
      );
    }
    return value as T;
  };
}

/**
 * Helper to safely validate API responses
 */
export function validateApiResponse<T>(
  response: unknown, 
  validator: Validator<T>,
  errorHandler?: (error: ValidationError) => void
): T | null {
  try {
    return validator(response);
  } catch (error) {
    if (error instanceof ValidationError) {
      console.error('API response validation error:', error);
      
      if (errorHandler) {
        errorHandler(error);
      }
      
      return null;
    }
    throw error;
  }
}

/**
 * Example validators for common types
 */

// Example: MarketData validator
export const marketDataValidator = object({
  symbol: string,
  price: number,
  volume: number,
  high: number,
  low: number,
  open: number,
  close: number,
  changePercent: number,
  timestamp: string
});

// Example: User validator
export const userValidator = object({
  id: string,
  username: string,
  email: string,
  fullName: optional(string),
  role: enumValue(['user', 'admin'] as const),
  createdAt: string,
  updatedAt: string,
  preferences: optional(object({
    theme: optional(enumValue(['light', 'dark', 'system'] as const)),
    language: optional(string),
    notifications: optional(object({
      email: boolean,
      push: boolean,
      sms: boolean
    })),
    defaultLeverage: optional(number),
    riskLevel: optional(enumValue(['low', 'medium', 'high'] as const))
  }))
});

// Example: Portfolio validator
export const portfolioValidator = object({
  id: string,
  userId: string,
  totalValue: number,
  availableBalance: number,
  pnl: number,
  pnlPercent: number,
  positions: array(object({
    id: string,
    portfolioId: string,
    assetId: string,
    symbol: string,
    quantity: number,
    entryPrice: number,
    currentPrice: number,
    pnl: number,
    pnlPercent: number,
    leverage: number,
    direction: enumValue(['long', 'short'] as const),
    createdAt: string,
    updatedAt: string
  })),
  updatedAt: string
});

export default {
  string,
  number,
  boolean,
  date,
  object,
  array,
  optional,
  oneOf,
  literal,
  enumValue,
  validateApiResponse,
  // Example validators
  marketDataValidator,
  userValidator,
  portfolioValidator
}; 