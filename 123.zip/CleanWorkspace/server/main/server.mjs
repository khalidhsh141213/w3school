/**
 * Main application server
 * This server acts as the primary entry point for the application.
 * It coordinates with:
 * - arabic-ai-server.mjs for Arabic language processing
 * - gpt2_server.py for GPT-2 model integration
 */

import express from 'express';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);

const app = express();
const port = process.env.FLASK_PORT || 5000;

app.use(express.json());

// Enable CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({ status: 'ok', message: 'AI service is running' });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', model: 'mock-model' });
});

// Text generation endpoint
app.post('/generate', (req, res) => {
  try {
    const { prompt } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }
    
    // Mock AI response
    const response = `AI response to: "${prompt}"\n\nThis is a mock response from the AI service. The actual AI model is not loaded to save memory.`;
    
    res.json({ response });
  } catch (error) {
    console.error('Error generating text:', error);
    res.status(500).json({ error: error.message });
  }
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`AI service running on port ${port}`);
}); 