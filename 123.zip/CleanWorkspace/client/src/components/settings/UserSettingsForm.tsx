import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/lib/authContext';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';

// Define the form schema - these are the editable user settings
const userSettingsFormSchema = z.object({
  languagePreference: z.string().min(2),
  currencyPreference: z.string().min(2).default("USD"),
  themePreference: z.string().min(2).default("light"),
  notificationPreferences: z.object({
    email: z.boolean().default(true),
    browser: z.boolean().default(true),
    marketAlerts: z.boolean().default(true),
    tradingUpdates: z.boolean().default(true),
    securityAlerts: z.boolean().default(true),
  }),
  privacySettings: z.object({
    showProfileToOthers: z.boolean().default(true),
    shareTradeHistory: z.boolean().default(false),
    allowMarketingCommunications: z.boolean().default(true),
  }),
});

type UserSettingsFormValues = z.infer<typeof userSettingsFormSchema>;

interface UserSettingsFormProps {
  existingSettings?: any;
  isLoading?: boolean;
}

export default function UserSettingsForm({ existingSettings, isLoading }: UserSettingsFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSaving, setIsSaving] = useState(false);

  // Set up form with default values from existing settings or defaults
  const form = useForm<UserSettingsFormValues>({
    resolver: zodResolver(userSettingsFormSchema),
    defaultValues: {
      languagePreference: 'en',
      currencyPreference: 'USD',
      themePreference: 'light',
      notificationPreferences: {
        email: true,
        browser: true,
        marketAlerts: true,
        tradingUpdates: true,
        securityAlerts: true,
      },
      privacySettings: {
        showProfileToOthers: true,
        shareTradeHistory: false,
        allowMarketingCommunications: true,
      },
    },
  });

  // Update form when existing settings are loaded
  useEffect(() => {
    if (existingSettings) {
      // Populate form with existing settings
      form.reset({
        languagePreference: existingSettings.languagePreference || 'en',
        currencyPreference: existingSettings.currencyPreference || 'USD',
        themePreference: existingSettings.themePreference || 'light',
        notificationPreferences: {
          email: existingSettings.notificationPreferences?.email ?? true,
          browser: existingSettings.notificationPreferences?.browser ?? true,
          marketAlerts: existingSettings.notificationPreferences?.marketAlerts ?? true,
          tradingUpdates: existingSettings.notificationPreferences?.tradingUpdates ?? true,
          securityAlerts: existingSettings.notificationPreferences?.securityAlerts ?? true,
        },
        privacySettings: {
          showProfileToOthers: existingSettings.privacySettings?.showProfileToOthers ?? true,
          shareTradeHistory: existingSettings.privacySettings?.shareTradeHistory ?? false,
          allowMarketingCommunications: existingSettings.privacySettings?.allowMarketingCommunications ?? true,
        },
      });
    }
  }, [existingSettings, form]);

  async function onSubmit(values: UserSettingsFormValues) {
    if (!user?.id) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to update settings",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);

    try {
      if (existingSettings?.id) {
        // Update existing settings
        await apiRequest(
          "PATCH",
          `/api/user-settings/${existingSettings.id}`,
          values
        );

        toast({
          title: "Settings updated",
          description: "Your settings have been saved successfully.",
        });
      } else {
        // Create new settings
        await apiRequest(
          "POST",
          '/api/user-settings',
          {
            ...values,
            userId: user.id,
          }
        );

        toast({
          title: "Settings created",
          description: "Your settings have been created successfully.",
        });
      }

      // Invalidate the user settings query to refetch the latest data
      queryClient.invalidateQueries({ queryKey: ['/api/user-settings'] });
    } catch (error) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error",
        description: "There was a problem saving your settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  }

  // Create language options
  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Spanish' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' },
    { value: 'zh', label: 'Chinese' },
    { value: 'ja', label: 'Japanese' },
    { value: 'ko', label: 'Korean' },
    { value: 'ar', label: 'Arabic' },
    { value: 'ru', label: 'Russian' },
  ];
  
  // Create currency options
  const currencyOptions = [
    { value: 'USD', label: 'US Dollar ($)' },
    { value: 'EUR', label: 'Euro (€)' },
    { value: 'GBP', label: 'British Pound (£)' },
    { value: 'JPY', label: 'Japanese Yen (¥)' },
    { value: 'CAD', label: 'Canadian Dollar (CA$)' },
    { value: 'AUD', label: 'Australian Dollar (A$)' },
    { value: 'CNY', label: 'Chinese Yuan (¥)' },
    { value: 'AED', label: 'UAE Dirham (د.إ)' },
  ];
  
  // Create theme options
  const themeOptions = [
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System' },
  ];

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg text-textDark">User Settings</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="h-12 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/3"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Language Preference Section */}
              <div className="space-y-4">
                <h3 className="font-medium text-sm text-gray-500 uppercase">Display Settings</h3>
                <FormField
                  control={form.control}
                  name="languagePreference"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Language</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select language" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {languageOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="currencyPreference"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Currency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {currencyOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="themePreference"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Theme</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select theme" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {themeOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Notification Preferences Section */}
              <div className="space-y-4">
                <h3 className="font-medium text-sm text-gray-500 uppercase">Notifications</h3>
                <div className="space-y-3">
                  <FormField
                    control={form.control}
                    name="notificationPreferences.email"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="email-notifications" className="flex-grow">
                          Email Notifications
                        </Label>
                        <FormControl>
                          <Switch
                            id="email-notifications"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notificationPreferences.browser"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="browser-notifications" className="flex-grow">
                          Browser Notifications
                        </Label>
                        <FormControl>
                          <Switch
                            id="browser-notifications"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notificationPreferences.marketAlerts"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="market-alerts" className="flex-grow">
                          Market Alerts
                        </Label>
                        <FormControl>
                          <Switch
                            id="market-alerts"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notificationPreferences.tradingUpdates"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="trading-updates" className="flex-grow">
                          Trading Updates
                        </Label>
                        <FormControl>
                          <Switch
                            id="trading-updates"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notificationPreferences.securityAlerts"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="security-alerts" className="flex-grow">
                          Security Alerts
                        </Label>
                        <FormControl>
                          <Switch
                            id="security-alerts"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />
                </div>
              </div>

              {/* Privacy Settings Section */}
              <div className="space-y-4">
                <h3 className="font-medium text-sm text-gray-500 uppercase">Privacy</h3>
                <div className="space-y-3">
                  <FormField
                    control={form.control}
                    name="privacySettings.showProfileToOthers"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-profile" className="flex-grow">
                          Show profile to other users
                        </Label>
                        <FormControl>
                          <Switch
                            id="show-profile"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="privacySettings.shareTradeHistory"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="share-history" className="flex-grow">
                          Share trade history with other users
                        </Label>
                        <FormControl>
                          <Switch
                            id="share-history"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="privacySettings.allowMarketingCommunications"
                    render={({ field }) => (
                      <div className="flex items-center justify-between">
                        <Label htmlFor="marketing-comms" className="flex-grow">
                          Receive marketing communications
                        </Label>
                        <FormControl>
                          <Switch
                            id="marketing-comms"
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    )}
                  />
                </div>
              </div>

              <CardFooter className="px-0 pt-4">
                <Button type="submit" disabled={isSaving} className="ml-auto">
                  {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Settings
                </Button>
              </CardFooter>
            </form>
          </Form>
        )}
      </CardContent>
    </Card>
  );
}