// WebSocketManagerSingleton.ts
// A singleton wrapper for WebSocketManager for backward compatibility

// Import directly from TypeScript file to avoid circular dependency
import WebSocketManager, { ConnectionStatus } from './WebSocketManager.ts';

/**
 * This class provides a singleton interface for the WebSocketManager
 * It maintains a mapping of URLs to WebSocketManager instances
 * Used for backward compatibility with older code
 */
class WebSocketManagerSingleton {
  private static instance: WebSocketManagerSingleton;
  private managers: Map<string, WebSocketManager> = new Map();
  private listeners: Map<string, Map<Function, Function>> = new Map();
  private statusListeners: ((status: ConnectionStatus) => void)[] = [];
  // Default WebSocket connection URL
  private defaultUrl: string = '';
  // Track current status
  private status: ConnectionStatus = ConnectionStatus.DISCONNECTED;

  private constructor() {
    // Private constructor to enforce singleton pattern
  }

  public static getInstance(): WebSocketManagerSingleton {
    if (!WebSocketManagerSingleton.instance) {
      WebSocketManagerSingleton.instance = new WebSocketManagerSingleton();
    }
    return WebSocketManagerSingleton.instance;
  }
  
  /**
   * Connect to a WebSocket server
   * @param url WebSocket URL to connect to and set as default
   */
  public connect(url: string): void {
    this.defaultUrl = url;
    const manager = this.getManagerForUrl(url);
    manager.connect();
    
    // Forward status updates
    manager.onStatusChange((status) => {
      this.status = status;
      this.notifyStatusListeners(status);
    });
  }
  
  /**
   * Check if the default WebSocket is connected
   * @returns True if connected, false otherwise
   */
  public isConnected(): boolean {
    if (!this.defaultUrl || !this.managers.has(this.defaultUrl)) {
      return false;
    }
    return this.managers.get(this.defaultUrl)!.isConnected();
  }
  
  /**
   * Register a status change listener
   * @param listener Status change callback function
   */
  public onStatusChange(listener: (status: ConnectionStatus) => void): void {
    this.statusListeners.push(listener);
    // Immediately notify of current status
    listener(this.status);
  }
  
  /**
   * Remove a status change listener
   * @param listener Status change callback function to remove
   */
  public offStatusChange(listener: (status: ConnectionStatus) => void): void {
    const index = this.statusListeners.indexOf(listener);
    if (index !== -1) {
      this.statusListeners.splice(index, 1);
    }
  }
  
  /**
   * Notify all status listeners of a status change
   * @param status New connection status
   */
  private notifyStatusListeners(status: ConnectionStatus): void {
    this.statusListeners.forEach(listener => {
      try {
        listener(status);
      } catch (error) {
        console.error("[WebSocketManagerSingleton] Error in status listener:", error);
      }
    });
  }

  /**
   * Get or create a WebSocketManager for a URL
   * @param url WebSocket URL
   * @returns The WebSocketManager instance
   */
  private getManagerForUrl(url: string): WebSocketManager {
    if (!this.managers.has(url)) {
      const manager = new WebSocketManager(url);
      manager.connect();
      this.managers.set(url, manager);
      this.listeners.set(url, new Map());
    }
    return this.managers.get(url)!;
  }

  /**
   * Subscribe to messages from a WebSocket
   * @param url WebSocket URL
   * @param handler Message handler
   */
  public subscribe(url: string, handler: (data: any) => void): void {
    const manager = this.getManagerForUrl(url);
    
    // Create handler mapping for unsubscribe
    if (!this.listeners.has(url)) {
      this.listeners.set(url, new Map());
    }
    
    // We need to create a wrapper function that extracts data from the message
    const wrapperHandler = (message: any) => {
      handler(message);
    };
    
    // Store reference to original and wrapper handlers
    this.listeners.get(url)!.set(handler, wrapperHandler);
    
    // Subscribe to all messages (we'll filter in the wrapper)
    manager.subscribe('message', wrapperHandler);
  }

  /**
   * Unsubscribe from messages
   * @param url WebSocket URL
   * @param handler Message handler
   */
  public unsubscribe(url: string, handler: (data: any) => void): void {
    if (!this.managers.has(url) || !this.listeners.has(url)) {
      return;
    }
    
    const manager = this.managers.get(url)!;
    const listeners = this.listeners.get(url)!;
    
    if (listeners.has(handler)) {
      const wrapperHandler = listeners.get(handler)!;
      manager.unsubscribe('message', wrapperHandler);
      listeners.delete(handler);
    }
  }

  /**
   * Get the connection status for a WebSocket
   * @param url WebSocket URL
   * @returns ConnectionStatus
   */
  public getStatus(url: string): ConnectionStatus {
    if (!this.managers.has(url)) {
      return ConnectionStatus.DISCONNECTED;
    }
    return this.managers.get(url)!.getStatus();
  }

  /**
   * Send a message through a WebSocket
   * @param url WebSocket URL
   * @param message Message to send
   */
  public send(url: string, message: any): boolean {
    const manager = this.getManagerForUrl(url);
    return manager.send('message', message);
  }

  /**
   * Reset a WebSocket connection
   * @param url WebSocket URL
   */
  public reset(url: string): void {
    if (this.managers.has(url)) {
      this.managers.get(url)!.reset();
    }
  }

  /**
   * Close a WebSocket connection
   * @param url WebSocket URL
   */
  public close(url: string): void {
    if (this.managers.has(url)) {
      this.managers.get(url)!.disconnect();
      this.managers.delete(url);
      this.listeners.delete(url);
    }
  }

  /**
   * Close all WebSocket connections
   */
  public closeAll(): void {
    for (const url of this.managers.keys()) {
      this.close(url);
    }
  }
}

// Export the ConnectionStatus enum and the WebSocketManagerSingleton
export { ConnectionStatus };
export default WebSocketManagerSingleton;