import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { DatabaseStorage } from "./storage.js";

// Create an instance of the storage class
const storage = new DatabaseStorage();
import { setupWebsocket, startWebSocketTest } from "./websocket.js";
import { WebSocket } from "ws"; // Add this import here
import { 
  insertUserSchema, 
  insertWatchlistSchema, 
  insertTradeSchema,
  type Asset,
  type PriceHistory,
  type EconomicEvent,
  type User
} from "../shared/schema.js";
import axios from "axios";
import { z } from "zod";
import { log } from "./vite.js";
import { checkRateLimit, createRateLimitedResponse } from "./validation.js";
import { analysisCache, marketDataCache, userCache, assetsCache, economicEventsCache } from "./cache.js";
import { initializeHealthMonitoring, runHealthChecks, cleanupHealthMonitoring, ServiceHealth } from "./health.js";
import { errorHandler, ErrorType, ErrorSeverity } from "./services/errorHandlingService.js";
import adminRouter from "./routes/admin/index.js";
import bonusRouter from "./routes/bonus.js";
import economicCalendarRouter from "./routes/economic-calendar.js";
import { 
  runAllNotificationChecks, 
  checkForEconomicEventNotifications, 
  checkEconomicEventCorrelations, 
  checkUpcomingVolatilityEvents 
} from "./services/notificationService.js";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Setup WebSocket for real-time market data
  const wss = setupWebsocket(httpServer);

  // Register economic calendar routes
  app.use('/api', economicCalendarRouter);

  // تم إيقاف خدمة إرسال بيانات السوق التجريبية بناءً على طلب المستخدم
  // startWebSocketTest(wss);

  // API Routes
  // Initialize health monitoring system
  const healthMonitoring = initializeHealthMonitoring(60); // Check every 60 seconds
  log('Health monitoring system initialized', 'health');

  // Comprehensive health check endpoint
  app.get('/api/health', async (req: Request, res: Response) => {
    try {
      // Run all health checks
      const health = await runHealthChecks();

      // Set appropriate status code based on health status
      if (health.status === ServiceHealth.DOWN) {
        res.status(503); // Service Unavailable
      } else if (health.status === ServiceHealth.DEGRADED) {
        res.status(200); // Still OK but with warnings
      } else {
        res.status(200); // All good
      }

      // Return detailed health information
      res.json(health);
    } catch (error) {
      log(`Error in health endpoint: ${error}`, 'health');
      res.status(500).json({ 
        status: ServiceHealth.DEGRADED,
        message: 'Health check failed to execute',
        timestamp: new Date()
      });
    }
  });

  // Simple health check for load balancers and monitoring tools
  app.get('/api/health/simple', (req: Request, res: Response) => {
    res.json({ status: 'online' });
  });

  // Authentication routes are handled in auth.ts

  // User data route to get authenticated user's data
  app.get('/api/user', (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });

  // User settings routes
  app.get('/api/user-settings', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const userId = req.user.id;

      // الحصول على إعدادات المستخدم من جدول المستخدمين
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // إعداد كائن الإعدادات بناءً على بيانات المستخدم
      const userSettings = {
        id: user.id.toString(),
        userId: user.id.toString(),
        languagePreference: user.languagePreference || 'en',
        currencyPreference: user.currencyPreference || 'USD',
        themePreference: user.themePreference || 'light',
        notificationPreferences: typeof user.notificationPreference === 'object' 
          ? user.notificationPreference 
          : {
              priceAlerts: true,
              newsAlerts: true,
              tradingUpdates: true,
              marketSummaries: true
            },
        privacySettings: typeof user.privacySettings === 'object'
          ? user.privacySettings
          : {
              shareTradeHistory: false,
              showPortfolioValue: true,
              allowDataCollection: true
            },
        createdAt: user.createdAt.toISOString(),
        updatedAt: user.updatedAt ? user.updatedAt.toISOString() : user.createdAt.toISOString()
      };

      res.json(userSettings);
    } catch (error) {
      console.error("Error fetching user settings:", error);
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });

  app.get('/api/user-settings/:id', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const requestedUserId = parseInt(req.params.id);
      const currentUserId = req.user.id;

      // تحقق من أن المستخدم يحاول الوصول إلى بياناته الخاصة فقط أو أنه مسؤول
      if (currentUserId !== requestedUserId && req.user.userRole !== 'admin') {
        return res.status(403).json({ message: "Forbidden - you can only access your own settings" });
      }

      // الحصول على إعدادات المستخدم من جدول المستخدمين
      const user = await storage.getUser(requestedUserId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // إعداد كائن الإعدادات بناءً على بيانات المستخدم
      const userSettings = {
        id: user.id.toString(),
        userId: user.id.toString(),
        languagePreference: user.languagePreference || 'en',
        currencyPreference: user.currencyPreference || 'USD',
        themePreference: user.themePreference || 'light',
        notificationPreferences: typeof user.notificationPreference === 'object' 
          ? user.notificationPreference 
          : {
              priceAlerts: true,
              newsAlerts: true,
              tradingUpdates: true,
              marketSummaries: true
            },
        privacySettings: typeof user.privacySettings === 'object'
          ? user.privacySettings
          : {
              shareTradeHistory: false,
              showPortfolioValue: true,
              allowDataCollection: true
            },
        createdAt: user.createdAt.toISOString(),
        updatedAt: user.updatedAt ? user.updatedAt.toISOString() : user.createdAt.toISOString()
      };

      res.json(userSettings);
    } catch (error) {
      console.error("Error fetching user settings:", error);
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });

  app.post('/api/user-settings', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const userId = req.user.id;
      const settingsData = req.body;

      // تحقق من أن المستخدم يحاول تحديث بياناته الخاصة فقط
      if (parseInt(settingsData.userId) !== userId) {
        return res.status(403).json({ message: "Forbidden - you can only update your own settings" });
      }

      // تحديث إعدادات المستخدم في جدول المستخدمين
      const updates: Partial<User> = {
        languagePreference: settingsData.languagePreference,
        notificationPreference: settingsData.notificationPreferences,
        privacySettings: settingsData.privacySettings
      };

      // إضافة الإعدادات الإضافية إذا كانت متوفرة
      if (settingsData.currencyPreference) {
        updates.currencyPreference = settingsData.currencyPreference;
      }

      if (settingsData.themePreference) {
        updates.themePreference = settingsData.themePreference;
      }

      const updatedUser = await storage.updateUserPreferences(userId, updates);

      // إعداد كائن الرد
      const updatedSettings = {
        id: updatedUser.id.toString(),
        userId: updatedUser.id.toString(),
        languagePreference: updatedUser.languagePreference || 'en',
        currencyPreference: updatedUser.currencyPreference || 'USD',
        themePreference: updatedUser.themePreference || 'light',
        notificationPreferences: typeof updatedUser.notificationPreference === 'object' 
          ? updatedUser.notificationPreference 
          : {
              priceAlerts: true,
              newsAlerts: true,
              tradingUpdates: true,
              marketSummaries: true
            },
        privacySettings: typeof updatedUser.privacySettings === 'object'
          ? updatedUser.privacySettings
          : {
              shareTradeHistory: false,
              showPortfolioValue: true,
              allowDataCollection: true
            },
        createdAt: updatedUser.createdAt.toISOString(),
        updatedAt: updatedUser.updatedAt ? updatedUser.updatedAt.toISOString() : updatedUser.createdAt.toISOString()
      };

      res.json(updatedSettings);
    } catch (error) {
      console.error("Error updating user settings:", error);
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });

  // Update user data
  app.patch('/api/user/:id', async (req: Request, res: Response) => {
    try {
      // تحقق من المصادقة
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // تحقق من أن المستخدم يحاول تحديث بياناته الخاصة فقط
      const userId = parseInt(req.params.id);
      if (req.user.id !== userId) {
        return res.status(403).json({ message: "Forbidden - you can only update your own user data" });
      }

      // تحديث بيانات المستخدم
      const updates = req.body;

      // منع تحديث بعض الحقول الحساسة
      delete updates.id;
      delete updates.password;
      delete updates.email; // إذا أردت السماح بتحديث البريد الإلكتروني، قم بإضافة منطق خاص للتحقق

      try {
        const updatedUser = await storage.updateUserPreferences(userId, updates);
        if (!updatedUser) {
          return res.status(404).json({ message: "User not found" });
        }

        // إزالة كلمة المرور من البيانات المرسلة
        const { password: _, ...userWithoutPassword } = updatedUser;
        res.json(userWithoutPassword);
      } catch (error) {
        return res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Watchlist routes
  app.get('/api/watchlist', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.query.userId as string);

      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Valid userId is required' });
      }

      const watchlistItems = await storage.getWatchlistItems(userId);
      res.json(watchlistItems);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch watchlist' });
    }
  });

  app.post('/api/watchlist', async (req: Request, res: Response) => {
    try {
      const watchlistInput = insertWatchlistSchema.parse(req.body);
      const item = await storage.addToWatchlist(watchlistInput);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to add to watchlist' });
    }
  });

  app.delete('/api/watchlist/:userId/:symbol', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const { symbol } = req.params;

      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Valid userId is required' });
      }

      await storage.removeFromWatchlist(userId, symbol);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: 'Failed to remove from watchlist' });
    }
  });

  // Portfolio routes
  app.get('/api/portfolio', async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const portfolio = await storage.getPortfolioItems(req.user.id);
      const trades = await storage.getUserTrades(req.user.id);
      const summary = await storage.getPortfolioSummary(req.user.id);
      
      res.json({
        portfolio: portfolio || [],
        trades: trades || [],
        summary: {
          totalValue: summary?.totalValue || "0",
          changePercent: summary?.changePercent || "0",
          holdings: summary?.holdings || []
        },
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error("Portfolio fetch error:", error);
      res.status(500).json({ error: "Failed to fetch portfolio data" });
    }
  });
  
  // Get detailed portfolio summary
  app.get('/api/portfolio-summary', async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const detailedSummary = await storage.getDetailedPortfolioSummary(req.user.id);
      
      if (!detailedSummary) {
        // If no detailed summary exists yet, create a default one
        const defaultSummary = {
          userId: req.user.id,
          totalBalance: "0.00",
          totalEquity: "0.00",
          totalProfit: "0.00",
          totalLoss: "0.00",
          openPositions: 0,
          totalInvestment: "0.00",
          availableBalance: "0.00",
          totalReturn: "0.00",
          marginAuthorized: "0.00",
          marginUsed: "0.00",
          unauthorizedPnl: "0.00"
        };
        
        const newSummary = await storage.savePortfolioSummary(defaultSummary);
        res.json(newSummary);
      } else {
        res.json(detailedSummary);
      }
    } catch (error) {
      console.error("Portfolio summary fetch error:", error);
      res.status(500).json({ error: "Failed to fetch portfolio summary data" });
    }
  });

  // Trade routes
  app.post('/api/trades', async (req: Request, res: Response) => {
    try {
      const tradeInput = insertTradeSchema.parse(req.body);

      // Get user
      const user = await storage.getUser(tradeInput.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Calculate total cost/proceeds
      const totalWithCommission = parseFloat(tradeInput.total.toString()) + parseFloat(tradeInput.commission.toString());

      // Check if user has enough balance for buy orders
      if (tradeInput.type === 'buy') {
        const currentBalance = parseFloat(user.balance.toString());
        if (currentBalance < totalWithCommission) {
          return res.status(400).json({ message: 'Insufficient funds' });
        }

        // Update user balance
        const newBalance = (currentBalance - totalWithCommission).toFixed(2);
        await storage.updateUserBalance(user.id, newBalance);
      } else if (tradeInput.type === 'sell') {
        // For sell orders, check if user has the shares
        const portfolioItem = await storage.getPortfolioItem(user.id, tradeInput.symbol);
        if (!portfolioItem || parseFloat(portfolioItem.shares.toString()) < parseFloat(tradeInput.shares.toString())) {
          return res.status(400).json({ message: 'Insufficient shares' });
        }

        // Update user balance (add proceeds)
        const currentBalance = parseFloat(user.balance.toString());
        const newBalance = (currentBalance + parseFloat(tradeInput.total.toString()) - parseFloat(tradeInput.commission.toString())).toFixed(2);
        await storage.updateUserBalance(user.id, newBalance);
      }

      // Create the trade
      const trade = await storage.createTrade(tradeInput);

      // Update portfolio
      const existingItem = await storage.getPortfolioItem(tradeInput.userId, tradeInput.symbol);
      if (tradeInput.type === 'buy') {
        if (existingItem) {
          // Update existing position
          const currentShares = parseFloat(existingItem.shares.toString());
          const currentAvgPrice = parseFloat(existingItem.avgPrice.toString());
          const newShares = currentShares + parseFloat(tradeInput.shares.toString());

          // Calculate new average price
          const newAvgPrice = (
            (currentShares * currentAvgPrice) + parseFloat(tradeInput.total.toString())
          ) / newShares;

          await storage.updatePortfolio({
            userId: tradeInput.userId,
            symbol: tradeInput.symbol,
            shares: newShares.toString(),
            avgPrice: newAvgPrice.toFixed(2)
          });
        } else {
          // Create new position
          await storage.updatePortfolio({
            userId: tradeInput.userId,
            symbol: tradeInput.symbol,
            shares: tradeInput.shares.toString(),
            avgPrice: (parseFloat(tradeInput.total.toString()) / parseFloat(tradeInput.shares.toString())).toFixed(2)
          });
        }
      } else if (tradeInput.type === 'sell' && existingItem) {
        // Update position after sell
        const currentShares = parseFloat(existingItem.shares.toString());
        const newShares = currentShares - parseFloat(tradeInput.shares.toString());

        if (newShares > 0) {
          // Update with remaining shares
          await storage.updatePortfolio({
            userId: tradeInput.userId,
            symbol: tradeInput.symbol,
            shares: newShares.toString(),
            avgPrice: existingItem.avgPrice.toString()
          });
        } else {
          // Remove the position completely
          await storage.updatePortfolio({
            userId: tradeInput.userId,
            symbol: tradeInput.symbol,
            shares: "0",
            avgPrice: "0"
          });
        }
      }

      res.status(201).json(trade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      console.error('Trade error:', error);
      res.status(500).json({ message: 'Failed to process trade' });
    }
  });

  app.get('/api/trades', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.query.userId as string);

      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Valid userId is required' });
      }

      const trades = await storage.getUserTrades(userId);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch trades' });
    }
  });

  // Market data routes
  app.get('/api/market-data', async (req: Request, res: Response) => {
    try {
      if (req.query.symbol) {
        const data = await storage.getMarketData(req.query.symbol as string);
        if (!data) {
          return res.status(404).json({ message: 'Symbol not found' });
        }
        return res.json(data);
      }

      const data = await storage.getAllMarketData();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch market data' });
    }
  });

  // Endpoint to update market data
  app.put('/api/market-data', async (req: Request, res: Response) => {
    try {
      const marketData = req.body;

      if (!marketData || !marketData.symbol || marketData.price === undefined) {
        return res.status(400).json({ message: 'Invalid market data. Symbol and price are required.' });
      }

      // Get current market data for comparison
      const existingData = await storage.getMarketData(marketData.symbol);

      // Update the market data in storage
      const updatedData = await storage.updateMarketData({
        symbol: marketData.symbol,
        price: parseFloat(marketData.price),
        change: marketData.change !== undefined ? parseFloat(marketData.change) : (existingData ? existingData.price - marketData.price : 0),
        changePercent: marketData.changePercent !== undefined ? parseFloat(marketData.changePercent) : 0,
        volume: marketData.volume !== undefined ? parseInt(marketData.volume) : (existingData ? existingData.volume : 0),
        updatedAt: new Date()
      });

      // Send market updates via the WebSocket server that was initialized at line 33
      const message = JSON.stringify({
        type: 'price',
        symbol: marketData.symbol,
        price: parseFloat(marketData.price),
        changePercent: marketData.changePercent !== undefined ? parseFloat(marketData.changePercent) : 0,
        timestamp: Date.now()
      });

      // Broadcast to all connected clients
      if (wss && wss.clients) {
        wss.clients.forEach((client) => {
          if (client.readyState === 1) { // WebSocket.OPEN = 1
            client.send(message);
          }
        });
      }

      // Clear the market data cache
      marketDataCache.delete(marketData.symbol);
      marketDataCache.delete('all_market_data');

      res.json(updatedData);
    } catch (error) {
      console.error('Error updating market data:', error);
      res.status(500).json({ message: 'Failed to update market data' });
    }
  });

  // AI Analysis routes
  app.get('/api/analysis/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const analysis = await storage.getAnalysisForSymbol(symbol);

      if (!analysis) {
        // If no analysis exists, request one from the AI service
        return requestAndSaveAnalysis(symbol, res);
      }

      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch analysis' });
    }
  });

  app.post('/api/analysis/refresh/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const forceRefresh = req.query.force === 'true';
      return requestAndSaveAnalysis(symbol, res, forceRefresh);
    } catch (error) {
      res.status(500).json({ message: 'Failed to refresh analysis' });
    }
  });

  // Asset routes with proper error handling and caching
  app.get('/api/assets', async (req: Request, res: Response) => {
    try {
      // Handle query parameters for filtering
      const { type, sector, country } = req.query;

      // If specific filters are provided, use the filter function
      if (type || sector || country) {
        const filteredAssets = await storage.getAssetsByFilter({
          type: type as string || undefined,
          sector: sector as string || undefined,
          country: country as string || undefined
        });
        return res.json(filteredAssets);
      }

      // If only type is specified, use the type-specific function
      if (type && !sector && !country) {
        const typeAssets = await storage.getAssetsByType(type as string);
        return res.json(typeAssets);
      }

      // Otherwise, get all assets
      const assets = await storage.getAllAssets();
      return res.json(assets);
    } catch (error) {
      // Use error handling service
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { query: req.query }
      );

      res.status(500).json({ 
        message: 'Failed to fetch assets',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get trending assets endpoint
  app.get('/api/assets/trending', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;

      const assets = await storage.getTrendingAssets(limit);

      res.json(assets);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { limit: req.query.limit }
      );

      res.status(500).json({ message: 'Failed to fetch trending assets' });
    }
  });
  
  app.get('/api/assets/featured', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 8;

      const assets = await storage.getFeaturedAssets(limit);

      res.json(assets);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { limit: req.query.limit }
      );

      res.status(500).json({ message: 'Failed to fetch featured assets' });
    }
  });
  
  app.get('/api/assets/movers', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;

      const assets = await storage.getMovers(limit);

      res.json(assets);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { limit: req.query.limit }
      );

      res.status(500).json({ message: 'Failed to fetch market movers' });
    }
  });
  
  // Get recently updated assets (for live data)
  app.get('/api/assets/live', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      
      // If symbols are provided, fetch specific assets
      if (req.query.symbols) {
        const symbols = (req.query.symbols as string).split(',').map(s => s.trim());
        if (symbols.length > 0) {
          const assets = await storage.getAssetsBySymbols(symbols);
          return res.json(assets);
        }
      }
      
      // Otherwise, get the most recently updated assets
      const assets = await storage.getRecentlyUpdatedAssets(limit);
      
      res.json(assets);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { limit: req.query.limit, symbols: req.query.symbols }
      );
      
      res.status(500).json({ message: 'Failed to fetch live asset data' });
    }
  });

  // Get asset by symbol 
  app.get('/api/assets/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const asset = await storage.getAsset(symbol);

      if (!asset) {
        return res.status(404).json({ message: 'Asset not found' });
      }

      res.json(asset);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { symbol: req.params.symbol }
      );

      res.status(500).json({ message: 'Failed to fetch asset' });
    }
  });

  // Price history routes with caching and pagination
  app.get('/api/price-history/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const { interval = '1d', limit = '100' } = req.query;

      // Validate parameters
      if (!symbol) {
        return res.status(400).json({ message: 'Symbol is required' });
      }

      // Check if the asset exists
      const asset = await storage.getAsset(symbol);
      if (!asset) {
        return res.status(404).json({ message: 'Asset not found' });
      }

      // Get price history with the specified interval and limit
      const priceHistory = await storage.getPriceHistory(
        symbol,
        interval as string,
        parseInt(limit as string, 10)
      );

      res.json(priceHistory);
    } catch (error) {
      // Use error handling service
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'price_history',
        { 
          symbol: req.params.symbol,
          interval: req.query.interval,
          limit: req.query.limit
        }
      );

      res.status(500).json({ message: 'Failed to fetch price history' });
    }
  });

  app.get('/api/price-history/:symbol/range', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const { start, end, interval = '1d' } = req.query;

      // Validate parameters
      if (!symbol || !start || !end) {
        return res.status(400).json({ 
          message: 'Symbol, start date, and end date are required',
          required: {
            symbol: 'Asset symbol',
            start: 'Start date (ISO format)',
            end: 'End date (ISO format)',
            interval: 'Optional: Data interval (e.g., 1m, 5m, 15m, 1h, 4h, 1d, 1w, 1mo)'
          }
        });
      }

      // Parse dates
      let startDate: Date, endDate: Date;
      try {
        startDate = new Date(start as string);
        endDate = new Date(end as string);

        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
          throw new Error('Invalid date format');
        }
      } catch (err) {
        return res.status(400).json({ 
          message: 'Invalid date format',
          details: 'Dates must be in ISO format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS.sssZ)'
        });
      }

      // Get price history within the date range
      const priceHistory = await storage.getPriceHistoryByDateRange(
        symbol,
        startDate,
        endDate,
        interval as string
      );

      res.json(priceHistory);
    } catch (error) {
      // Use error handling service
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'price_history',
        { 
          symbol: req.params.symbol,
          start: req.query.start,
          end: req.query.end,
          interval: req.query.interval
        }
      );

      res.status(500).json({ message: 'Failed to fetch price history for date range' });
    }
  });

  // Economic Events routes with caching
  app.get('/api/economic-events', async (req: Request, res: Response) => {
    try {
      const { limit = '50', country, impact } = req.query;

      // Handle specific filtering scenarios
      if (country) {
        const events = await storage.getEconomicEventsByCountry(country as string);
        return res.json(events);
      }

      if (impact) {
        const events = await storage.getEconomicEventsByImpact(impact as string);
        return res.json(events);
      }

      // Default to getting all economic events with a limit
      const events = await storage.getEconomicEvents(parseInt(limit as string, 10));
      res.json(events);
    } catch (error) {
      // Use error handling service
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'economic_events',
        { query: req.query }
      );

      res.status(500).json({ message: 'Failed to fetch economic events' });
    }
  });

  // Get upcoming events for the next few days
  app.get('/api/economic-events/upcoming', async (req: Request, res: Response) => {
    try {
      // Default to 7 days and Medium impact
      const { days = '7', impact = 'medium' } = req.query;

      // Import and use the economic event service
      const { getUpcomingEvents } = await import('./services/economicEventService.js');

      // Note: getUpcomingEvents will normalize impact level case internally
      const events = await getUpcomingEvents(
        parseInt(days as string, 10),
        impact as string
      );

      res.json(events);
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'economic_events',
        { source: 'getUpcomingEvents', query: req.query }
      );

      res.status(500).json({ message: 'Failed to fetch upcoming economic events' });
    }
  });

  // Get economic events affecting a specific asset
  app.get('/api/economic-events/asset/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const { threshold = '2.0', limit = '10' } = req.query;

      // Validate symbol
      if (!symbol) {
        return res.status(400).json({ message: 'Asset symbol is required' });
      }

      // Import and use the economic event service
      const { findSignificantEventsForAsset } = await import('./services/economicEventService.js');

      const events = await findSignificantEventsForAsset(
        symbol,
        parseFloat(threshold as string),
        parseInt(limit as string, 10)
      );

      res.json(events);
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'economic_events',
        { 
          source: 'findSignificantEventsForAsset', 
          symbol: req.params.symbol, 
          query: req.query 
        }
      );

      res.status(500).json({ message: 'Failed to fetch economic events for the specified asset' });
    }
  });

  // Get events affected by market movements
  app.get('/api/economic-events/movement/:symbol', async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const { date, days = '3' } = req.query;

      // Validate parameters
      if (!symbol) {
        return res.status(400).json({ message: 'Asset symbol is required' });
      }

      if (!date) {
        return res.status(400).json({ message: 'Event date is required (ISO format)' });
      }

      // Parse date
      let eventDate: Date;
      try {
        eventDate = new Date(date as string);
        if (isNaN(eventDate.getTime())) {
          throw new Error('Invalid date');
        }
      } catch (err) {
        return res.status(400).json({ 
          message: 'Invalid date format',
          details: 'Date must be in ISO format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS.sssZ)'
        });
      }

      // Import and use the economic event service
      const { findMarketMovementAroundEvent } = await import('./services/economicEventService.js');

      const movement = await findMarketMovementAroundEvent(
        symbol,
        eventDate,
        parseInt(days as string, 10)
      );

      res.json(movement);
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'price_history',
        { 
          source: 'findMarketMovementAroundEvent', 
          symbol: req.params.symbol, 
          date: req.query.date 
        }
      );

      res.status(500).json({ message: 'Failed to analyze market movement around the event' });
    }
  });

  // Get economic events that might affect a user's portfolio
  app.get('/api/economic-events/portfolio/:userId', async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const { days = '7' } = req.query;

      // Validate parameters
      if (!userId || isNaN(parseInt(userId, 10))) {
        return res.status(400).json({ message: 'Valid user ID is required' });
      }

      // Import and use the economic event service
      const { getEventsForPortfolio } = await import('./services/economicEventService.js');

      const events = await getEventsForPortfolio(
        parseInt(userId, 10),
        parseInt(days as string, 10)
      );

      res.json(events);
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'economic_events',
        { 
          source: 'getEventsForPortfolio', 
          userId: req.params.userId, 
          days: req.query.days 
        }
      );

      res.status(500).json({ message: 'Failed to fetch economic events for the user portfolio' });
    }
  });

  app.get('/api/economic-events/range', async (req: Request, res: Response) => {
    try {
      const { start, end } = req.query;

      // Validate parameters
      if (!start || !end) {
        return res.status(400).json({ 
          message: 'Start date and end date are required',
          required: {
            start: 'Start date (ISO format)',
            end: 'End date (ISO format)'
          }
        });
      }

      // Parse dates
      let startDate: Date, endDate: Date;
      try {
        startDate = new Date(start as string);
        endDate = new Date(end as string);

        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
          throw new Error('Invalid date format');
        }
      } catch (err) {
        return res.status(400).json({ 
          message: 'Invalid date format',
          details: 'Dates must be in ISO format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS.sssZ)'
        });
      }

      // We'll pass the Date objects directly to the database layer
      // The storage layer will handle proper SQL conversion

      // Get economic events within the date range
      const events = await storage.getEconomicEventsByDateRange(startDate, endDate);
      res.json(events);
    } catch (error) {
      // Use error handling service
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'economic_events',
        { 
          start: req.query.start,
          end: req.query.end
        }
      );

      res.status(500).json({ message: 'Failed to fetch economic events for date range' });
    }
  });

  async function requestAndSaveAnalysis(symbol: string, res: Response, forceRefresh: boolean = false) {
    // Use a unique client ID for rate limiting based on the symbol
    // This is a simple approach - in production you'd use IP, API key, or user ID
    const clientId = `analysis_${symbol}`;

    try {
      const aiServiceUrl = process.env.AI_SERVICE_URL || 'http://0.0.0.0:5000';
      const deepseekApiKey = process.env.DEEPSEEK_API_KEY;
      const useArabicModel = process.env.USE_ARABIC_MODEL === 'true';

      // Try to get from cache first (if we have a cached analysis and not forcing refresh)
      const cachedAnalysis = analysisCache.get(symbol);
      if (cachedAnalysis && !forceRefresh) {
        log(`Using cached analysis for ${symbol}`, 'ai');
        return res.json(cachedAnalysis);
      }

      // If we're forcing a refresh, clear this item from cache
      if (forceRefresh && cachedAnalysis) {
        log(`Force refreshing analysis for ${symbol}`, 'ai');
        analysisCache.delete(symbol);
      }

      // Get market data for the symbol
      const marketData = await storage.getMarketData(symbol);
      if (!marketData) {
        return res.status(404).json({ message: 'Symbol not found in market data' });
      }

      let englishAnalysis;
      let indicators;
      let arabicAnalysis = null;
      let usedDeepSeekFallback = false;

      try {
        // Try the local AI service first
        log(`Requesting analysis from local AI service at ${aiServiceUrl}`, 'ai');

        // Request analysis from AI service with timeout and error handling
        const englishResponse = await axios.post(`${aiServiceUrl}/analyze`, {
          symbol: symbol,
          price: marketData.price.toString(),
          change: marketData.change.toString(),
          changePercent: marketData.changePercent.toString()
        }, { 
          timeout: 5000, // 5 second timeout to fail fast if service is down
          validateStatus: (status) => status === 200 // Only accept 200 responses
        });

        englishAnalysis = englishResponse.data.analysis;
        indicators = englishResponse.data.indicators;

        if (useArabicModel) {
          // Also request Arabic analysis if enabled (in parallel using a worker thread)
          const arabicRequestPromise = new Promise<string>(async (resolve, reject) => {
            try {
              // Run in a separate flow to avoid blocking main thread
              setTimeout(async () => {
                try {
                  const arabicResponse = await axios.post(`${aiServiceUrl}/analyze/arabic`, {
                    symbol: symbol,
                    price: marketData.price.toString(),
                    change: marketData.change.toString(),
                    changePercent: marketData.changePercent.toString()
                  }, { timeout: 8000 }); // Longer timeout for Arabic model

                  resolve(arabicResponse.data.analysis);
                } catch (arabicError) {
                  // Log Arabic-specific error but don't fail the whole request
                  log(`DeepSeek API fallback for ${symbol} (arabic): ${arabicError}`, 'ai');

                  // If we have DeepSeek API key, try to translate the English analysis
                  if (deepseekApiKey && checkRateLimit(clientId, 'deepseek')) {
                    try {
                      log(`Falling back to DeepSeek for Arabic translation of ${symbol}`, 'ai');

                      const arabicPrompt = `
                      Translate the following market analysis to formal Arabic:

                      ${englishAnalysis}
                      `;

                      const arabicDeepseekResponse = await axios.post(
                        'https://api.deepseek.com/v1/chat/completions',
                        {
                          model: "deepseek-chat",
                          messages: [{ role: "user", content: arabicPrompt }],
                          temperature: 0.3,
                          max_tokens: 1000
                        },
                        {
                          headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${deepseekApiKey}`
                          }
                        }
                      );

                      const arabicTranslation = arabicDeepseekResponse.data.choices[0].message.content;
                      log(`Successfully translated ${symbol} analysis to Arabic via DeepSeek`, 'ai');
                      resolve(arabicTranslation);
                    } catch (deepseekError) {
                      // If DeepSeek also fails, just return null for arabicAnalysis
                      log(`DeepSeek Arabic translation failed: ${deepseekError}`, 'ai');
                      reject(deepseekError);
                    }
                  } else {
                    // No DeepSeek API key or rate limited
                    reject(arabicError);
                  }
                }
              }, 0);
            } catch (error) {
              reject(error);
            }
          });

          // Wait for Arabic translation with timeout
          try {
            arabicAnalysis = await Promise.race([
              arabicRequestPromise,
              new Promise<null>((resolve) => setTimeout(() => resolve(null), 10000)) // 10 second max wait
            ]);

            if (arabicAnalysis === null) {
              log(`Arabic translation timed out for ${symbol}`, 'ai');
            }
          } catch (arabicError) {
            log(`Arabic translation failed: ${arabicError}`, 'ai');
            // Continue without Arabic translation
          }
        }
      } catch (localAiError) {
        // Log the local AI service failure
        log(`DeepSeek API fallback for ${symbol} (english): ${localAiError instanceof Error ? localAiError.message : String(localAiError)}`, 'ai');
        log(`Local AI service failed: ${localAiError.message}. Falling back to DeepSeek API.`, 'ai');

        // Check if we can use DeepSeek API as fallback
        if (!deepseekApiKey) {
          log('No DeepSeek API key found in environment.', 'ai');
          throw new Error('AI service unavailable and no DeepSeek API key configured');
        }

        // Check rate limit before making the API call
        if (!checkRateLimit(clientId, 'deepseek')) {
          log(`Rate limit exceeded for DeepSeek API request for ${symbol}`, 'ai');
          return res.status(429).json({ 
            message: 'Rate limit exceeded for AI analysis. Please try again later.',
            retryAfter: 60 // Suggest retry after 1 minute
          });
        }

        usedDeepSeekFallback = true;

        // Construct market analysis prompt for DeepSeek
        const prompt = `
        Analyze the following stock/cryptocurrency:
        Symbol: ${symbol}
        Current Price: ${marketData.price.toString()}
        Change: ${marketData.change.toString()} (${marketData.changePercent.toString()}%)

        Provide a comprehensive market analysis including:
        1. Technical indicators assessment
        2. Recent price movement analysis
        3. Market sentiment
        4. Short-term price prediction

        Format your response as a JSON object with the following structure:
        {
          "analysis": "Your detailed market analysis here...",
          "indicators": {
            "rsi": number (0-100),
            "macd": "bullish" or "bearish",
            "moving_average": "uptrend" or "downtrend"
          }
        }
        `;

        try {
          // Call DeepSeek API with proper error handling
          log(`Requesting analysis from DeepSeek API for ${symbol}`, 'ai');
          const deepseekResponse = await axios.post(
            'https://api.deepseek.com/v1/chat/completions',
            {
              model: "deepseek-chat",
              messages: [{ role: "user", content: prompt }],
              response_format: { type: "json_object" },
              temperature: 0.3,
              max_tokens: 1000
            },
            {
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${deepseekApiKey}`
              },
              timeout: 15000 // 15 second timeout for external API
            }
          );

          // Parse DeepSeek response
          const content = deepseekResponse.data.choices[0].message.content;
          let parsedContent;

          try {
            parsedContent = JSON.parse(content);
          } catch (parseError) {
            log(`Failed to parse DeepSeek response for ${symbol}: ${parseError}`, 'ai');
            // Try to salvage analysis by extracting from non-JSON response
            const analysisMatch = content.match(/\"analysis\"\s*:\s*\"(.*?)\"/);
            const rsiMatch = content.match(/\"rsi\"\s*:\s*(\d+)/);
            const macdMatch = content.match(/\"macd\"\s*:\s*\"(bullish|bearish)\"/);
            const movingAvgMatch = content.match(/\"moving_average\"\s*:\s*\"(uptrend|downtrend)\"/);

            if (analysisMatch && rsiMatch && macdMatch && movingAvgMatch) {
              parsedContent = {
                analysis: analysisMatch[1],
                indicators: {
                  rsi: parseInt(rsiMatch[1]),
                  macd: macdMatch[1],
                  moving_average: movingAvgMatch[1]
                }
              };
              log(`Salvaged partial analysis for ${symbol} from malformed JSON`, 'ai');
            } else {
              throw new Error('Could not parse or salvage DeepSeek response');
            }
          }

          englishAnalysis = parsedContent.analysis;
          indicators = parsedContent.indicators;

          // If Arabic analysis is required and we haven't already obtained it
          if (useArabicModel && !arabicAnalysis) {
            // Check rate limit for the Arabic translation request
            if (checkRateLimit(`${clientId}_arabic`, 'deepseek')) {
              try {
                log(`Requesting Arabic translation from DeepSeek for ${symbol}`, 'ai');
                const arabicPrompt = `
                Translate the following market analysis to formal Arabic:

                ${englishAnalysis}
                `;

                const arabicDeepseekResponse = await axios.post(
                  'https://api.deepseek.com/v1/chat/completions',
                  {
                    model: "deepseek-chat",
                    messages: [{ role: "user", content: arabicPrompt }],
                    temperature: 0.3,
                    max_tokens: 1000
                  },
                  {
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${deepseekApiKey}`
                    },
                    timeout: 10000 // 10 second timeout for translation
                  }
                );

                arabicAnalysis = arabicDeepseekResponse.data.choices[0].message.content;
                log(`Successfully translated ${symbol} analysis to Arabic via DeepSeek`, 'ai');
              } catch (arabicError) {
                log(`DeepSeek Arabic translation failed: ${arabicError}`, 'ai');
                arabicAnalysis = null; // Proceed without Arabic translation
              }
            } else {
              log(`Rate limit exceeded for Arabic translation of ${symbol}`, 'ai');
              arabicAnalysis = null; // Skip translation due to rate limit
            }
          }
        } catch (deepseekError) {
          // Handle DeepSeek API errors
          log(`DeepSeek API error for ${symbol}: ${deepseekError}`, 'ai');

          // Send a more specific error response based on the error
          if (deepseekError.response?.status === 429) {
            return res.status(429).json({
              message: 'DeepSeek API rate limit exceeded. Please try again later.',
              retryAfter: 300 // 5 minutes
            });
          } else {
            throw new Error(`DeepSeek API error: ${deepseekError.message}`);
          }
        }
      }

      // Calculate prediction based on indicators - handle different formats safely
      // First, determine if macd is a string or an object with components
      let macdSentiment = 'neutral';
      if (indicators && indicators.macd) {
        // Handle string macd value (e.g., 'bullish' or 'bearish')
        if (typeof indicators.macd === 'string') {
          macdSentiment = indicators.macd;
        } 
        // Handle object macd value (e.g., {value: "-0.70", signal: "0.73", histogram: "0.14"})
        else if (typeof indicators.macd === 'object' && indicators.macd.value && indicators.macd.signal) {
          // If histogram is positive, consider bullish
          if (indicators.macd.histogram && parseFloat(indicators.macd.histogram) > 0) {
            macdSentiment = 'bullish';
          } else {
            macdSentiment = 'bearish';
          }
        }
      }

      const prediction = {
        direction: macdSentiment === 'bullish' ? 'up' : 'down',
        target: (parseFloat(marketData.price.toString()) * 
                (1 + (macdSentiment === 'bullish' ? 0.03 : -0.02))).toFixed(2),
        days: 7
      };

      let confidence = "75.00"; // Default confidence
      if (indicators && typeof indicators.rsi === 'number') {
        confidence = (indicators.rsi > 70 || indicators.rsi < 30) ? "85.00" : "75.00";
      }

      // Ensure we have a valid analysis text to save to database
      const defaultAnalysis = `Analysis for ${symbol} at ${new Date().toISOString()}. 
The current price is ${marketData.price} with a recent change of ${marketData.change} (${marketData.changePercent}%). 
Based on technical indicators, the market sentiment appears to be ${macdSentiment}.`;

      // Save analysis to database with fallback for missing values
      const newAnalysis = await storage.saveAnalysis({
        symbol: symbol,
        analysis: englishAnalysis || defaultAnalysis,
        arabicAnalysis: arabicAnalysis,
        indicators: indicators || { 
          rsi: 50, 
          macd: macdSentiment, 
          ema: { ema9: "0", ema21: "0" }, 
          sma: { sma50: "0", sma200: "0" } 
        },
        prediction: prediction,
        confidence: confidence
      });

      // Add fallback information in response
      const responseData = {
        ...newAnalysis,
        meta: {
          usedFallback: usedDeepSeekFallback,
          generatedAt: new Date().toISOString(),
          hasArabicTranslation: !!arabicAnalysis
        }
      };

      // Create rate-limited response with headers
      const rateLimitedResponse = createRateLimitedResponse(
        responseData,
        clientId,
        usedDeepSeekFallback ? 'deepseek' : 'default'
      );

      // Set rate limit headers
      res.set({
        'X-RateLimit-Remaining': rateLimitedResponse.rateLimit.remaining.toString(),
        'X-RateLimit-Reset': new Date(rateLimitedResponse.rateLimit.reset).toISOString()
      });

      res.json(rateLimitedResponse.data);
    } catch (error) {
      console.error('AI analysis error:', error);
      res.status(500).json({ 
        message: 'Failed to get AI analysis', 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Admin monitoring endpoints
  app.get('/api/admin/error-stats', (req: Request, res: Response) => {
    try {
      const stats = errorHandler.getErrorStats();
      res.json(stats);
    } catch (error) {
      console.error('Failed to get error stats:', error);
      res.status(500).json({ error: 'Failed to retrieve error statistics' });
    }
  });

  app.get('/api/admin/recent-errors', (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const errors = errorHandler.getRecentErrors(limit);
      res.json(errors);
    } catch (error) {
      console.error('Failed to get recent errors:', error);
      res.status(500).json({ error: 'Failed to retrieve recent errors' });
    }
  });

  app.post('/api/admin/reset-error-stats', (req: Request, res: Response) => {
    try {
      errorHandler.resetStats();
      res.json({ success: true, message: 'Error statistics have been reset' });
    } catch (error) {
      console.error('Failed to reset error stats:', error);
      res.status(500).json({ error: 'Failed to reset error statistics' });
    }
  });

  app.get('/api/admin/cache-stats', (req: Request, res: Response) => {
    try {
      const stats = {
        marketData: marketDataCache.getStats(),
        analysis: analysisCache.getStats(),
        users: userCache.getStats(),
        assets: assetsCache.getStats(),
        economicEvents: economicEventsCache.getStats()
      };
      res.json(stats);
    } catch (error) {
      console.error('Failed to get cache stats:', error);
      res.status(500).json({ error: 'Failed to retrieve cache statistics' });
    }
  });

  app.post('/api/admin/clear-cache', (req: Request, res: Response) => {
    try {
      const { cache } = req.body;

      if (cache === 'all') {
        marketDataCache.clear();
        analysisCache.clear();
        userCache.clear();
        assetsCache.clear();
        economicEventsCache.clear();
        res.json({ success: true, message: 'All caches cleared' });
      } else if (cache === 'marketData') {
        marketDataCache.clear();
        res.json({ success: true, message: 'Market data cache cleared' });
      } else if (cache === 'analysis') {
        analysisCache.clear();
        res.json({ success: true, message: 'Analysis cache cleared' });
      } else if (cache === 'users') {
        userCache.clear();
        res.json({ success: true, message: 'User cache cleared' });
      } else if (cache === 'assets') {
        assetsCache.clear();
        res.json({ success: true, message: 'Assets cache cleared' });
      } else if (cache === 'economicEvents') {
        economicEventsCache.clear();
        res.json({ success: true, message: 'Economic events cache cleared' });
      } else {
        res.status(400).json({ error: 'Invalid cache specified' });
      }
    } catch (error) {
      console.error('Failed to clear cache:', error);
      res.status(500).json({ error: 'Failed to clear cache' });
    }
  });

  // Test endpoint for triggering notifications without admin auth
  app.post('/api/test/trigger-notifications', async (req: Request, res: Response) => {
    try {
      const { types = ['all'], userId } = req.body;

      console.log(`[TEST] Manually triggering notifications: ${types.join(', ')}`);

      const results = { triggered: [], errors: [], timing: {} };

      // Check which notification types to trigger
      const triggerAll = types.includes('all');
      const triggerEconomicEvents = triggerAll || types.includes('economic_events');
      const triggerCorrelations = triggerAll || types.includes('correlations');
      const triggerVolatility = triggerAll || types.includes('volatility');

      // Get user ID from request if provided (default to user 1)
      const targetUserId = userId || 1;

      // Run the notification checks based on requested types
      if (triggerEconomicEvents) {
        try {
          const start = Date.now();
          await checkForEconomicEventNotifications();
          const duration = Date.now() - start;
          results.triggered.push('economic_events');
          results.timing['economic_events'] = `${duration}ms`;
        } catch (error) {
          console.error("Error triggering economic event notifications:", error);
          results.errors.push({
            type: 'economic_events',
            message: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      if (triggerCorrelations) {
        try {
          const start = Date.now();
          await checkEconomicEventCorrelations();
          const duration = Date.now() - start;
          results.triggered.push('correlations');
          results.timing['correlations'] = `${duration}ms`;
        } catch (error) {
          console.error("Error triggering correlation notifications:", error);
          results.errors.push({
            type: 'correlations',
            message: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      if (triggerVolatility) {
        try {
          const start = Date.now();
          await checkUpcomingVolatilityEvents();
          const duration = Date.now() - start;
          results.triggered.push('volatility');
          results.timing['volatility'] = `${duration}ms`;
        } catch (error) {
          console.error("Error triggering volatility notifications:", error);
          results.errors.push({
            type: 'volatility',
            message: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      // Run all checks at once if requested
      if (triggerAll && types.length === 1) {
        try {
          const start = Date.now();
          await runAllNotificationChecks();
          const duration = Date.now() - start;
          results.timing['all_combined'] = `${duration}ms`;
        } catch (error) {
          console.error("Error triggering all notifications:", error);
          results.errors.push({
            type: 'all_combined',
            message: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      res.json({
        success: true,
        triggered: Date.now(),
        results
      });
    } catch (error) {
      console.error("Error in test trigger-notifications endpoint:", error);
      res.status(500).json({ 
        error: "Failed to trigger notifications",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Mount admin routes
  app.use('/api/admin', adminRouter);
  app.use('/api/bonuses', bonusRouter);

  // Portfolio summary route
  app.get("/api/portfolio-summary", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const summary = await storage.getPortfolioSummary(req.user.id);
      res.json({
        totalValue: summary?.totalValue || "0",
        changePercent: summary?.changePercent || "0", 
        holdings: summary?.holdings || [],
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error("Portfolio summary error:", error);
      res.status(500).json({ error: "Failed to fetch portfolio summary" });
    }
  });

  return httpServer;
}