#!/usr/bin/env node

/**
 * Type Issues Identification Script
 *
 * This script scans the codebase for components with potential type issues
 * and identifies files that need to use the shared types and validation utilities.
 */

const fs = require('fs');
const path = require('path');
const glob = require('glob');

// Configuration
const sourceDir = path.resolve(__dirname, '../src');
const componentsGlob = `${sourceDir}/**/*.{tsx,ts,jsx,js}`;

// Parse command line arguments
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');

// Patterns that indicate type issues
const typeIssuePatterns = [
  'any',
  'object',
  'unknown',
  'Function',
  ': {',
  'Record<string',
  'type: string',
  'as any',
  'as unknown',
];

// Patterns that indicate proper type usage
const goodTypePatterns = [
  'import { MarketData',
  'import { Asset',
  'import { Order',
  'import { Position',
  'import { User',
  'import { Portfolio',
  'import type { MarketData',
  'import type { Asset',
  'import type { Order',
  'import type { Position',
  'import type { User',
  'import type { Portfolio',
];

// Patterns that indicate validation usage
const validationPatterns = [
  'validateApiResponse',
  'string(',
  'number(',
  'boolean(',
  'object(',
  'array(',
  'ValidationError',
];

// Check if a file has potential type issues
function hasPotentialTypeIssues(content) {
  // Consider files with React components or functions with potential type issues
  return (content.includes('React.FC') || content.includes('function') || content.includes('const') || content.includes('class')) && 
         typeIssuePatterns.some(pattern => content.includes(pattern));
}

// Check if a file already uses shared types
function usesSharedTypes(content) {
  return goodTypePatterns.some(pattern => content.includes(pattern));
}

// Check if a file uses validation utilities
function usesValidation(content) {
  return validationPatterns.some(pattern => content.includes(pattern));
}

// Main function
async function main() {
  try {
    // Find all component files
    const files = glob.sync(componentsGlob);
    console.log(`Scanning ${files.length} files for type issues...`);
    
    const needsTypeUpdateList = [];
    const needsValidationList = [];
    const goodTypesList = [];
    
    for (const file of files) {
      // Skip files in the node_modules directory and test files
      if (file.includes('node_modules') || file.includes('.test.') || file.includes('.spec.')) {
        continue;
      }
      
      const content = fs.readFileSync(file, 'utf8');
      
      // Check if file has API calls that might need validation
      const hasApiCalls = content.includes('api.') && 
        (content.includes('.then(') || content.includes('await api.'));
      
      const usesTypes = usesSharedTypes(content);
      const usesValidationUtils = usesValidation(content);
      const hasPotentialIssues = hasPotentialTypeIssues(content);
      
      if (hasPotentialIssues && !usesTypes) {
        needsTypeUpdateList.push(file);
      } else if (usesTypes) {
        goodTypesList.push(file);
      }
      
      if (hasApiCalls && !usesValidationUtils) {
        needsValidationList.push(file);
      }
    }
    
    // Print results
    console.log('\n=== Type Issues Report ===\n');
    
    console.log(`Found ${needsTypeUpdateList.length} files with potential type issues that need updates.`);
    console.log(`Found ${needsValidationList.length} files with API calls that could benefit from validation.`);
    console.log(`Found ${goodTypesList.length} files already using shared types.\n`);
    
    if (needsTypeUpdateList.length > 0) {
      console.log('Files that need type updates:');
      needsTypeUpdateList.forEach(file => {
        const relativePath = path.relative(process.cwd(), file);
        console.log(`- ${relativePath}`);
      });
      console.log();
    }
    
    if (needsValidationList.length > 0) {
      console.log('Files that could benefit from validation utilities:');
      needsValidationList.forEach(file => {
        const relativePath = path.relative(process.cwd(), file);
        console.log(`- ${relativePath}`);
      });
      console.log();
    }
    
    // Output actionable items
    if (needsTypeUpdateList.length > 0 || needsValidationList.length > 0) {
      console.log('Next steps:');
      console.log('1. Update components to use shared types from src/types');
      console.log('2. Add validation to API responses using validateApiResponse');
      console.log('3. Run the add-validation.js script to automatically add validation to API calls');
      console.log('4. Refer to the VALIDATION_GUIDE.md for implementation details');
    } else {
      console.log('✅ All files are using proper types and validation!');
    }
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Run the script
main(); 