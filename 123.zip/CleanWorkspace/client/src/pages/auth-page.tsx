import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import SignInForm from '@/components/auth/SignInForm';
import SignUpForm from '@/components/auth/SignUpForm';
import { useAuth } from '@/lib/authContext';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState('signin');
  const { isAuthenticated } = useAuth();
  const [_, navigate] = useLocation();

  // If user is already authenticated, redirect to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="flex min-h-screen bg-muted/30">
      {/* Left column - Forms */}
      <div className="flex items-center justify-center flex-1 p-4 md:p-8">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold">Pro Trading Platform</h1>
            <p className="mt-2 text-muted-foreground">
              {activeTab === 'signin' 
                ? 'Sign in to access your trading dashboard' 
                : 'Create an account to start trading'}
            </p>
          </div>

          <Tabs 
            defaultValue="signin" 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="signin">Sign In</TabsTrigger>
              <TabsTrigger value="signup">Create Account</TabsTrigger>
            </TabsList>
            
            <TabsContent value="signin">
              <SignInForm />
            </TabsContent>
            
            <TabsContent value="signup">
              <SignUpForm />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Right column - Hero section */}
      <div className="hidden md:flex md:w-1/2 bg-primary text-primary-foreground">
        <div className="flex flex-col items-start justify-center p-12 space-y-8">
          <div>
            <h2 className="text-4xl font-bold">Welcome to Pro Trading</h2>
            <p className="mt-4 text-xl">
              The most comprehensive trading platform for stocks, crypto, and more.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="mt-1 bg-primary-foreground/20 p-1 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Real-time Market Data</h3>
                <p className="text-primary-foreground/80">Stay updated with live stock and crypto prices</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="mt-1 bg-primary-foreground/20 p-1 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Portfolio Management</h3>
                <p className="text-primary-foreground/80">Track and manage your investments in one place</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="mt-1 bg-primary-foreground/20 p-1 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Advanced Analytics</h3>
                <p className="text-primary-foreground/80">Powerful tools to analyze market trends</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="mt-1 bg-primary-foreground/20 p-1 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Copy Trading</h3>
                <p className="text-primary-foreground/80">Follow and copy successful traders automatically</p>
              </div>
            </div>
          </div>

          <div className="pt-4">
            <Button variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
              Learn More About Pro Trading
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}