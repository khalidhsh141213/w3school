import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import Backend from 'i18next-http-backend';

// Import translations
import enTranslation from '../locales/en/translation.json';
import arTranslation from '../locales/ar/translation.json';

// Initialize i18next
i18n
  // HTTP backend for loading translations from server (optional, not used here as we import directly)
  .use(Backend)
  // Detect user language
  .use(LanguageDetector)
  // Pass the i18n instance to react-i18next
  .use(initReactI18next)
  // Initialize i18next
  .init({
    // Default resources - we load them directly in this file
    resources: {
      en: {
        translation: enTranslation,
      },
      ar: {
        translation: arTranslation,
      },
    },
    // Default language
    fallbackLng: 'en',
    // Debug mode (turn off in production)
    debug: process.env.NODE_ENV === 'development',

    // Detection options
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },

    interpolation: {
      escapeValue: false, // React already escapes values
    },

    // React specific settings
    react: {
      useSuspense: true,
    },

    backend: {
      loadPath: '/locales/{{lng}}/{{ns}}.json',
    },
  });

// Function to set language with RTL support
export const setLanguage = (language: string) => {
  i18n.changeLanguage(language);
  
  // Handle RTL for Arabic
  if (language === 'ar') {
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
    document.body.classList.add('rtl');
  } else {
    document.documentElement.dir = 'ltr';
    document.documentElement.lang = language;
    document.body.classList.remove('rtl');
  }
  
  // Save selected language to localStorage
  localStorage.setItem('i18nextLng', language);
};

export default i18n; 