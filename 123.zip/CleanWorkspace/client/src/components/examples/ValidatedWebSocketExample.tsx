import React, { useEffect, useRef, useState } from 'react';
import {
    number,
    object,
    string,
    validateApiResponse,
    ValidationError
} from '../../lib/validation';
import { WebSocketManager } from '../../lib/websocket/WebSocketManager';
import { MarketData } from '../../types';

interface ValidatedWebSocketExampleProps {
  symbol: string;
}

// Define a custom validator for real-time market updates
const realTimeMarketUpdateValidator = object({
  type: string,
  symbol: string,
  price: number,
  volume: number,
  timestamp: string,
  changePercent: number
});

const ValidatedWebSocketExample: React.FC<ValidatedWebSocketExampleProps> = ({ symbol }) => {
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [messageCount, setMessageCount] = useState<number>(0);
  const [validMessageCount, setValidMessageCount] = useState<number>(0);
  
  const wsManagerRef = useRef<WebSocketManager | null>(null);
  
  useEffect(() => {
    // Initialize WebSocket manager if not already initialized
    if (!wsManagerRef.current) {
      wsManagerRef.current = new WebSocketManager('wss://trading-api.example.com/ws');
      
      // Register connection event handlers
      wsManagerRef.current.onConnect(() => {
        setIsConnected(true);
        setError(null);
      });
      
      wsManagerRef.current.onDisconnect(() => {
        setIsConnected(false);
      });
      
      wsManagerRef.current.onError((err) => {
        setError(`WebSocket error: ${err.message}`);
      });
    }
    
    // Connect to the WebSocket server
    wsManagerRef.current.connect();
    
    return () => {
      // Clean up the connection when component unmounts
      if (wsManagerRef.current) {
        wsManagerRef.current.disconnect();
      }
    };
  }, []);
  
  useEffect(() => {
    if (!wsManagerRef.current || !isConnected) return;
    
    // Subscribe to market data updates for the specified symbol
    const handleMessage = (message: any) => {
      try {
        // Increment total message count
        setMessageCount(prev => prev + 1);
        
        // Validate the incoming message
        const validatedMessage = validateApiResponse(
          message,
          realTimeMarketUpdateValidator,
          (validationError: ValidationError) => {
            console.error('WebSocket message validation error:', validationError);
            // Add to validation errors list
            setValidationErrors(prev => [
              ...prev, 
              `Error at ${validationError.path}: Expected ${validationError.expected}, got ${JSON.stringify(validationError.received)}`
            ].slice(-5)); // Keep only the 5 most recent errors
          }
        );
        
        if (validatedMessage) {
          // Increment valid message count
          setValidMessageCount(prev => prev + 1);
          
          // Update state with validated data
          setMarketData({
            symbol: validatedMessage.symbol,
            price: validatedMessage.price,
            volume: validatedMessage.volume,
            high: validatedMessage.price, // Simplified for this example
            low: validatedMessage.price,  // Simplified for this example
            open: validatedMessage.price, // Simplified for this example
            close: validatedMessage.price, // Simplified for this example
            changePercent: validatedMessage.changePercent,
            timestamp: validatedMessage.timestamp
          });
        }
      } catch (err) {
        if (err instanceof Error) {
          setError(`Message processing error: ${err.message}`);
        }
      }
    };
    
    // Subscribe to updates
    wsManagerRef.current.subscribe(`market:${symbol}`, handleMessage);
    
    // Mock sending a subscription message to the server
    console.log(`Subscribed to market updates for ${symbol}`);
    
    // Cleanup: unsubscribe when symbol changes or component unmounts
    return () => {
      if (wsManagerRef.current) {
        wsManagerRef.current.unsubscribe(`market:${symbol}`);
      }
    };
  }, [symbol, isConnected]);
  
  // For demo purposes - simulate incoming messages
  useEffect(() => {
    if (!isConnected) return;
    
    // Simulate WebSocket messages
    const simulateInterval = setInterval(() => {
      const price = 50000 + Math.random() * 1000 - 500;
      const validMessage = {
        type: 'market-update',
        symbol: symbol,
        price: price,
        volume: Math.floor(Math.random() * 100) + 1,
        timestamp: new Date().toISOString(),
        changePercent: (Math.random() * 2 - 1) * 0.5
      };
      
      // Every 5th message, send an invalid message to demonstrate validation
      const messageCount = Math.floor(Math.random() * 10);
      if (messageCount % 5 === 0) {
        // Invalid message (price is a string instead of a number)
        const invalidMessage = {
          ...validMessage,
          price: price.toString() // This should trigger validation error
        };
        
        if (wsManagerRef.current) {
          wsManagerRef.current.triggerMessageHandlers(`market:${symbol}`, invalidMessage);
        }
      } else {
        // Valid message
        if (wsManagerRef.current) {
          wsManagerRef.current.triggerMessageHandlers(`market:${symbol}`, validMessage);
        }
      }
    }, 3000);
    
    return () => clearInterval(simulateInterval);
  }, [symbol, isConnected]);
  
  const resetStats = () => {
    setMessageCount(0);
    setValidMessageCount(0);
    setValidationErrors([]);
  };
  
  return (
    <div className="validated-websocket-example p-4 border rounded shadow-sm">
      <h2 className="text-xl font-bold mb-4">Validated WebSocket Example: {symbol}</h2>
      
      <div className="mb-4 flex items-center">
        <div className={`h-3 w-3 rounded-full mr-2 ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
        <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
      </div>
      
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
          <p>{error}</p>
        </div>
      )}
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-100 p-4 rounded">
          <h3 className="font-semibold mb-2">Statistics</h3>
          <div className="grid grid-cols-2 gap-2">
            <div>Total messages:</div>
            <div>{messageCount}</div>
            
            <div>Valid messages:</div>
            <div>{validMessageCount}</div>
            
            <div>Validation rate:</div>
            <div>{messageCount > 0 ? `${Math.round((validMessageCount / messageCount) * 100)}%` : 'N/A'}</div>
          </div>
          <button 
            onClick={resetStats}
            className="mt-2 bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded text-sm"
          >
            Reset Stats
          </button>
        </div>
        
        <div className="bg-gray-100 p-4 rounded">
          <h3 className="font-semibold mb-2">Latest Market Data</h3>
          {marketData ? (
            <div className="grid grid-cols-2 gap-2">
              <div>Symbol:</div>
              <div>{marketData.symbol}</div>
              
              <div>Price:</div>
              <div>${marketData.price.toLocaleString()}</div>
              
              <div>Change:</div>
              <div className={marketData.changePercent >= 0 ? 'text-green-600' : 'text-red-600'}>
                {marketData.changePercent >= 0 ? '+' : ''}{marketData.changePercent.toFixed(2)}%
              </div>
              
              <div>Time:</div>
              <div>{new Date(marketData.timestamp).toLocaleString()}</div>
            </div>
          ) : (
            <p className="text-gray-500">Waiting for data...</p>
          )}
        </div>
      </div>
      
      <div className="mb-4">
        <h3 className="font-semibold mb-2">Recent Validation Errors</h3>
        {validationErrors.length > 0 ? (
          <ul className="bg-yellow-50 border border-yellow-200 rounded p-2 text-sm">
            {validationErrors.map((error, i) => (
              <li key={i} className="mb-1 last:mb-0 text-yellow-800">{error}</li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No validation errors yet</p>
        )}
      </div>
      
      <div className="bg-gray-100 p-4 rounded text-sm">
        <p className="font-medium">About this component:</p>
        <ul className="list-disc pl-5 mt-1 space-y-1">
          <li>Demonstrates real-time WebSocket data validation</li>
          <li>Uses a custom validator for market update messages</li>
          <li>Shows how validation can filter out invalid messages</li>
          <li>Simulates both valid and invalid messages for demonstration</li>
          <li>Tracks validation statistics to monitor data quality</li>
        </ul>
      </div>
    </div>
  );
};

export default ValidatedWebSocketExample; 