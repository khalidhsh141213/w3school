import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO, subDays } from "date-fns";
import { Activity, Calendar, Database, DollarSign, Download, Filter, RotateCw, Search, Settings, Shield, User } from "lucide-react";
import { useState } from "react";

// Define types for audit log data
interface AuditLogEntry {
  id: string;
  action: string;
  category: string;
  entity: string;
  entityId: string;
  username: string;
  userRole: string;
  details: string;
  timestamp: string;
  ip: string;
}

export default function AuditLogViewer() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTimeRange, setSelectedTimeRange] = useState("24h");
  const [selectedTab, setSelectedTab] = useState("all");
  const [selectedEntries, setSelectedEntries] = useState<string[]>([]);
  
  // Mock data
  const mockAuditLogs: AuditLogEntry[] = [
    {
      id: "1",
      action: "create",
      category: "user",
      entity: "user",
      entityId: "user_123",
      username: "admin",
      userRole: "admin",
      details: "New user created",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "2",
      action: "update",
      category: "asset",
      entity: "asset",
      entityId: "asset_btc",
      username: "admin",
      userRole: "admin",
      details: "BTC asset information updated",
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "3",
      action: "delete",
      category: "trade",
      entity: "order",
      entityId: "order_456",
      username: "admin",
      userRole: "admin",
      details: "Trade order deleted",
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "4",
      action: "update",
      category: "finance",
      entity: "withdrawal",
      entityId: "withdrawal_789",
      username: "admin",
      userRole: "admin",
      details: "Withdrawal request approved",
      timestamp: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "5",
      action: "update",
      category: "setting",
      entity: "platform_setting",
      entityId: "setting_fees",
      username: "admin",
      userRole: "admin",
      details: "Fee settings updated",
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "6",
      action: "create",
      category: "kyc",
      entity: "kyc_approval",
      entityId: "kyc_123",
      username: "admin",
      userRole: "admin",
      details: "KYC approved for user user_123",
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "7",
      action: "create",
      category: "user",
      entity: "user_role",
      entityId: "user_456",
      username: "superadmin",
      userRole: "superadmin",
      details: "User role changed to admin",
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
    {
      id: "8",
      action: "update",
      category: "security",
      entity: "security_setting",
      entityId: "setting_2fa",
      username: "superadmin",
      userRole: "superadmin",
      details: "Two-factor authentication required for all admins",
      timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      ip: "192.168.1.100"
    },
  ];
  
  // Get time range timestamp
  const getTimeRangeTimestamp = () => {
    switch (selectedTimeRange) {
      case "24h":
        return subDays(new Date(), 1).toISOString();
      case "7d":
        return subDays(new Date(), 7).toISOString();
      case "30d":
        return subDays(new Date(), 30).toISOString();
      default:
        return null;
    }
  };
  
  // Filter logs based on search, category, and time range
  const filteredLogs = mockAuditLogs.filter(log => {
    // Filter by search query
    const matchesSearch = searchQuery === "" || 
      log.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.entity.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by category
    const matchesCategory = selectedCategory === "all" || log.category === selectedCategory;
    
    // Filter by time range
    const matchesTimeRange = selectedTimeRange === "all" || 
      (getTimeRangeTimestamp() ? new Date(log.timestamp) >= new Date(getTimeRangeTimestamp()!) : true);
    
    // Filter by tab
    const matchesTab = selectedTab === "all" || 
      (selectedTab === "user" && log.category === "user") ||
      (selectedTab === "asset" && log.category === "asset") ||
      (selectedTab === "trade" && log.category === "trade") ||
      (selectedTab === "finance" && log.category === "finance") ||
      (selectedTab === "settings" && (log.category === "setting" || log.category === "security"));
    
    return matchesSearch && matchesCategory && matchesTimeRange && matchesTab;
  });
  
  // Get category icon
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "user":
        return <User className="h-4 w-4 text-blue-500" />;
      case "asset":
        return <Database className="h-4 w-4 text-green-500" />;
      case "trade":
        return <Activity className="h-4 w-4 text-purple-500" />;
      case "finance":
        return <DollarSign className="h-4 w-4 text-yellow-500" />;
      case "setting":
        return <Settings className="h-4 w-4 text-gray-500" />;
      case "kyc":
        return <User className="h-4 w-4 text-orange-500" />;
      case "security":
        return <Shield className="h-4 w-4 text-red-500" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };
  
  // Get action badge
  const getActionBadge = (action: string) => {
    switch (action) {
      case "create":
        return <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Create</Badge>;
      case "update":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">Update</Badge>;
      case "delete":
        return <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Delete</Badge>;
      case "login":
        return <Badge variant="outline" className="bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400">Login</Badge>;
      default:
        return <Badge variant="outline">{action}</Badge>;
    }
  };
  
  // Handle exporting logs
  const exportSelectedLogs = () => {
    if (selectedEntries.length === 0) {
      toast({
        title: "No logs selected",
        description: "Please select the logs you want to export",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Export Complete",
      description: `Exported ${selectedEntries.length} logs`,
    });
  };
  
  // Handle selecting all entries
  const handleSelectAll = () => {
    if (selectedEntries.length === filteredLogs.length) {
      setSelectedEntries([]);
    } else {
      setSelectedEntries(filteredLogs.map(log => log.id));
    }
  };
  
  // Handle selecting an entry
  const handleSelectEntry = (id: string) => {
    if (selectedEntries.includes(id)) {
      setSelectedEntries(selectedEntries.filter(entry => entry !== id));
    } else {
      setSelectedEntries([...selectedEntries, id]);
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-80 mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-10 w-full mb-6" />
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Activity Log</CardTitle>
            <CardDescription>Monitor all actions taken on the platform</CardDescription>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={() => setIsLoading(true)}>
              <RotateCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button 
              variant="default" 
              size="sm" 
              onClick={exportSelectedLogs}
              disabled={selectedEntries.length === 0}
            >
              <Download className="h-4 w-4 mr-2" />
              Export {selectedEntries.length > 0 ? `(${selectedEntries.length})` : ''}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search user, type, or details..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Categories" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="user">Users</SelectItem>
                <SelectItem value="asset">Assets</SelectItem>
                <SelectItem value="trade">Trades</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="setting">Settings</SelectItem>
                <SelectItem value="security">Security</SelectItem>
                <SelectItem value="kyc">KYC</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Last 24 Hours" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 Hours</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* Tabs for categories */}
          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto">
              <TabsTrigger value="all">All Categories</TabsTrigger>
              <TabsTrigger value="user">Users</TabsTrigger>
              <TabsTrigger value="asset">Assets</TabsTrigger>
              <TabsTrigger value="trade">Trades</TabsTrigger>
              <TabsTrigger value="finance">Finance</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Log table */}
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40px]">
                    <Checkbox 
                      checked={selectedEntries.length === filteredLogs.length && filteredLogs.length > 0} 
                      onCheckedChange={handleSelectAll} 
                    />
                  </TableHead>
                  <TableHead className="w-[100px]">Action</TableHead>
                  <TableHead className="w-[120px]">Category</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead className="w-[160px]">User</TableHead>
                  <TableHead className="w-[180px] text-right">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.length > 0 ? (
                  filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>
                        <Checkbox 
                          checked={selectedEntries.includes(log.id)} 
                          onCheckedChange={() => handleSelectEntry(log.id)} 
                        />
                      </TableCell>
                      <TableCell>{getActionBadge(log.action)}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {getCategoryIcon(log.category)}
                          <span className="ml-2 capitalize">{log.category}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{log.details}</span>
                          <span className="text-xs text-muted-foreground">{log.entity} ID: {log.entityId}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{log.username}</span>
                          <span className="text-xs text-muted-foreground">{log.ip}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex flex-col items-end">
                          <span>{format(parseISO(log.timestamp), 'PPP')}</span>
                          <span className="text-xs text-muted-foreground">
                            {format(parseISO(log.timestamp), 'HH:mm')}
                          </span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="flex flex-col items-center">
                        <Filter className="h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-lg font-semibold">No activity logs found matching your filters</p>
                        <p className="text-muted-foreground">Please try adjusting your filters to find more logs</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 