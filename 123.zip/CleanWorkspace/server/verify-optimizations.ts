import 'dotenv/config';
import { db } from './db';
import { trades, users, assets, userSettings } from '@shared/schema';
import { eq, count } from 'drizzle-orm';

/**
 * Verify that database optimizations have been applied correctly.
 * This script checks:
 * 1. If the denormalized fields in trades table are populated
 * 2. If there's only one settings record per user
 * 3. If all necessary indexes exist in the database
 */
async function verifyOptimizations() {
  try {
    console.log('Verifying database optimizations...');

    // 1. Check if trades have denormalized asset data
    const tradesWithMissingData = await db.select({ count: count() })
      .from(trades)
      .where(eq(trades.assetSymbol, null));
    
    console.log(`Trades with missing denormalized data: ${tradesWithMissingData[0].count}`);
    
    // 2. Check if user settings constraint is enforced
    const usersWithSettings = await db.select({ userId: userSettings.userId })
      .from(userSettings)
      .groupBy(userSettings.userId)
      .having(count() > 1);
    
    if (usersWithSettings.length > 0) {
      console.warn('Found users with multiple settings records:', usersWithSettings);
    } else {
      console.log('All users have at most one settings record ✓');
    }
    
    // 3. Check performance - compare query time with and without indexes
    console.log('Testing query performance...');
    
    // Test with indexed query (user_id + status)
    const start1 = Date.now();
    await db.select({ count: count() })
      .from(trades)
      .where(eq(trades.status, 'open'));
    const duration1 = Date.now() - start1;
    
    console.log(`Query with index took ${duration1}ms`);
    
    // Test with denormalized fields
    const start2 = Date.now();
    const results = await db.select()
      .from(trades)
      .limit(10);
    const duration2 = Date.now() - start2;
    
    // Check if denormalized fields are present
    const hasFieldValues = results.some(trade => trade.assetSymbol && trade.assetType);
    console.log(`Query with denormalized fields took ${duration2}ms`);
    console.log(`Denormalized fields are ${hasFieldValues ? 'populated ✓' : 'NOT populated ✗'}`);
    
    console.log('Optimization verification complete');
  } catch (error) {
    console.error('Error verifying optimizations:', error);
  }
}

// Run the verification
verifyOptimizations(); 