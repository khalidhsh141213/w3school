import { db } from '../db.js';
import { assets, marketData } from '../../shared/schema.js';
import { eq, desc, and, sql } from 'drizzle-orm';
import fetch from 'node-fetch';
import { Cache } from '../utils/cache.js';
import { WebSocket } from 'ws';
import { logger } from '../utils/logger.js';

// Cache for market data to reduce database load
const marketDataCache = new Cache<{
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
  high24h: string | null;
  low24h: string | null;
  volume: string;
  updatedAt: Date;
}>('marketData', 200);

// API configuration
// In a production environment, these would be accessed via environment variables
const API_BASE_URL = process.env.POLYGON_API_BASE_URL || 'https://api.polygon.io';
const API_KEY = process.env.POLYGON_API_KEY || '';

// WebSocket configuration
const WS_BASE_URL = process.env.POLYGON_WS_BASE_URL || 'wss://socket.polygon.io';
let wsConnection: WebSocket | null = null;
let wsHeartbeatInterval: NodeJS.Timeout | null = null;
const subscribedSymbols = new Set<string>();
const pendingSubscriptions = new Map<string, NodeJS.Timeout>();

/**
 * Initialize the WebSocket connection to Polygon.io
 */
function initializeWebSocket() {
  if (!API_KEY) {
    logger.warn('WebSocket initialization skipped: No Polygon API key provided');
    return;
  }

  if (wsConnection) {
    logger.info('WebSocket connection already exists');
    return;
  }

  try {
    logger.info(`Connecting to WebSocket at ${WS_BASE_URL}/stocks`);
    wsConnection = new WebSocket(`${WS_BASE_URL}/stocks`);

    wsConnection.on('open', () => {
      logger.info('WebSocket connection established');
      authenticateWebSocket();
      setupWebSocketHeartbeat();
      subscribeToAllActiveSymbols();
    });

    wsConnection.on('message', async (data) => {
      try {
        const messages = JSON.parse(data.toString());
        processWebSocketMessages(messages);
      } catch (error) {
        logger.error('Error processing WebSocket message:', error);
      }
    });

    wsConnection.on('error', (error) => {
      logger.error('WebSocket error:', error);
    });

    wsConnection.on('close', (code, reason) => {
      logger.warn(`WebSocket connection closed: ${code} - ${reason}`);
      cleanupWebSocket();
      // Attempt to reconnect after a delay
      setTimeout(() => {
        logger.info('Attempting to reconnect WebSocket...');
        initializeWebSocket();
      }, 5000);
    });
  } catch (error) {
    logger.error('Failed to initialize WebSocket:', error);
  }
}

/**
 * Authenticate the WebSocket connection
 */
function authenticateWebSocket() {
  if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
    logger.warn('Cannot authenticate: WebSocket not open');
    return;
  }

  const authMessage = JSON.stringify({
    action: 'auth',
    params: API_KEY
  });

  wsConnection.send(authMessage);
  logger.info('Authentication message sent to WebSocket');
}

/**
 * Set up the heartbeat for the WebSocket connection
 */
function setupWebSocketHeartbeat() {
  if (wsHeartbeatInterval) {
    clearInterval(wsHeartbeatInterval);
  }

  wsHeartbeatInterval = setInterval(() => {
    if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
      wsConnection.send(JSON.stringify({ action: 'ping' }));
    }
  }, 30000); // Send heartbeat every 30 seconds
}

/**
 * Clean up WebSocket resources
 */
function cleanupWebSocket() {
  if (wsHeartbeatInterval) {
    clearInterval(wsHeartbeatInterval);
    wsHeartbeatInterval = null;
  }

  if (wsConnection) {
    if (wsConnection.readyState === WebSocket.OPEN || wsConnection.readyState === WebSocket.CONNECTING) {
      wsConnection.close();
    }
    wsConnection = null;
  }

  // Clear all pending subscription timeouts
  pendingSubscriptions.forEach(timeout => clearTimeout(timeout));
  pendingSubscriptions.clear();
}

/**
 * Process WebSocket messages
 */
function processWebSocketMessages(messages: any) {
  if (Array.isArray(messages)) {
    messages.forEach(msg => {
      if (msg.ev === 'T') { // Trade event
        // Process trade message
        const symbol = msg.sym;
        const price = msg.p.toString();
        
        updateMarketDataFromWebSocket(symbol, {
          price: price,
          // These would typically come from a separate subscription or aggregated data
          // For now, we'll just use the trade price
          change: '0',
          changePercent: '0',
          volume: msg.s.toString(), // Size of the trade as volume
        });
      } else if (msg.ev === 'status') {
        // Process status message
        logger.info(`WebSocket status: ${msg.status}`);
        
        if (msg.status === 'auth_success') {
          logger.info('WebSocket authentication successful');
        } else if (msg.status === 'auth_failed') {
          logger.error('WebSocket authentication failed');
        }
      } else if (msg.ev === 'AM') { // Aggregate minute data
        // Process minute bar
        const symbol = msg.sym;
        const closePrice = msg.c.toString();
        const openPrice = msg.o.toString();
        const change = (msg.c - msg.o).toString();
        const changePercent = (((msg.c - msg.o) / msg.o) * 100).toString();
        
        updateMarketDataFromWebSocket(symbol, {
          price: closePrice,
          change: change,
          changePercent: changePercent,
          high24h: msg.h.toString(),
          low24h: msg.l.toString(),
          volume: msg.v.toString(),
        });
      }
    });
  }
}

/**
 * Update market data from WebSocket
 */
async function updateMarketDataFromWebSocket(symbol: string, data: Partial<{
  price: string;
  change: string;
  changePercent: string;
  high24h: string | null;
  low24h: string | null;
  volume: string;
}>) {
  try {
    // Get existing data from cache or DB
    let existingData = marketDataCache.get(symbol);
    
    if (!existingData) {
      const dbData = await db.select().from(marketData).where(eq(marketData.symbol, symbol)).limit(1);
      existingData = dbData[0] || {
        symbol,
        price: '0',
        change: '0',
        changePercent: '0',
        high24h: null,
        low24h: null,
        volume: '0',
        updatedAt: new Date()
      };
    }

    // Update with new data
    const updatedData = {
      ...existingData,
      ...data,
      updatedAt: new Date()
    };

    // Update cache
    marketDataCache.set(symbol, updatedData);

    // Don't update DB on every WebSocket message - throttle database updates
    // Only update DB every 5 seconds per symbol to prevent excessive writes
    const lastDbUpdate = marketDataCache.getMetadata(symbol, 'lastDbUpdate') || 0;
    const currentTime = Date.now();
    
    if (currentTime - lastDbUpdate > 5000) { // 5 seconds
      await db.insert(marketData).values({
        symbol: updatedData.symbol,
        price: updatedData.price,
        change: updatedData.change,
        changePercent: updatedData.changePercent,
        high24h: updatedData.high24h,
        low24h: updatedData.low24h,
        volume: updatedData.volume
      }).onConflictDoUpdate({
        target: marketData.symbol,
        set: {
          price: updatedData.price,
          change: updatedData.change,
          changePercent: updatedData.changePercent,
          high24h: updatedData.high24h,
          low24h: updatedData.low24h,
          volume: updatedData.volume,
          updatedAt: new Date()
        }
      });
      
      marketDataCache.setMetadata(symbol, 'lastDbUpdate', currentTime);
      logger.debug(`Updated market data in DB for ${symbol}`);
    }

    // Broadcast market update to clients through WebSocket server
    broadcastMarketUpdate(symbol, updatedData);
  } catch (error) {
    logger.error(`Error updating market data from WebSocket for ${symbol}:`, error);
  }
}

/**
 * Broadcast market update to clients
 */
function broadcastMarketUpdate(symbol: string, data: any) {
  try {
    // This would connect to your application's WebSocket server to broadcast to clients
    // For now, we'll just log it
    logger.debug(`Broadcasting market update for ${symbol}: ${data.price}`);
    
    // In a real implementation, you would send this to your WebSocket server
    // Example:
    // webSocketServer.broadcast('marketUpdate', { symbol, ...data });
  } catch (error) {
    logger.error(`Error broadcasting market update for ${symbol}:`, error);
  }
}

/**
 * Subscribe to market data updates for a symbol via WebSocket
 */
async function subscribeToMarketData(symbol: string) {
  // Format the symbol for Polygon (remove any / for forex/crypto pairs)
  const formattedSymbol = symbol.replace('/', '');
  
  if (subscribedSymbols.has(formattedSymbol)) {
    logger.debug(`Already subscribed to ${formattedSymbol}`);
    return;
  }

  if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
    logger.warn(`WebSocket not ready, queueing subscription for ${formattedSymbol}`);
    
    // Clear any existing pending subscription
    if (pendingSubscriptions.has(formattedSymbol)) {
      clearTimeout(pendingSubscriptions.get(formattedSymbol)!);
    }
    
    // Queue for retry
    pendingSubscriptions.set(formattedSymbol, setTimeout(() => {
      pendingSubscriptions.delete(formattedSymbol);
      subscribeToMarketData(symbol);
    }, 5000));
    
    return;
  }

  try {
    // Subscribe to trades
    const tradeSubscription = JSON.stringify({
      action: 'subscribe',
      params: `T.${formattedSymbol}`
    });
    wsConnection.send(tradeSubscription);
    
    // Subscribe to minute aggregates
    const aggregateSubscription = JSON.stringify({
      action: 'subscribe',
      params: `AM.${formattedSymbol}`
    });
    wsConnection.send(aggregateSubscription);
    
    logger.info(`Subscribed to market data for ${formattedSymbol}`);
    subscribedSymbols.add(formattedSymbol);
  } catch (error) {
    logger.error(`Failed to subscribe to market data for ${formattedSymbol}:`, error);
  }
}

/**
 * Subscribe to all active symbols
 */
async function subscribeToAllActiveSymbols() {
  try {
    const activeAssets = await db.select().from(assets)
      .where(eq(assets.market_status, 'active'));
    
    logger.info(`Found ${activeAssets.length} active assets to subscribe to`);
    
    for (const asset of activeAssets) {
      if (asset.polygon_symbol) {
        await subscribeToMarketData(asset.polygon_symbol);
      } else if (asset.symbol) {
        await subscribeToMarketData(asset.symbol);
      }
    }
  } catch (error) {
    logger.error('Failed to subscribe to all active symbols:', error);
  }
}

/**
 * Initialize the market data service
 */
export async function initializeMarketDataService() {
  logger.info('Initializing Market Data Service');
  
  // Populate the cache with existing market data
  const existingData = await db.select().from(marketData)
    .orderBy(desc(marketData.updatedAt))
    .limit(200);
  
  for (const data of existingData) {
    marketDataCache.set(data.symbol, data);
  }
  
  logger.info(`Loaded ${existingData.length} market data entries into cache`);
  
  // Initialize WebSocket for real-time data
  initializeWebSocket();
  
  // Schedule regular polling for assets that don't support WebSocket
  scheduleRestApiPolling();
  
  return {
    getMarketData,
    updateMarketData,
    subscribeToMarketData,
  };
}

/**
 * Schedule polling via REST API for assets that don't support real-time WebSocket updates
 */
function scheduleRestApiPolling() {
  // Crypto and Forex are handled by WebSocket, only poll other asset types
  setInterval(async () => {
    try {
      const stockAssets = await db.select().from(assets)
        .where(
          and(
            eq(assets.market_status, 'active'),
            sql`${assets.type} NOT IN ('crypto', 'forex')`
          )
        );
      
      logger.info(`Polling ${stockAssets.length} stock/index assets via REST API`);
      
      for (const asset of stockAssets) {
        await fetchMarketDataViaRest(asset.symbol, asset.type);
      }
    } catch (error) {
      logger.error('Error during REST API polling:', error);
    }
  }, 300000); // Poll every 5 minutes
}

/**
 * Fetch market data via REST API
 */
async function fetchMarketDataViaRest(symbol: string, type: string) {
  if (!API_KEY) {
    logger.warn(`Cannot fetch market data for ${symbol}: No API key`);
    return;
  }
  
  try {
    // Format symbol for API request
    const formattedSymbol = symbol.replace('/', '');
    let endpoint = '';
    
    if (type.toLowerCase() === 'stock' || type.toLowerCase() === 'index') {
      endpoint = `/v2/snapshot/locale/us/markets/stocks/tickers/${formattedSymbol}`;
    } else if (type.toLowerCase() === 'commodity') {
      endpoint = `/v2/snapshot/locale/global/markets/forex/tickers/${formattedSymbol}`;
    }
    
    if (!endpoint) {
      logger.warn(`Unsupported asset type for REST API: ${type} (${symbol})`);
      return;
    }
    
    const url = `${API_BASE_URL}${endpoint}?apiKey=${API_KEY}`;
    logger.debug(`Fetching market data for ${symbol} from ${endpoint}`);
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.status === 'OK' && data.ticker) {
      const tickerData = data.ticker;
      
      // Process and update the data
      await updateMarketData({
        symbol,
        price: tickerData.lastTrade?.p?.toString() || tickerData.todaysChange?.toString() || '0',
        change: tickerData.todaysChange?.toString() || '0',
        changePercent: tickerData.todaysChangePerc?.toString() || '0',
        high24h: tickerData.high?.toString() || null,
        low24h: tickerData.low?.toString() || null,
        volume: tickerData.volume?.toString() || '0',
      });
      
      logger.info(`Updated market data for ${symbol} via REST API`);
    } else {
      logger.warn(`Failed to fetch market data for ${symbol}: ${data.status || 'Unknown error'}`);
    }
  } catch (error) {
    logger.error(`Error fetching market data for ${symbol}:`, error);
  }
}

/**
 * Update market data in the database
 */
export async function updateMarketData(data: {
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
  high24h: string | null;
  low24h: string | null;
  volume: string;
}) {
  try {
    const updatedData = {
      ...data,
      updatedAt: new Date()
    };
    
    // Update the cache
    marketDataCache.set(data.symbol, updatedData);
    
    // Update the database
    await db.insert(marketData).values({
      symbol: data.symbol,
      price: data.price,
      change: data.change,
      changePercent: data.changePercent,
      high24h: data.high24h,
      low24h: data.low24h,
      volume: data.volume,
    }).onConflictDoUpdate({
      target: marketData.symbol,
      set: {
        price: data.price,
        change: data.change,
        changePercent: data.changePercent,
        high24h: data.high24h,
        low24h: data.low24h,
        volume: data.volume,
        updatedAt: new Date()
      }
    });
    
    // Also update the price in the assets table to keep them in sync
    await db.update(assets)
      .set({ price: Number(data.price) })
      .where(eq(assets.symbol, data.symbol));
    
    logger.debug(`Updated market data for ${data.symbol}`);
    return true;
  } catch (error) {
    logger.error(`Failed to update market data for ${data.symbol}:`, error);
    return false;
  }
}

/**
 * Get market data for a symbol
 */
export async function getMarketData(symbol: string) {
  try {
    // Try to get from cache first
    const cachedData = marketDataCache.get(symbol);
    if (cachedData) {
      return cachedData;
    }
    
    // If not in cache, get from database
    const data = await db.select().from(marketData)
      .where(eq(marketData.symbol, symbol))
      .limit(1);
    
    if (data.length > 0) {
      // Add to cache for future requests
      marketDataCache.set(symbol, data[0]);
      return data[0];
    }
    
    return null;
  } catch (error) {
    logger.error(`Failed to get market data for ${symbol}:`, error);
    return null;
  }
}