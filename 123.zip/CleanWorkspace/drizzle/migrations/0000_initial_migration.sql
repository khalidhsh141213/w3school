/*
 * Initial Database Migration
 * Creates the foundational database structure including:
 * - Essential enum types for various statuses and types
 * - Core tables for users, assets, trades, and transactions
 * - Authentication and authorization tables
 * - Economic events and user settings
 * 
 * Dependencies: None (This is the first migration)
 */

-- Create enum types
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'verification_status') THEN
    CREATE TYPE "verification_status" AS ENUM ('pending', 'verified', 'rejected');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
    CREATE TYPE "user_role" AS ENUM ('user', 'admin');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'asset_type') THEN
    CREATE TYPE "asset_type" AS ENUM ('crypto', 'stock', 'forex', 'commodity');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'market_status') THEN
    CREATE TYPE "market_status" AS ENUM ('active', 'suspended');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'trade_type') THEN
    CREATE TYPE "trade_type" AS ENUM ('buy', 'sell');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'trade_status') THEN
    CREATE TYPE "trade_status" AS ENUM ('open', 'closed', 'cancelled');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'transaction_type') THEN
    CREATE TYPE "transaction_type" AS ENUM ('deposit', 'withdrawal', 'refund', 'adjustment');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'transaction_status') THEN
    CREATE TYPE "transaction_status" AS ENUM ('pending', 'completed', 'failed');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'importance_level') THEN
    CREATE TYPE "importance_level" AS ENUM ('low', 'medium', 'high');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'time_interval') THEN
    CREATE TYPE "time_interval" AS ENUM ('1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M');
  END IF;
END$$;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS "users" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "username" VARCHAR(255) NOT NULL UNIQUE,
  "email" TEXT NOT NULL UNIQUE,
  "password_hash" TEXT NOT NULL,
  "full_name" TEXT NOT NULL,
  "phone_number" TEXT,
  "profile_picture_url" TEXT,
  "is_verified" BOOLEAN NOT NULL DEFAULT false,
  "verification_status" verification_status NOT NULL DEFAULT 'pending',
  "user_role" user_role NOT NULL DEFAULT 'user',
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 2. Admin Actions Log
CREATE TABLE IF NOT EXISTS "admin_actions_log" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "admin_user_id" UUID NOT NULL REFERENCES "users"("id"),
  "action_type" TEXT NOT NULL,
  "target_table" TEXT NOT NULL,
  "target_id" UUID NOT NULL,
  "action_timestamp" TIMESTAMP NOT NULL DEFAULT NOW(),
  "action_details" TEXT
);

-- 3. Assets Table
CREATE TABLE IF NOT EXISTS "assets" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "asset_type" asset_type NOT NULL,
  "symbol" TEXT NOT NULL UNIQUE,
  "polygon_symbol" TEXT,
  "tradingview_symbol" TEXT,
  "price" DOUBLE PRECISION,
  "market_status" market_status NOT NULL DEFAULT 'active',
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 4. Trades Table
CREATE TABLE IF NOT EXISTS "trades" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "asset_id" UUID NOT NULL REFERENCES "assets"("id"),
  "trade_type" trade_type NOT NULL,
  "quantity" DOUBLE PRECISION NOT NULL,
  "entry_price" DOUBLE PRECISION NOT NULL,
  "exit_price" DOUBLE PRECISION,
  "status" trade_status NOT NULL DEFAULT 'open',
  "leverage" INTEGER NOT NULL DEFAULT 1,
  "stop_loss" DOUBLE PRECISION,
  "take_profit" DOUBLE PRECISION,
  "profit_loss" DOUBLE PRECISION,
  "opened_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "closed_at" TIMESTAMP
);

-- 5. Transactions Table
CREATE TABLE IF NOT EXISTS "transactions" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "type" transaction_type NOT NULL,
  "amount" DOUBLE PRECISION NOT NULL,
  "currency" TEXT NOT NULL,
  "status" transaction_status NOT NULL DEFAULT 'pending',
  "transaction_date" TIMESTAMP NOT NULL DEFAULT NOW(),
  "processed_by_admin" BOOLEAN NOT NULL DEFAULT false,
  "notes" TEXT
);

-- 6. Watchlist Table
CREATE TABLE IF NOT EXISTS "watchlist" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "asset_id" UUID NOT NULL REFERENCES "assets"("id"),
  "added_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 7. Economic Events
CREATE TABLE IF NOT EXISTS "economic_events" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "event_name" TEXT NOT NULL,
  "event_date" TIMESTAMP NOT NULL,
  "asset_impact" TEXT NOT NULL,
  "description" TEXT,
  "importance_level" importance_level NOT NULL DEFAULT 'medium'
);

-- 8. User Settings
CREATE TABLE IF NOT EXISTS "user_settings" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "language_preference" TEXT NOT NULL DEFAULT 'en',
  "notification_preferences" JSONB NOT NULL,
  "privacy_settings" JSONB NOT NULL,
  "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 9. Authentication Tokens
CREATE TABLE IF NOT EXISTS "auth_tokens" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "token" TEXT NOT NULL,
  "expires_at" TIMESTAMP NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW()
); 