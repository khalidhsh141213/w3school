/**
 * هذا البرنامج ينشئ الجداول اللازمة لنظام المكافآت والإحالات وتتبع الأنشطة
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { db } from './db.js'; // تصحيح الاستيراد بإضافة امتداد .js
import { sql } from 'drizzle-orm';
// الجداول متاحة بالفعل من خلال db، لا حاجة لاستيرادها بشكل منفصل

// تعريف المسار الحالي (بديل عن __dirname في ESM)
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function createBonusSystem() {
  console.log('بدء إنشاء نظام المكافآت والإحالات وتتبع الأنشطة...');

  try {
    // قراءة ملف SQL
    const sqlFilePath = path.join(__dirname, 'sql', 'create-new-tables.sql');
    const sqlContent = fs.readFileSync(sqlFilePath, 'utf8');

    // تقسيم الأوامر SQL (بالتجاهل التعليقات)
    const sqlCommands = sqlContent
      .split(';')
      .filter(command => {
        // تنظيف الأمر وإزالة التعليقات
        const cleanCommand = command
          .split('\n')
          .filter(line => !line.trim().startsWith('--'))
          .join('\n')
          .trim();
        
        return cleanCommand.length > 0;
      });

    // تنفيذ كل أمر SQL بشكل منفصل
    for (const command of sqlCommands) {
      try {
        console.log(`تنفيذ: ${command.substring(0, 50)}...`);
        await db.execute(sql.raw(`${command};`));
        console.log('✓ تم تنفيذ الأمر بنجاح');
      } catch (error) {
        console.error(`خطأ في تنفيذ الأمر SQL: ${command.substring(0, 100)}...`);
        console.error(error);
        // استمر في تنفيذ الأوامر الأخرى حتى في حالة حدوث خطأ
      }
    }

    console.log('✅ تم إنشاء وتحديث الجداول بنجاح');
  } catch (error) {
    console.error('حدث خطأ أثناء تنفيذ البرنامج:');
    console.error(error);
    process.exit(1);
  }
}

// تنفيذ البرنامج
createBonusSystem()
  .then(() => {
    console.log('اكتمل تنفيذ البرنامج بنجاح');
    process.exit(0);
  })
  .catch(error => {
    console.error('حدث خطأ أثناء تنفيذ البرنامج:');
    console.error(error);
    process.exit(1);
  });