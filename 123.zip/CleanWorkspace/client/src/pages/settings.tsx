import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useRedirect } from '@/hooks/use-redirect';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/authContext';
import { apiRequest, getQueryFn } from '@/lib/queryClient';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, Check, Loader2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useLocation } from 'wouter';
import { z } from 'zod';

// Define TypeScript interfaces
interface UserSettings {
  id: string;
  userId: string;
  languagePreference: string;
  currencyPreference: string;
  themePreference: string;
  notificationPreferences: {
    priceAlerts: boolean;
    newsAlerts: boolean;
    tradingUpdates: boolean;
    marketSummaries: boolean;
  };
  privacySettings: {
    shareTradeHistory: boolean;
    showPortfolioValue: boolean;
    allowDataCollection: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

interface UserProfile {
  id: string;
  username: string;
  email: string;
  fullName: string;
  phoneNumber?: string;
  profilePictureUrl?: string;
}

// Form schemas
const profileFormSchema = z.object({
  fullName: z.string().min(2, { message: "Full name is required" }),
  email: z.string().email({ message: "Invalid email address" }),
  phoneNumber: z.string().optional(),
});

const securityFormSchema = z.object({
  currentPassword: z.string().min(1, { message: "Current password is required" }),
  newPassword: z.string().min(8, { message: "Password must be at least 8 characters" }),
  confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;
type SecurityFormValues = z.infer<typeof securityFormSchema>;

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [verificationLevel, setVerificationLevel] = useState(1);
  const [activeTab, setActiveTab] = useState('overview');
  const [activeSettingsCategory, setActiveSettingsCategory] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState('profile');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [updateError, setUpdateError] = useState<string | null>(null);
  const [location, setLocation] = useLocation();
  
  // Use the redirect hook for settings#support -> /support
  useRedirect();
  
  // Parse hash from URL to set active category
  useEffect(() => {
    // Get the hash from window.location since useLocation doesn't provide it
    const hash = window.location.hash.replace('#', '');
    
    // For other hash values, set the active category
    if (hash && ['profile', 'security', 'preferences', 'notifications', 'privacy'].includes(hash)) {
      setActiveCategory(hash);
    }
    
    // Redirect to the support page if the hash is 'support'
    if (hash === 'support') {
      setLocation('/support');
    }
  }, [setLocation]);
  
  const userId = user?.id;
  
  // Fetch current user data
  const { data: userData, isLoading: isUserLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user?.id,
  });
  
  // Fetch user settings
  const { data: userSettings, isLoading: isSettingsLoading, isError: isSettingsError } = useQuery({
    queryKey: ['/api/user-settings'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user?.id,
  });
  
  // Fetch user profile
  const { 
    data: profile, 
    isLoading: loadingProfile,
    error: profileError
  } = useQuery<UserProfile>({
    queryKey: ['profile', userId],
    queryFn: async () => {
      const res = await fetch(`/api/user/${userId}`);
      if (!res.ok) throw new Error('Failed to fetch user profile');
      return res.json();
    },
    enabled: !!userId,
  });
  
  // Initialize user settings if they don't exist
  const initializeUserSettings = useMutation({
    mutationFn: async () => {
      if (!user?.id) return null;
      
      // First check if the user already has settings to avoid duplicate creation
      const existingSettings = await apiRequest(
        'GET', 
        `/api/user-settings/${user.id}`
      );
      
      // If settings already exist, return them without creating new ones
      if (existingSettings && !isSettingsError) {
        return existingSettings;
      }
      
      // Default user settings values
      const defaultSettings = {
        userId: user.id,
        languagePreference: 'en',
        notificationPreferences: {
          email: true,
          browser: true,
          marketAlerts: true,
          tradingUpdates: true,
          securityAlerts: true,
        },
        privacySettings: {
          showProfileToOthers: true,
          shareTradeHistory: false,
          allowMarketingCommunications: true,
        },
      };
      
      return await apiRequest(
        'POST',
        '/api/user-settings',
        defaultSettings
      );
    },
    onSuccess: () => {
      // Refetch settings after successful initialization
      queryClient.invalidateQueries({ queryKey: ['/api/user-settings'] });
      toast({
        title: 'Settings initialized',
        description: 'Your settings have been set up with default values.',
      });
    },
    onError: (error) => {
      console.error('Error initializing settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to initialize user settings. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  // Check and initialize settings if needed
  // Track if we've already tried to initialize settings to prevent infinite loops
  const [hasTriedInitialization, setHasTriedInitialization] = useState(false);
  
  useEffect(() => {
    if (user?.id && isSettingsError && !isSettingsLoading && !hasTriedInitialization) {
      // If we tried to load settings but they don't exist, initialize them once
      setHasTriedInitialization(true);
      initializeUserSettings.mutate();
    }
  }, [user?.id, isSettingsError, isSettingsLoading, hasTriedInitialization]);
  
  // Update verification level based on user data
  useEffect(() => {
    if (userData) {
      // Use actual verification level from API or fallback to a default
      const level = userData.verificationLevel || 1;
      setVerificationLevel(level);
    }
  }, [userData]);

  // Update profile form values when profile data is loaded
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phoneNumber: '',
    }
  });
  
  // Update form values when profile data loads
  useEffect(() => {
    if (profile) {
      profileForm.reset({
        fullName: profile.fullName || '',
        email: profile.email || '',
        phoneNumber: profile.phoneNumber || '',
      });
    }
  }, [profile, profileForm]);
  
  // Initialize security form
  const securityForm = useForm<SecurityFormValues>({
    resolver: zodResolver(securityFormSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    }
  });
  
  // Reset security form when switching to security tab
  useEffect(() => {
    if (activeCategory === 'security') {
      securityForm.reset({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    }
  }, [activeCategory, securityForm]);
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: Partial<UserSettings>) => {
      const res = await fetch(`/api/users/${userId}/settings`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSettings),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update settings');
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['settings', userId] });
      setUpdateSuccess(true);
      setUpdateError(null);
      
      // Show toast notification
      toast({
        title: 'Settings updated',
        description: 'Your settings have been successfully updated.',
      });
      
      // Reset success message after a delay
      setTimeout(() => setUpdateSuccess(false), 3000);
    },
    onError: (error: Error) => {
      setUpdateError(error.message);
      setUpdateSuccess(false);
      
      // Show toast notification
      toast({
        variant: 'destructive',
        title: 'Error updating settings',
        description: error.message,
      });
    },
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      const res = await fetch(`/api/users/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update profile');
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile', userId] });
      setUpdateSuccess(true);
      setUpdateError(null);
      
      // Show toast notification
      toast({
        title: 'Profile updated',
        description: 'Your profile has been successfully updated.',
      });
      
      // Reset success message after a delay
      setTimeout(() => setUpdateSuccess(false), 3000);
    },
    onError: (error: Error) => {
      setUpdateError(error.message);
      setUpdateSuccess(false);
      
      // Show toast notification
      toast({
        variant: 'destructive',
        title: 'Error updating profile',
        description: error.message,
      });
    },
  });
  
  // Update password mutation
  const updatePasswordMutation = useMutation({
    mutationFn: async (data: SecurityFormValues) => {
      const res = await fetch(`/api/auth/change-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          currentPassword: data.currentPassword,
          newPassword: data.newPassword,
        }),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update password');
      }
      
      return res.json();
    },
    onSuccess: () => {
      securityForm.reset();
      setUpdateSuccess(true);
      setUpdateError(null);
      
      // Show toast notification
      toast({
        title: 'Password updated',
        description: 'Your password has been successfully updated.',
      });
      
      // Reset success message after a delay
      setTimeout(() => setUpdateSuccess(false), 3000);
    },
    onError: (error: Error) => {
      setUpdateError(error.message);
      setUpdateSuccess(false);
      
      // Show toast notification
      toast({
        variant: 'destructive',
        title: 'Error updating password',
        description: error.message,
      });
    },
  });
  
  // Handle profile form submission
  const onProfileSubmit: SubmitHandler<ProfileFormValues> = (data) => {
    updateProfileMutation.mutate(data);
  };
  
  // Handle security form submission
  const onSecuritySubmit: SubmitHandler<SecurityFormValues> = (data) => {
    updatePasswordMutation.mutate(data);
  };
  
  // Handle settings update
  const handleSettingsUpdate = (updatedSettings: Partial<UserSettings>) => {
    updateSettingsMutation.mutate(updatedSettings);
  };
  
  // Handle logout
  const handleLogout = () => {
    logout();
    location('/auth');
  };
  
  // Handle opening settings category
  const handleOpenSettings = (category: string) => {
    setActiveCategory(category);
  };
  
  // Check if any mutations are in progress
  const isMutating = 
    updateProfileMutation.isPending || 
    updatePasswordMutation.isPending || 
    updateSettingsMutation.isPending;
  
  // Check if there are any loading states
  const isLoading = isUserLoading || isSettingsLoading || loadingProfile;
  
  // Check if there are any errors
  const hasError = isSettingsError || profileError;
  
  // Get error message
  const errorMessage = 
    isSettingsError instanceof Error ? isSettingsError.message : 
    profileError instanceof Error ? profileError.message : 
    'An error occurred while loading your settings';
  
  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Settings</h1>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2">Loading settings...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (hasError) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Settings</h1>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {errorMessage}
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2"
              onClick={() => window.location.reload()}
            >
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  // Render settings form based on active category
  const renderSettingsForm = () => {
    switch (activeCategory) {
      case 'profile':
        return (
          <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input 
                id="fullName"
                {...profileForm.register('fullName')}
                placeholder="Your full name"
              />
              {profileForm.formState.errors.fullName && (
                <p className="text-red-500 text-sm mt-1">{profileForm.formState.errors.fullName.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input 
                id="email"
                {...profileForm.register('email')}
                placeholder="Your email address"
                type="email"
              />
              {profileForm.formState.errors.email && (
                <p className="text-red-500 text-sm mt-1">{profileForm.formState.errors.email.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Phone Number (Optional)</Label>
              <Input 
                id="phoneNumber"
                {...profileForm.register('phoneNumber')}
                placeholder="Your phone number"
              />
              {profileForm.formState.errors.phoneNumber && (
                <p className="text-red-500 text-sm mt-1">{profileForm.formState.errors.phoneNumber.message}</p>
              )}
            </div>
            
            <Button 
              type="submit" 
              disabled={profileForm.formState.isSubmitting || !profileForm.formState.isDirty}
            >
              {profileForm.formState.isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating Profile...
                </>
              ) : (
                'Save Profile'
              )}
            </Button>
          </form>
        );
        
      case 'security':
        return (
          <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <Input 
                  id="currentPassword" 
                  type="password" 
                  {...securityForm.register('currentPassword')} 
                  placeholder="Your current password" 
                />
                {securityForm.formState.errors.currentPassword && (
                  <p className="text-red-500 text-sm mt-1">
                    {securityForm.formState.errors.currentPassword.message}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="newPassword">New Password</Label>
                <Input 
                  id="newPassword" 
                  type="password" 
                  {...securityForm.register('newPassword')} 
                  placeholder="Your new password" 
                />
                {securityForm.formState.errors.newPassword && (
                  <p className="text-red-500 text-sm mt-1">
                    {securityForm.formState.errors.newPassword.message}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <Input 
                  id="confirmPassword" 
                  type="password" 
                  {...securityForm.register('confirmPassword')} 
                  placeholder="Confirm your new password" 
                />
                {securityForm.formState.errors.confirmPassword && (
                  <p className="text-red-500 text-sm mt-1">
                    {securityForm.formState.errors.confirmPassword.message}
                  </p>
                )}
              </div>
            </div>
            
            <Button 
              type="submit" 
              disabled={updatePasswordMutation.isPending || !securityForm.formState.isDirty}
              className="w-full"
            >
              {updatePasswordMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                'Change Password'
              )}
            </Button>
          </form>
        );
        
      case 'preferences':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language">Language</Label>
                <Select 
                  value={userSettings?.languagePreference || 'en'} 
                  onValueChange={(value) => {
                    handleSettingsUpdate({
                      ...userSettings,
                      languagePreference: value,
                    });
                  }}
                >
                  <SelectTrigger id="language">
                    <SelectValue placeholder="Select a language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ar">Arabic</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="currency">Default Currency</Label>
                <Select 
                  value={userSettings?.currencyPreference || 'USD'} 
                  onValueChange={(value) => {
                    handleSettingsUpdate({
                      ...userSettings,
                      currencyPreference: value,
                    });
                  }}
                >
                  <SelectTrigger id="currency">
                    <SelectValue placeholder="Select a currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">US Dollar ($)</SelectItem>
                    <SelectItem value="EUR">Euro (€)</SelectItem>
                    <SelectItem value="GBP">British Pound (£)</SelectItem>
                    <SelectItem value="JPY">Japanese Yen (¥)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="theme">Theme</Label>
                <Select 
                  value={userSettings?.themePreference || 'light'} 
                  onValueChange={(value) => {
                    handleSettingsUpdate({
                      ...userSettings,
                      themePreference: value,
                    });
                  }}
                >
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select a theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );
        
      case 'notifications':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Price Alerts</h3>
                  <p className="text-sm text-gray-500">Get notified when your watched assets change in price</p>
                </div>
                <Switch 
                  checked={userSettings?.notificationPreferences.priceAlerts || false}
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        notificationPreferences: {
                          ...userSettings.notificationPreferences,
                          priceAlerts: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">News Alerts</h3>
                  <p className="text-sm text-gray-500">Receive updates about market news</p>
                </div>
                <Switch 
                  checked={userSettings?.notificationPreferences.newsAlerts || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        notificationPreferences: {
                          ...userSettings.notificationPreferences,
                          newsAlerts: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Trading Updates</h3>
                  <p className="text-sm text-gray-500">Get notified about your trading activity</p>
                </div>
                <Switch 
                  checked={userSettings?.notificationPreferences.tradingUpdates || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        notificationPreferences: {
                          ...userSettings.notificationPreferences,
                          tradingUpdates: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Market Summaries</h3>
                  <p className="text-sm text-gray-500">Receive daily/weekly market summaries</p>
                </div>
                <Switch 
                  checked={userSettings?.notificationPreferences.marketSummaries || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        notificationPreferences: {
                          ...userSettings.notificationPreferences,
                          marketSummaries: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
            </div>
          </div>
        );
        
      case 'privacy':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Share Trading History</h3>
                  <p className="text-sm text-gray-500">Allow other users to see your trading history</p>
                </div>
                <Switch 
                  checked={userSettings?.privacySettings.shareTradeHistory || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        privacySettings: {
                          ...userSettings.privacySettings,
                          shareTradeHistory: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Show Portfolio Value</h3>
                  <p className="text-sm text-gray-500">Allow other users to see your portfolio value</p>
                </div>
                <Switch 
                  checked={userSettings?.privacySettings.showPortfolioValue || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        privacySettings: {
                          ...userSettings.privacySettings,
                          showPortfolioValue: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Data Collection</h3>
                  <p className="text-sm text-gray-500">Allow us to collect data for platform improvement</p>
                </div>
                <Switch 
                  checked={userSettings?.privacySettings.allowDataCollection || false} 
                  onCheckedChange={(checked) => {
                    if (userSettings) {
                      handleSettingsUpdate({
                        ...userSettings,
                        privacySettings: {
                          ...userSettings.privacySettings,
                          allowDataCollection: checked,
                        },
                      });
                    }
                  }}
                />
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  // Get title for active settings category
  const getActiveSettingsCategoryTitle = () => {
    switch (activeCategory) {
      case 'profile':
        return 'Profile Information';
      case 'security':
        return 'Security Settings';
      case 'preferences':
        return 'Display Preferences';
      case 'notifications':
        return 'Notification Settings';
      case 'privacy':
        return 'Privacy Controls';
      default:
        return 'Settings';
    }
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-textDark mb-6">Settings</h1>
      
      <div className="grid gap-6 md:grid-cols-[250px_1fr]">
        {/* Settings Categories */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-2">
              <Tabs defaultValue={activeCategory} orientation="vertical" onValueChange={setActiveCategory}>
                <TabsList className="flex flex-col items-stretch h-auto">
                  <TabsTrigger 
                    value="profile" 
                    className="justify-start text-left px-4"
                  >
                    Profile
                  </TabsTrigger>
                  <TabsTrigger 
                    value="security" 
                    className="justify-start text-left px-4"
                  >
                    Security
                  </TabsTrigger>
                  <TabsTrigger 
                    value="preferences" 
                    className="justify-start text-left px-4"
                  >
                    Preferences
                  </TabsTrigger>
                  <TabsTrigger 
                    value="notifications" 
                    className="justify-start text-left px-4"
                  >
                    Notifications
                  </TabsTrigger>
                  <TabsTrigger 
                    value="privacy" 
                    className="justify-start text-left px-4"
                  >
                    Privacy
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <Button 
                variant="destructive" 
                className="w-full"
                onClick={handleLogout}
              >
                Logout
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Settings Form */}
        <Card>
          <CardHeader>
            <CardTitle>{getActiveSettingsCategoryTitle()}</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {updateSuccess && (
              <Alert className="mb-6 bg-green-50 border-green-200">
                <Check className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-600">
                  Settings updated successfully
                </AlertDescription>
              </Alert>
            )}
            
            {updateError && (
              <Alert variant="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {updateError}
                </AlertDescription>
              </Alert>
            )}
            
            {renderSettingsForm()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}