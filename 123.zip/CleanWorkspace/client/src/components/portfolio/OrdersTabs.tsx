"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, type ReactNode } from "react";

interface OrdersTabsProps {
  ordersContent: ReactNode;
  tradesContent: ReactNode;
  defaultTab?: "orders" | "trades";
}

export default function OrdersTabs({
  ordersContent,
  tradesContent,
  defaultTab = "orders"
}: OrdersTabsProps) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);

  return (
    <Tabs
      defaultValue={defaultTab}
      value={activeTab}
      onValueChange={setActiveTab}
      className="w-full"
    >
      <div className="border-b mb-6">
        <TabsList className="bg-transparent">
          <TabsTrigger 
            value="orders" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none data-[state=active]:shadow-none px-6"
          >
            Orders
          </TabsTrigger>
          <TabsTrigger 
            value="trades" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none data-[state=active]:shadow-none px-6"
          >
            Manual Trades
          </TabsTrigger>
        </TabsList>
      </div>

      <TabsContent value="orders" className="mt-0">
        {ordersContent}
      </TabsContent>
      
      <TabsContent value="trades" className="mt-0">
        {tradesContent}
      </TabsContent>
    </Tabs>
  );
}