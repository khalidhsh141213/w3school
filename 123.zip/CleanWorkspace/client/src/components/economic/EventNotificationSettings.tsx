import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Switch } from '../ui/switch';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { 
  Bell, 
  BellOff, 
  Calendar, 
  Check, 
  Clock, 
  Flag, 
  Globe, 
  LineChart, 
  Mail, 
  RefreshCw, 
  Smartphone, 
  TrendingUp
} from 'lucide-react';
import useEventNotifications, { 
  EventCategory, 
  EventNotification,
  NotificationChannel
} from '@/hooks/useEventNotifications';
import { format, formatDistanceToNow } from 'date-fns';

// List of all event categories
const EVENT_CATEGORIES: { label: string; value: EventCategory; icon: React.ReactNode }[] = [
  { label: 'High Impact Events', value: 'high_impact', icon: <TrendingUp className="h-4 w-4" /> },
  { label: 'Interest Rates', value: 'interest_rate', icon: <LineChart className="h-4 w-4" /> },
  { label: 'GDP', value: 'gdp', icon: <Flag className="h-4 w-4" /> },
  { label: 'Employment', value: 'employment', icon: <Smartphone className="h-4 w-4" /> },
  { label: 'Inflation', value: 'inflation', icon: <TrendingUp className="h-4 w-4" /> },
  { label: 'Trade', value: 'trade', icon: <Globe className="h-4 w-4" /> },
  { label: 'Consumer', value: 'consumer', icon: <Smartphone className="h-4 w-4" /> },
  { label: 'Housing', value: 'housing', icon: <Flag className="h-4 w-4" /> },
  { label: 'Central Bank', value: 'central_bank', icon: <LineChart className="h-4 w-4" /> },
];

// List of impact levels
const IMPACT_LEVELS = [
  { label: 'High Impact', value: 'high' },
  { label: 'Medium Impact', value: 'medium' },
  { label: 'Low Impact', value: 'low' },
];

// List of countries
const COUNTRIES = [
  { label: 'United States', value: 'US' },
  { label: 'Eurozone', value: 'EU' },
  { label: 'United Kingdom', value: 'UK' },
  { label: 'Japan', value: 'JP' },
  { label: 'China', value: 'CN' },
  { label: 'Canada', value: 'CA' },
  { label: 'Australia', value: 'AU' },
];

// Notification channel options
const NOTIFICATION_CHANNELS: { label: string; value: NotificationChannel; icon: React.ReactNode }[] = [
  { label: 'In-App', value: 'app', icon: <Bell className="h-4 w-4" /> },
  { label: 'Email', value: 'email', icon: <Mail className="h-4 w-4" /> },
  { label: 'Push', value: 'push', icon: <Smartphone className="h-4 w-4" /> },
  { label: 'SMS', value: 'sms', icon: <Smartphone className="h-4 w-4" /> },
];

// Advance notice options
const ADVANCE_NOTICE_OPTIONS = [
  { label: '5 minutes', value: 5 },
  { label: '15 minutes', value: 15 },
  { label: '30 minutes', value: 30 },
  { label: '1 hour', value: 60 },
  { label: '4 hours', value: 240 },
  { label: '1 day', value: 1440 },
];

// Notification item component
const NotificationItem = ({ 
  notification,
  onMarkAsRead,
  onDelete 
}: { 
  notification: EventNotification; 
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
}) => {
  return (
    <div className={`p-4 border-b last:border-0 ${notification.read ? 'bg-background' : 'bg-primary/5'}`}>
      <div className="flex justify-between items-start">
        <div>
          <h4 className="text-sm font-medium flex items-center">
            {notification.eventImpact === 'high' && <TrendingUp className="h-3 w-3 text-red-500 mr-1" />}
            {notification.eventTitle}
          </h4>
          <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
          <div className="flex items-center mt-2 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3 mr-1" />
            <span>{format(new Date(notification.eventDate), 'PPP')}</span>
            <span className="mx-2">•</span>
            <Clock className="h-3 w-3 mr-1" />
            <span>{formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}</span>
          </div>
        </div>
        <div className="flex space-x-1">
          {!notification.read && (
            <Button 
              variant="ghost"
              size="sm"
              onClick={() => onMarkAsRead(notification.id)}
              className="h-8 w-8 p-0 rounded-full"
              title="Mark as read"
            >
              <Check className="h-4 w-4" />
            </Button>
          )}
          <Button 
            variant="ghost"
            size="sm"
            onClick={() => onDelete(notification.id)}
            className="h-8 w-8 p-0 rounded-full text-muted-foreground"
            title="Delete notification"
          >
            <BellOff className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export function EventNotificationSettings() {
  // Use the notifications hook
  const {
    settings,
    notifications,
    unreadCount,
    isLoading,
    error,
    
    // Subscription methods
    subscribeToCategory,
    unsubscribeFromCategory,
    subscribeToImpactLevel,
    unsubscribeFromImpactLevel,
    subscribeToCountry,
    unsubscribeFromCountry,
    
    // Setting methods
    setNotificationChannels,
    setAdvanceNotice,
    setNotificationsEnabled,
    
    // Notification management
    markAsRead,
    markAllAsRead,
    deleteNotification,
    
    // Helpers
    isSubscribed,
    isSubscribedToImpactLevel,
    isSubscribedToCountry,
    
    // Manual refresh
    fetchNotifications,
    fetchSettings
  } = useEventNotifications({
    autoMarkAsRead: false,
    showToasts: true,
    fetchOnStart: true
  });
  
  // Handle errors
  if (error) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Error loading notification settings</AlertTitle>
        <AlertDescription>
          {error.message}
          <Button 
            variant="outline" 
            size="sm"
            className="mt-2"
            onClick={() => {
              fetchSettings();
              fetchNotifications();
            }}
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  
  // Loading state
  if (isLoading && !settings) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Notification Settings</CardTitle>
          <CardDescription>Loading your notification preferences...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center p-6">
          <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
        </CardContent>
      </Card>
    );
  }
  
  // Handle empty settings (should never happen because of default settings)
  if (!settings) {
    return (
      <Alert>
        <AlertTitle>No notification settings found</AlertTitle>
        <AlertDescription>
          Your notification settings could not be loaded.
          <Button 
            variant="outline" 
            size="sm"
            className="mt-2"
            onClick={() => fetchSettings()}
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Initialize Settings
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Event Notifications</CardTitle>
            <CardDescription>Manage your economic event alerts</CardDescription>
          </div>
          <div className="flex items-center">
            <Switch 
              checked={settings.enabled}
              onCheckedChange={(checked) => setNotificationsEnabled(checked)}
              id="notifications-enabled"
            />
            <Label htmlFor="notifications-enabled" className="ml-2">
              {settings.enabled ? 'Enabled' : 'Disabled'}
            </Label>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="categories">
          <TabsList className="mb-6">
            <TabsTrigger value="categories">Event Categories</TabsTrigger>
            <TabsTrigger value="channels">Notification Channels</TabsTrigger>
            <TabsTrigger value="inbox" className="relative">
              Notification Inbox
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-4 min-w-4 flex items-center justify-center px-1">
                  {unreadCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="categories" className="space-y-6">
            <div>
              <h3 className="text-sm font-medium mb-3">Event Categories</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {EVENT_CATEGORIES.map((category) => (
                  <div key={category.value} className="flex items-center space-x-2 py-2">
                    <Checkbox 
                      id={`category-${category.value}`}
                      checked={isSubscribed(category.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          subscribeToCategory(category.value);
                        } else {
                          unsubscribeFromCategory(category.value);
                        }
                      }}
                    />
                    <Label 
                      htmlFor={`category-${category.value}`}
                      className="flex items-center cursor-pointer"
                    >
                      {category.icon}
                      <span className="ml-2">{category.label}</span>
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-3">Impact Levels</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {IMPACT_LEVELS.map((impact) => (
                  <div key={impact.value} className="flex items-center space-x-2 py-2">
                    <Checkbox 
                      id={`impact-${impact.value}`}
                      checked={isSubscribedToImpactLevel(impact.value as any)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          subscribeToImpactLevel(impact.value as any);
                        } else {
                          unsubscribeFromImpactLevel(impact.value as any);
                        }
                      }}
                    />
                    <Label 
                      htmlFor={`impact-${impact.value}`}
                      className="cursor-pointer"
                    >
                      {impact.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-3">Countries</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {COUNTRIES.map((country) => (
                  <div key={country.value} className="flex items-center space-x-2 py-2">
                    <Checkbox 
                      id={`country-${country.value}`}
                      checked={isSubscribedToCountry(country.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          subscribeToCountry(country.value);
                        } else {
                          unsubscribeFromCountry(country.value);
                        }
                      }}
                    />
                    <Label 
                      htmlFor={`country-${country.value}`}
                      className="cursor-pointer"
                    >
                      {country.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="channels" className="space-y-6">
            <div>
              <h3 className="text-sm font-medium mb-3">Notification Channels</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {NOTIFICATION_CHANNELS.map((channel) => (
                  <div key={channel.value} className="flex items-center space-x-2 py-2">
                    <Checkbox 
                      id={`channel-${channel.value}`}
                      checked={settings.channels.includes(channel.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setNotificationChannels([...settings.channels, channel.value]);
                        } else {
                          setNotificationChannels(settings.channels.filter(c => c !== channel.value));
                        }
                      }}
                    />
                    <Label 
                      htmlFor={`channel-${channel.value}`}
                      className="flex items-center cursor-pointer"
                    >
                      {channel.icon}
                      <span className="ml-2">{channel.label}</span>
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-3">Advance Notice</h3>
              <div className="flex flex-col space-y-2">
                <Label htmlFor="advance-notice">
                  How early should we notify you before an event?
                </Label>
                <Select
                  value={settings.advanceNotice.toString()}
                  onValueChange={(value) => setAdvanceNotice(parseInt(value))}
                >
                  <SelectTrigger id="advance-notice" className="w-[200px]">
                    <SelectValue placeholder="Select advance notice" />
                  </SelectTrigger>
                  <SelectContent>
                    {ADVANCE_NOTICE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="inbox">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-medium">
                Notification Inbox
                {unreadCount > 0 && (
                  <span className="ml-2 inline-block bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5">
                    {unreadCount} unread
                  </span>
                )}
              </h3>
              
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => fetchNotifications()}
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Refresh
                </Button>
                
                {unreadCount > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => markAllAsRead()}
                  >
                    <Check className="h-3 w-3 mr-1" />
                    Mark All Read
                  </Button>
                )}
              </div>
            </div>
            
            <div className="border rounded-md">
              {notifications.length > 0 ? (
                notifications.map((notification) => (
                  <NotificationItem 
                    key={notification.id}
                    notification={notification}
                    onMarkAsRead={markAsRead}
                    onDelete={deleteNotification}
                  />
                ))
              ) : (
                <div className="p-8 text-center">
                  <Bell className="h-8 w-8 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No notifications yet</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    You'll be notified here when important economic events are coming up
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default EventNotificationSettings;