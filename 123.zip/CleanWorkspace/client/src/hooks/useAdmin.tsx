import { useState } from 'react';
import axios from 'axios';

type AdminDataType = 'assets' | 'trades' | 'finances' | 'kyc';

/**
 * Hook for admin operations
 * Provides functionality for fetching, updating, and deleting admin data
 */
export const useAdmin = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Fetch data from the admin API
   * @param dataType Type of data to fetch
   * @returns Promise with the fetched data
   */
  const fetchData = async (dataType: AdminDataType) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.get(`/api/admin/${dataType}`);
      return response.data;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to fetch data';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Update an item
   * @param dataType Type of data to update
   * @param id ID of the item to update
   * @param data Updated data
   * @returns Promise with the updated data
   */
  const updateItem = async (dataType: AdminDataType, id: string | number, data: any) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.put(`/api/admin/${dataType}/${id}`, data);
      return response.data;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to update item';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Delete an item
   * @param dataType Type of data to delete
   * @param id ID of the item to delete
   * @returns Promise indicating success
   */
  const deleteItem = async (dataType: AdminDataType, id: string | number) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.delete(`/api/admin/${dataType}/${id}`);
      return response.data;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to delete item';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Add a new item
   * @param dataType Type of data to add
   * @param data Data for the new item
   * @returns Promise with the created data
   */
  const addItem = async (dataType: AdminDataType, data: any) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(`/api/admin/${dataType}`, data);
      return response.data;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to add item';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Export data as CSV
   * @param dataType Type of data to export
   * @returns Promise with the export URL
   */
  const exportData = async (dataType: AdminDataType) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.get(`/api/admin/${dataType}/export`, {
        responseType: 'blob'
      });
      
      // Create a URL for the blob
      const url = window.URL.createObjectURL(new Blob([response.data]));
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${dataType}_export_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      
      return url;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to export data';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Get statistics for admin dashboard
   * @returns Promise with the statistics data
   */
  const getStats = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.get('/api/admin/stats');
      return response.data;
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to fetch statistics';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Process a KYC request (approve or reject)
   * @param id ID of the KYC request
   * @param status New status (verified/rejected)
   * @param notes Admin notes about the verification
   * @returns Promise with the updated KYC request
   */
  const processKycRequest = async (id: number, status: 'verified' | 'rejected', notes: string) => {
    return updateItem('kyc', id, { status, verificationNotes: notes });
  };

  return {
    fetchData,
    updateItem,
    deleteItem,
    addItem,
    exportData,
    getStats,
    processKycRequest,
    loading,
    error
  };
};

export default useAdmin;