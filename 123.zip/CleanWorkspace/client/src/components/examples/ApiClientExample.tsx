import React, { useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { AssetsApi, MarketDataApi, TradingApi } from '../../services/ApiService';
import { OrderInput } from '../../types/schemas';
import { formatCurrency, formatDateTime, formatPercentage } from '../../utils/formatters';

/**
 * API Client Example Component
 * 
 * Demonstrates various features of the API client and hooks
 */
const ApiClientExample: React.FC = () => {
  // State for the example
  const [symbol, setSymbol] = useState<string>('AAPL');
  const [orderStatus, setOrderStatus] = useState<string | null>(null);
  
  // Basic API request for market data
  const { 
    data: marketData, 
    loading: marketLoading, 
    error: marketError,
    refetch: refetchMarketData
  } = useApi({
    apiMethod: () => MarketDataApi.getQuote(symbol),
    dependencies: [symbol],
  });
  
  // API request with cache enabled
  const { 
    data: asset,
    loading: assetLoading,
    error: assetError
  } = useApi({
    apiMethod: () => AssetsApi.getBySymbol(symbol),
    dependencies: [symbol],
  });
  
  // API post request (doesn't execute immediately due to skip)
  const { 
    data: orderResult,
    loading: orderLoading,
    error: orderError,
    execute: placeOrder
  } = useApi({
    apiMethod: (orderData: OrderInput) => TradingApi.createOrder(orderData),
    skip: true, // Don't execute immediately
    onSuccess: (data) => {
      setOrderStatus(`Order placed successfully: ${data.id}`);
      // Refresh market data after placing an order
      refetchMarketData();
    },
    onError: (error) => {
      setOrderStatus(`Error placing order: ${error.message}`);
    }
  });
  
  // Trending assets for demonstration
  const { 
    data: trendingAssets 
  } = useApi({
    apiMethod: AssetsApi.getTrending,
  });
  
  // Handle symbol change
  const handleSymbolChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSymbol(event.target.value);
  };
  
  // Handle refresh click
  const handleRefresh = () => {
    refetchMarketData();
  };
  
  // Handle order submission
  const handlePlaceOrder = (side: 'buy' | 'sell') => {
    if (!marketData) return;
    
    const orderData: OrderInput = {
      symbol: symbol,
      side: side,
      type: 'market',
      quantity: 1,
      timeInForce: 'day',
    };
    
    placeOrder(orderData);
  };
  
  return (
    <div className="api-client-example">
      <div className="example-header">
        <h2>API Client Example</h2>
        <p className="description">
          This example demonstrates the various features of the API client, 
          including data fetching, error handling, and caching.
        </p>
      </div>
      
      <div className="example-controls">
        <div className="control-group">
          <label htmlFor="symbol-select">Select Symbol:</label>
          <select 
            id="symbol-select" 
            value={symbol} 
            onChange={handleSymbolChange}
            disabled={marketLoading}
          >
            <option value="AAPL">Apple (AAPL)</option>
            <option value="MSFT">Microsoft (MSFT)</option>
            <option value="GOOGL">Google (GOOGL)</option>
            <option value="AMZN">Amazon (AMZN)</option>
            <option value="TSLA">Tesla (TSLA)</option>
          </select>
          
          <button 
            className="refresh-button" 
            onClick={handleRefresh}
            disabled={marketLoading}
          >
            Refresh Data
          </button>
        </div>
      </div>
      
      <div className="example-content">
        <div className="data-section">
          <h3>Market Data</h3>
          {marketLoading ? (
            <div className="loading-state">Loading market data...</div>
          ) : marketError ? (
            <div className="error-state">
              <div className="error-message">
                Error loading market data: {marketError.message}
              </div>
              <button onClick={refetchMarketData}>Retry</button>
            </div>
          ) : marketData ? (
            <div className="market-data">
              <div className="data-row">
                <span className="label">Symbol:</span>
                <span className="value">{marketData.symbol}</span>
              </div>
              <div className="data-row">
                <span className="label">Price:</span>
                <span className="value">{formatCurrency(marketData.price)}</span>
              </div>
              <div className="data-row">
                <span className="label">Change:</span>
                <span className={`value ${marketData.change >= 0 ? 'positive' : 'negative'}`}>
                  {formatCurrency(marketData.change)} ({formatPercentage(marketData.changePercent)})
                </span>
              </div>
              <div className="data-row">
                <span className="label">Volume:</span>
                <span className="value">{marketData.volume.toLocaleString()}</span>
              </div>
              <div className="data-row">
                <span className="label">Updated:</span>
                <span className="value">
                  {formatDateTime(marketData.timestamp)}
                </span>
              </div>
            </div>
          ) : (
            <div className="empty-state">No market data available</div>
          )}
        </div>
        
        <div className="data-section">
          <h3>Asset Information</h3>
          {assetLoading ? (
            <div className="loading-state">Loading asset information...</div>
          ) : assetError ? (
            <div className="error-state">
              <div className="error-message">
                Error loading asset: {assetError.message}
              </div>
            </div>
          ) : asset ? (
            <div className="asset-info">
              <div className="data-row">
                <span className="label">Name:</span>
                <span className="value">{asset.name}</span>
              </div>
              {asset.description && (
                <div className="data-row">
                  <span className="label">Description:</span>
                  <span className="value">{asset.description}</span>
                </div>
              )}
              <div className="data-row">
                <span className="label">Type:</span>
                <span className="value">{asset.type}</span>
              </div>
              <div className="data-row">
                <span className="label">Exchange:</span>
                <span className="value">{asset.exchange}</span>
              </div>
              {asset.sector && (
                <div className="data-row">
                  <span className="label">Sector:</span>
                  <span className="value">{asset.sector}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="empty-state">No asset information available</div>
          )}
        </div>
      </div>
      
      <div className="actions-section">
        <h3>Trading Actions</h3>
        <div className="action-buttons">
          <button 
            className="buy-button" 
            onClick={() => handlePlaceOrder('buy')}
            disabled={!marketData || orderLoading}
          >
            Buy
          </button>
          <button 
            className="sell-button" 
            onClick={() => handlePlaceOrder('sell')}
            disabled={!marketData || orderLoading}
          >
            Sell
          </button>
        </div>
        
        {orderLoading && (
          <div className="order-status loading">Processing order...</div>
        )}
        
        {orderStatus && (
          <div className={`order-status ${orderError ? 'error' : 'success'}`}>
            {orderStatus}
          </div>
        )}
      </div>
      
      <div className="trending-section">
        <h3>Trending Assets</h3>
        {trendingAssets && trendingAssets.length > 0 ? (
          <div className="trending-assets">
            <ul>
              {trendingAssets.slice(0, 5).map((asset) => (
                <li key={asset.symbol} onClick={() => setSymbol(asset.symbol)}>
                  <span className="asset-symbol">{asset.symbol}</span>
                  <span className="asset-name">{asset.name}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="empty-state">No trending assets available</div>
        )}
      </div>
      
      <div className="example-docs">
        <h3>Implementation Notes</h3>
        <ul>
          <li>
            <strong>Basic API Request:</strong> The market data is fetched using the <code>useApi</code> hook
            with a dependency on the selected symbol, automatically refetching when the symbol changes.
          </li>
          <li>
            <strong>Error Handling:</strong> All API requests handle loading states and errors,
            showing appropriate UI for each state.
          </li>
          <li>
            <strong>Caching:</strong> The asset information is cached to reduce API calls
            for previously loaded symbols.
          </li>
          <li>
            <strong>Manual Refetching:</strong> The "Refresh Data" button demonstrates manually
            triggering a refetch of the market data.
          </li>
          <li>
            <strong>Mutation Example:</strong> The "Buy" and "Sell" buttons demonstrate using the API
            for POST requests, with success and error callbacks.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default ApiClientExample; 