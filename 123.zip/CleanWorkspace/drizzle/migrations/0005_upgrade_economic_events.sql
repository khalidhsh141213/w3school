/*
 * Economic Events Enhancement Migration
 * Expands economic events tracking capabilities:
 * - Adds detailed event information columns
 * - Implements time zone aware timestamps
 * - Adds performance optimization indexes
 * - Enables better event filtering and analysis
 * 
 * Dependencies:
 * - 0000_initial_migration.sql (economic_events table)
 * - 0004_optimize_database_schema.sql (optimization patterns)
 */

-- Add new columns to economic_events table
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS event_time TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS country TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS source TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS source_id TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS actual_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS forecast_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS previous_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS affected_markets TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_economic_events_date ON economic_events(event_date);
CREATE INDEX IF NOT EXISTS idx_economic_events_country ON economic_events(country);
CREATE INDEX IF NOT EXISTS idx_economic_events_importance ON economic_events(importance_level);
CREATE INDEX IF NOT EXISTS idx_economic_events_source ON economic_events(source); 