# WebSocket: أفضل الممارسات

## مقدمة

تُستخدم تقنية WebSocket في منصتنا لتوفير تحديثات الأسعار في الوقت الفعلي للعملات الرقمية (Crypto) والعملات الأجنبية (Forex). تم تصميم البنية التحتية لتوفير تحديثات سريعة وموثوقة مع الحفاظ على أداء عالٍ.

## المبادئ الرئيسية

1. **مخصصة للبيانات في الوقت الفعلي فقط**: يجب استخدام WebSocket فقط للبيانات التي تتطلب تحديثات في الوقت الفعلي مثل أسعار الكريبتو والفوركس.
2. **استخدام REST للتحديثات الأقل تكرارًا**: بالنسبة للأصول التي لا تتطلب تحديثات مستمرة (مثل الأسهم والمؤشرات)، استخدم طلبات REST API.
3. **التعامل مع انقطاع الاتصال**: تم تنفيذ آليات لإعادة الاتصال تلقائيًا في حالة فقدان الاتصال مع الخادم.
4. **الحد من عدد الاشتراكات**: تم تطبيق حدود على عدد الأصول التي يمكن الاشتراك فيها لتجنب تجاوز حدود الاستخدام.

## استخدام WebSocketManager

`WebSocketManager` هو مكون مركزي لإدارة الاتصالات WebSocket في التطبيق. يوفر واجهة موحدة للتعامل مع الاتصالات والرسائل والاشتراكات.

### الاستخدام الأساسي

```typescript
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';

// استخدام WebSocketManager في المكون الخاص بك
function YourComponent() {
  // الحصول على عنوان WebSocket الديناميكي
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = `${protocol}//${host}/ws`;
  
  // استخدام WebSocketManager
  const { status, send, subscribe } = useWebSocket(wsUrl, {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });
  
  // الاشتراك في تحديثات الأسعار عند تحميل المكون
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      // إرسال طلب اشتراك للرموز المحددة
      send({
        type: 'subscribe',
        symbols: ['BTC/USD', 'ETH/USD', 'EUR/USD']
      });
      
      // الاشتراك في الرسائل الواردة
      subscribe((message) => {
        if (message.type === 'priceUpdate') {
          // معالجة تحديث الأسعار
          console.log(`تم استلام تحديث سعر لـ ${message.data.symbol}: ${message.data.price}`);
        }
      });
    }
    
    // تنظيف الاشتراكات عند إزالة المكون
    return () => {
      if (status === ConnectionStatus.CONNECTED) {
        send({
          type: 'unsubscribe',
          symbols: ['BTC/USD', 'ETH/USD', 'EUR/USD']
        });
      }
    };
  }, [status, send, subscribe]);
  
  // عرض حالة الاتصال للمستخدم
  return (
    <div>
      <div>حالة الاتصال: {status}</div>
      {/* واجهة المستخدم الخاصة بك */}
    </div>
  );
}
```

### إعادة استخدام الاتصال

`WebSocketManager` مصمم كنمط Singleton لضمان استخدام اتصال واحد فقط لكل عنوان URL. هذا يعني أن جميع المكونات التي تستخدم نفس عنوان WebSocket تشترك في نفس الاتصال، مما يقلل من استهلاك الموارد.

```typescript
// مكون 1
const { status: status1, send: send1 } = useWebSocket('wss://example.com/ws');

// مكون 2 - يستخدم نفس اتصال WebSocket
const { status: status2, send: send2 } = useWebSocket('wss://example.com/ws');
```

## أنواع الرسائل

### الاشتراك في الرموز

```json
{
  "type": "subscribe",
  "symbols": ["BTC/USD", "ETH/USD", "EUR/USD"]
}
```

### إلغاء الاشتراك من الرموز

```json
{
  "type": "unsubscribe",
  "symbols": ["BTC/USD", "ETH/USD", "EUR/USD"]
}
```

### الاشتراك حسب نوع الأصل

```json
{
  "type": "subscribe",
  "assetTypes": ["crypto", "forex"]
}
```

### تحديث الأسعار (من الخادم)

```json
{
  "type": "priceUpdate",
  "data": {
    "symbol": "BTC/USD",
    "price": "29750.45",
    "change": "120.75",
    "changePercent": "0.41",
    "volume": "4356789",
    "timestamp": "2025-03-30T12:34:56.789Z"
  }
}
```

## التعامل مع الأخطاء وإعادة الاتصال

`WebSocketManager` يتضمن آليات متقدمة للتعامل مع الأخطاء وإعادة الاتصال:

1. **Circuit Breaker**: يمنع محاولات إعادة الاتصال المتكررة عند وجود مشاكل في الخادم.
2. **Rate Limiter**: يحد من عدد الرسائل المرسلة في فترة زمنية محددة.
3. **Message Queue**: يحتفظ بالرسائل في قائمة انتظار عندما يكون الاتصال مقطوعاً.
4. **إعادة الاتصال التلقائية**: يحاول إعادة الاتصال تلقائياً عند انقطاعه.

```typescript
// التكوين المتقدم
const { status, send, subscribe } = useWebSocket(wsUrl, {
  reconnectAttempts: 5,
  reconnectInterval: 3000,
  heartbeatInterval: 30000,
  heartbeatTimeout: 60000,
  circuitBreaker: {
    enabled: true,
    failureThreshold: 3,
    resetTimeout: 30000
  },
  rateLimiter: {
    enabled: true,
    maxOperations: 20,
    windowMs: 1000
  }
});
```

## تنظيف الموارد

من المهم تنظيف الاشتراكات والموارد عند إزالة المكون من DOM:

```typescript
useEffect(() => {
  // اشتراك في تحديثات الأسعار
  const handlePriceUpdate = (data) => {
    // معالجة التحديث
  };
  
  subscribe(handlePriceUpdate);
  
  // تنظيف عند إزالة المكون
  return () => {
    // إلغاء الاشتراك من الرموز
    send({
      type: 'unsubscribe',
      symbols: ['BTC/USD', 'ETH/USD']
    });
  };
}, [subscribe, send]);
```

## حدود التنفيذ الحالية

1. **أصول محدودة**: حالياً، يتم دعم WebSocket فقط للعملات الرقمية والفوركس.
2. **أداء عطلة نهاية الأسبوع**: تُوقف تحديثات الفوركس يوم الأحد، بينما تستمر تحديثات العملات الرقمية.
3. **الاعتماد على مزودي البيانات**: يعتمد توفر البيانات في الوقت الفعلي على مزودي البيانات الخارجيين.

## ملاحظات إضافية

- استخدم دائماً الوظيفة `subscribe` للاشتراك في الرسائل وليس الاستماع المباشر لأحداث `onmessage` للحفاظ على التنظيف المناسب.
- تجنب الاشتراك في عدد كبير من الرموز في وقت واحد لتجنب مشاكل الأداء.
- استخدم التنبيهات السعرية بدلاً من تحديثات الأسعار المستمرة للمراقبة طويلة المدى.