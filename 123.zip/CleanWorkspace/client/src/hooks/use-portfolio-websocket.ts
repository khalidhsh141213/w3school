/**
 * usePortfolioWebSocket Hook
 * 
 * A specialized hook for subscribing to and managing real-time portfolio data.
 * Built on top of the WebSocket connection hook with features for portfolio updates.
 * 
 * @example
 * ```tsx
 * function PortfolioSummary() {
 *   const { 
 *     portfolio, 
 *     positions, 
 *     isLoading, 
 *     error 
 *   } = usePortfolioWebSocket();
 *   
 *   if (isLoading) return <div>Loading...</div>;
 *   if (error) return <div>Error: {error.message}</div>;
 *   
 *   return (
 *     <div>
 *       <h2>Portfolio Summary</h2>
 *       <div>Total Value: ${portfolio.totalValue.toFixed(2)}</div>
 *       <div>P/L: ${portfolio.unrealizedPL.toFixed(2)}</div>
 *       <h3>Positions ({positions.length})</h3>
 *       {positions.map(pos => (
 *         <div key={pos.assetId}>
 *           {pos.assetSymbol}: {pos.quantity} @ ${pos.entryPrice.toFixed(2)}
 *         </div>
 *       ))}
 *     </div>
 *   );
 * }
 * ```
 */

import { useCallback, useEffect, useState } from 'react';
import { ConnectionStatus, Priority } from '../services/WebSocketService';
import useWebSocketConnection from './useWebSocketConnection';
import { validateApiResponse } from '../lib/validation';
import api from '../lib/api';

// Portfolio data interface
export interface Portfolio {
  id: string;
  userId: string;
  totalValue: number;
  availableBalance: number;
  investedAmount: number;
  unrealizedPL: number;
  plPercentage: number;
  createdAt: string;
  updatedAt: string;
  positions?: Position[];
}

// Position data interface
export interface Position {
  id: string;
  portfolioId: string;
  assetId: string;
  assetSymbol?: string;
  assetType?: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPL?: number;
  plPercentage?: number;
  direction: 'long' | 'short';
  leverage?: number;
  stopLoss?: number;
  takeProfit?: number;
  openDate: string;
  lastUpdate?: string;
}

// Order data interface
export interface Order {
  id: string;
  userId: string;
  assetId: string;
  assetSymbol?: string;
  assetType?: string;
  quantity: number;
  price: number;
  orderType: 'market' | 'limit' | 'stop' | 'stop_limit';
  orderStatus: 'pending' | 'open' | 'filled' | 'canceled' | 'rejected';
  direction: 'buy' | 'sell';
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  filledAt?: string;
  filledPrice?: number;
  leverage?: number;
  stopLoss?: number;
  takeProfit?: number;
}

// Default portfolio data when none exists
export const defaultPortfolio: Portfolio = {
  id: "",
  userId: "",
  totalValue: 50000,
  availableBalance: 50000,
  investedAmount: 0,
  unrealizedPL: 0,
  plPercentage: 0,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  positions: []
};

// Interface for hook options
export interface PortfolioWebSocketOptions {
  // How often to poll for updates even if WebSocket is unavailable (0 to disable)
  pollingInterval?: number;
  // Whether to fetch initial data via API call
  fetchInitialData?: boolean;
  // Throttle updates to avoid too many renders (milliseconds, 0 to disable)
  throttleUpdates?: number;
  // Cache behavior
  cache?: {
    // Whether to use cached data if available
    enabled: boolean;
    // Max age of cached data in milliseconds
    maxAge: number;
  };
}

// Default options
const DEFAULT_OPTIONS: PortfolioWebSocketOptions = {
  pollingInterval: 30000, // 30 seconds
  fetchInitialData: true,
  throttleUpdates: 500, // 500ms
  cache: {
    enabled: true,
    maxAge: 60000 // 1 minute
  }
};

// Local cache
const portfolioCache = new Map<string, {
  data: Portfolio;
  timestamp: number;
}>();

/**
 * Hook for subscribing to real-time portfolio data
 * @param userId User ID to get portfolio data for (optional, uses current user if not provided)
 * @param options Options for the hook
 * @returns Object with portfolio data and status
 */
export function usePortfolioWebSocket(
  userId?: string,
  options: Partial<PortfolioWebSocketOptions> = {}
) {
  // Merge options with defaults
  const mergedOptions: PortfolioWebSocketOptions = {
    ...DEFAULT_OPTIONS,
    ...options,
    cache: {
      ...DEFAULT_OPTIONS.cache,
      ...options.cache
    }
  };
  
  // Portfolio data state
  const [portfolio, setPortfolio] = useState<Portfolio>(defaultPortfolio);
  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [lastUpdateTime, setLastUpdateTime] = useState<number>(0);
  
  // Track current user ID for subscriptions
  const [currentUserId, setCurrentUserId] = useState<string | undefined>(userId);
  
  // For throttling updates
  const updateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Use our WebSocket connection hook
  const { 
    status, 
    subscribe, 
    subscribeTopic,
    send, 
    isConnected 
  } = useWebSocketConnection('/portfolio');
  
  // Determine if we should use the current user
  useEffect(() => {
    if (!userId && !currentUserId) {
      // Try to get current user from API
      const fetchCurrentUser = async () => {
        try {
          const response = await api.auth.me();
          if (response.data?.id) {
            setCurrentUserId(response.data.id);
          }
        } catch (err) {
          console.error('Failed to fetch current user:', err);
          // Don't set error state here as the user might not be logged in
        }
      };
      
      fetchCurrentUser();
    } else if (userId && userId !== currentUserId) {
      setCurrentUserId(userId);
    }
  }, [userId, currentUserId]);
  
  // Handle portfolio update
  const handlePortfolioUpdate = useCallback((data: any) => {
    if (!data) {
      console.warn('[usePortfolioWebSocket] Received empty portfolio update');
      return;
    }
    
    const now = Date.now();
    
    // Update cache if enabled
    if (mergedOptions.cache?.enabled && currentUserId) {
      portfolioCache.set(currentUserId, {
        data,
        timestamp: now
      });
    }
    
    // Handle throttling if enabled
    if (mergedOptions.throttleUpdates && mergedOptions.throttleUpdates > 0) {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      
      const timeSinceLastUpdate = now - lastUpdateTime;
      
      if (timeSinceLastUpdate >= mergedOptions.throttleUpdates) {
        // Update immediately
        setPortfolio(data);
        setPositions(data.positions || []);
        setLastUpdateTime(now);
      } else {
        // Schedule an update
        updateTimeoutRef.current = setTimeout(() => {
          setPortfolio(data);
          setPositions(data.positions || []);
          setLastUpdateTime(now);
        }, mergedOptions.throttleUpdates - timeSinceLastUpdate);
      }
    } else {
      // No throttling, update immediately
      setPortfolio(data);
      setPositions(data.positions || []);
    }
    
    // Mark as loaded
    setIsLoading(false);
  }, [mergedOptions.cache?.enabled, mergedOptions.throttleUpdates, lastUpdateTime, currentUserId]);
  
  // Handle order update
  const handleOrderUpdate = useCallback((data: any) => {
    if (!data || !Array.isArray(data)) {
      console.warn('[usePortfolioWebSocket] Received invalid order update:', data);
      return;
    }
    
    setOrders(data);
    
    // Mark as loaded (for orders part)
    setIsLoading(false);
  }, []);
  
  // Fetch initial portfolio data
  const fetchPortfolioData = useCallback(async () => {
    if (!currentUserId) {
      return;
    }
    
    try {
      // Check cache first if enabled
      if (mergedOptions.cache?.enabled) {
        const cached = portfolioCache.get(currentUserId);
        if (cached && (Date.now() - cached.timestamp) < mergedOptions.cache.maxAge) {
          handlePortfolioUpdate(cached.data);
          return;
        }
      }
      
      // Fetch portfolio data
      const response = await api.portfolio.getSummary(currentUserId);
      
      if (response.data) {
        handlePortfolioUpdate(response.data);
      } else {
        console.warn(`[usePortfolioWebSocket] No portfolio data returned for user: ${currentUserId}`);
        handlePortfolioUpdate(defaultPortfolio);
      }
    } catch (err) {
      console.error(`[usePortfolioWebSocket] Error fetching portfolio data:`, err);
      setError(err instanceof Error ? err : new Error(String(err)));
      setIsLoading(false);
    }
  }, [currentUserId, handlePortfolioUpdate, mergedOptions.cache]);
  
  // Fetch initial orders data
  const fetchOrdersData = useCallback(async () => {
    if (!currentUserId) {
      return;
    }
    
    try {
      // Fetch orders
      const response = await api.orders.getAll(currentUserId);
      
      if (response.data?.items) {
        handleOrderUpdate(response.data.items);
      } else {
        console.warn(`[usePortfolioWebSocket] No orders returned for user: ${currentUserId}`);
        handleOrderUpdate([]);
      }
    } catch (err) {
      console.error(`[usePortfolioWebSocket] Error fetching orders:`, err);
      // Don't set error here, as portfolio data might still be available
    }
  }, [currentUserId, handleOrderUpdate]);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    // Skip if no user ID is available
    if (!currentUserId) {
      return;
    }
    
    // If WebSocket is connected, subscribe to updates
    if (status === ConnectionStatus.CONNECTED) {
      // Subscribe to portfolio updates
      const portfolioUnsubscribe = subscribe('portfolioUpdate', (data) => {
        // Only process if it's for the current user
        if (data.userId === currentUserId) {
          handlePortfolioUpdate(data);
        }
      });
      
      // Subscribe to order updates
      const orderUnsubscribe = subscribe('orderUpdate', (data) => {
        // Only process if it's for the current user
        if (data.userId === currentUserId) {
          handleOrderUpdate(data.orders || []);
        }
      });
      
      // Send subscription message
      subscribeTopic('portfolio', currentUserId);
      
      // Return cleanup function
      return () => {
        portfolioUnsubscribe();
        orderUnsubscribe();
      };
    }
    
    // Fetch initial data if WebSocket is not connected
    if (mergedOptions.fetchInitialData) {
      fetchPortfolioData();
      fetchOrdersData();
    }
  }, [
    status,
    subscribe,
    subscribeTopic,
    currentUserId,
    mergedOptions.fetchInitialData,
    handlePortfolioUpdate,
    handleOrderUpdate,
    fetchPortfolioData,
    fetchOrdersData
  ]);
  
  // Set up polling if needed
  useEffect(() => {
    if (!currentUserId || status === ConnectionStatus.CONNECTED) {
      return; // Skip if no user ID or WebSocket is connected
    }
    
    if (mergedOptions.pollingInterval && mergedOptions.pollingInterval > 0) {
      const interval = setInterval(() => {
        fetchPortfolioData();
        fetchOrdersData();
      }, mergedOptions.pollingInterval);
      
      return () => clearInterval(interval);
    }
  }, [currentUserId, status, mergedOptions.pollingInterval, fetchPortfolioData, fetchOrdersData]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, []);
  
  // Calculate if data is stale
  const isStale = useCallback(() => {
    if (!lastUpdateTime) return false;
    
    return (Date.now() - lastUpdateTime) > (mergedOptions.cache?.maxAge || 0);
  }, [lastUpdateTime, mergedOptions.cache?.maxAge]);
  
  // Return the hook's API
  return {
    portfolio,
    positions,
    orders,
    isLoading,
    error,
    isStale: isStale(),
    isConnected,
    connectionStatus: status,
    lastUpdateTime,
    
    // Helper to manually trigger a refresh
    refresh: useCallback(() => {
      if (currentUserId) {
        fetchPortfolioData();
        fetchOrdersData();
      }
    }, [currentUserId, fetchPortfolioData, fetchOrdersData])
  };
}

export default usePortfolioWebSocket;