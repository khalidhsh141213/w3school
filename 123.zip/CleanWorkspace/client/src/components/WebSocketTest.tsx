/**
 * WebSocket Test Component
 * 
 * This component tests the WebSocket connection and displays the connection status.
 */
import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { InfoIcon, WifiIcon, AlertTriangleIcon, AlertCircleIcon, CheckCircleIcon } from "lucide-react";

// Define possible WebSocket connection states
enum ConnectionStatus {
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected',
  RECONNECTING = 'reconnecting',
  ERROR = 'error'
}

// Helper function to get protocol based on current location
function getWebSocketUrl() {
  // Check for environment variable first
  const envWsUrl = import.meta.env.VITE_WS_URL;
  if (envWsUrl) {
    console.log(`Using WS_URL from environment: ${envWsUrl}`);
    return envWsUrl;
  }
  
  // Fallback to dynamic construction
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = `${protocol}//${host}/ws`;
  console.log(`Dynamically constructed WebSocket URL: ${wsUrl}`);
  return wsUrl;
}

export function WebSocketTest() {
  // State for connection status and received messages
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [messages, setMessages] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [lastPing, setLastPing] = useState<number | null>(null);
  const [pingTime, setPingTime] = useState<number | null>(null);
  
  // Reference to the WebSocket connection
  const wsRef = useRef<WebSocket | null>(null);
  
  // Function to establish a WebSocket connection
  const connect = () => {
    try {
      setStatus(ConnectionStatus.CONNECTING);
      setError(null);
      
      const wsUrl = getWebSocketUrl();
      console.log(`Connecting to WebSocket at: ${wsUrl}`);
      
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connection established');
        setStatus(ConnectionStatus.CONNECTED);
        // Send initial ping to test round-trip time
        sendPing();
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message received:', data);
          
          // Handle pong messages (response to our ping)
          if (data.type === 'pong' && lastPing) {
            const roundTripTime = Date.now() - lastPing;
            setPingTime(roundTripTime);
          }
          
          // Add message to our messages list
          setMessages(prev => {
            // Keep only the latest 20 messages to prevent excessive rendering
            const newMessages = [data, ...prev];
            if (newMessages.length > 20) {
              return newMessages.slice(0, 20);
            }
            return newMessages;
          });
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      };
      
      ws.onclose = () => {
        console.log('WebSocket connection closed');
        setStatus(ConnectionStatus.DISCONNECTED);
        wsRef.current = null;
      };
      
      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        setStatus(ConnectionStatus.ERROR);
        setError('Connection error occurred. See console for details.');
      };
      
      wsRef.current = ws;
    } catch (err: any) {
      console.error('Failed to establish WebSocket connection:', err);
      setStatus(ConnectionStatus.ERROR);
      setError(err.message || 'Unknown error occurred');
      wsRef.current = null;
    }
  };
  
  // Function to disconnect the WebSocket
  const disconnect = () => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
      setStatus(ConnectionStatus.DISCONNECTED);
    }
  };
  
  // Function to reconnect the WebSocket
  const reconnect = () => {
    disconnect();
    // Short delay before reconnecting
    setTimeout(() => {
      connect();
    }, 500);
  };
  
  // Function to send a ping message to test latency
  const sendPing = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      setLastPing(Date.now());
      wsRef.current.send(JSON.stringify({ type: 'ping' }));
    }
  };
  
  // Function to request market data
  const requestMarketData = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ 
        type: 'request_market_data',
        symbols: [] // Empty array gets all symbols
      }));
    }
  };
  
  // Function to clear messages
  const clearMessages = () => {
    setMessages([]);
  };
  
  // Render appropriate badge based on connection status
  const renderStatusBadge = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return <Badge className="bg-green-500">Connected</Badge>;
      case ConnectionStatus.CONNECTING:
        return <Badge className="bg-blue-500">Connecting...</Badge>;
      case ConnectionStatus.RECONNECTING:
        return <Badge className="bg-yellow-500">Reconnecting...</Badge>;
      case ConnectionStatus.DISCONNECTED:
        return <Badge className="bg-gray-500">Disconnected</Badge>;
      case ConnectionStatus.ERROR:
        return <Badge className="bg-red-500">Error</Badge>;
      default:
        return <Badge className="bg-gray-300">Unknown</Badge>;
    }
  };
  
  // Cleanup WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);
  
  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <Card className="shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-t-lg">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl md:text-2xl flex items-center">
                <WifiIcon className="mr-2" /> WebSocket Connection Test
              </CardTitle>
              <CardDescription className="text-gray-100">
                Test real-time data connections
              </CardDescription>
            </div>
            {renderStatusBadge()}
          </div>
        </CardHeader>
        
        <CardContent className="pt-6">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircleIcon className="h-4 w-4" />
              <AlertTitle>Connection Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Connection Info</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Status:</span>
                  <span className="font-medium">{status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">URL:</span>
                  <span className="font-medium">{getWebSocketUrl()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Ping Time:</span>
                  <span className="font-medium">{pingTime !== null ? `${pingTime}ms` : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Messages:</span>
                  <span className="font-medium">{messages.length}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-2">Actions</h3>
              <div className="space-y-2">
                <Button 
                  className={`w-full ${status === ConnectionStatus.CONNECTED ? 'bg-green-100 text-green-800' : 'bg-blue-600'}`}
                  onClick={connect}
                  disabled={status === ConnectionStatus.CONNECTED || status === ConnectionStatus.CONNECTING}
                >
                  Connect
                </Button>
                <Button 
                  className="w-full bg-red-500 hover:bg-red-600"
                  onClick={disconnect}
                  disabled={status !== ConnectionStatus.CONNECTED}
                >
                  Disconnect
                </Button>
                <Button 
                  className="w-full bg-yellow-500 hover:bg-yellow-600"
                  onClick={reconnect}
                  disabled={status === ConnectionStatus.CONNECTING || status === ConnectionStatus.RECONNECTING}
                >
                  Reconnect
                </Button>
                <Button 
                  className="w-full bg-purple-500 hover:bg-purple-600"
                  onClick={sendPing}
                  disabled={status !== ConnectionStatus.CONNECTED}
                >
                  Send Ping
                </Button>
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={requestMarketData}
                  disabled={status !== ConnectionStatus.CONNECTED}
                >
                  Request Market Data
                </Button>
              </div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold">Received Messages</h3>
              <Button variant="outline" size="sm" onClick={clearMessages}>
                Clear
              </Button>
            </div>
            
            {messages.length === 0 ? (
              <div className="p-8 text-center text-gray-500 border border-dashed rounded-lg">
                <InfoIcon className="mx-auto mb-2 h-8 w-8" />
                <p>No messages received yet. Connect and interact with the WebSocket to see data here.</p>
              </div>
            ) : (
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-80 overflow-y-auto">
                  {messages.map((msg, index) => (
                    <div key={index} className={`p-3 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} border-b text-sm`}>
                      <div className="flex justify-between mb-1">
                        <span className="font-medium text-blue-700">
                          Type: {msg.type || 'Unknown'}
                        </span>
                        <span className="text-gray-500 text-xs">
                          {new Date(msg.timestamp || Date.now()).toLocaleTimeString()}
                        </span>
                      </div>
                      <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
                        {JSON.stringify(msg, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="bg-gray-50 border-t">
          <div className="w-full text-center text-gray-500 text-sm flex items-center justify-center">
            <AlertTriangleIcon className="h-4 w-4 mr-2" />
            <span>Note: Reconnection logic should be built into production applications for robustness.</span>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}