import PortfolioSummary from '@/components/common/PortfolioSummary';
import MarketOverview from '@/components/dashboard/MarketOverview';
import WatchlistTable from '@/components/watchlist/WatchlistTable';
import { Helmet } from 'react-helmet';

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Dashboard | Pro Trading Platform</title>
        <meta name="description" content="View your portfolio performance, track market movements, and monitor your watchlist all in one place." />
        <meta name="keywords" content="trading dashboard, portfolio, market overview, watchlist" />
      </Helmet>
      
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Dashboard</h1>
        
        <PortfolioSummary variant="dashboard" />
        
        <MarketOverview />
        
        <WatchlistTable />
      </div>
    </>
  );
}
