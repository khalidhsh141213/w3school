import { useContext } from 'react';
import { AppContext } from '../context/AppContext';

interface Translations {
  [key: string]: {
    en: string;
    ar: string;
  };
}

const translations: Translations = {
  welcome: {
    en: 'Welcome',
    ar: 'مرحباً'
  },
  dashboard: {
    en: 'Dashboard',
    ar: 'لوحة التحكم'
  },
  portfolio: {
    en: 'Portfolio',
    ar: 'المحفظة'
  },
  trading: {
    en: 'Trading',
    ar: 'التداول'
  },
  settings: {
    en: 'Settings',
    ar: 'الإعدادات'
  }
};

const translations: Translations = {
  // Header
  'tradingPlatform': {
    en: 'Trading Platform',
    ar: 'منصة التداول'
  },
  // Ticker
  // Market Overview
  'marketOverview': {
    en: 'Market Overview',
    ar: 'نظرة عامة على السوق'
  },
  // Market Sentiment
  'marketSentiment': {
    en: 'Market Sentiment',
    ar: 'مؤشر المشاعر'
  },
  'bullish': {
    en: 'Bullish',
    ar: 'صاعد'
  },
  'bearish': {
    en: 'Bearish',
    ar: 'هابط'
  },
  'analysisUpdated': {
    en: 'Analysis updated',
    ar: 'تم تحديث التحليل'
  },
  'ago': {
    en: 'ago',
    ar: 'منذ'
  },
  // Watchlist
  'watchlist': {
    en: 'Watchlist',
    ar: 'قائمة المراقبة'
  },
  // Chart
  // AI Analysis
  'aiMarketAnalysis': {
    en: 'AI Market Analysis',
    ar: 'تحليل السوق بالذكاء الاصطناعي'
  },
  'rsi': {
    en: 'RSI',
    ar: 'مؤشر القوة النسبية'
  },
  'macd': {
    en: 'MACD',
    ar: 'مؤشر الماكد'
  },
  'movingAverage': {
    en: 'Moving Average',
    ar: 'المتوسط المتحرك'
  },
  'positiveCrossover': {
    en: 'Positive Crossover',
    ar: 'تقاطع إيجابي'
  },
  'aboveBullish': {
    en: 'Above (Bullish)',
    ar: 'فوق (صاعد)'
  },
  'aiPrediction': {
    en: 'AI Prediction',
    ar: 'توقعات الذكاء الاصطناعي'
  },
  'confidence': {
    en: 'Confidence:',
    ar: 'الثقة:'
  },
  'projectedGrowth': {
    en: 'Projected growth:',
    ar: 'النمو المتوقع:'
  },
  'targetPrice': {
    en: 'Target price:',
    ar: 'السعر المستهدف:'
  },
  'inNextDays': {
    en: 'in next',
    ar: 'في الـ'
  },
  'days': {
    en: 'days',
    ar: 'أيام القادمة'
  },
  // News
  'latestNews': {
    en: 'Latest News',
    ar: 'أحدث الأخبار'
  },
  'viewAllNews': {
    en: 'View all news',
    ar: 'عرض جميع الأخبار'
  },
  // Trading
  'trade': {
    en: 'Trade',
    ar: 'تداول'
  },
  'symbol': {
    en: 'Symbol',
    ar: 'الرمز'
  },
  'balance': {
    en: 'Balance:',
    ar: 'الرصيد:'
  },
  'quantity': {
    en: 'Quantity',
    ar: 'الكمية'
  },
  'price': {
    en: 'Price',
    ar: 'السعر'
  },
  'orderType': {
    en: 'Order Type',
    ar: 'نوع الأمر'
  },
  'buy': {
    en: 'Buy',
    ar: 'شراء'
  },
  'sell': {
    en: 'Sell',
    ar: 'بيع'
  },
  'estimatedCost': {
    en: 'Estimated Cost:',
    ar: 'التكلفة المقدرة:'
  },
  'commission': {
    en: 'Commission:',
    ar: 'العمولة:'
  },
  'total': {
    en: 'Total:',
    ar: 'الإجمالي:'
  },
  // Portfolio
  'portfolioSummary': {
    en: 'Portfolio Summary',
    ar: 'ملخص المحفظة'
  },
  'todaysChange': {
    en: 'Today\'s change',
    ar: 'تغير اليوم'
  },
  'shares': {
    en: 'shares',
    ar: 'سهم'
  },
  'viewPortfolioDetails': {
    en: 'View Portfolio Details',
    ar: 'عرض تفاصيل المحفظة'
  },
  // AI Recommendations
  'aiRecommendations': {
    en: 'AI Recommendations',
    ar: 'توصيات الذكاء الاصطناعي'
  },
  'hold': {
    en: 'Hold',
    ar: 'احتفاظ'
  },
  // Footer
  'allRightsReserved': {
    en: '© 2023 Trading Platform. All rights reserved.',
    ar: '© 2023 منصة التداول. جميع الحقوق محفوظة.'
  },
  'terms': {
    en: 'Terms',
    ar: 'الشروط'
  },
  'privacy': {
    en: 'Privacy',
    ar: 'الخصوصية'
  },
  'help': {
    en: 'Help',
    ar: 'المساعدة'
  }
};

export const useTranslation = () => {
  const { appState } = useContext(AppContext);
  const language = appState.language;

  const t = (key: string): string => {
    if (!translations[key]) {
      console.warn(`Translation missing for key: ${key}`);
      return key;
    }
    return translations[key][language];
  };

  return { t, language };
};
