/**
 * أداة مساعدة لتسجيل أنشطة المستخدمين
 * تم تصميمها لتعمل مع نظام المكافآت والإحالات وتتبع الأنشطة الجديد
 */

import { db } from '../db.js';
import { activities } from '../../shared/schema.js';

export interface ActivityLogParams {
  userId: number;
  type: string;
  description: string;
  metadata?: Record<string, any>;
  ip?: string;
  userAgent?: string;
  relatedEntityType?: string;
  relatedEntityId?: string;
}

/**
 * تسجيل نشاط جديد للمستخدم
 * @param params معلمات النشاط
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logUserActivity(params: ActivityLogParams) {
  try {
    const {
      userId,
      type,
      description,
      metadata = {},
      ip,
      userAgent,
      relatedEntityType,
      relatedEntityId
    } = params;

    const [activity] = await db.insert(activities).values({
      userId,
      type,
      description,
      metadata,
      ip,
      userAgent,
      timestamp: new Date(),
      relatedEntityType,
      relatedEntityId
    }).returning();

    console.log(`✓ تم تسجيل نشاط "${type}" للمستخدم ${userId}`);
    return activity;
  } catch (error) {
    console.error('خطأ في تسجيل نشاط المستخدم:', error);
    throw error;
  }
}

/**
 * تسجيل نشاط تسجيل الدخول
 * @param userId معرف المستخدم
 * @param ip عنوان IP
 * @param userAgent معلومات متصفح المستخدم
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logLoginActivity(userId: number, ip?: string, userAgent?: string) {
  return logUserActivity({
    userId,
    type: 'login',
    description: 'تسجيل دخول المستخدم',
    ip,
    userAgent,
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}

/**
 * تسجيل نشاط الصفقة
 * @param userId معرف المستخدم
 * @param tradeId معرف الصفقة
 * @param tradeType نوع الصفقة (شراء، بيع)
 * @param symbol رمز الأصل
 * @param amount قيمة الصفقة
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logTradeActivity(
  userId: number,
  tradeId: number,
  tradeType: string,
  symbol: string,
  amount: string
) {
  return logUserActivity({
    userId,
    type: 'trade',
    description: `صفقة ${tradeType} لـ ${symbol}`,
    relatedEntityType: 'trade',
    relatedEntityId: tradeId.toString(),
    metadata: {
      tradeId,
      tradeType,
      symbol,
      amount,
      timestamp: new Date().toISOString()
    }
  });
}

/**
 * تسجيل نشاط استخدام المكافأة
 * @param userId معرف المستخدم
 * @param bonusId معرف المكافأة
 * @param amount المبلغ المستخدم
 * @param context سياق استخدام المكافأة (صفقة، إيداع، الخ)
 * @param contextId معرف سياق استخدام المكافأة
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logBonusUsedActivity(
  userId: number,
  bonusId: string,
  amount: string,
  context: string,
  contextId: string
) {
  return logUserActivity({
    userId,
    type: 'bonus_used',
    description: `استخدام مكافأة بقيمة ${amount}`,
    relatedEntityType: 'bonus',
    relatedEntityId: bonusId,
    metadata: {
      bonusId,
      amount,
      context,
      contextId,
      timestamp: new Date().toISOString()
    }
  });
}

/**
 * تسجيل نشاط الحصول على مكافأة
 * @param userId معرف المستخدم
 * @param bonusId معرف المكافأة
 * @param amount قيمة المكافأة
 * @param bonusType نوع المكافأة
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logBonusReceivedActivity(
  userId: number,
  bonusId: string,
  amount: string,
  bonusType: string
) {
  return logUserActivity({
    userId,
    type: 'bonus_received',
    description: `حصول على مكافأة ${bonusType} بقيمة ${amount}`,
    relatedEntityType: 'bonus',
    relatedEntityId: bonusId,
    metadata: {
      bonusId,
      amount,
      bonusType,
      timestamp: new Date().toISOString()
    }
  });
}

/**
 * تسجيل نشاط إحالة
 * @param referrerId معرف المستخدم المحيل
 * @param referredId معرف المستخدم المحال
 * @param referralId معرف الإحالة
 * @returns وعد يحتوي على السجل المضاف
 */
export async function logReferralActivity(
  referrerId: number,
  referredId: number,
  referralId: string
) {
  return logUserActivity({
    userId: referrerId,
    type: 'referral',
    description: `قام المستخدم بإحالة مستخدم جديد`,
    relatedEntityType: 'referral',
    relatedEntityId: referralId,
    metadata: {
      referralId,
      referredId,
      timestamp: new Date().toISOString()
    }
  });
}