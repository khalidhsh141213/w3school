/**
 * Logger Utility - Simple logging with timestamps and levels
 * 
 * This module provides a standardized way to log messages across the application
 * with consistent formatting, timestamp, and log levels.
 */

// Log levels with color codes for console output
const LOG_LEVELS = {
  debug: { priority: 0, color: '\x1b[34m' }, // blue
  info: { priority: 1, color: '\x1b[32m' },  // green
  warn: { priority: 2, color: '\x1b[33m' },  // yellow
  error: { priority: 3, color: '\x1b[31m' }, // red
  fatal: { priority: 4, color: '\x1b[35m' }  // magenta
};

// Default configuration
const config = {
  level: process.env.LOG_LEVEL || 'info',
  dateFormat: 'h:mm:ss A',
  colorize: true
};

/**
 * Formats the current timestamp for log messages
 */
function formatTimestamp() {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0');
  
  return `${hours}:${minutes}:${seconds}`;
}

/**
 * Main logger class
 */
class Logger {
  constructor(options = {}) {
    this.config = { ...config, ...options };
  }
  
  /**
   * Sets the logging level
   */
  setLevel(level) {
    if (LOG_LEVELS[level]) {
      this.config.level = level;
    }
  }
  
  /**
   * Log a message at the specified level
   */
  log(level, ...args) {
    if (!LOG_LEVELS[level]) level = 'info';
    
    // Skip if current log level is higher priority
    if (LOG_LEVELS[level].priority < LOG_LEVELS[this.config.level].priority) return;
    
    const timestamp = formatTimestamp();
    const colorReset = '\x1b[0m';
    const color = this.config.colorize ? LOG_LEVELS[level].color : '';
    
    // Format: [timestamp] [category] message
    let category = '';
    if (typeof args[0] === 'string' && args[0].startsWith('[') && args[0].includes(']')) {
      category = args.shift();
    }
    
    // Format: [timestamp] [level] [category] message
    console.log(
      `${color}${timestamp} [${level}]${category ? ' ' + category : ''}${colorReset}`,
      ...args
    );
  }
  
  // Log level methods
  debug(...args) { this.log('debug', ...args); }
  info(...args) { this.log('info', ...args); }
  warn(...args) { this.log('warn', ...args); }
  error(...args) { this.log('error', ...args); }
  fatal(...args) { this.log('fatal', ...args); }
}

// Create and export a singleton instance
const logger = new Logger();

export { logger };