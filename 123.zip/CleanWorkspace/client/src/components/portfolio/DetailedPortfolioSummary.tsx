import { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, usePortfolioSummary } from '@/hooks/use-portfolio-summary';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, TrendingDown, TrendingUp, Wallet, DollarSign, PieChart } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

export function DetailedPortfolioSummary() {
  const { t } = useTranslation();
  const { data, isLoading, isError, error } = usePortfolioSummary();
  const { toast } = useToast();

  // Show error toast if data fetch fails
  useEffect(() => {
    if (isError) {
      toast({
        title: t('Error fetching portfolio summary'),
        description: error ? (error as Error).message : t('Failed to load portfolio data'),
        variant: 'destructive',
      });
    }
  }, [isError, error, toast, t]);

  if (isLoading) {
    return <PortfolioSummarySkeleton />;
  }

  if (isError || !data) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>{t('Error')}</AlertTitle>
        <AlertDescription>
          {t('Could not load portfolio summary. Please try again later.')}
        </AlertDescription>
      </Alert>
    );
  }

  const summary = data as any;

  // Calculate utilization percentages for the progress bars
  const marginUtilization = summary.marginAuthorized 
    ? (parseFloat(summary.marginUsed) / parseFloat(summary.marginAuthorized)) * 100 
    : 0;
  
  const investmentUtilization = summary.totalBalance 
    ? (parseFloat(summary.totalInvestment) / parseFloat(summary.totalBalance)) * 100 
    : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-xl">{t('Portfolio Summary')}</CardTitle>
          <CardDescription>
            {t('Last updated')}: {new Date(summary.lastUpdate).toLocaleString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Total Value */}
            <div className="flex flex-col space-y-1.5 rounded-lg border p-3">
              <div className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
                <Wallet className="h-4 w-4" />
                {t('Total Balance')}
              </div>
              <div className="text-2xl font-bold">
                {formatCurrency(summary.totalBalance)}
              </div>
              <div className="text-xs text-muted-foreground">
                {t('Available')}: {formatCurrency(summary.availableBalance)}
              </div>
            </div>

            {/* Equity */}
            <div className="flex flex-col space-y-1.5 rounded-lg border p-3">
              <div className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
                <PieChart className="h-4 w-4" />
                {t('Total Equity')}
              </div>
              <div className="text-2xl font-bold">
                {formatCurrency(summary.totalEquity)}
              </div>
              <div className="text-xs text-muted-foreground">
                {t('Positions')}: {summary.openPositions || 0}
              </div>
            </div>

            {/* Profit/Loss */}
            <div className="flex flex-col space-y-1.5 rounded-lg border p-3">
              <div className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
                <DollarSign className="h-4 w-4" />
                {t('Profit & Loss')}
              </div>
              <div className="flex items-center gap-2">
                <div className={cn(
                  "text-2xl font-bold",
                  parseFloat(summary.totalProfit) > parseFloat(summary.totalLoss) 
                    ? "text-green-500" 
                    : "text-red-500"
                )}>
                  {formatCurrency(
                    parseFloat(summary.totalProfit) - parseFloat(summary.totalLoss)
                  )}
                </div>
                {parseFloat(summary.totalProfit) > parseFloat(summary.totalLoss) ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
              <div className="text-xs text-muted-foreground">
                {t('Return')}: {summary.totalReturn}%
              </div>
            </div>
          </div>

          <Separator className="my-4" />

          {/* Investment allocation */}
          <div className="space-y-4">
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <div className="font-medium">{t('Investment Allocation')}</div>
                <div className="text-muted-foreground">
                  {formatCurrency(summary.totalInvestment)} / {formatCurrency(summary.totalBalance)}
                </div>
              </div>
              <Progress value={investmentUtilization} className="h-2" />
              <div className="mt-1 text-xs text-muted-foreground">
                {investmentUtilization.toFixed(1)}% {t('of your funds are invested')}
              </div>
            </div>

            {/* Margin utilization (if margin trading is enabled) */}
            {parseFloat(summary.marginAuthorized) > 0 && (
              <div>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <div className="font-medium">{t('Margin Utilization')}</div>
                  <div className="text-muted-foreground">
                    {formatCurrency(summary.marginUsed)} / {formatCurrency(summary.marginAuthorized)}
                  </div>
                </div>
                <Progress 
                  value={marginUtilization} 
                  className={cn(
                    "h-2",
                    marginUtilization > 80 ? "bg-red-200" : 
                    marginUtilization > 50 ? "bg-yellow-200" : ""
                  )} 
                />
                <div className="mt-1 text-xs text-muted-foreground">
                  {marginUtilization.toFixed(1)}% {t('of your margin is utilized')}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function PortfolioSummarySkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-6 w-36" />
        <Skeleton className="h-4 w-48" />
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex flex-col space-y-1.5 rounded-lg border p-3">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-3 w-20" />
            </div>
          ))}
        </div>
        <Separator className="my-4" />
        <div className="space-y-4">
          <div>
            <div className="mb-1 flex items-center justify-between">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-24" />
            </div>
            <Skeleton className="h-2 w-full" />
            <Skeleton className="mt-1 h-3 w-40" />
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-24" />
            </div>
            <Skeleton className="h-2 w-full" />
            <Skeleton className="mt-1 h-3 w-40" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}