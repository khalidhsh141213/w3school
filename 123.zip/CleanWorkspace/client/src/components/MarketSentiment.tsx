import { useTranslation } from '../lib/useTranslation';
import { useQuery } from '@tanstack/react-query';

const MarketSentiment = () => {
  const { t, language } = useTranslation();
  
  // This would fetch actual sentiment data from an API
  const { data: sentiment, isLoading } = useQuery({
    queryKey: ['/api/sentiment'],
    queryFn: async () => {
      // For demonstration, we'll return static data
      // In a real app, this would call an actual API
      return {
        bullish: 65,
        bearish: 35,
        updatedAt: new Date().getTime() - 300000 // 5 minutes ago
      };
    },
    retry: false,
    staleTime: 60000 // 1 minute
  });

  // Format the time since update
  const formatTimeSince = (timestamp: number) => {
    const seconds = Math.floor((new Date().getTime() - timestamp) / 1000);
    let interval = Math.floor(seconds / 3600);
    
    if (interval >= 1) {
      return `${interval}h`;
    }
    
    interval = Math.floor(seconds / 60);
    if (interval >= 1) {
      return `${interval}m`;
    }
    
    return `${Math.floor(seconds)}s`;
  };

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <h2 className="text-lg font-condensed font-bold mb-3">
        {t('marketSentiment')}
      </h2>
      {isLoading ? (
        <div className="py-4 text-center text-neutral">Loading sentiment data...</div>
      ) : sentiment ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span>{t('bullish')}</span>
            <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-secondary h-2.5 rounded-full" 
                style={{ width: `${sentiment.bullish}%` }}
              ></div>
            </div>
            <span className="ml-2">{sentiment.bullish}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span>{t('bearish')}</span>
            <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-accent h-2.5 rounded-full" 
                style={{ width: `${sentiment.bearish}%` }}
              ></div>
            </div>
            <span className="ml-2">{sentiment.bearish}%</span>
          </div>
          <div className="mt-4 pt-4 border-t text-center text-sm text-neutral">
            {t('analysisUpdated')}
            <span className="font-semibold"> {formatTimeSince(sentiment.updatedAt)} </span>
            {t('ago')}
          </div>
        </div>
      ) : (
        <div className="py-4 text-center text-neutral">No sentiment data available</div>
      )}
    </div>
  );
};

export default MarketSentiment;
