/**
 * Asset Service
 * Provides efficient data access layer for assets with caching and error handling
 */

import { db } from '../db';
import { assets, Asset, marketData, aiAnalysis } from '../../shared/schema';
import { assetsCache } from '../cache';
import { eq } from 'drizzle-orm';
import { errorHandler, ErrorType, ErrorSeverity } from './errorHandlingService';
import { log } from '../vite';

export class AssetService {
  private static instance: AssetService;

  private constructor() {}

  public static getInstance(): AssetService {
    if (!AssetService.instance) {
      AssetService.instance = new AssetService();
    }
    return AssetService.instance;
  }

  /**
   * Get all assets with caching
   */
  public async getAllAssets(forceRefresh = false): Promise<Asset[]> {
    try {
      // Use cache if available and not forcing refresh
      if (!forceRefresh) {
        const cachedAssetsArray = assetsCache.get<Asset[]>('all_assets');
        if (cachedAssetsArray) {
          return cachedAssetsArray;
        }
      }

      // Fetch from database
      const allAssets = await db.select().from(assets);
      
      // Cache the results
      assetsCache.set('all_assets', allAssets);
      
      return allAssets;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets'
      );
      return [];
    }
  }

  /**
   * Get asset by symbol with caching
   */
  public async getAssetBySymbol(symbol: string): Promise<Asset | null> {
    try {
      // Try to get from cache first
      const cachedAsset = assetsCache.get<Asset>(`asset_${symbol}`);
      if (cachedAsset) {
        return cachedAsset;
      }

      // Fetch from database
      const [asset] = await db
        .select()
        .from(assets)
        .where(eq(assets.symbol, symbol));
      
      if (asset) {
        // Cache the result
        assetsCache.set(`asset_${symbol}`, asset);
        return asset;
      }
      
      return null;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { symbol }
      );
      return null;
    }
  }

  /**
   * Get multiple assets by symbols with efficient caching
   */
  public async getAssetsBySymbols(symbols: string[]): Promise<Record<string, Asset>> {
    if (!symbols.length) return {};
    
    try {
      const result: Record<string, Asset> = {};
      const missingSymbols: string[] = [];
      
      // Check cache first for each symbol
      symbols.forEach(symbol => {
        const cachedAsset = assetsCache.get<Asset>(`asset_${symbol}`);
        if (cachedAsset) {
          result[symbol] = cachedAsset;
        } else {
          missingSymbols.push(symbol);
        }
      });
      
      // If all assets were in cache, return early
      if (missingSymbols.length === 0) {
        return result;
      }
      
      // Fetch missing assets from database in a single query
      const fetchedAssets = await db
        .select()
        .from(assets)
        .where(
          missingSymbols.length === 1
            ? eq(assets.symbol, missingSymbols[0])
            : assets.symbol.in(missingSymbols)
        );
      
      // Cache each asset and add to result
      fetchedAssets.forEach(asset => {
        assetsCache.set(`asset_${asset.symbol}`, asset);
        result[asset.symbol] = asset;
      });
      
      return result;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT_MULTIPLE',
        'assets',
        { symbols }
      );
      return {};
    }
  }
  
  /**
   * Get asset with its related market data
   */
  public async getAssetWithMarketData(symbol: string): Promise<{ asset: Asset, marketData: any } | null> {
    try {
      // Try to get from cache first
      const cachedFullAsset = assetsCache.get<{ asset: Asset, marketData: any }>(`full_asset_${symbol}`);
      if (cachedFullAsset) {
        return cachedFullAsset;
      }

      // Get asset
      const asset = await this.getAssetBySymbol(symbol);
      if (!asset) return null;
      
      // Get market data
      const [marketDataEntry] = await db
        .select()
        .from(marketData)
        .where(eq(marketData.symbol, symbol));
      
      if (!marketDataEntry) return null;
      
      const result = { asset, marketData: marketDataEntry };
      
      // Cache the combined result with a shorter TTL
      assetsCache.set(`full_asset_${symbol}`, result, 60000); // 1 minute TTL
      
      return result;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT_WITH_RELATED',
        'assets',
        { symbol }
      );
      return null;
    }
  }
  
  /**
   * Get asset with its related AI analysis
   */
  public async getAssetWithAnalysis(symbol: string): Promise<{ asset: Asset, analysis: any } | null> {
    try {
      // Get asset
      const asset = await this.getAssetBySymbol(symbol);
      if (!asset) return null;
      
      // Get analysis data
      const [analysisEntry] = await db
        .select()
        .from(aiAnalysis)
        .where(eq(aiAnalysis.symbol, symbol));
      
      if (!analysisEntry) return null;
      
      return { asset, analysis: analysisEntry };
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT_WITH_ANALYSIS',
        'assets',
        { symbol }
      );
      return null;
    }
  }
  
  /**
   * Preload common assets into cache
   */
  public async preloadCommonAssets(): Promise<void> {
    try {
      // Get all assets
      const allAssets = await this.getAllAssets(true);
      
      // Cache individual assets by symbol
      const assetsBySymbol: Record<string, Asset> = {};
      allAssets.forEach(asset => {
        assetsBySymbol[`asset_${asset.symbol}`] = asset;
      });
      
      // Bulk set to cache
      assetsCache.setBulk(assetsBySymbol);
      
      log(`Preloaded ${allAssets.length} assets into cache`, 'asset');
    } catch (error) {
      errorHandler.logError(
        error,
        ErrorType.CACHE,
        ErrorSeverity.WARNING,
        { operation: 'preloadCommonAssets' }
      );
    }
  }
  
  /**
   * Clear the asset cache
   */
  public clearCache(): void {
    assetsCache.clear();
  }
}

// Export singleton instance
export const assetService = AssetService.getInstance();