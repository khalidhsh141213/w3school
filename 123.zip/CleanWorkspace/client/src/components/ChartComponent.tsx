import { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { useTranslation } from '../lib/useTranslation';

interface ChartProps {
  symbol: string;
  marketData: any;
}

// Simulate historical data by generating daily prices
const generateHistoricalData = (
  currentPrice: number, 
  days: number, 
  timeframe: string
) => {
  const now = new Date();
  const data = [];
  const volatility = 0.02; // 2% volatility
  let price = currentPrice;
  
  // Set the interval based on timeframe
  let interval: number;
  let format: (date: Date) => string;
  
  switch (timeframe) {
    case '1D':
      interval = 24 / 20; // 20 points for a day
      format = (date) => date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      break;
    case '1W':
      interval = 24 * 7 / 20; // 20 points for a week
      format = (date) => date.toLocaleDateString([], { weekday: 'short' });
      break;
    case '1M':
      interval = 24 * 30 / 20; // 20 points for a month
      format = (date) => date.toLocaleDateString([], { day: 'numeric', month: 'short' });
      break;
    case '3M':
      interval = 24 * 90 / 20; // 20 points for 3 months
      format = (date) => date.toLocaleDateString([], { day: 'numeric', month: 'short' });
      break;
    case '1Y':
      interval = 24 * 365 / 20; // 20 points for a year
      format = (date) => date.toLocaleDateString([], { month: 'short' });
      break;
    default:
      interval = 24 / 20;
      format = (date) => date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  
  for (let i = days; i >= 0; i--) {
    // Calculate timestamp for this data point
    const timestamp = new Date(now.getTime() - (i * interval * 60 * 60 * 1000));
    
    // Generate a random price movement
    const change = (Math.random() - 0.5) * volatility * price;
    price = Math.max(0.01, price + change);
    
    data.push({
      time: format(timestamp),
      price: parseFloat(price.toFixed(2))
    });
  }
  
  return data;
};

const ChartComponent = ({ symbol, marketData }: ChartProps) => {
  const { t } = useTranslation();
  const [timeframe, setTimeframe] = useState('1W');
  const [chartData, setChartData] = useState<any[]>([]);
  
  // Generate chart data whenever the symbol, market data, or timeframe changes
  useEffect(() => {
    if (marketData && marketData.price) {
      const currentPrice = parseFloat(marketData.price);
      
      // Generate historical data based on timeframe
      let days;
      switch (timeframe) {
        case '1D': days = 1; break;
        case '1W': days = 7; break;
        case '1M': days = 30; break;
        case '3M': days = 90; break;
        case '1Y': days = 365; break;
        default: days = 7;
      }
      
      const data = generateHistoricalData(currentPrice, days, timeframe);
      setChartData(data);
    }
  }, [symbol, marketData, timeframe]);

  // Format price change display
  const formatPriceChange = () => {
    if (!marketData) return { text: '—', className: '' };
    
    const change = parseFloat(marketData.change || '0');
    const changePercent = parseFloat(marketData.changePercent || '0');
    
    return {
      text: `${change >= 0 ? '+' : ''}${change.toFixed(2)} (${changePercent >= 0 ? '+' : ''}${changePercent.toFixed(2)}%)`,
      className: change >= 0 ? 'text-secondary-light' : 'text-accent-light'
    };
  };

  const priceChange = formatPriceChange();

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-condensed font-bold">{symbol}</h2>
          <div className="text-sm text-neutral">
            {marketData ? getCompanyName(symbol) : 'Loading...'}
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-semibold">
            ${marketData ? parseFloat(marketData.price).toFixed(2) : '—'}
          </div>
          <div className={priceChange.className}>
            {priceChange.text}
          </div>
        </div>
      </div>
      
      <div className="chart-container border rounded p-2">
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="time" 
                padding={{ left: 10, right: 10 }}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip 
                formatter={(value) => [`$${value}`, 'Price']}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke="#1E88E5" 
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-neutral">
            Loading chart data...
          </div>
        )}
      </div>
      
      <div className="flex space-x-2 mt-4">
        {['1D', '1W', '1M', '3M', '1Y', 'ALL'].map((period) => (
          <button 
            key={period}
            className={`px-3 py-1 rounded-md text-sm ${
              timeframe === period 
                ? 'bg-primary text-white' 
                : 'bg-gray-200 hover:bg-gray-300 dark:bg-neutral-dark dark:hover:bg-gray-700'
            }`}
            onClick={() => setTimeframe(period)}
          >
            {period}
          </button>
        ))}
      </div>
    </div>
  );
};

// Helper function to get company name for a symbol
function getCompanyName(symbol: string): string {
  const companies: Record<string, string> = {
    'AAPL': 'Apple Inc.',
    'MSFT': 'Microsoft Corporation',
    'GOOGL': 'Alphabet Inc.',
    'AMZN': 'Amazon.com Inc.',
    'META': 'Meta Platforms, Inc.',
    'TSLA': 'Tesla Inc.',
    'NVDA': 'NVIDIA Corporation',
    'JPM': 'JPMorgan Chase & Co.',
    'NKE': 'Nike, Inc.'
  };
  
  return companies[symbol] || symbol;
}

export default ChartComponent;
