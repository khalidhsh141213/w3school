/**
 * Service for handling Polygon.io WebSocket connections
 * This service provides real-time market data through WebSocket connections.
 * For historical data and REST API calls, see polygon.ts
 */

import { EventEmitter } from 'events';
import { default as WebSocket, default as WS } from 'ws';
import { log } from '../vite';

export interface PolygonWebSocketOptions {
  apiKey: string;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export interface PolygonPriceUpdate {
  symbol: string;
  price: number;
  timestamp: number;
  highPrice?: number;
  lowPrice?: number;
  closePrice?: number;
  volume?: number;
  marketCap?: number;
  priceChange24h?: number;
  volume24h?: number;
  high24h?: number;
  low24h?: number;
}

/**
 * Service for connecting to Polygon.io WebSockets
 * Handles authentication, subscription, and reconnection
 * Based on https://polygon.io/docs/websocket/quickstart
 */
export class PolygonWebSocketService extends EventEmitter {
  private apiKey: string;
  private reconnectInterval: number;
  private maxReconnectAttempts: number;
  private reconnectAttempts: Record<string, number> = {};

  private cryptoWs: WebSocket | null = null;
  private forexWs: WebSocket | null = null;

  private cryptoSubscriptions: Set<string> = new Set();
  private forexSubscriptions: Set<string> = new Set();

  private connected: Record<string, boolean> = {
    crypto: false,
    forex: false
  };

  private isReconnectingCrypto = false;
  private isReconnectingForex = false;
  private reconnectDelayMs = 5000; // Start with 5 seconds delay between reconnections
  private maxReconnectDelayMs = 60000; // Maximum reconnect delay (1 minute)

  // Keep track of connection timestamps to limit rapid reconnections
  private lastConnectionAttempt: Record<string, number> = {
    crypto: 0,
    forex: 0
  };

  // Minimum time between connection attempts (10 seconds)
  private minConnectionInterval = 10000;

  // Connection throttle flags
  private connectionThrottled: Record<string, boolean> = {
    crypto: false,
    forex: false
  };

  constructor(options: PolygonWebSocketOptions) {
    super();
    this.apiKey = options.apiKey;
    this.reconnectInterval = options.reconnectInterval || 10000;
    this.maxReconnectAttempts = options.maxReconnectAttempts || 5;
    this.reconnectAttempts = {
      crypto: 0,
      forex: 0
    };
  }

  /**
   * Connect to Polygon WebSocket endpoints
   */
  public connect(): void {
    this.connectCrypto();
    this.connectForex();
  }

  /**
   * Connect to Polygon Crypto WebSocket
   */
  private connectCrypto(): void {
    // Check if we're already connected or connecting
    if (this.cryptoWs && (this.cryptoWs.readyState === WebSocket.OPEN || this.cryptoWs.readyState === WebSocket.CONNECTING)) {
      return;
    }

    // Check if we're throttling connections
    const now = Date.now();
    if (this.connectionThrottled.crypto) {
      log('Crypto WebSocket connection throttled, skipping connection attempt', 'polygonWs');
      return;
    }

    // Check if we've attempted to connect too recently
    if (now - this.lastConnectionAttempt.crypto < this.minConnectionInterval) {
      log('Too many crypto connection attempts, throttling', 'polygonWs');
      this.connectionThrottled.crypto = true;

      // Reset throttle after the minimum interval
      setTimeout(() => {
        this.connectionThrottled.crypto = false;
        this.connectCrypto();
      }, this.minConnectionInterval);

      return;
    }

    // Update last connection attempt timestamp
    this.lastConnectionAttempt.crypto = now;

    log('Connecting to Polygon Crypto WebSocket...', 'polygonWs');
    this.cryptoWs = new WebSocket('wss://socket.polygon.io/crypto');

    this.cryptoWs.on('open', () => {
      log('Connected to Polygon Crypto WebSocket', 'polygonWs');
      this.connected.crypto = true;
      this.reconnectAttempts.crypto = 0;

      // Authenticate - MANDATORY FIRST STEP according to docs
      if (this.cryptoWs) {
        log('Authenticating with Polygon Crypto WebSocket...', 'polygonWs');
        this.cryptoWs.send(JSON.stringify({ action: "auth", params: this.apiKey }));

        // Resubscribe to channels after reconnection
        if (this.cryptoSubscriptions.size > 0) {
          setTimeout(() => {
            this.subscribeCrypto([...this.cryptoSubscriptions]);
          }, 1000); // Wait 1 second after auth before subscribing
        }
      }
    });

    this.cryptoWs.on('message', (data: WebSocket.Data) => {
      try {
        const messages = JSON.parse(data.toString());

        for (const message of messages) {
          // Handle authentication status
          if (message.ev === 'status') {
            log(`Crypto WebSocket Status: ${message.status}`, 'polygonWs');

            if (message.status === 'auth_success') {
              log('Successfully authenticated with Polygon Crypto WebSocket', 'polygonWs');
            } else if (message.status === 'auth_failed') {
              log('Authentication failed with Polygon Crypto WebSocket', 'polygonWs');
            }
            continue;
          }

          // Handle real-time trades (XT events)
          if (message.ev === 'XT' && message.pair) {
            const symbol = message.pair.replace('-', '/');

            const update: PolygonPriceUpdate = {
              symbol: symbol,
              price: message.p,
              timestamp: message.t
            };

            log(`Received crypto trade update for ${symbol}: ${message.p}`, 'polygonWs');
            this.emit('priceUpdate', update);
          }

          // Handle aggregate events (XA events) - these provide more data
          if (message.ev === 'XA' && message.pair) {
            const symbol = message.pair.replace('-', '/');

            const update: PolygonPriceUpdate = {
              symbol: symbol,
              price: message.c, // Use close price
              timestamp: message.e,
              highPrice: message.h,
              lowPrice: message.l,
              closePrice: message.c,
              volume: message.v
            };

            log(`Received crypto aggregate update for ${symbol}: ${message.c}`, 'polygonWs');
            this.emit('priceUpdate', update);
          }
        }
      } catch (error) {
        log(`Error parsing crypto WebSocket message: ${error}`, 'polygonWs');
      }
    });

    this.cryptoWs.on('error', (error) => {
      log(`Crypto WebSocket error: ${error}`, 'polygonWs');
    });

    this.cryptoWs.on('close', (code, reason) => {
      log(`Crypto WebSocket connection closed: ${code} - ${reason}`, 'polygonWs');
      this.connected.crypto = false;

      // Handle max_connections error specifically
      if (code === 1008 && reason.includes('max_connections')) {
        log('Received max_connections error, delaying reconnection attempt', 'polygonWs');
        this.connectionThrottled.crypto = true;

        // Use exponential backoff for reconnection
        const backoffTime = Math.min(
          this.reconnectDelayMs * Math.pow(2, this.reconnectAttempts.crypto),
          this.maxReconnectDelayMs
        );

        setTimeout(() => {
          this.connectionThrottled.crypto = false;
          // Only connect if we're not already connected
          if (!this.connected.crypto) {
            this.connectCrypto();
          }
        }, backoffTime);

        return;
      }

      // Attempt to reconnect with standard approach
      if (this.reconnectAttempts.crypto < this.maxReconnectAttempts) {
        this.reconnectAttempts.crypto++;
        log(`Attempting to reconnect to Crypto WebSocket (${this.reconnectAttempts.crypto}/${this.maxReconnectAttempts})`, 'polygonWs');

        setTimeout(() => {
          this.connectCrypto();
        }, this.reconnectInterval);
      } else {
        log('Max reconnection attempts reached for Crypto WebSocket', 'polygonWs');
      }
    });
  }

  /**
   * Connect to Polygon Forex WebSocket
   */
  private connectForex(): void {
    // Check if we're already connected or connecting
    if (this.forexWs && (this.forexWs.readyState === WebSocket.OPEN || this.forexWs.readyState === WebSocket.CONNECTING)) {
      return;
    }

    // Check if we're throttling connections
    const now = Date.now();
    if (this.connectionThrottled.forex) {
      log('Forex WebSocket connection throttled, skipping connection attempt', 'polygonWs');
      return;
    }

    // Check if we've attempted to connect too recently
    if (now - this.lastConnectionAttempt.forex < this.minConnectionInterval) {
      log('Too many forex connection attempts, throttling', 'polygonWs');
      this.connectionThrottled.forex = true;

      // Reset throttle after the minimum interval
      setTimeout(() => {
        this.connectionThrottled.forex = false;
        this.connectForex();
      }, this.minConnectionInterval);

      return;
    }

    // Update last connection attempt timestamp
    this.lastConnectionAttempt.forex = now;

    log('Connecting to Polygon Forex WebSocket...', 'polygonWs');
    this.forexWs = new WebSocket('wss://socket.polygon.io/forex');

    this.forexWs.on('open', () => {
      log('Connected to Polygon Forex WebSocket', 'polygonWs');
      this.connected.forex = true;
      this.reconnectAttempts.forex = 0;

      // Authenticate - MANDATORY FIRST STEP according to docs
      if (this.forexWs) {
        log('Authenticating with Polygon Forex WebSocket...', 'polygonWs');
        this.forexWs.send(JSON.stringify({ action: "auth", params: this.apiKey }));

        // Resubscribe to channels after reconnection
        if (this.forexSubscriptions.size > 0) {
          setTimeout(() => {
            this.subscribeForex([...this.forexSubscriptions]);
          }, 1000); // Wait 1 second after auth before subscribing
        }
      }
    });

    this.forexWs.on('message', (data: WebSocket.Data) => {
      try {
        const messages = JSON.parse(data.toString());

        for (const message of messages) {
          // Handle authentication status
          if (message.ev === 'status') {
            log(`Forex WebSocket Status: ${message.status}`, 'polygonWs');

            if (message.status === 'auth_success') {
              log('Successfully authenticated with Polygon Forex WebSocket', 'polygonWs');
            } else if (message.status === 'auth_failed') {
              log('Authentication failed with Polygon Forex WebSocket', 'polygonWs');
            }
            continue;
          }

          // Handle real-time trades
          if (message.ev === 'C') {
            // For forex, use the average of bid and ask as the "price"
            const price = (message.a + message.b) / 2;

            const update: PolygonPriceUpdate = {
              symbol: message.p,
              price: price,
              timestamp: message.t
            };

            log(`Received forex update for ${message.p}: ${price}`, 'polygonWs');
            this.emit('priceUpdate', update);
          }
        }
      } catch (error) {
        log(`Error parsing forex WebSocket message: ${error}`, 'polygonWs');
      }
    });

    this.forexWs.on('error', (error) => {
      log(`Forex WebSocket error: ${error}`, 'polygonWs');
    });

    this.forexWs.on('close', (code, reason) => {
      log(`Forex WebSocket connection closed: ${code} - ${reason}`, 'polygonWs');
      this.connected.forex = false;

      // Handle max_connections error specifically
      if (code === 1008 && reason.includes('max_connections')) {
        log('Received max_connections error, delaying reconnection attempt', 'polygonWs');
        this.connectionThrottled.forex = true;

        // Use exponential backoff for reconnection
        const backoffTime = Math.min(
          this.reconnectDelayMs * Math.pow(2, this.reconnectAttempts.forex),
          this.maxReconnectDelayMs
        );

        setTimeout(() => {
          this.connectionThrottled.forex = false;
          // Only connect if we're not already connected
          if (!this.connected.forex) {
            this.connectForex();
          }
        }, backoffTime);

        return;
      }

      // Attempt to reconnect with standard approach
      if (this.reconnectAttempts.forex < this.maxReconnectAttempts) {
        this.reconnectAttempts.forex++;
        log(`Attempting to reconnect to Forex WebSocket (${this.reconnectAttempts.forex}/${this.maxReconnectAttempts})`, 'polygonWs');

        setTimeout(() => {
          this.connectForex();
        }, this.reconnectInterval);
      } else {
        log('Max reconnection attempts reached for Forex WebSocket', 'polygonWs');
      }
    });
  }

  /**
   * Subscribe to crypto symbols
   * @param symbols Array of symbols to subscribe to
   */
  public subscribeCrypto(symbols: string[]): void {
    if (!this.cryptoWs || this.cryptoWs.readyState !== WebSocket.OPEN) {
      symbols.forEach(symbol => this.cryptoSubscriptions.add(symbol));
      log(`Queued crypto subscription for ${symbols.join(", ")}`, 'polygonWs');
      return;
    }

    // Format symbols for crypto subscription
    const formattedSymbols = symbols.map(symbol => {
      // Convert any USD/BTC format to BTC-USD format
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `XT.${parts[1]}-${parts[0]}`;
      }

      // If it's already in BTC-USD format, use directly
      if (symbol.includes('-')) {
        return `XT.${symbol}`;
      }

      // Otherwise, assume it's a basic symbol and use as is
      return `XT.${symbol}`;
    });

    // Add to subscription set
    symbols.forEach(symbol => this.cryptoSubscriptions.add(symbol));

    // Send subscription message
    const subscribeMsg = JSON.stringify({
      action: "subscribe",
      params: formattedSymbols.join(",")
    });

    log(`Subscribing to crypto channels: ${subscribeMsg}`, 'polygonWs');
    this.cryptoWs.send(subscribeMsg);

    // Also subscribe to aggregates for backup
    const aggregatesSymbols = symbols.map(symbol => {
      // Convert any USD/BTC format to BTC-USD format for aggregates
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `XA.${parts[1]}-${parts[0]}`;
      }

      // If it's already in BTC-USD format, use directly
      if (symbol.includes('-')) {
        return `XA.${symbol}`;
      }

      // Otherwise, assume it's a basic symbol and use as is
      return `XA.${symbol}`;
    });

    const aggregatesMsg = JSON.stringify({
      action: "subscribe",
      params: aggregatesSymbols.join(",")
    });

    log(`Subscribing to crypto aggregates: ${aggregatesMsg}`, 'polygonWs');
    this.cryptoWs.send(aggregatesMsg);
  }

  /**
   * Subscribe to forex symbols
   * @param symbols Array of symbols to subscribe to
   */
  private subscribeForex(symbols: string[]): void {
    if (!this.forexWs || this.forexWs.readyState !== WebSocket.OPEN) {
      symbols.forEach(symbol => this.forexSubscriptions.add(symbol));
      log(`Queued forex subscription for ${symbols.join(", ")}`, 'polygonWs');
      return;
    }

    // Format symbols for forex subscription
    const formattedSymbols = symbols.map(symbol => {
      // Convert any USD/EUR format to C.USD-EUR format
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `C.${parts[0]}-${parts[1]}`;
      }

      // Otherwise, use as is
      return `C.${symbol}`;
    });

    // Send subscription message
    const subscribeMsg = JSON.stringify({
      action: "subscribe",
      params: formattedSymbols.join(",")
    });

    log(`Subscribing to forex channels: ${subscribeMsg}`, 'polygonWs');
    this.forexWs.send(subscribeMsg);

    // Add to our subscription set
    symbols.forEach(symbol => this.forexSubscriptions.add(symbol));
  }

  /**
   * Unsubscribe from crypto symbols
   * @param symbols Array of symbols to unsubscribe from
   */
  public unsubscribeCrypto(symbols: string[]): void {
    if (!this.cryptoWs || this.cryptoWs.readyState !== WebSocket.OPEN) {
      symbols.forEach(symbol => this.cryptoSubscriptions.delete(symbol));
      return;
    }

    // Format symbols for unsubscription
    const formattedSymbols = symbols.map(symbol => {
      // Convert any USD/BTC format to BTC-USD format
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `XT.${parts[1]}-${parts[0]}`;
      }

      // If it's already in BTC-USD format, use directly
      if (symbol.includes('-')) {
        return `XT.${symbol}`;
      }

      // Otherwise, assume it's a basic symbol and use as is
      return `XT.${symbol}`;
    });

    // Send unsubscription message
    const unsubscribeMsg = JSON.stringify({
      action: "unsubscribe",
      params: formattedSymbols.join(",")
    });

    log(`Unsubscribing from crypto channels: ${unsubscribeMsg}`, 'polygonWs');
    this.cryptoWs.send(unsubscribeMsg);

    // Also unsubscribe from aggregates
    const aggregatesSymbols = symbols.map(symbol => {
      // Convert any USD/BTC format to BTC-USD format for aggregates
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `XA.${parts[1]}-${parts[0]}`;
      }

      // If it's already in BTC-USD format, use directly
      if (symbol.includes('-')) {
        return `XA.${symbol}`;
      }

      // Otherwise, assume it's a basic symbol and use as is
      return `XA.${symbol}`;
    });

    const aggregatesUnsubMsg = JSON.stringify({
      action: "unsubscribe",
      params: aggregatesSymbols.join(",")
    });

    log(`Unsubscribing from crypto aggregates: ${aggregatesUnsubMsg}`, 'polygonWs');
    this.cryptoWs.send(aggregatesUnsubMsg);

    // Remove from our subscription set
    symbols.forEach(symbol => this.cryptoSubscriptions.delete(symbol));
  }

  /**
   * Unsubscribe from forex symbols
   * @param symbols Array of symbols to unsubscribe from
   */
  public unsubscribeForex(symbols: string[]): void {
    if (!this.forexWs || this.forexWs.readyState !== WebSocket.OPEN) {
      symbols.forEach(symbol => this.forexSubscriptions.delete(symbol));
      return;
    }

    // Format symbols for unsubscription
    const formattedSymbols = symbols.map(symbol => {
      // Convert any USD/EUR format to C.USD-EUR format
      const parts = symbol.split('/');
      if (parts.length === 2) {
        return `C.${parts[0]}-${parts[1]}`;
      }

      // Otherwise, use as is
      return `C.${symbol}`;
    });

    // Send unsubscription message
    const unsubscribeMsg = JSON.stringify({
      action: "unsubscribe",
      params: formattedSymbols.join(",")
    });

    log(`Unsubscribing from forex channels: ${unsubscribeMsg}`, 'polygonWs');
    this.forexWs.send(unsubscribeMsg);

    // Remove from our subscription set
    symbols.forEach(symbol => this.forexSubscriptions.delete(symbol));
  }

  /**
   * Subscribe to multiple symbols
   * @param symbols Array of symbols to subscribe to
   * @param type Type of subscription (crypto or forex)
   */
  public subscribe(symbols: string[], type: 'crypto' | 'forex'): void {
    if (type === 'crypto') {
      this.subscribeCrypto(symbols);
    } else if (type === 'forex') {
      this.subscribeForex(symbols);
    }
  }

  /**
   * Unsubscribe from multiple symbols
   * @param symbols Array of symbols to unsubscribe from
   * @param type Type of subscription (crypto or forex)
   */
  public unsubscribe(symbols: string[], type: 'crypto' | 'forex'): void {
    if (type === 'crypto') {
      this.unsubscribeCrypto(symbols);
    } else if (type === 'forex') {
      this.unsubscribeForex(symbols);
    }
  }

  /**
   * Disconnect from all WebSockets
   */
  public disconnect(): void {
    if (this.cryptoWs) {
      this.cryptoWs.close();
      this.cryptoWs = null;
    }

    if (this.forexWs) {
      this.forexWs.close();
      this.forexWs = null;
    }

    this.connected = {
      crypto: false,
      forex: false
    };

    log('Disconnected from all Polygon WebSockets', 'polygonWs');
  }

  /**
   * Check if connected to a specific WebSocket
   * @param type Type of WebSocket (crypto or forex)
   * @returns Boolean indicating connection status
   */
  public isConnected(type: 'crypto' | 'forex'): boolean {
    return this.connected[type];
  }

  /**
   * Send a ping to the WebSockets to keep them alive
   */
  public ping(): void {
    if (this.cryptoWs && this.cryptoWs.readyState === WebSocket.OPEN) {
      this.cryptoWs.ping();
    }

    if (this.forexWs && this.forexWs.readyState === WebSocket.OPEN) {
      this.forexWs.ping();
    }
  }

  private reconnect(type: 'crypto' | 'forex', attempt: number = 1): void {
    const isReconnecting = type === 'crypto' ? this.isReconnectingCrypto : this.isReconnectingForex;
    if (isReconnecting) {
      log(`Already attempting to reconnect to ${type} WebSocket`, 'polygonWs');
      return;
    }

    // Set reconnecting flag
    if (type === 'crypto') {
      this.isReconnectingCrypto = true;
    } else {
      this.isReconnectingForex = true;
    }

    // Calculate exponential backoff delay (with jitter)
    const maxAttempt = 10;
    if (attempt > maxAttempt) {
      log(`Failed to reconnect to ${type} WebSocket after ${maxAttempt} attempts, giving up`, 'polygonWs');
      // Reset reconnecting flag
      if (type === 'crypto') {
        this.isReconnectingCrypto = false;
      } else {
        this.isReconnectingForex = false;
      }
      return;
    }

    // Calculate delay with exponential backoff and jitter
    const baseDelay = Math.min(this.reconnectDelayMs * Math.pow(1.5, attempt - 1), this.maxReconnectDelayMs);
    const jitter = Math.random() * 0.3 + 0.85; // Random between 0.85 and 1.15
    const delay = Math.floor(baseDelay * jitter);

    log(`Attempting to reconnect to ${type} WebSocket (${attempt}/${maxAttempt}) in ${delay}ms`, 'polygonWs');

    setTimeout(() => {
      log(`Connecting to Polygon ${type} WebSocket...`, 'polygonWs');

      try {
        // Create a new WebSocket
        if (type === 'crypto') {
          this.cryptoWs = new WS(this.cryptoEndpoint);
          this.setupWebSocket(this.cryptoWs, 'crypto');
        } else {
          this.forexWs = new WS(this.forexEndpoint);
          this.setupWebSocket(this.forexWs, 'forex');
        }
      } catch (error) {
        log(`Error reconnecting to ${type} WebSocket: ${error}`, 'polygonWs');
        this.reconnect(type, attempt + 1);
      } finally {
        // Reset reconnecting flag
        if (type === 'crypto') {
          this.isReconnectingCrypto = false;
        } else {
          this.isReconnectingForex = false;
        }
      }
    }, delay);
  }
}

// Create and export a singleton instance
export const polygonWebSocketService = new PolygonWebSocketService({
  apiKey: process.env.POLYGON_API_KEY || '',
  reconnectInterval: 5000, // 5 seconds
  maxReconnectAttempts: 10
});
import WebSocket from 'ws';
import { db } from '../db';
import { assets } from '../../shared/schema';
import { eq, and, or } from 'drizzle-orm';
import { log } from '../utils/logger';

export class PolygonWebSocketService {
  private ws: WebSocket | null = null;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private reconnectAttempts = 0;
  private readonly maxReconnectAttempts = 5;
  private readonly reconnectDelay = 3000;
  private symbols: string[] = [];
  private updateIntervals: Record<string, number>;
  private updateTimers: Map<string, NodeJS.Timeout>;

  constructor(
    private readonly apiKey: string,
    private readonly onPriceUpdate: (data: any) => void
  ) {
    this.updateIntervals = {};
    this.updateTimers = new Map();
  }

  private async loadSymbols(): Promise<void> {
    try {
      // Get active assets only and filter by type
      const allAssets = await db.query.assets.findMany({
        where: (assets, { eq, and, or }) => and(
          eq(assets.isActive, true),
          or(
            eq(assets.type, 'crypto'),
            eq(assets.type, 'forex')
          )
        )
      });

      this.symbols = allAssets.map(asset => asset.symbol);
      log(`Loaded ${this.symbols.length} active symbols for real-time updates`, 'websocket');

      // Store update intervals by type
      this.updateIntervals = {
        crypto: 5000,  // 5 seconds
        forex: 5000,   // 5 seconds
        stocks: 300000 // 5 minutes
      };

    } catch (error) {
      log(`Error loading symbols: ${error}`, 'error');
    }
  }

  // Add method to handle dynamic symbol updates
  public async reloadSymbols(): Promise<void> {
    await this.loadSymbols();

    // Resubscribe to updated symbol list
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      await this.subscribe();
    }
  }


  public connect() {
    if (this.ws) {
      this.ws.terminate();
    }

    this.ws = new WebSocket('wss://socket.polygon.io/forex');

    this.ws.on('open', async () => {
      log('Polygon WebSocket connection established', 'websocket');
      this.reconnectAttempts = 0;

      // إرسال رسالة المصادقة
      const authMsg = { action: 'auth', params: this.apiKey };
      this.ws?.send(JSON.stringify(authMsg));

      // الاشتراك في التحديثات
      await this.subscribe();
      this.startUpdateTimers();
    });

    this.ws.on('message', async (data: string) => {
      try {
        const message = JSON.parse(data);

        if (Array.isArray(message) && message[0].ev === 'T') {
          const update = message[0];
          await this.updatePrice(update);
        }
      } catch (error) {
        log(`Error processing WebSocket message: ${error}`, 'error');
      }
    });

    this.ws.on('close', () => {
      log('Polygon WebSocket connection closed', 'websocket');
      this.scheduleReconnect();
    });

    this.ws.on('error', (error) => {
      log(`Polygon WebSocket error: ${error}`, 'error');
    });
  }

  private async updatePrice(data: any) {
    try {
      const symbol = data.pair.replace('XT.', '').replace('-', '/');

      // Get current asset data
      const currentAsset = await db.query.assets.findFirst({
        where: eq(assets.symbol, symbol),
        columns: { price: true }
      });

      const newPrice = data.p.toString();

      // Only update if price changed
      if (!currentAsset || currentAsset.price !== newPrice) {
        await db
          .insert(assets)
          .values({
            symbol: symbol,
            price: newPrice,
            lastPrice: currentAsset?.price || newPrice,
            dailyChange: (data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)).toString(),
            dailyChangePercent: ((data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)) / 
              (currentAsset?.price ? parseFloat(currentAsset.price) : data.o) * 100).toString(),
            intradayChange: (data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)).toString(),
            intradayChangePercent: ((data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)) / 
              (currentAsset?.price ? parseFloat(currentAsset.price) : data.o) * 100).toString(),
            volume: data.v?.toString() || '0',
            updatedAt: new Date()
          })
          .onConflictDoUpdate({
            target: [assets.symbol],
            set: {
              price: newPrice,
              lastPrice: currentAsset?.price || newPrice,
              dailyChange: (data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)).toString(),
              dailyChangePercent: ((data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)) / 
                (currentAsset?.price ? parseFloat(currentAsset.price) : data.o) * 100).toString(),
              intradayChange: (data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)).toString(),
              intradayChangePercent: ((data.p - (currentAsset?.price ? parseFloat(currentAsset.price) : data.o)) / 
                (currentAsset?.price ? parseFloat(currentAsset.price) : data.o) * 100).toString(),
              volume: data.v?.toString() || '0',
              updatedAt: new Date()
            }
          });

        this.onPriceUpdate({
          ...data,
          lastPrice: currentAsset?.price
        });
      }
    } catch (error) {
      log(`Error updating price in database: ${error}`, 'error');
    }
  }

  private scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      log('Max reconnection attempts reached', 'error');
      return;
    }

    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts);
    this.reconnectTimeout = setTimeout(() => {
      this.reconnectAttempts++;
      this.connect();
    }, delay);
  }

  public disconnect() {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    if (this.ws) {
      this.ws.terminate();
      this.ws = null;
    }
  }

  private startUpdateTimers(): void {
    // Clear existing timers
    this.updateTimers.forEach(timer => clearInterval(timer));
    this.updateTimers.clear();

    // Start new timers for each asset type
    Object.entries(this.updateIntervals).forEach(([type, interval]) => {
      const timer = setInterval(() => {
        this.updateAssetsByType(type);
      }, interval);

      this.updateTimers.set(type, timer);
    });
  }

  private async updateAssetsByType(type: string): Promise<void> {
    try {
      const assets = await db.query.assets.findMany({
        where: (assets, { eq }) => eq(assets.type, type)
      });

      // Request updates for these assets
      if (this.ws?.readyState === WebSocket.OPEN) {
        assets.forEach(asset => {
          this.requestAssetUpdate(asset.symbol);
        });
      }
    } catch (error) {
      log(`Error updating ${type} assets: ${error}`, 'error');
    }
  }

  private requestAssetUpdate(symbol: string): void {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          //Construct and send message to request update for specific symbol.  Implementation depends on your WebSocket API.
          const updateMsg = { action: 'update', params: symbol}; //Example - Adapt to your API
          this.ws.send(JSON.stringify(updateMsg));
      }
  }

  private async subscribe(): Promise<void> {
    await this.loadSymbols();
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const subscribeMsg = {
        action: 'subscribe',
        params: this.symbols.join(',')
      };
      this.ws.send(JSON.stringify(subscribeMsg));
    }
  }

  public async initialize(): Promise<void> {
    await this.loadSymbols();
    await this.connect();
    this.startUpdateTimers();

    // Listen for asset changes in database
    db.eventEmitter.on('asset_changed', async () => {
      await this.reloadSymbols();
    });
  }

  public async cleanup(): Promise<void> {
    this.updateTimers.forEach(timer => clearInterval(timer));
    this.updateTimers.clear();

    if (this.ws) {
      this.ws.close();
    }
  }
}