import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import {
  PlusCircle,
  Trash2,
  Edit,
  RefreshCw,
  FileUp,
  Download,
  AlertCircle,
  Search,
  Filter
} from 'lucide-react';

// UI Components
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import AddEventForm from '@/components/AddEventForm';
import BatchImportEvents from '@/components/BatchImportEvents';

export default function EconomicEventsAdmin() {
  const [activeTab, setActiveTab] = useState('view');
  
  // Fetch existing events
  const { data: events = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/economic-events'],
    queryFn: async () => {
      const res = await fetch('/api/economic-events');
      if (!res.ok) {
        throw new Error('Failed to fetch events');
      }
      return res.json();
    }
  });

  const handleEventAdded = () => {
    // Refetch events after adding a new one
    refetch();
    // Optionally switch back to view tab
    setActiveTab('view');
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Economic Events Administration</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="view">View Events</TabsTrigger>
          <TabsTrigger value="add">Add Event</TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
} 