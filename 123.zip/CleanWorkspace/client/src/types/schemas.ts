/**
 * Schema types and validators for the API
 */

import { z } from 'zod';

// ===== Authentication =====

export const authResponseValidator = z.object({
  token: z.string(),
  refreshToken: z.string(),
  user: z.object({
    id: z.string(),
    email: z.string().email(),
    name: z.string(),
    role: z.enum(['user', 'admin']),
  }),
});

export type AuthResponse = z.infer<typeof authResponseValidator>;

export const userRegistrationValidator = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
});

export type UserRegistration = z.infer<typeof userRegistrationValidator>;

// ===== User =====

export const userValidator = z.object({
  id: z.string(),
  email: z.string().email(),
  name: z.string(),
  role: z.enum(['user', 'admin']),
  avatar: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type User = z.infer<typeof userValidator>;

export const userSettingsValidator = z.object({
  id: z.string(),
  userId: z.string(),
  notifications: z.object({
    email: z.boolean(),
    push: z.boolean(),
    trade: z.boolean(),
    news: z.boolean(),
    priceAlerts: z.boolean(),
  }),
  theme: z.enum(['light', 'dark', 'system']),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type UserSettings = z.infer<typeof userSettingsValidator>;

export const userPreferencesValidator = z.object({
  id: z.string(),
  userId: z.string(),
  defaultWatchlist: z.string().optional(),
  defaultTimeframe: z.enum(['1d', '1w', '1m', '3m', '1y', 'all']),
  defaultInterval: z.enum(['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']),
  chartType: z.enum(['candle', 'line', 'area']),
  indicators: z.array(z.string()),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type UserPreferences = z.infer<typeof userPreferencesValidator>;

// ===== Assets =====

export const assetValidator = z.object({
  id: z.string(),
  symbol: z.string(),
  name: z.string(),
  description: z.string().optional(),
  type: z.enum(['stock', 'crypto', 'forex', 'index', 'commodity']),
  exchange: z.string(),
  currency: z.string(),
  logo: z.string().optional(),
  website: z.string().optional(),
  sector: z.string().optional(),
  industry: z.string().optional(),
  marketCap: z.number().optional(),
  volume: z.number().optional(),
  isActive: z.boolean(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type Asset = z.infer<typeof assetValidator>;

// ===== Market Data =====

export const marketDataValidator = z.object({
  symbol: z.string(),
  price: z.number(),
  change: z.number(),
  changePercent: z.number(),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  volume: z.number(),
  previousClose: z.number(),
  timestamp: z.string(),
});

export type MarketData = z.infer<typeof marketDataValidator>;

export const candleValidator = z.object({
  symbol: z.string(),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  volume: z.number(),
  timestamp: z.string(),
});

export type Candle = z.infer<typeof candleValidator>;

export const newsItemValidator = z.object({
  id: z.string(),
  title: z.string(),
  summary: z.string(),
  content: z.string().optional(),
  source: z.string(),
  url: z.string(),
  imageUrl: z.string().optional(),
  symbols: z.array(z.string()),
  categories: z.array(z.string()),
  sentiment: z.enum(['positive', 'negative', 'neutral']).optional(),
  publishedAt: z.string(),
  createdAt: z.string(),
});

export type NewsItem = z.infer<typeof newsItemValidator>;

// ===== Trading =====

export const orderValidator = z.object({
  id: z.string(),
  userId: z.string(),
  symbol: z.string(),
  type: z.enum(['market', 'limit', 'stop', 'stop_limit']),
  side: z.enum(['buy', 'sell']),
  quantity: z.number().positive(),
  price: z.number().positive().optional(),
  stopPrice: z.number().positive().optional(),
  timeInForce: z.enum(['day', 'gtc', 'ioc', 'fok']),
  status: z.enum(['open', 'filled', 'partially_filled', 'cancelled', 'rejected', 'expired']),
  filledQuantity: z.number().default(0),
  filledPrice: z.number().optional(),
  commission: z.number().default(0),
  notes: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
  executedAt: z.string().optional(),
});

export type Order = z.infer<typeof orderValidator>;

export const orderInputValidator = z.object({
  symbol: z.string(),
  type: z.enum(['market', 'limit', 'stop', 'stop_limit']),
  side: z.enum(['buy', 'sell']),
  quantity: z.number().positive(),
  price: z.number().positive().optional(),
  stopPrice: z.number().positive().optional(),
  timeInForce: z.enum(['day', 'gtc', 'ioc', 'fok']),
  notes: z.string().optional(),
});

export type OrderInput = z.infer<typeof orderInputValidator>;

export const positionValidator = z.object({
  id: z.string(),
  userId: z.string(),
  symbol: z.string(),
  quantity: z.number(),
  averageEntryPrice: z.number(),
  currentPrice: z.number(),
  marketValue: z.number(),
  costBasis: z.number(),
  unrealizedPnl: z.number(),
  unrealizedPnlPercent: z.number(),
  todayPnl: z.number(),
  todayPnlPercent: z.number(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type Position = z.infer<typeof positionValidator>;

export const transactionValidator = z.object({
  id: z.string(),
  userId: z.string(),
  orderId: z.string().optional(),
  type: z.enum(['buy', 'sell', 'deposit', 'withdrawal', 'dividend', 'interest', 'fee', 'tax', 'other']),
  symbol: z.string().optional(),
  quantity: z.number().optional(),
  price: z.number().optional(),
  amount: z.number(),
  commission: z.number().default(0),
  notes: z.string().optional(),
  status: z.enum(['pending', 'completed', 'cancelled', 'failed']),
  createdAt: z.string(),
  updatedAt: z.string(),
  settledAt: z.string().optional(),
});

export type Transaction = z.infer<typeof transactionValidator>;

// ===== Portfolio =====

export const portfolioValidator = z.object({
  id: z.string(),
  userId: z.string(),
  cash: z.number(),
  marketValue: z.number(),
  totalValue: z.number(),
  dayChange: z.number(),
  dayChangePercent: z.number(),
  totalChange: z.number(),
  totalChangePercent: z.number(),
  updatedAt: z.string(),
});

export type Portfolio = z.infer<typeof portfolioValidator>;

export const portfolioPerformanceValidator = z.object({
  timeframe: z.enum(['1d', '1w', '1m', '3m', '1y', 'all']),
  startValue: z.number(),
  endValue: z.number(),
  change: z.number(),
  changePercent: z.number(),
  deposits: z.number(),
  withdrawals: z.number(),
  netDeposits: z.number(),
  realizedGain: z.number(),
  unrealizedGain: z.number(),
  totalGain: z.number(),
  annualizedReturn: z.number().optional(),
});

export type PortfolioPerformance = z.infer<typeof portfolioPerformanceValidator>;

export const portfolioHistoryPointValidator = z.object({
  timestamp: z.string(),
  value: z.number(),
  cash: z.number(),
  marketValue: z.number(),
});

export type PortfolioHistoryPoint = z.infer<typeof portfolioHistoryPointValidator>;

export const portfolioAllocationValidator = z.object({
  userId: z.string(),
  updatedAt: z.string(),
  categories: z.array(
    z.object({
      type: z.string(),
      value: z.number(),
      percentage: z.number(),
      items: z.array(
        z.object({
          symbol: z.string(),
          name: z.string(),
          value: z.number(),
          percentage: z.number(),
          color: z.string().optional(),
        })
      ),
    })
  ),
});

export type PortfolioAllocation = z.infer<typeof portfolioAllocationValidator>;

// ===== Watchlist =====

export const watchlistValidator = z.object({
  id: z.string(),
  userId: z.string(),
  name: z.string(),
  description: z.string().optional(),
  symbols: z.array(z.string()),
  isDefault: z.boolean().default(false),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type Watchlist = z.infer<typeof watchlistValidator>;

export const watchlistInputValidator = z.object({
  name: z.string(),
  description: z.string().optional(),
  symbols: z.array(z.string()).default([]),
  isDefault: z.boolean().default(false),
});

export type WatchlistInput = z.infer<typeof watchlistInputValidator>; 