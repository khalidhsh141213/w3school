import 'dotenv/config';
import postgres from 'postgres';

async function createPortfolio() {
  console.log('Creating portfolio for test user...');
  
  try {
    // Create a connection
    const sql = postgres(process.env.DATABASE_URL, { max: 1 });
    
    // Get the test user ID
    const user = await sql`
      SELECT id FROM users WHERE username = 'tradeuser'
    `;
    
    if (user.length === 0) {
      console.error('Test user not found');
      await sql.end();
      return;
    }
    
    const userId = user[0].id;
    console.log(`Found user ID: ${userId}`);
    
    // Check if portfolio already exists
    const existingPortfolio = await sql`
      SELECT id FROM portfolios WHERE user_id = ${userId}
    `;
    
    if (existingPortfolio.length > 0) {
      console.log('Portfolio already exists for this user');
      await sql.end();
      return;
    }
    
    // Create portfolio with initial balance of 50,000
    const result = await sql`
      INSERT INTO portfolios (
        user_id,
        total_value,
        available_balance,
        invested_amount,
        unrealized_pl,
        pl_percentage
      ) VALUES (
        ${userId},
        50000,
        50000,
        0,
        0,
        0
      )
      RETURNING id, user_id, total_value, available_balance
    `;
    
    console.log('Portfolio created:', result[0]);
    
    await sql.end();
  } catch (error) {
    console.error('Failed to create portfolio:', error);
  }
}

createPortfolio(); 