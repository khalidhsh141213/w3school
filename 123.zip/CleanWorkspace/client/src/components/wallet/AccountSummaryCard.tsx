import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface AccountSummaryCardProps {
  availableBalance: number;
  totalValue: number;
  lastUpdated: Date;
}

export default function AccountSummaryCard({ 
  availableBalance, 
  totalValue, 
  lastUpdated 
}: AccountSummaryCardProps) {
  return (
    <Card className="shadow-md overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-primary/10 to-primary/5">
        <CardTitle className="text-lg">Account Summary</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <div className="text-sm text-textGray">Available Balance</div>
            <div className="text-2xl font-bold mt-1">${availableBalance.toLocaleString()}</div>
            <div className="text-xs text-textGray mt-1">
              <Clock className="h-3 w-3 inline mr-1" />
              Last updated {formatDistanceToNow(lastUpdated)} ago
            </div>
          </div>
          
          <div>
            <div className="text-sm text-textGray">Total Portfolio Value</div>
            <div className="text-2xl font-bold mt-1">${totalValue.toLocaleString()}</div>
            
            <div className="flex gap-2 mt-3">
              <Button variant="outline" size="sm" className="flex-1">
                <ArrowDownRight className="h-4 w-4 mr-1" />
                Deposit
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                <ArrowUpRight className="h-4 w-4 mr-1" />
                Withdraw
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}