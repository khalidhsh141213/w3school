# WebSocket: Best Practices

## Introduction

WebSocket technology is used in our platform to provide real-time price updates for cryptocurrencies and forex pairs. The infrastructure is designed to deliver fast and reliable updates while maintaining high performance.

## Core Principles

1. **Reserved for Real-time Data Only**: WebSockets should only be used for data that requires real-time updates, such as crypto and forex prices.
2. **Use REST for Less Frequent Updates**: For assets that don't require continuous updates (like stocks and indices), use REST API requests.
3. **Handle Disconnections**: Mechanisms are implemented to automatically reconnect when the connection with the server is lost.
4. **Limit Subscriptions**: Limits are applied to the number of assets that can be subscribed to avoid exceeding usage limits.

## Using WebSocketManager

`WebSocketManager` is a central component for managing WebSocket communications in the application. It provides a unified interface for handling connections, messages, and subscriptions.

### Basic Usage

```typescript
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';

// Using WebSocketManager in your component
function YourComponent() {
  // Get dynamic WebSocket URL
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = `${protocol}//${host}/ws`;
  
  // Use WebSocketManager
  const { status, send, subscribe } = useWebSocket(wsUrl, {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });
  
  // Subscribe to price updates when component loads
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      // Send subscription request for specified symbols
      send({
        type: 'subscribe',
        symbols: ['BTC/USD', 'ETH/USD', 'EUR/USD']
      });
      
      // Subscribe to incoming messages
      subscribe((message) => {
        if (message.type === 'priceUpdate') {
          // Handle price update
          console.log(`Received price update for ${message.data.symbol}: ${message.data.price}`);
        }
      });
    }
    
    // Clean up subscriptions when component is unmounted
    return () => {
      if (status === ConnectionStatus.CONNECTED) {
        send({
          type: 'unsubscribe',
          symbols: ['BTC/USD', 'ETH/USD', 'EUR/USD']
        });
      }
    };
  }, [status, send, subscribe]);
  
  // Display connection status to user
  return (
    <div>
      <div>Connection Status: {status}</div>
      {/* Your UI */}
    </div>
  );
}
```

### Connection Reuse

`WebSocketManager` is designed as a Singleton pattern to ensure only one connection is used per URL. This means all components that use the same WebSocket URL share the same connection, reducing resource consumption.

```typescript
// Component 1
const { status: status1, send: send1 } = useWebSocket('wss://example.com/ws');

// Component 2 - uses the same WebSocket connection
const { status: status2, send: send2 } = useWebSocket('wss://example.com/ws');
```

## Message Types

### Subscribing to Symbols

```json
{
  "type": "subscribe",
  "symbols": ["BTC/USD", "ETH/USD", "EUR/USD"]
}
```

### Unsubscribing from Symbols

```json
{
  "type": "unsubscribe",
  "symbols": ["BTC/USD", "ETH/USD", "EUR/USD"]
}
```

### Subscribing by Asset Type

```json
{
  "type": "subscribe",
  "assetTypes": ["crypto", "forex"]
}
```

### Price Update (from Server)

```json
{
  "type": "priceUpdate",
  "data": {
    "symbol": "BTC/USD",
    "price": "29750.45",
    "change": "120.75",
    "changePercent": "0.41",
    "volume": "4356789",
    "timestamp": "2025-03-30T12:34:56.789Z"
  }
}
```

## Error Handling and Reconnection

`WebSocketManager` includes advanced mechanisms for error handling and reconnection:

1. **Circuit Breaker**: Prevents repeated reconnection attempts when server issues exist.
2. **Rate Limiter**: Limits the number of messages sent in a specific time period.
3. **Message Queue**: Keeps messages in a queue when the connection is down.
4. **Automatic Reconnection**: Attempts to reconnect automatically when connection drops.

```typescript
// Advanced configuration
const { status, send, subscribe } = useWebSocket(wsUrl, {
  reconnectAttempts: 5,
  reconnectInterval: 3000,
  heartbeatInterval: 30000,
  heartbeatTimeout: 60000,
  circuitBreaker: {
    enabled: true,
    failureThreshold: 3,
    resetTimeout: 30000
  },
  rateLimiter: {
    enabled: true,
    maxOperations: 20,
    windowMs: 1000
  }
});
```

## Resource Cleanup

It's important to clean up subscriptions and resources when the component is removed from the DOM:

```typescript
useEffect(() => {
  // Subscribe to price updates
  const handlePriceUpdate = (data) => {
    // Handle the update
  };
  
  subscribe(handlePriceUpdate);
  
  // Clean up when component is unmounted
  return () => {
    // Unsubscribe from symbols
    send({
      type: 'unsubscribe',
      symbols: ['BTC/USD', 'ETH/USD']
    });
  };
}, [subscribe, send]);
```

## Current Implementation Limitations

1. **Limited Assets**: Currently, WebSocket is only supported for crypto and forex assets.
2. **Weekend Performance**: Forex updates are suspended on Sunday, while crypto updates continue.
3. **Data Provider Dependency**: Real-time data availability depends on external data providers.

## Additional Notes

- Always use the `subscribe` function to subscribe to messages rather than listening directly to `onmessage` events to ensure proper cleanup.
- Avoid subscribing to too many symbols at once to prevent performance issues.
- Use price alerts instead of continuous price updates for long-term monitoring.