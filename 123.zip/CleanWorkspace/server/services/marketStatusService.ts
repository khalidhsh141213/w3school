/**
 * Market Status Service
 * خدمة للتحقق من حالة الأسواق (مفتوحة أو مغلقة)
 */

// أنواع الأسواق المدعومة
export enum MarketType {
  STOCKS = 'stocks',
  FOREX = 'forex',
  CRYPTO = 'crypto',
  COMMODITY = 'commodity'
}

// حالة السوق
export enum MarketStatus {
  OPEN = 'open',
  CLOSED = 'closed',
  PREMARKET = 'premarket',
  AFTERHOURS = 'afterhours',
  WEEKEND = 'weekend',
  HOLIDAY = 'holiday'
}

interface MarketHours {
  open: { hour: number; minute: number };
  close: { hour: number; minute: number };
  timezone: string;
  weekend: number[]; // أيام الأسبوع (0 = الأحد، 6 = السبت)
}

// ساعات عمل الأسواق المختلفة (بتوقيت UTC)
const marketHours: Record<MarketType, MarketHours> = {
  [MarketType.STOCKS]: {
    open: { hour: 13, minute: 30 }, // 9:30 AM EST = 13:30 UTC
    close: { hour: 20, minute: 0 }, // 4:00 PM EST = 20:00 UTC
    timezone: 'America/New_York',
    weekend: [0, 6] // الأحد والسبت
  },
  [MarketType.FOREX]: {
    open: { hour: 22, minute: 0 }, // يفتح الأحد 5:00 PM EST = 22:00 UTC
    close: { hour: 21, minute: 0 }, // يغلق الجمعة 5:00 PM EST = 21:00 UTC
    timezone: 'UTC',
    weekend: [6] // السبت فقط (يغلق جزئياً)
  },
  [MarketType.CRYPTO]: {
    open: { hour: 0, minute: 0 }, // يعمل على مدار الساعة
    close: { hour: 23, minute: 59 },
    timezone: 'UTC',
    weekend: [] // لا عطلة أسبوعية
  },
  [MarketType.COMMODITY]: {
    open: { hour: 13, minute: 30 }, // 9:30 AM EST = 13:30 UTC
    close: { hour: 20, minute: 0 }, // 4:00 PM EST = 20:00 UTC
    timezone: 'America/New_York',
    weekend: [0, 6] // الأحد والسبت
  }
};

// قائمة العطل الرسمية (يمكن تحديثها لتشمل العطل الرسمية للسنة الحالية)
const holidays: Record<MarketType, Date[]> = {
  [MarketType.STOCKS]: [
    new Date('2025-01-01'), // New Year's Day
    new Date('2025-01-20'), // Martin Luther King Jr. Day
    new Date('2025-02-17'), // Presidents' Day
    new Date('2025-04-18'), // Good Friday
    new Date('2025-05-26'), // Memorial Day
    new Date('2025-06-19'), // Juneteenth
    new Date('2025-07-04'), // Independence Day
    new Date('2025-09-01'), // Labor Day
    new Date('2025-11-27'), // Thanksgiving Day
    new Date('2025-12-25'), // Christmas Day
  ],
  [MarketType.FOREX]: [
    new Date('2025-01-01'), // New Year's Day
    new Date('2025-04-18'), // Good Friday
    new Date('2025-12-25'), // Christmas Day
  ],
  [MarketType.CRYPTO]: [], // لا عطل رسمية
  [MarketType.COMMODITY]: [
    new Date('2025-01-01'), // New Year's Day
    new Date('2025-01-20'), // Martin Luther King Jr. Day
    new Date('2025-02-17'), // Presidents' Day
    new Date('2025-04-18'), // Good Friday
    new Date('2025-05-26'), // Memorial Day
    new Date('2025-06-19'), // Juneteenth
    new Date('2025-07-04'), // Independence Day
    new Date('2025-09-01'), // Labor Day
    new Date('2025-11-27'), // Thanksgiving Day
    new Date('2025-12-25'), // Christmas Day
  ]
};

/**
 * التحقق من عطل السوق
 * @param date التاريخ للتحقق
 * @param marketType نوع السوق
 * @returns هل اليوم عطلة رسمية
 */
function isHoliday(date: Date, marketType: MarketType): boolean {
  return holidays[marketType].some(holiday => 
    holiday.getDate() === date.getDate() &&
    holiday.getMonth() === date.getMonth() &&
    holiday.getFullYear() === date.getFullYear()
  );
}

/**
 * التحقق من عطلة نهاية الأسبوع
 * @param date التاريخ للتحقق
 * @param marketType نوع السوق
 * @returns هل اليوم عطلة نهاية أسبوع
 */
function isWeekend(date: Date, marketType: MarketType): boolean {
  const day = date.getDay();
  return marketHours[marketType].weekend.includes(day);
}

/**
 * التحقق مما إذا كان الوقت الحالي خلال ساعات التداول
 * @param date الوقت للتحقق
 * @param marketType نوع السوق
 * @returns هل الوقت ضمن ساعات التداول
 */
function isDuringTradingHours(date: Date, marketType: MarketType): boolean {
  // للعملات المشفرة، دائماً مفتوح
  if (marketType === MarketType.CRYPTO) {
    return true;
  }

  const hours = date.getUTCHours();
  const minutes = date.getUTCMinutes();
  const currentTime = hours * 60 + minutes;

  const market = marketHours[marketType];
  const openTime = market.open.hour * 60 + market.open.minute;
  const closeTime = market.close.hour * 60 + market.close.minute;

  // للتعامل مع الأسواق التي تستمر عبر منتصف الليل
  if (openTime < closeTime) {
    return currentTime >= openTime && currentTime <= closeTime;
  } else {
    return currentTime >= openTime || currentTime <= closeTime;
  }
}

/**
 * الحصول على حالة السوق الحالية
 * @param marketType نوع السوق
 * @param referenceDate التاريخ المرجعي (اختياري، افتراضياً الوقت الحالي)
 * @returns حالة السوق
 */
export function getMarketStatus(marketType: MarketType, referenceDate: Date = new Date()): MarketStatus {
  // تحقق من العطل الرسمية
  if (isHoliday(referenceDate, marketType)) {
    return MarketStatus.HOLIDAY;
  }

  // تحقق من عطلة نهاية الأسبوع
  if (isWeekend(referenceDate, marketType)) {
    return MarketStatus.WEEKEND;
  }

  // تحقق من ساعات التداول
  if (isDuringTradingHours(referenceDate, marketType)) {
    return MarketStatus.OPEN;
  }

  // تحديد ما إذا كانت فترة ما قبل أو بعد السوق
  const hours = referenceDate.getUTCHours();
  const minutes = referenceDate.getUTCMinutes();
  const currentTime = hours * 60 + minutes;
  
  const market = marketHours[marketType];
  const openTime = market.open.hour * 60 + market.open.minute;
  
  if (currentTime < openTime) {
    return MarketStatus.PREMARKET;
  } else {
    return MarketStatus.AFTERHOURS;
  }
}

/**
 * تحديد نوع السوق بناءً على نوع الأصل
 * @param assetType نوع الأصل
 * @returns نوع السوق المقابل
 */
export function getMarketTypeForAsset(assetType: string): MarketType {
  switch (assetType.toLowerCase()) {
    case 'stock':
    case 'etf':
    case 'index':
      return MarketType.STOCKS;
    case 'forex':
    case 'currency':
      return MarketType.FOREX;
    case 'crypto':
    case 'cryptocurrency':
      return MarketType.CRYPTO;
    case 'commodity':
    case 'futures':
      return MarketType.COMMODITY;
    default:
      return MarketType.STOCKS; // افتراضي
  }
}

/**
 * تحديد ما إذا كان السوق مفتوحاً الآن
 * @param assetType نوع الأصل
 * @returns هل السوق مفتوح
 */
export function isMarketOpen(assetType: string): boolean {
  const marketType = getMarketTypeForAsset(assetType);
  const status = getMarketStatus(marketType);
  return status === MarketStatus.OPEN;
}

/**
 * الحصول على حالة السوق الحالية بناءً على نوع الأصل
 * @param assetType نوع الأصل
 * @returns حالة السوق
 */
export function getMarketStatusForAsset(assetType: string): MarketStatus {
  const marketType = getMarketTypeForAsset(assetType);
  return getMarketStatus(marketType);
}

/**
 * الحصول على رسالة حالة السوق بلغتين
 * @param assetType نوع الأصل
 * @param lang اللغة (en أو ar)
 * @returns رسالة عن حالة السوق
 */
export function getMarketStatusMessage(assetType: string, lang: string = 'en'): string {
  const status = getMarketStatusForAsset(assetType);
  
  if (lang === 'ar') {
    switch (status) {
      case MarketStatus.OPEN:
        return 'السوق مفتوح';
      case MarketStatus.CLOSED:
        return 'السوق مغلق';
      case MarketStatus.PREMARKET:
        return 'فترة ما قبل افتتاح السوق';
      case MarketStatus.AFTERHOURS:
        return 'فترة ما بعد إغلاق السوق';
      case MarketStatus.WEEKEND:
        return 'عطلة نهاية الأسبوع';
      case MarketStatus.HOLIDAY:
        return 'عطلة رسمية';
      default:
        return 'حالة السوق غير معروفة';
    }
  } else {
    switch (status) {
      case MarketStatus.OPEN:
        return 'Market is Open';
      case MarketStatus.CLOSED:
        return 'Market is Closed';
      case MarketStatus.PREMARKET:
        return 'Pre-market Hours';
      case MarketStatus.AFTERHOURS:
        return 'After-hours Trading';
      case MarketStatus.WEEKEND:
        return 'Weekend - Market Closed';
      case MarketStatus.HOLIDAY:
        return 'Holiday - Market Closed';
      default:
        return 'Market status unknown';
    }
  }
}

/**
 * الحصول على وقت افتتاح السوق المقبل
 * @param assetType نوع الأصل
 * @returns تاريخ الافتتاح المقبل
 */
export function getNextMarketOpenTime(assetType: string): Date {
  const marketType = getMarketTypeForAsset(assetType);
  const now = new Date();
  const status = getMarketStatus(marketType, now);
  
  // إذا كان السوق مفتوحاً بالفعل، أعد الوقت الحالي
  if (status === MarketStatus.OPEN) {
    return now;
  }
  
  // ابدأ بتاريخ اليوم
  const nextOpenDate = new Date(now);
  let daysToAdd = 0;
  
  // تحديد عدد الأيام التي يجب إضافتها
  if (status === MarketStatus.WEEKEND) {
    // حساب عدد الأيام حتى يوم الاثنين المقبل
    const currentDay = now.getDay();
    daysToAdd = currentDay === 0 ? 1 : (8 - currentDay); // للأحد أضف 1، للسبت أضف 2
  }
  
  // إضافة الأيام المحسوبة
  if (daysToAdd > 0) {
    nextOpenDate.setDate(nextOpenDate.getDate() + daysToAdd);
  }
  
  // تعيين وقت الافتتاح
  const market = marketHours[marketType];
  nextOpenDate.setUTCHours(market.open.hour, market.open.minute, 0, 0);
  
  // إذا كان التاريخ الناتج قبل الوقت الحالي (كما في حالة AFTERHOURS)
  // أضف يوماً واحداً
  if (nextOpenDate <= now) {
    nextOpenDate.setDate(nextOpenDate.getDate() + 1);
  }
  
  // تكرار للتأكد من أن التاريخ ليس عطلة
  while (isHoliday(nextOpenDate, marketType) || isWeekend(nextOpenDate, marketType)) {
    nextOpenDate.setDate(nextOpenDate.getDate() + 1);
  }
  
  return nextOpenDate;
}

// تصدير كل ما سبق للاستخدام في أنحاء التطبيق
export default {
  MarketType,
  MarketStatus,
  getMarketStatus,
  getMarketTypeForAsset,
  isMarketOpen,
  getMarketStatusForAsset,
  getMarketStatusMessage,
  getNextMarketOpenTime
};