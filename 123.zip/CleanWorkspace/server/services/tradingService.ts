/**
 * Service for managing trading operations and portfolio management
 * This service handles trade execution, validation, and portfolio updates.
 * Uses real-time prices from marketData.ts for trade execution.
 */

import { db } from '../db';
import { eq } from 'drizzle-orm';
import { portfolios, trades } from '../db/schema';

interface TradeValidation {
  positionSize: number;
  usedMargin: number;
  availableBalance: number;
  isValid: boolean;
  error?: string;
}

export class TradingService {
  static validateTrade(
    quantity: number,
    price: number,
    leverage: number,
    accountBalance: number
  ): TradeValidation {
    const positionSize = quantity * price;
    const usedMargin = positionSize / leverage;
    const availableBalance = accountBalance - usedMargin;
    
    return {
      positionSize,
      usedMargin,
      availableBalance,
      isValid: accountBalance >= usedMargin,
      error: accountBalance < usedMargin ? "Insufficient funds to open this trade" : undefined
    };
  }

  static calculateProfitLoss(
    openPrice: number,
    closePrice: number,
    quantity: number,
    direction: 'buy' | 'sell'
  ): number {
    return direction === 'buy'
      ? (closePrice - openPrice) * quantity
      : (openPrice - closePrice) * quantity;
  }

  static async openTrade(
    userId: string,
    symbol: string,
    direction: 'buy' | 'sell',
    quantity: number,
    price: number,
    leverage: number,
    stopLoss?: number,
    takeProfit?: number
  ) {
    const portfolio = await db.query.portfolios.findFirst({
      where: eq(portfolios.userId, userId)
    });

    if (!portfolio) {
      throw new Error("Portfolio not found");
    }

    const validation = this.validateTrade(
      quantity,
      price,
      leverage,
      parseFloat(portfolio.availableBalance)
    );

    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    // Begin transaction
    return await db.transaction(async (tx) => {
      // Update portfolio balance
      await tx
        .update(portfolios)
        .set({
          availableBalance: (parseFloat(portfolio.availableBalance) - validation.usedMargin).toString(),
          usedMargin: (parseFloat(portfolio.usedMargin) + validation.usedMargin).toString()
        })
        .where(eq(portfolios.userId, userId));

      // Create trade record
      return await tx.insert(trades).values({
        userId,
        symbol,
        direction,
        quantity,
        openPrice: price,
        leverage,
        stopLoss,
        takeProfit,
        status: 'open',
        positionSize: validation.positionSize,
        usedMargin: validation.usedMargin
      });
    });
  }

  static async closeTrade(
    tradeId: string,
    closePrice: number
  ) {
    const trade = await db.query.trades.findFirst({
      where: eq(trades.id, tradeId)
    });

    if (!trade || trade.status !== 'open') {
      throw new Error("Trade not found or already closed");
    }

    const portfolio = await db.query.portfolios.findFirst({
      where: eq(portfolios.userId, trade.userId)
    });

    if (!portfolio) {
      throw new Error("Portfolio not found");
    }

    const profitLoss = this.calculateProfitLoss(
      trade.openPrice,
      closePrice,
      trade.quantity,
      trade.direction as 'buy' | 'sell'
    );

    // Begin transaction
    return await db.transaction(async (tx) => {
      // Update portfolio
      await tx
        .update(portfolios)
        .set({
          availableBalance: (parseFloat(portfolio.availableBalance) + trade.usedMargin + profitLoss).toString(),
          usedMargin: (parseFloat(portfolio.usedMargin) - trade.usedMargin).toString()
        })
        .where(eq(portfolios.userId, trade.userId));

      // Update trade
      return await tx
        .update(trades)
        .set({
          closePrice,
          closedAt: new Date(),
          status: 'closed',
          profitLoss
        })
        .where(eq(trades.id, tradeId));
    });
  }

  static async checkMarginCall(userId: string) {
    const portfolio = await db.query.portfolios.findFirst({
      where: eq(portfolios.userId, userId)
    });

    if (!portfolio) {
      throw new Error("Portfolio not found");
    }

    const availableBalance = parseFloat(portfolio.availableBalance);
    const usedMargin = parseFloat(portfolio.usedMargin);
    
    // Margin call if available balance is less than 50% of used margin
    return {
      isMarginCall: availableBalance < (usedMargin * 0.5),
      availableBalance,
      usedMargin
    };
  }
}
