import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle, Cpu, Database, Globe, RefreshCw, Server } from "lucide-react";
import { useState } from "react";

export default function SystemStatus() {
  const { toast } = useToast();
  const [refreshKey, setRefreshKey] = useState(0);

  // Fetch system status
  const { data: statusData, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/system-status", refreshKey],
    queryFn: getQueryFn({ on401: "throw" }),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Handle manual refresh
  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
    toast({
      title: "تحديث...",
      description: "جاري تحديث حالة النظام",
    });
  };

  // Mock data while API is built
  const systemStatus = statusData || {
    status: "operational",
    lastUpdated: new Date().toISOString(),
    components: [
      { name: "API Server", status: "operational", uptime: 99.98, load: 42 },
      { name: "Database", status: "operational", uptime: 99.95, load: 33 },
      { name: "WebSocket Server", status: "operational", uptime: 99.99, load: 28 },
      { name: "External Data Provider", status: "degraded", uptime: 98.5, load: 65 },
      { name: "Background Processing", status: "operational", uptime: 99.92, load: 51 }
    ],
    metrics: {
      cpuUsage: 38,
      memoryUsage: 45,
      diskUsage: 62,
      networkLatency: 24
    }
  };

  // Get status badge variant
  const getStatusBadge = (status) => {
    switch(status) {
      case "operational":
        return <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">تشغيل عادي</Badge>;
      case "degraded":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">أداء منخفض</Badge>;
      case "partial_outage":
        return <Badge variant="outline" className="bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400">انقطاع جزئي</Badge>;
      case "major_outage":
        return <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">انقطاع رئيسي</Badge>;
      default:
        return <Badge variant="outline">غير معروف</Badge>;
    }
  };

  // Get component icon
  const getComponentIcon = (name) => {
    if (name.toLowerCase().includes("api") || name.toLowerCase().includes("server")) {
      return <Server className="h-4 w-4" />;
    } else if (name.toLowerCase().includes("database")) {
      return <Database className="h-4 w-4" />;
    } else if (name.toLowerCase().includes("websocket") || name.toLowerCase().includes("socket")) {
      return <Globe className="h-4 w-4" />;
    } else if (name.toLowerCase().includes("processing")) {
      return <Cpu className="h-4 w-4" />;
    } else {
      return <CheckCircle className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-60 mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5).fill(0).map((_, index) => (
              <Skeleton key={index} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-xl">حالة النظام</CardTitle>
          <CardDescription>
            مراقبة حالة مكونات النظام والأداء
          </CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh}>
          <RefreshCw className="h-4 w-4 mr-1" /> تحديث
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            {systemStatus.status === "operational" ? (
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
            )}
            <span className="font-medium">
              الحالة الكلية: {systemStatus.status === "operational" ? "جميع الأنظمة تعمل" : "هناك مشاكل في بعض الأنظمة"}
            </span>
          </div>
          {getStatusBadge(systemStatus.status)}
        </div>

        <div className="space-y-4 mt-4">
          {systemStatus.components.map((component, index) => (
            <div key={index} className="border border-border rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  {getComponentIcon(component.name)}
                  <span className="ml-2 font-medium">{component.name}</span>
                </div>
                {getStatusBadge(component.status)}
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">نسبة التشغيل</div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{component.uptime}%</span>
                    <Progress value={component.uptime} className="h-2 ml-2 flex-1" />
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">الحمل</div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{component.load}%</span>
                    <Progress 
                      value={component.load} 
                      className={`h-2 ml-2 flex-1 ${
                        component.load > 80 ? "bg-red-200" : 
                        component.load > 60 ? "bg-orange-200" : 
                        "bg-sky-200"
                      }`} 
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="border border-border rounded-lg p-3">
            <div className="text-xs text-muted-foreground">CPU</div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-medium">{systemStatus.metrics.cpuUsage}%</span>
              <Progress value={systemStatus.metrics.cpuUsage} className="h-2 w-20" />
            </div>
          </div>
          <div className="border border-border rounded-lg p-3">
            <div className="text-xs text-muted-foreground">الذاكرة</div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-medium">{systemStatus.metrics.memoryUsage}%</span>
              <Progress value={systemStatus.metrics.memoryUsage} className="h-2 w-20" />
            </div>
          </div>
          <div className="border border-border rounded-lg p-3">
            <div className="text-xs text-muted-foreground">القرص</div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-medium">{systemStatus.metrics.diskUsage}%</span>
              <Progress value={systemStatus.metrics.diskUsage} className="h-2 w-20" />
            </div>
          </div>
          <div className="border border-border rounded-lg p-3">
            <div className="text-xs text-muted-foreground">زمن الاستجابة</div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-medium">{systemStatus.metrics.networkLatency}ms</span>
              <Progress value={systemStatus.metrics.networkLatency} max={100} className="h-2 w-20" />
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground border-t border-border pt-4">
        آخر تحديث: {new Date(systemStatus.lastUpdated).toLocaleString()}
      </CardFooter>
    </Card>
  );
} 