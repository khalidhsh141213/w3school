/**
 * Simple in-memory caching system optimized for Replit environment
 * This module provides caching for frequently requested data to reduce database load
 */

import { log } from './vite';

// Define cache entry structure with expiration
interface CacheEntry<T> {
  data: T;
  expiry: number;
}

export class Cache {
  private cache: Map<string, CacheEntry<any>>;
  private maxEntries: number;
  private defaultTTL: number;
  private hits: number = 0;
  private misses: number = 0;
  private name: string;

  /**
   * Create a new cache instance
   * @param name Identifier for this cache (used in logging)
   * @param maxEntries Maximum number of entries to store (defaults to 100)
   * @param defaultTTL Default time-to-live in milliseconds (defaults to 30 seconds)
   */
  constructor(name: string, maxEntries = 100, defaultTTL = 30000) {
    this.cache = new Map();
    this.maxEntries = maxEntries;
    this.defaultTTL = defaultTTL;
    this.name = name;
    
    // Set up automatic cleanup every minute to prevent memory leaks
    setInterval(() => this.cleanup(), 60000);
    
    log(`Cache '${name}' initialized with max ${maxEntries} entries and ${defaultTTL}ms TTL`, 'cache');
  }

  /**
   * Get an item from the cache
   * @param key Cache key
   * @returns The cached item or undefined if not found or expired
   */
  get<T>(key: string): T | undefined {
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.misses++;
      return undefined;
    }
    
    // Check if entry has expired
    if (entry.expiry < Date.now()) {
      this.cache.delete(key);
      this.misses++;
      return undefined;
    }
    
    this.hits++;
    return entry.data as T;
  }

  /**
   * Store an item in the cache
   * @param key Cache key
   * @param data Data to cache
   * @param ttl Optional custom TTL (in ms)
   */
  set<T>(key: string, data: T, ttl?: number): void {
    // If cache is at capacity, remove oldest entry
    if (this.cache.size >= this.maxEntries) {
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }
    
    const expiry = Date.now() + (ttl || this.defaultTTL);
    this.cache.set(key, { data, expiry });
  }
  
  /**
   * Store multiple items in the cache at once
   * @param items Object with key-value pairs to cache
   * @param ttl Optional custom TTL (in ms)
   */
  setBulk<T>(items: Record<string, T>, ttl?: number): void {
    const expiry = Date.now() + (ttl || this.defaultTTL);
    
    // Check if we need to make room
    const spaceNeeded = Object.keys(items).length;
    const freeSpace = this.maxEntries - this.cache.size;
    
    // If we need to remove items to make space
    if (spaceNeeded > freeSpace) {
      const toRemove = spaceNeeded - freeSpace;
      const keys = Array.from(this.cache.keys()).slice(0, toRemove);
      keys.forEach(key => this.cache.delete(key));
    }
    
    // Add all items
    Object.entries(items).forEach(([key, data]) => {
      this.cache.set(key, { data, expiry });
    });
    
    log(`Cache '${this.name}' bulk set: added ${Object.keys(items).length} items`, 'cache');
  }

  /**
   * Remove an item from the cache
   * @param key Cache key
   */
  delete(key: string): void {
    this.cache.delete(key);
  }
  
  /**
   * Get multiple items from the cache at once
   * @param keys Array of cache keys to retrieve
   * @returns Object with key-value pairs of found items
   */
  getBulk<T>(keys: string[]): Record<string, T> {
    const result: Record<string, T> = {};
    let hits = 0;
    
    keys.forEach(key => {
      const value = this.get<T>(key);
      if (value !== undefined) {
        result[key] = value;
        hits++;
      }
    });
    
    // We don't increment this.hits here because the get method already does it
    if (hits > 0) {
      log(`Cache '${this.name}' bulk get: ${hits}/${keys.length} hits`, 'cache');
    }
    
    return result;
  }
  
  /**
   * Check if cache has a key that's not expired
   * @param key Cache key
   * @returns True if the key exists and is not expired
   */
  has(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;
    
    if (entry.expiry < Date.now()) {
      this.cache.delete(key);
      return false;
    }
    
    return true;
  }

  /**
   * Clear all items from the cache
   */
  clear(): void {
    this.cache.clear();
    log(`Cache '${this.name}' cleared`, 'cache');
  }

  /**
   * Remove expired items from the cache
   */
  private cleanup(): void {
    const now = Date.now();
    let removed = 0;
    
    for (const [key, entry] of this.cache.entries()) {
      if (entry.expiry < now) {
        this.cache.delete(key);
        removed++;
      }
    }
    
    if (removed > 0) {
      log(`Cache '${this.name}' cleanup: removed ${removed} expired entries`, 'cache');
    }
  }

  /**
   * Get cache statistics
   */
  getStats(): { size: number, hits: number, misses: number, hitRate: number } {
    const total = this.hits + this.misses;
    const hitRate = total === 0 ? 0 : this.hits / total;
    
    return {
      size: this.cache.size,
      hits: this.hits,
      misses: this.misses,
      hitRate: Math.round(hitRate * 100) / 100  // Round to 2 decimal places
    };
  }

  /**
   * Reset cache statistics
   */
  resetStats(): void {
    this.hits = 0;
    this.misses = 0;
  }
}

// Create and export specific caches
export const marketDataCache = new Cache('marketData', 200, 60000); // 1 minute TTL for market data
export const analysisCache = new Cache('analysis', 50, 300000); // 5 minutes TTL for analysis
export const userCache = new Cache('users', 100, 300000); // 5 minutes TTL for user data
export const assetsCache = new Cache('assets', 300, 1800000); // 30 minutes TTL for assets data (rarely changes)
export const economicEventsCache = new Cache('economicEvents', 100, 3600000); // 1 hour TTL for economic events