import { useState, useRef, useEffect } from 'react';
import { useTranslation } from '../lib/useTranslation';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface AiAnalysisProps {
  symbol: string;
}

const AiAnalysis = ({ symbol }: AiAnalysisProps) => {
  const { t, language } = useTranslation();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [forceRefresh, setForceRefresh] = useState(false);
  const optionsRef = useRef<HTMLDivElement>(null);

  // Fetch AI analysis data
  const { data: analysis, isLoading } = useQuery({
    queryKey: ['/api/analysis', symbol],
    queryFn: async () => {
      const response = await fetch(`/api/analysis/${symbol}`);
      if (!response.ok) throw new Error('Failed to fetch analysis');
      return await response.json();
    },
    enabled: !!symbol,
  });

  // Refresh analysis mutation
  const refreshMutation = useMutation({
    mutationFn: async () => {
      setIsRefreshing(true);
      const url = forceRefresh 
        ? `/api/analysis/refresh/${symbol}?force=true`
        : `/api/analysis/refresh/${symbol}`;
      
      const response = await fetch(url, {
        method: 'POST',
      });
      if (!response.ok) throw new Error('Failed to refresh analysis');
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analysis', symbol] });
      setIsRefreshing(false);
      // Reset force refresh after successful refresh
      setForceRefresh(false);
      // Close options menu
      setShowOptions(false);
    },
    onError: () => {
      setIsRefreshing(false);
    }
  });

  // Handle refresh button click
  const handleRefresh = () => {
    refreshMutation.mutate();
  };
  
  // Toggle settings dropdown
  const toggleSettings = () => {
    setShowOptions(!showOptions);
  };
  
  // Close dropdown when clicking outside
  const handleClickOutside = (e: MouseEvent) => {
    if (optionsRef.current && !optionsRef.current.contains(e.target as Node)) {
      setShowOptions(false);
    }
  };
  
  // Add event listener for clicks outside dropdown
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Get the appropriate analysis text based on the current language
  const getAnalysisText = () => {
    if (!analysis) return '';
    return language === 'ar' && analysis.arabicAnalysis 
      ? analysis.arabicAnalysis 
      : analysis.analysis;
  };

  // Format indicators from the analysis data
  const formatIndicators = () => {
    if (!analysis || !analysis.indicators) return null;
    
    const { rsi, macd, moving_average } = analysis.indicators;
    
    return {
      rsi: {
        value: rsi,
        status: rsi > 70 ? 'overbought' : rsi < 30 ? 'oversold' : 'bullish'
      },
      macd: {
        value: typeof macd === 'string' ? macd : macd.toFixed(2),
        status: macd === 'bullish' || parseFloat(macd) > 0 ? 'positive' : 'negative'
      },
      movingAverage: {
        value: typeof moving_average === 'string' 
          ? moving_average 
          : moving_average.toFixed(2),
        status: moving_average === 'uptrend' || 
                (typeof moving_average === 'number' && moving_average > 0) 
                ? 'bullish' : 'bearish'
      }
    };
  };

  // Format prediction data
  const formatPrediction = () => {
    if (!analysis || !analysis.prediction) return null;
    
    const { direction, target, days } = analysis.prediction;
    const isUp = direction === 'up';
    
    return {
      direction: isUp ? 'trending_up' : 'trending_down',
      className: isUp ? 'text-secondary' : 'text-accent',
      growth: isUp ? '+3.2%' : '-2.1%',
      target,
      days: days || 7
    };
  };

  const indicators = formatIndicators();
  const prediction = formatPrediction();

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-condensed font-bold">
          {t('aiMarketAnalysis')}
        </h2>
        <div className="flex">
          <button 
            className="text-primary mr-2" 
            title="Refresh analysis"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <span className="material-icons">{isRefreshing ? 'sync' : 'refresh'}</span>
          </button>
          <div className="relative">
            <button 
              className="text-primary" 
              title="Settings"
              onClick={toggleSettings}
            >
              <span className="material-icons">settings</span>
            </button>
            
            {showOptions && (
              <div 
                ref={optionsRef}
                className="absolute right-0 mt-2 w-48 bg-white dark:bg-neutral-800 rounded-md shadow-lg z-10 border border-neutral-200 dark:border-neutral-700"
              >
                <div className="py-1">
                  <label className="flex items-center px-4 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-700 cursor-pointer">
                    <input
                      type="checkbox"
                      className="mr-2 h-4 w-4"
                      checked={forceRefresh}
                      onChange={() => setForceRefresh(!forceRefresh)}
                    />
                    {t('forceRefresh')}
                  </label>
                  <div className="px-4 py-2 text-xs text-neutral-500 border-t border-neutral-200 dark:border-neutral-700">
                    {t('forceRefreshExplanation')}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {isLoading || isRefreshing ? (
        <div className="p-4 text-center text-neutral">Loading analysis...</div>
      ) : analysis ? (
        <>
          <div className="p-4 border rounded-lg bg-neutral-50 dark:bg-neutral-dark">
            <div className="flex space-x-3 mb-4">
              <div className="flex-none">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
                  <span className="material-icons">psychology</span>
                </div>
              </div>
              <div className="flex-1">
                <p className="mb-2">{getAnalysisText()}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-4">
              {indicators && (
                <>
                  <div className="bg-white p-3 rounded shadow-sm dark:bg-neutral-dark">
                    <div className="text-sm text-neutral">{t('rsi')}</div>
                    <div className="text-xl font-semibold">{indicators.rsi.value}</div>
                    <div className={`text-xs ${indicators.rsi.status === 'oversold' ? 'text-accent-light' : 'text-secondary-light'}`}>
                      {t(indicators.rsi.status === 'oversold' ? 'bearish' : 'bullish')}
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded shadow-sm dark:bg-neutral-dark">
                    <div className="text-sm text-neutral">{t('macd')}</div>
                    <div className="text-xl font-semibold">{indicators.macd.value}</div>
                    <div className={`text-xs ${indicators.macd.status === 'positive' ? 'text-secondary-light' : 'text-accent-light'}`}>
                      {t('positiveCrossover')}
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded shadow-sm dark:bg-neutral-dark">
                    <div className="text-sm text-neutral">{t('movingAverage')}</div>
                    <div className="text-xl font-semibold">
                      {typeof indicators.movingAverage.value === 'string' 
                        ? indicators.movingAverage.value 
                        : `$${indicators.movingAverage.value}`}
                    </div>
                    <div className={`text-xs ${indicators.movingAverage.status === 'bullish' ? 'text-secondary-light' : 'text-accent-light'}`}>
                      {t('aboveBullish')}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">
                {t('aiPrediction')}
              </h3>
              <span className="text-xs text-neutral">
                {t('confidence')} <span className="font-semibold">{analysis.confidence}%</span>
              </span>
            </div>
            {prediction && (
              <div className="bg-secondary/10 p-3 rounded-lg mt-2 border border-secondary/20">
                <div className="flex items-center">
                  <span className={`material-icons ${prediction.className} mr-2`}>
                    {prediction.direction}
                  </span>
                  <div>
                    <div className={`font-semibold ${prediction.className}`}>
                      {t('projectedGrowth')} {prediction.growth} {t('inNextDays')} {prediction.days} {t('days')}
                    </div>
                    <div className="text-sm">
                      {t('targetPrice')} ${prediction.target}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="p-4 text-center text-neutral">
          No analysis available for {symbol}
        </div>
      )}
    </div>
  );
};

export default AiAnalysis;
