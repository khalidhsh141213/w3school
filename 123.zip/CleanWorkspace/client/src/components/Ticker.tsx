import { useEffect, useState } from 'react';

interface MarketDataItem {
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
}

interface TickerProps {
  marketData: Record<string, any>;
  isConnected: boolean;
}

const Ticker = ({ marketData, isConnected }: TickerProps) => {
  const [tickerItems, setTickerItems] = useState<MarketDataItem[]>([]);

  // Update ticker items when market data changes
  useEffect(() => {
    if (Object.keys(marketData).length > 0) {
      const items = Object.values(marketData).map(item => ({
        symbol: item.symbol,
        price: parseFloat(item.price).toFixed(2),
        change: parseFloat(item.change).toFixed(2),
        changePercent: parseFloat(item.changePercent).toFixed(2)
      }));
      setTickerItems(items);
    }
  }, [marketData]);

  return (
    <div className="bg-neutral-dark text-white py-1 ticker-container">
      <div className="ticker-content">
        {tickerItems.length > 0 ? (
          tickerItems.map((item, index) => (
            <div className="inline-block px-4" key={`${item.symbol}-${index}`}>
              <span className="font-bold">{item.symbol}</span>
              <span className={`ml-1 ${parseFloat(item.changePercent) >= 0 ? 'text-secondary-light' : 'text-accent-light'}`}>
                {parseFloat(item.changePercent) >= 0 ? '+' : ''}{item.changePercent}%
              </span>
              <span className="ml-1">${item.price}</span>
            </div>
          ))
        ) : (
          <div className="inline-block px-4">
            {isConnected ? 'Loading market data...' : 'Connecting to market data...'}
          </div>
        )}
      </div>
    </div>
  );
};

export default Ticker;
