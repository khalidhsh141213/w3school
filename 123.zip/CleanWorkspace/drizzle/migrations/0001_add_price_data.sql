/*
 * Price Data Migration
 * Enhances the assets table with detailed price information:
 * - Adds OHLCV (Open, High, Low, Close, Volume) data
 * - Creates price history table for historical data
 * - Adds performance metrics (24h changes, market cap)
 * - Sets up indexes for efficient querying
 * 
 * Dependencies: 0000_initial_migration.sql
 */

-- Add new enum type for time intervals
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'time_interval') THEN
    CREATE TYPE "time_interval" AS ENUM ('1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M');
  END IF;
END$$;

-- Add new columns to assets table
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "open_price" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "high_price" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "low_price" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "close_price" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "volume" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "market_cap" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "price_change_percent" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "price_change_24h" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "volume_24h" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "high_24h" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "low_24h" DOUBLE PRECISION;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "last_updated" TIMESTAMP;

-- Create price_history table for OHLCV data
CREATE TABLE IF NOT EXISTS "price_history" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "asset_id" UUID NOT NULL REFERENCES "assets"("id"),
  "timestamp" TIMESTAMP NOT NULL,
  "interval" time_interval NOT NULL,
  "open" DOUBLE PRECISION NOT NULL,
  "high" DOUBLE PRECISION NOT NULL,
  "low" DOUBLE PRECISION NOT NULL,
  "close" DOUBLE PRECISION NOT NULL,
  "volume" DOUBLE PRECISION NOT NULL
);

-- Add index for faster queries on price history
CREATE INDEX IF NOT EXISTS "price_history_asset_id_timestamp_idx" ON "price_history"("asset_id", "timestamp");
CREATE INDEX IF NOT EXISTS "price_history_interval_idx" ON "price_history"("interval");

-- Update existing assets with default values for new columns
UPDATE "assets" SET 
  "open_price" = "price",
  "high_price" = "price",
  "low_price" = "price",
  "close_price" = "price",
  "volume" = 0,
  "price_change_percent" = 0,
  "last_updated" = NOW()
WHERE "open_price" IS NULL; 