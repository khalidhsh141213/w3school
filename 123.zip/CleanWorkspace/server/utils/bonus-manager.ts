/**
 * أداة مساعدة لإدارة نظام المكافآت
 * تم تصميمها لتعمل مع نظام المكافآت والإحالات وتتبع الأنشطة الجديد
 */

import { db } from '../db.js';
import { bonuses, users } from '../../shared/schema.js';
import { eq, and, lt, gt, or, isNull } from 'drizzle-orm';
import { logBonusReceivedActivity, logBonusUsedActivity } from './activity-logger.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * إنشاء مكافأة جديدة
 * @param userId معرف المستخدم
 * @param amount قيمة المكافأة
 * @param type نوع المكافأة (welcome, deposit, referral, promotion)
 * @param description وصف المكافأة
 * @param currency عملة المكافأة (USD, EUR, الخ.)
 * @param expiryDays عدد أيام صلاحية المكافأة (0 تعني أنها لا تنتهي)
 * @param conditions شروط استخدام المكافأة
 * @returns وعد يحتوي على المكافأة المنشأة
 */
export async function createBonus(
  userId: number,
  amount: string,
  type: string,
  description: string,
  currency: string = 'USD',
  expiryDays: number = 30,
  conditions: Record<string, any> = {}
) {
  try {
    const startDate = new Date();
    let expiryDate = null;
    
    if (expiryDays > 0) {
      expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + expiryDays);
    }

    const bonusId = uuidv4();
    
    const [bonus] = await db.insert(bonuses).values({
      id: bonusId,
      userId,
      amount,
      currency,
      type,
      description,
      status: 'active',
      conditions,
      startDate,
      expiryDate,
      usedAmount: '0.00',
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();

    // تحديث رصيد المكافآت للمستخدم
    await db.update(users)
      .set({ 
        bonusBalance: (user) => `${user.bonusBalance} + ${amount}`,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));

    // تسجيل النشاط
    await logBonusReceivedActivity(userId, bonusId, amount, type);

    console.log(`✓ تم إنشاء مكافأة جديدة من نوع "${type}" للمستخدم ${userId} بقيمة ${amount} ${currency}`);
    return bonus;
  } catch (error) {
    console.error('خطأ في إنشاء مكافأة جديدة:', error);
    throw error;
  }
}

/**
 * الحصول على المكافآت النشطة للمستخدم
 * @param userId معرف المستخدم
 * @returns وعد يحتوي على قائمة المكافآت النشطة
 */
export async function getActiveBonuses(userId: number) {
  try {
    const now = new Date();
    
    const activeBonuses = await db.select()
      .from(bonuses)
      .where(
        and(
          eq(bonuses.userId, userId),
          eq(bonuses.status, 'active'),
          or(
            isNull(bonuses.expiryDate),
            gt(bonuses.expiryDate, now)
          )
        )
      )
      .orderBy(bonuses.createdAt);

    return activeBonuses;
  } catch (error) {
    console.error('خطأ في الحصول على المكافآت النشطة:', error);
    throw error;
  }
}

/**
 * استخدام جزء من المكافأة
 * @param bonusId معرف المكافأة
 * @param amount المبلغ المستخدم
 * @param context سياق استخدام المكافأة (trade, withdrawal, الخ.)
 * @param contextId معرف سياق استخدام المكافأة (معرف الصفقة مثلاً)
 * @returns وعد يحتوي على المكافأة المحدثة
 */
export async function useBonus(
  bonusId: string,
  amount: string,
  context: string,
  contextId: string
) {
  try {
    // الحصول على المكافأة
    const [bonus] = await db.select()
      .from(bonuses)
      .where(eq(bonuses.id, bonusId));

    if (!bonus) {
      throw new Error(`المكافأة غير موجودة: ${bonusId}`);
    }

    if (bonus.status !== 'active') {
      throw new Error(`المكافأة غير نشطة: ${bonusId}`);
    }

    const now = new Date();
    if (bonus.expiryDate && bonus.expiryDate < now) {
      throw new Error(`المكافأة منتهية الصلاحية: ${bonusId}`);
    }

    // حساب المبلغ المتبقي بعد الاستخدام
    const parsedAmount = parseFloat(amount);
    const usedAmount = parseFloat(bonus.usedAmount);
    const bonusAmount = parseFloat(bonus.amount);
    
    const newUsedAmount = usedAmount + parsedAmount;
    
    if (newUsedAmount > bonusAmount) {
      throw new Error(`المبلغ المطلوب أكبر من المبلغ المتاح. متاح: ${bonusAmount - usedAmount}, مطلوب: ${parsedAmount}`);
    }

    // تحديث حالة المكافأة
    const status = newUsedAmount >= bonusAmount ? 'used' : 'active';
    
    const [updatedBonus] = await db.update(bonuses)
      .set({ 
        usedAmount: newUsedAmount.toFixed(2),
        status,
        updatedAt: new Date()
      })
      .where(eq(bonuses.id, bonusId))
      .returning();

    // تحديث رصيد المكافآت للمستخدم
    await db.update(users)
      .set({ 
        bonusBalance: (user) => `${user.bonusBalance} - ${amount}`,
        updatedAt: new Date()
      })
      .where(eq(users.id, bonus.userId));

    // تسجيل النشاط
    await logBonusUsedActivity(bonus.userId, bonusId, amount, context, contextId);

    console.log(`✓ تم استخدام ${amount} من المكافأة ${bonusId}`);
    return updatedBonus;
  } catch (error) {
    console.error('خطأ في استخدام المكافأة:', error);
    throw error;
  }
}

/**
 * تحديث حالة المكافآت المنتهية
 * يجب تشغيل هذه الدالة بشكل دوري (مثلاً من خلال وظيفة مجدولة)
 * @returns وعد يحتوي على عدد المكافآت المحدثة
 */
export async function updateExpiredBonuses() {
  try {
    const now = new Date();
    
    const { rowCount } = await db.update(bonuses)
      .set({ 
        status: 'expired',
        updatedAt: now
      })
      .where(
        and(
          eq(bonuses.status, 'active'),
          lt(bonuses.expiryDate, now)
        )
      );

    console.log(`✓ تم تحديث ${rowCount} من المكافآت المنتهية`);
    return rowCount;
  } catch (error) {
    console.error('خطأ في تحديث المكافآت المنتهية:', error);
    throw error;
  }
}

// إنشاء مكافأة ترحيبية للمستخدم الجديد
export async function createWelcomeBonus(userId: number) {
  return createBonus(
    userId,
    '50.00',
    'welcome',
    'مكافأة ترحيبية للعضو الجديد',
    'USD',
    30,
    { minTrades: 3 }
  );
}

// إنشاء مكافأة إحالة
export async function createReferralBonus(userId: number, referralCode: string) {
  return createBonus(
    userId,
    '25.00',
    'referral',
    `مكافأة إحالة مستخدم جديد (${referralCode})`,
    'USD',
    60,
    { referralCode }
  );
}

// استخراج كل العمليات اللازمة للتعامل مع نظام المكافآت
export const BonusManager = {
  createBonus,
  getActiveBonuses,
  useBonus,
  updateExpiredBonuses,
  createWelcomeBonus,
  createReferralBonus
};