import { ReactNode, useState, useEffect, useCallback } from "react";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import MarketTicker from "@/components/layout/MarketTicker";
import { ChevronLeft, ChevronRight, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMediaQuery } from "@/hooks/use-media-query";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [autoHideTimer, setAutoHideTimer] = useState<NodeJS.Timeout | null>(null);
  const [isInteracting, setIsInteracting] = useState(false);
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  // Initialize dark mode based on user preference or system preference
  useEffect(() => {
    // Check if user has a preference stored
    const savedTheme = localStorage.getItem('tradepro-theme');
    if (savedTheme) {
      setDarkMode(savedTheme === 'dark');
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    } else {
      // Otherwise check system preference
      const isDarkPreferred = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setDarkMode(isDarkPreferred);
      document.documentElement.classList.toggle('dark', isDarkPreferred);
    }
  }, []);

  // Toggle dark mode
  const toggleDarkMode = () => {
    const newValue = !darkMode;
    setDarkMode(newValue);
    document.documentElement.classList.toggle('dark', newValue);
    localStorage.setItem('tradepro-theme', newValue ? 'dark' : 'light');
  };

  // Auto-hide sidebar on small screens
  useEffect(() => {
    if (!isDesktop && sidebarOpen) {
      setSidebarOpen(false);
    }
  }, [isDesktop]);

  // Reset auto-hide timer when sidebar is interacted with
  const resetAutoHideTimer = useCallback(() => {
    // استخدام setAutoHideTimer مع وظيفة callback لتجنب الاعتماد على autoHideTimer 
    // في مصفوفة التبعيات، وبذلك نقطع حلقة التحديث اللانهائية
    setAutoHideTimer(prevTimer => {
      // تنظيف المؤقت السابق إذا كان موجودا
      if (prevTimer) {
        clearTimeout(prevTimer);
      }
      
      // إنشاء مؤقت جديد لإخفاء الشريط الجانبي بعد 5 ثوان
      return setTimeout(() => {
        if (!isInteracting) {
          if (!isDesktop) {
            setMobileSidebarOpen(false);
          } else {
            setSidebarOpen(false);
          }
        }
      }, 5000);
    });
  }, [isDesktop, isInteracting]);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (autoHideTimer) {
        clearTimeout(autoHideTimer);
      }
    };
  }, [autoHideTimer]);

  // Handle keyboard shortcuts for sidebar
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'b') {
        setSidebarOpen(prev => !prev);
        resetAutoHideTimer();
      }
    };

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [resetAutoHideTimer]);

  // Prevent scrolling when mobile sidebar is open
  useEffect(() => {
    if (mobileSidebarOpen) {
      document.body.style.overflow = 'hidden';
      resetAutoHideTimer();
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileSidebarOpen, resetAutoHideTimer]);

  // Handle sidebar toggle
  const handleSidebarToggle = () => {
    setSidebarOpen(!sidebarOpen);
    resetAutoHideTimer();
  };

  // Handle mobile sidebar toggle
  const handleMobileSidebarToggle = (open: boolean) => {
    setMobileSidebarOpen(open);
    if (open) {
      resetAutoHideTimer();
    }
  };

  return (
    <div className="flex bg-background text-foreground min-h-screen relative">
      {/* Sidebar toggle button for desktop */}
      <Button 
        variant="outline" 
        size="icon"
        onClick={handleSidebarToggle}
        className="fixed top-[70px] left-3 z-50 hidden lg:flex h-8 w-8 items-center justify-center rounded-full border border-border/40 bg-background/95 backdrop-blur-sm shadow-sm"
        title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
      >
        {sidebarOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
      </Button>
      
      {/* Dark mode toggle button */}
      <Button 
        variant="outline" 
        size="icon"
        onClick={toggleDarkMode}
        className="fixed bottom-4 right-4 z-50 h-10 w-10 rounded-full border border-border/40 bg-background/95 backdrop-blur-sm shadow-md"
        title={darkMode ? "Switch to light mode" : "Switch to dark mode"}
      >
        {darkMode ? (
          <Sun className="h-5 w-5 text-yellow-500" />
        ) : (
          <Moon className="h-5 w-5 text-indigo-500" />
        )}
      </Button>
      
      {/* Sidebar - Desktop view */}
      <div 
        className={`fixed inset-y-0 left-0 z-40 transition-all duration-300 transform lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } w-64 hidden lg:block border-r border-border`}
        onMouseEnter={() => {
          setIsInteracting(true);
          if (autoHideTimer) {
            clearTimeout(autoHideTimer);
          }
        }}
        onMouseLeave={() => {
          setIsInteracting(false);
          resetAutoHideTimer();
        }}
      >
        <Sidebar />
      </div>
      
      {/* Mobile sidebar overlay */}
      {mobileSidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={() => handleMobileSidebarToggle(false)}
        />
      )}
      
      {/* Mobile sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 transition-all duration-300 transform ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:hidden w-64 shadow-xl`}
        onMouseEnter={() => {
          setIsInteracting(true);
          if (autoHideTimer) {
            clearTimeout(autoHideTimer);
          }
        }}
        onMouseLeave={() => {
          setIsInteracting(false);
          resetAutoHideTimer();
        }}
      >
        <Sidebar />
      </div>
      
      {/* Main Content Container */}
      <div className={`flex-1 flex flex-col w-full transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : 'lg:ml-0'}`}>
        {/* Header */}
        <Header 
          mobileSidebarOpen={mobileSidebarOpen} 
          setMobileSidebarOpen={handleMobileSidebarToggle}
        />
        
        {/* Market Ticker */}
        <MarketTicker />
        
        {/* Main Content */}
        <main className="flex-1 overflow-y-auto pt-0 pb-4 md:pb-6 px-3 sm:px-4 md:px-6 lg:px-8">
          {children}
        </main>
      </div>
    </div>
  );
}
