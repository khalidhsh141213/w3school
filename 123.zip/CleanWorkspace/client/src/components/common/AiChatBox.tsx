import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { checkAiServiceHealth, generateText } from '../../services/aiService';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
}

// Sample suggested questions for users
const suggestedQuestions = [
  "How do I deposit funds?",
  "What are the trading fees?",
  "How can I reset my password?",
  "How do I place a market order?",
  "What are the platform's trading hours?",
  "كيف يمكنني إيداع الأموال؟",
  "ما هي رسوم التداول؟"
];

const AiChatBox: React.FC = () => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isServiceAvailable, setIsServiceAvailable] = useState(true);

  // Check AI service health on component mount
  useEffect(() => {
    const checkService = async () => {
      const isHealthy = await checkAiServiceHealth();
      setIsServiceAvailable(isHealthy);
      
      // Add welcome message
      if (isHealthy) {
        setMessages([
          {
            id: Date.now().toString(),
            text: t('ai.welcome_message'),
            isUser: false,
          }
        ]);
      }
    };
    
    checkService();
  }, [t]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    // Add the user message to the chat
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      isUser: true,
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    try {
      // Enhance the prompt with customer service context
      const enhancedPrompt = `Customer Service Request: ${input}\nPlease provide a helpful, accurate, and friendly response about trading or platform support:`;
      
      // Get the AI response with longer max_length for more detailed responses
      const aiResponseText = await generateText(enhancedPrompt, {
        max_length: 200,
        temperature: 0.7
      });
      
      // Safely handle the response
      if (!aiResponseText) {
        throw new Error('Empty response received from AI service');
      }
      
      // Clean up the response to remove the prompt echo if present
      let cleanedResponse = aiResponseText;
      try {
        // Only attempt to clean up if the response is a string
        if (typeof aiResponseText === 'string') {
          cleanedResponse = aiResponseText.replace(enhancedPrompt, '').trim() || aiResponseText;
        }
      } catch (cleaningError) {
        console.warn('Could not clean response:', cleaningError);
        // Continue with the original response
      }
      
      // Add the AI response to the chat
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: cleanedResponse, 
        isUser: false,
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      
      // Add an error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: t('ai.error'),
        isUser: false,
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  if (!isServiceAvailable) {
    return (
      <div className="flex flex-col h-96 border rounded-lg p-4 bg-white shadow-md items-center justify-center">
        <div className="text-red-500 font-semibold mb-2">{t('ai.service_unavailable')}</div>
        <p className="text-center text-gray-600">
          {t('ai.try_again_later')}
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[550px] border rounded-lg bg-white shadow-md">
      <div className="p-4 bg-blue-700 text-white rounded-t-lg">
        <div className="text-xl font-semibold">{t('ai.chat_title')}</div>
        <div className="text-sm opacity-80">{t('ai.chat_subtitle')}</div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 mb-4">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 mt-10">
            {t('ai.empty_state')}
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`p-3 rounded-lg max-w-[85%] ${
                message.isUser
                  ? 'bg-blue-100 ml-auto text-blue-900'
                  : 'bg-gray-100 mr-auto text-gray-800'
              }`}
            >
              <div className="text-xs font-semibold mb-1">
                {message.isUser ? t('ai.you') : t('ai.assistant')}
              </div>
              <div className="whitespace-pre-line">{message.text}</div>
            </div>
          ))
        )}
        
        {isLoading && (
          <div className="flex items-center justify-center space-x-2 p-3 bg-gray-50 rounded-lg max-w-[85%] mr-auto">
            <div className="text-xs font-semibold mb-1 text-gray-700">
              {t('ai.assistant')}
            </div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-75"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-150"></div>
          </div>
        )}
      </div>
      
      {messages.length > 0 && messages.length < 3 && (
        <div className="px-4 mb-3">
          <div className="text-sm font-medium mb-2">{t('ai.suggested_questions')}</div>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.slice(0, 4).map((question, index) => (
              <button
                key={index}
                onClick={() => handleSuggestedQuestion(question)}
                className="text-xs bg-gray-100 hover:bg-gray-200 rounded-full px-3 py-1 transition-colors"
              >
                {question.length > 30 ? `${question.substring(0, 27)}...` : question}
              </button>
            ))}
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t('ai.input_placeholder')}
            disabled={isLoading}
            className="flex-1 p-3 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-3 bg-blue-700 text-white rounded-r-lg hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-300 transition-colors"
          >
            {isLoading ? t('ai.sending') : t('ai.send')}
          </button>
        </div>
        <div className="mt-2 text-xs text-gray-500 text-center">
          {t('ai.powered_by_bloom')}
        </div>
      </form>
    </div>
  );
};

export default AiChatBox; 