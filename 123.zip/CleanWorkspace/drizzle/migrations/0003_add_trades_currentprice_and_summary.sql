/*
 * Trade Current Price and Portfolio Summary Migration
 * Enhances trade tracking and portfolio management:
 * - Adds current_price to trades for real-time P&L calculation
 * - Creates portfolio_summary table for aggregated portfolio data
 * - Enables better performance for portfolio-wide queries
 * 
 * Dependencies:
 * - 0000_initial_migration.sql (users and trades tables)
 * - 0001_add_price_data.sql (price tracking)
 * - 0002_add_portfolios.sql (portfolio management)
 */

-- Add current_price to trades table
ALTER TABLE trades ADD COLUMN IF NOT EXISTS current_price DOUBLE PRECISION;

-- Create portfolio_summary table 
CREATE TABLE IF NOT EXISTS portfolio_summary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  total_balance DOUBLE PRECISION NOT NULL,
  total_equity DOUBLE PRECISION NOT NULL,
  total_profit DOUBLE PRECISION NOT NULL,
  total_loss DOUBLE PRECISION NOT NULL,
  open_positions INTEGER NOT NULL,
  total_invested_amount DOUBLE PRECISION NOT NULL,
  available_balance DOUBLE PRECISION NOT NULL,
  margin_utilization DOUBLE PRECISION NOT NULL,
  unrealized_pl DOUBLE PRECISION NOT NULL,
  total_return DOUBLE PRECISION NOT NULL,
  last_updated TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
); 