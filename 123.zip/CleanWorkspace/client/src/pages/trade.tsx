import { LineChart } from '@/components/charts';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { formatCurrency } from '@/lib/utils';
import { useWebSocket, ConnectionStatus } from '@/lib/useWebSocket';
import WebSocketStatus from '@/components/WebSocketStatus';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, RotateCcw, TrendingDown, TrendingUp } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useLocation, useRoute } from 'wouter';
import * as z from 'zod';

// Define interfaces for TypeScript
interface Asset {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  currentPrice: number;
  previousClosePrice: number;
  changePercent: number;
  type: 'stock' | 'crypto' | 'forex';
  icon?: string;
}

interface Trade {
  id: string;
  assetId: string;
  userId: string;
  quantity: number;
  price: number;
  type: 'buy' | 'sell';
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: string;
}

interface WebSocketMessage {
  type: string;
  symbol: string;
  price: number;
  changePercent: number;
  volume?: number;
  timestamp?: number;
}

// Form schema for validation
const tradeFormSchema = z.object({
  quantity: z.number().positive("Quantity must be positive"),
  price: z.number().positive("Price must be positive"),
  useMarketPrice: z.boolean().default(true),
});

type TradeFormValues = z.infer<typeof tradeFormSchema>;

export default function TradePage() {
  const [_, navigate] = useLocation();
  const [match, params] = useRoute('/trade/:symbol');
  const symbol = params?.symbol;
  const [activeTab, setActiveTab] = useState<'buy' | 'sell'>('buy');
  const [useMarketPrice, setUseMarketPrice] = useState(true);
  const [realTimePrice, setRealTimePrice] = useState<number | null>(null);
  const [priceChange, setPriceChange] = useState<number>(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Use dynamic WebSocket URL based on current window location
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = process.env.REACT_APP_WS_URL || `${protocol}//${host}/ws`;
  
  // Use WebSocketManager hook
  const { status: wsStatus, send, subscribe } = useWebSocket(wsUrl, {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
    circuitBreaker: {
      enabled: true,
      failureThreshold: 3,
      resetTimeout: 30000, // 30 seconds
    }
  });

  // Fetch asset details
  const { data: asset, isLoading: isLoadingAsset, error: assetError } = useQuery<Asset>({
    queryKey: ['asset', symbol],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${symbol}`);
      if (!res.ok) {
        throw new Error(`Failed to fetch asset: ${res.statusText}`);
      }
      return res.json();
    },
    enabled: !!symbol,
    refetchInterval: 30000, // Refetch every 30 seconds as backup if WebSocket fails
  });

  // Set up WebSocket subscription
  useEffect(() => {
    if (!symbol || wsStatus !== ConnectionStatus.CONNECTED) return;
    
    // Set up message handler
    subscribe((data) => {
      try {
        console.log('WebSocket message received in trade:', data);
        
        // Handle different message types
        if (data.type === 'price' || data.type === 'priceUpdate') {
          if (data.symbol === symbol) {
            setRealTimePrice(data.price);
            setPriceChange(data.changePercent || 0);
            
            // Update the form price if using market price
            if (useMarketPrice && data.price !== form.getValues('price')) {
              form.setValue('price', data.price);
            }
          }
        } else if (data.type === 'assetList' && Array.isArray(data.data)) {
          // Handle asset list updates
          data.data.forEach(asset => {
            if (asset.symbol === symbol) {
              const price = asset.price || asset.currentPrice;
              setRealTimePrice(price);
              setPriceChange(asset.changePercent || 0);
              
              // Update the form price if using market price
              if (useMarketPrice && price !== form.getValues('price')) {
                form.setValue('price', price);
              }
            }
          });
        }
      } catch (e) {
        console.error('Error handling WebSocket message in trade:', e);
      }
    });
    
    // Subscribe to real-time updates for this asset
    send({
      action: 'subscribe',
      symbols: [symbol]
    });
    console.log(`Subscribed to ${symbol} in trade page`);
    
  }, [symbol, wsStatus, subscribe, send, useMarketPrice, form]);
  
  // Update form value when asset data is loaded or realtime price changes
  useEffect(() => {
    if (asset && useMarketPrice) {
      const currentPrice = realTimePrice || asset.currentPrice;
      form.setValue('price', currentPrice);
    }
  }, [asset, realTimePrice, useMarketPrice, form]);

  // Form setup
  const form = useForm<TradeFormValues>({
    resolver: zodResolver(tradeFormSchema),
    defaultValues: {
      quantity: 1,
      price: 0,
      useMarketPrice: true,
    },
  });

  // Handle WebSocket reconnection
  const handleWsReconnect = () => {
    // Re-subscribe to asset data
    if (symbol) {
      send({
        action: 'subscribe',
        symbols: [symbol]
      });
    }
    
    // Update price from asset if available
    if (asset) {
      form.setValue('price', asset.currentPrice);
    }
  };

  // Calculate total cost/value
  const calculateTotal = () => {
    const quantity = form.getValues('quantity') || 0;
    const price = form.getValues('price') || 0;
    return quantity * price;
  };
  
  // Get estimated fees (simplified for demo)
  const getEstimatedFees = () => {
    const total = calculateTotal();
    // For demo purposes - 0.5% fee
    return total * 0.005; 
  };
  
  // Fetch user portfolio
  const { data: userPortfolio } = useQuery({
    queryKey: ['portfolio'],
    queryFn: async () => {
      const res = await fetch('/api/portfolio');
      if (!res.ok) {
        throw new Error('Failed to fetch portfolio');
      }
      return res.json();
    },
  });
  
  // Submit trade mutation
  const submitTrade = useMutation({
    mutationFn: async (values: TradeFormValues & { tradeType: 'buy' | 'sell' }) => {
      const { quantity, price, tradeType } = values;
      
      if (!symbol) {
        throw new Error('No asset symbol provided');
      }
      
      const response = await fetch('/api/trades', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symbol,
          quantity,
          price, 
          type: tradeType
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to execute ${tradeType} order`);
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['portfolio'] });
      
      // Show success toast
      toast({
        title: "Trade Successful",
        description: `Successfully ${variables.tradeType === 'buy' ? 'bought' : 'sold'} ${variables.quantity} ${symbol} at ${formatCurrency(variables.price)}.`,
      });
      
      // Reset form
      form.reset({
        quantity: 1,
        price: realTimePrice || (asset?.currentPrice || 0),
        useMarketPrice: true,
      });
      
      // Navigate to portfolio
      setTimeout(() => {
        navigate('/portfolio');
      }, 2000);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Trade Failed",
        description: error.message || "An unexpected error occurred. Please try again.",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: TradeFormValues) => {
    submitTrade.mutate({
      ...values,
      tradeType: activeTab,
    });
  };
  
  // Handle manual price entry
  const handlePriceCheckChange = (checked: boolean) => {
    setUseMarketPrice(checked);
    
    if (checked && (realTimePrice || asset?.currentPrice)) {
      form.setValue('price', realTimePrice || asset?.currentPrice || 0);
    }
  };
  
  // Get the current price to display
  const getCurrentPrice = () => {
    return realTimePrice || (asset?.currentPrice || 0);
  };
  
  // Format the price change display
  const formatPriceChange = () => {
    const changeAmount = priceChange || asset?.changePercent || 0;
    const changePercentage = Math.abs(changeAmount).toFixed(2);
    const isPositive = changeAmount >= 0;
    
    return {
      value: `${isPositive ? '+' : '-'}${changePercentage}%`,
      color: isPositive ? 'text-green-600' : 'text-red-600',
      icon: isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />,
    };
  };
  
  const priceChangeDisplay = formatPriceChange();
  
  if (isLoadingAsset) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-24 w-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </CardContent>
          <CardFooter>
            <Skeleton className="h-10 w-full" />
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  if (assetError) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load asset information. Please try again later.
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-4"
            onClick={() => window.location.reload()}
          >
            <RotateCcw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  
  if (!asset) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Not Found</AlertTitle>
        <AlertDescription>
          The requested asset could not be found. Please check the symbol and try again.
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-4"
            onClick={() => navigate('/discover')}
          >
            Back to Discover
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-textDark">{asset.name} ({asset.symbol})</h1>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-lg font-medium">{formatCurrency(getCurrentPrice())}</span>
            <span className={`text-sm flex items-center gap-1 ${priceChangeDisplay.color}`}>
              {priceChangeDisplay.icon} {priceChangeDisplay.value}
            </span>
            {wsStatus === ConnectionStatus.CONNECTED ? (
              <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded-full">
                Live
              </span>
            ) : (
              <span className="text-xs px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full">
                {wsStatus === ConnectionStatus.CONNECTING ? 'Connecting...' : 'Delayed'}
              </span>
            )}
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Price Chart</CardTitle>
              <CardDescription>
                {asset.symbol} {asset.type === 'stock' ? 'Stock' : asset.type} Price History
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <LineChart 
                  symbol={asset.symbol}
                  currentPrice={getCurrentPrice()}
                  previousClose={asset.previousClosePrice}
                />
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Place Order</CardTitle>
              <CardDescription>
                {activeTab === 'buy' ? 'Buy' : 'Sell'} {asset.symbol} at current market price
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'buy' | 'sell')}>
                <TabsList className="w-full mb-4">
                  <TabsTrigger value="buy" className="flex-1">Buy</TabsTrigger>
                  <TabsTrigger value="sell" className="flex-1">Sell</TabsTrigger>
                </TabsList>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Use Market Price</span>
                      <FormField
                        control={form.control}
                        name="useMarketPrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Switch
                                checked={useMarketPrice}
                                onCheckedChange={(checked) => {
                                  field.onChange(checked);
                                  handlePriceCheckChange(checked);
                                }}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quantity</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="any"
                              min="0.0001"
                              placeholder="Enter quantity"
                              {...field}
                              onChange={(e) => {
                                const value = parseFloat(e.target.value) || 0;
                                field.onChange(value);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="any"
                              min="0.0001"
                              placeholder="Enter price"
                              {...field}
                              onChange={(e) => {
                                const value = parseFloat(e.target.value) || 0;
                                field.onChange(value);
                              }}
                              disabled={useMarketPrice}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-2 py-2 border-t border-b">
                      <div className="flex justify-between text-sm">
                        <span>Estimated Total</span>
                        <span className="font-medium">{formatCurrency(calculateTotal())}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Fees</span>
                        <span className="font-medium">{formatCurrency(getEstimatedFees())}</span>
                      </div>
                      <div className="flex justify-between text-sm font-medium">
                        <span>Total {activeTab === 'buy' ? 'Cost' : 'Value'}</span>
                        <span>{formatCurrency(calculateTotal() + getEstimatedFees())}</span>
                      </div>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={submitTrade.isPending}
                      variant={activeTab === 'buy' ? 'default' : 'destructive'}
                    >
                      {submitTrade.isPending ? (
                        <div className="flex items-center">
                          <span className="animate-spin mr-2">
                            <RotateCcw className="h-4 w-4" />
                          </span>
                          Processing
                        </div>
                      ) : (
                        `${activeTab === 'buy' ? 'Buy' : 'Sell'} ${asset.symbol}`
                      )}
                    </Button>
                  </form>
                </Form>
              </Tabs>
            </CardContent>
          </Card>
          
          {/* WebSocket Status Card */}
          <WebSocketStatus 
            url={wsUrl} 
            onReconnect={handleWsReconnect}
            showDebugInfo={true}
          />
        </div>
      </div>
    </div>
  );
} 