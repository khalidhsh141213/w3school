import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { User } from "../shared/schema.js";
import { DatabaseStorage } from "./storage.js";

// Create an instance of the storage class
const storage = new DatabaseStorage();

// Define a type for authenticated user without the passwordHash
type AuthUser = Omit<User, 'password'>;

declare global {
  namespace Express {
    interface User extends AuthUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  // Standardize on 64 bytes (128 hex chars)
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  const hashedPassword = `${buf.toString("hex")}.${salt}`;
  console.log(`Hashed password length: ${hashedPassword.length}`);
  return hashedPassword;
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) {
      console.error("Invalid stored password format, missing hash or salt");
      return false;
    }
    
    // Add detailed logging
    console.log(`Comparing passwords: hash length=${hashed.length}, salt length=${salt.length}`);
    
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    
    if (hashedBuf.length !== suppliedBuf.length) {
      console.error(`Buffer length mismatch: ${hashedBuf.length} vs ${suppliedBuf.length}`);
      return false;
    }
    
    const result = timingSafeEqual(hashedBuf, suppliedBuf);
    console.log(`Password comparison result: ${result ? 'matched' : 'did not match'}`);
    return result;
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'trading-platform-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy({
      usernameField: 'username',
      passwordField: 'password'
    }, async (username, password, done) => {
      try {
        // Try to find the user by username
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          // Remove password from user object before returning
          const { password: _, ...userWithoutPassword } = user;
          return done(null, userWithoutPassword);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => {
    console.log("Serializing user:", user.id);
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log("Deserializing user ID:", id);
      const user = await storage.getUser(id);
      if (!user) {
        console.log("User not found with ID:", id);
        return done(null, false);
      }
      const { password: _, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (error) {
      console.error("Error deserializing user:", error);
      done(error);
    }
  });

  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const { username, email, password, fullName } = req.body;
      
      // Check if the username already exists
      const existingUserByUsername = await storage.getUserByUsername(username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if the email already exists
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create the user with hashed password
      const user = await storage.createUser({
        username,
        email,
        password: await hashPassword(password),
        fullName,
        createdAt: new Date()
      });

      // Create a portfolio with welcome bonus
      const WELCOME_BONUS_AMOUNT = 10000; // $10,000 welcome bonus
      const DEFAULT_BALANCE = 50000; // $50,000 default balance
      const TOTAL_STARTING_AMOUNT = DEFAULT_BALANCE + WELCOME_BONUS_AMOUNT;
      
      // Update user balance with the starting amount
      await storage.updateUserBalance(user.id, TOTAL_STARTING_AMOUNT.toString());
      
      // Transaction recording has been replaced with direct balance update
      // The welcome bonus is now included in the user's starting balance

      // Remove password before sending back to client
      const { password: _, ...userWithoutPassword } = user;

      // Log the user in
      req.login(userWithoutPassword, (err) => {
        if (err) return next(err);
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    console.log("Login attempt:", req.body.username);
    
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        console.error("Authentication error:", err);
        return next(err);
      }
      if (!user) {
        console.error("Authentication failed for user:", req.body.username);
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      console.log("Authentication successful for user:", req.body.username);
      req.login(user, (err) => {
        if (err) {
          console.error("Session login error:", err);
          return next(err);
        }
        console.log("Session established for user:", user.id);
        return res.status(200).json(user);
      });
    })(req, res, next);
  });
  
  // Diagnostic endpoint to check password verification
  app.post("/api/auth/verify-password", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Get user from storage
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "User not found", username });
      }
      
      // Verify password storage format
      const passwordParts = user.password.split('.');
      const diagInfo = {
        username,
        passwordStorageValid: passwordParts.length === 2,
        storedPasswordLength: user.password.length,
        storedHashLength: passwordParts[0]?.length || 0,
        storedSaltLength: passwordParts[1]?.length || 0
      };
      
      // Test password match
      const passwordMatches = await comparePasswords(password, user.password);
      return res.json({
        ...diagInfo,
        passwordMatches
      });
    } catch (error) {
      return res.status(500).json({ message: "Error verifying password", error: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      req.session.destroy((err) => {
        if (err) return next(err);
        res.clearCookie('connect.sid');
        res.status(200).json({ message: "Logged out successfully" });
      });
    });
  });

  app.get("/api/auth/session", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });
}