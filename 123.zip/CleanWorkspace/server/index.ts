import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes.js";
import { setupVite, serveStatic, log } from "./vite.js";
import { errorHandler, ErrorType, ErrorSeverity } from "./services/errorHandlingService.js";
import { startNotificationService } from "./services/notificationService.js";
import { setupAuth } from "./auth.js";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import { marketDataService } from "./services/market-data-service.js";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Setup authentication before registering routes
  setupAuth(app);
  
  // Start economic events scheduler
  try {
    // Use import.meta.url to get the path in ESM
    const dailyUpdateScriptPath = path.join(process.cwd(), 'scripts', 'daily-economic-update.js');
    const eventsUpdateScriptPath = path.join(process.cwd(), 'scripts', 'daily-economic-events-update.js');
    const marketUpdateScriptPath = path.join(process.cwd(), 'scripts', 'market-update.js');
    const polygonIntegrationPath = path.join(process.cwd(), 'scripts', 'run-polygon-integration.js');
    
    // Start economic events update scheduler as a background process
    console.log('[Server] Starting economic events updater...');
    const economicUpdater = spawn('node', [dailyUpdateScriptPath], {
      detached: true,
      stdio: 'ignore'
    });
    
    // Start the enhanced economic events updater (for recurring events)
    console.log('[Server] Starting enhanced economic events updater...');
    const enhancedEconomicUpdater = spawn('node', [eventsUpdateScriptPath], {
      detached: true,
      stdio: 'ignore'
    });
    
    // Start the market data updater
    console.log('[Server] Starting market data updater...');
    const marketUpdater = spawn('node', [marketUpdateScriptPath], {
      detached: true,
      stdio: 'inherit'
    });
    
    // Start specialized Polygon.io integration
    console.log('[Server] Starting Polygon.io WebSocket integration...');
    const polygonIntegration = spawn('node', [polygonIntegrationPath], {
      detached: true,
      stdio: 'inherit'
    });
    
    // Unref to allow the parent process to exit independently
    economicUpdater.unref();
    enhancedEconomicUpdater.unref();
    marketUpdater.unref();
    polygonIntegration.unref();
    
    log('Market data updater started successfully', 'server');
    log('Polygon.io WebSocket integration started', 'server');
    
    console.log('[Server] Economic events updaters started successfully');
    console.log('[Server] Market data services started successfully');
  } catch (error) {
    console.error('[Server] Failed to start background services:', error);
  }
  
  const server = await registerRoutes(app);

  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    
    // Use error handling service for centralized error tracking and monitoring
    errorHandler.logError(
      err,
      status >= 500 ? ErrorType.UNKNOWN : ErrorType.API,
      status >= 500 ? ErrorSeverity.ERROR : ErrorSeverity.WARNING,
      { 
        path: req.path,
        method: req.method,
        ip: req.ip
      }
    );
    
    // Create timestamp for response
    const timestamp = new Date().toISOString();
    
    // Send appropriate error response to client
    res.status(status).json({ 
      message,
      code: `ERROR_${status}`,
      timestamp
    });
    
    // Don't rethrow the error as it was already handled
  });

  // importantly only setup vite in development/test and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development" || app.get("env") === "test") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Changed to port 3000 as requested by the user
  // This serves both the API and the client.
  const port = 3000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, async () => {
    log(`serving on port ${port}`);
    
    // Initialize notification service
    startNotificationService();
    log(`Notification service started`);
    
    // Initialize market data service
    try {
      log(`Starting market data service (singleton implementation)...`);
      await marketDataService.initialize();
      log(`Market data service started successfully`);
    } catch (error) {
      console.error(`Failed to start market data service: ${error.message}`);
    }
    
    // Run initial sync for economic events only (scheduler already started above)
    try {
      const initialSyncScript = path.join(process.cwd(), 'scripts', 'enhanced-economic-events.js');
      log(`Running initial economic events sync...`);
      
      // Legacy code kept for compatibility
      try {
        const marketUpdateScript = path.join(process.cwd(), 'scripts', 'polygon-market-data-fixed.js');
        log(`Starting legacy market data service...`);
        
        // Commented out to avoid running duplicate market data services
        // spawn('node', [marketUpdateScript], {
        //   detached: true,
        //   stdio: 'inherit'
        // });
        
        log(`Legacy market data service disabled - using singleton service instead`);
      } catch (error) {
        console.error('Failed to start legacy market data service:', error);
      }
      
      spawn('node', [initialSyncScript], {
        detached: true,
        stdio: 'inherit'
      }).unref();
    } catch (error) {
      log(`Failed to run initial economic events sync: ${error.message}`);
    }
    
    // Start Polygon.io market data integration with fixed connection handling
    // Note: We ensure only one instance of this runs by using a dedicated script
    try {
      const polygonIntegrationScript = path.join(process.cwd(), 'scripts', 'run-polygon-integration.js');
      log(`Starting Polygon.io market data integration service...`);
      
      // Before starting a new instance, check if one is already running
      const checkProcess = spawn('ps', ['-ef']);
      let processData = '';
      
      checkProcess.stdout.on('data', (data) => {
        processData += data.toString();
      });
      
      checkProcess.on('close', (code) => {
        if (code === 0) {
          // Check if the integration script is already running
          if (processData.includes('run-polygon-integration.js') && 
              !processData.includes('<defunct>')) {
            log(`Polygon.io market data integration service is already running`);
          } else {
            // Start a new instance if not already running
            spawn('node', [polygonIntegrationScript], {
              detached: true,
              stdio: 'inherit'
            }).unref();
            
            log(`Polygon.io market data integration service started`);
          }
        }
      });
    } catch (error) {
      log(`Failed to start Polygon.io market data integration: ${error.message}`);
    }
  });
})();
