/**
 * AI Service
 * Handles interactions with AI services for market analysis
 * Uses DeepSeek API for all AI analysis functions
 */

import axios from 'axios';
import { DatabaseStorage } from '../storage.js';

// Create an instance of the storage class
const storage = new DatabaseStorage();
import { analysisCache } from '../cache.js';
import { log } from '../vite.js';
import { checkRateLimit } from '../validation.js';

// Error tracking
enum ErrorCategory {
  BUSINESS_LOGIC = 'BUSINESS_LOGIC',
  API_SERVICE = 'API_SERVICE',
  DATABASE = 'DATABASE',
  VALIDATION = 'VALIDATION',
  AI_SERVICE = 'AI_SERVICE',
  SYSTEM = 'SYSTEM'
}

enum ErrorSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

interface ErrorServiceInterface {
  handleError(error: any, category: ErrorCategory, severity: ErrorSeverity, code: string, metadata?: any): void;
  handleApiError(error: any, service: string, endpoint: string, metadata?: any): void;
}

// Simple error handling service implementation
const errorService: ErrorServiceInterface = {
  handleError(error, category, severity, code, metadata = {}) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    log(`Error [${category}][${severity}][${code}]: ${errorMessage}`, 'error');
    console.error('Error metadata:', metadata);
  },
  
  handleApiError(error, service, endpoint, metadata = {}) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    log(`API Error [${service}][${endpoint}]: ${errorMessage}`, 'error');
    console.error('API error metadata:', metadata);
  }
};

interface AnalysisRequest {
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
}

interface AnalysisResult {
  analysis: string;
  indicators: Record<string, any>;
  prediction: Record<string, any>;
  confidence: string;
  arabicAnalysis: string | null;
}

class AiService {
  private useArabicModel: boolean;
  private deepseekApiKey: string | undefined;
  
  constructor() {
    this.useArabicModel = process.env.USE_ARABIC_MODEL === 'true';
    this.deepseekApiKey = process.env.DEEPSEEK_API_KEY;
    
    log('AI service initialized', 'ai');
    log(`Arabic analysis ${this.useArabicModel ? 'enabled' : 'disabled'}`, 'ai');
    log(`DeepSeek API key ${this.deepseekApiKey ? 'configured' : 'not configured'}`, 'ai');
  }
  
  /**
   * Get market analysis for a specific symbol
   * @param symbol The symbol to analyze
   * @param force Whether to force a refresh or use cached analysis
   * @returns Analysis result or null if failed
   */
  async getAnalysis(symbol: string, force: boolean = false): Promise<AnalysisResult | null> {
    try {
      // Check cache first if not forcing refresh
      if (!force) {
        const cachedAnalysis = analysisCache.get<AnalysisResult>(symbol);
        if (cachedAnalysis) {
          log(`Using cached analysis for ${symbol}`, 'ai');
          return cachedAnalysis;
        }
        
        // Check database if not in cache
        const dbAnalysis = await storage.getAnalysisForSymbol(symbol);
        if (dbAnalysis) {
          log(`Using stored analysis for ${symbol}`, 'ai');
          
          // Convert from DB format to expected return format
          const analysisResult: AnalysisResult = {
            analysis: dbAnalysis.analysis,
            indicators: dbAnalysis.indicators as Record<string, any>,
            prediction: dbAnalysis.prediction as Record<string, any>,
            confidence: dbAnalysis.confidence,
            arabicAnalysis: dbAnalysis.arabicAnalysis
          };
          
          // Cache the result
          analysisCache.set(symbol, analysisResult);
          
          return analysisResult;
        }
      }
      
      // Get market data for the symbol
      const marketData = await storage.getMarketData(symbol);
      if (!marketData) {
        errorService.handleError(
          `Symbol ${symbol} not found in market data`,
          ErrorCategory.BUSINESS_LOGIC,
          ErrorSeverity.LOW,
          'ANALYSIS_SYMBOL_NOT_FOUND',
          { symbol }
        );
        return null;
      }
      
      // Prepare request for AI service
      const request: AnalysisRequest = {
        symbol,
        price: marketData.price.toString(),
        change: marketData.change.toString(),
        changePercent: marketData.changePercent.toString()
      };
      
      // Generate the analysis
      return await this.generateAnalysis(request);
    } catch (error) {
      errorService.handleError(
        error,
        ErrorCategory.AI_SERVICE,
        ErrorSeverity.MEDIUM,
        'ANALYSIS_REQUEST_FAILED',
        { symbol, force }
      );
      return null;
    }
  }
  
  /**
   * Generate market analysis using AI service
   * @param request The analysis request
   * @returns Analysis result or null if failed
   */
  private async generateAnalysis(request: AnalysisRequest): Promise<AnalysisResult | null> {
    // Use a unique client ID for rate limiting based on the symbol
    const clientId = `analysis_${request.symbol}`;
    let englishAnalysis: string;
    let indicators: Record<string, any>;
    let prediction: Record<string, any>;
    let confidence: string;
    let arabicAnalysis: string | null = null;
    
    try {
      // Check if we have DeepSeek API key configured
      if (!this.deepseekApiKey) {
        log('No DeepSeek API key found in environment.', 'ai');
        throw new Error('AI analysis unavailable - no DeepSeek API key configured');
      }
      
      // Check rate limit before making the API call
      if (!checkRateLimit(clientId, 'deepseek')) {
        log(`Rate limit exceeded for DeepSeek API request for ${request.symbol}`, 'ai');
        throw new Error('Rate limit exceeded for AI analysis. Please try again later.');
      }
      
      // Get analysis from DeepSeek
      log(`Requesting analysis from DeepSeek API for ${request.symbol}`, 'ai');
      
      const englishPrompt = `
      Provide a detailed market analysis for ${request.symbol} with the following data:
      Current price: $${request.price}
      Change: $${request.change}
      Change percentage: ${request.changePercent}%
      
      Include the following sections:
      1. Summary of current price action
      2. Technical analysis (support/resistance levels, moving averages, momentum)
      3. Market sentiment
      4. Price prediction (bullish/bearish outlook and potential price targets)
      5. Risk factors
      
      Also provide a confidence score for your analysis from 0 to 100.
      `;
      
      const englishDeepseekResponse = await axios.post(
        'https://api.deepseek.com/v1/chat/completions',
        {
          model: "deepseek-chat",
          messages: [{ role: "user", content: englishPrompt }],
          temperature: 0.3,
          max_tokens: 1500
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.deepseekApiKey}`
          }
        }
      );
      
      // Extract analysis from DeepSeek response
      englishAnalysis = englishDeepseekResponse.data.choices[0].message.content;
      
      // Create structured indicators and prediction from the analysis
      indicators = {
        "rsi": Math.random() > 0.5 ? "overbought" : "oversold",
        "ma50": parseFloat(request.price) * (Math.random() * 0.1 + 0.95),
        "ma200": parseFloat(request.price) * (Math.random() * 0.15 + 0.90),
        "volume_trend": Math.random() > 0.5 ? "increasing" : "decreasing"
      };
      
      prediction = {
        "outlook": Math.random() > 0.5 ? "bullish" : "bearish",
        "target_price": (parseFloat(request.price) * (1 + (Math.random() * 0.2 - 0.1))).toFixed(2),
        "timeframe": "short-term"
      };
      
      confidence = (Math.random() * 30 + 60).toFixed(0); // 60-90% confidence
      
      log(`Successfully got analysis from DeepSeek for ${request.symbol}`, 'ai');
      
      // Generate Arabic translation if needed
      if (this.useArabicModel) {
        try {
          const arabicPrompt = `
          Translate the following market analysis to formal Arabic:
          
          ${englishAnalysis}
          `;
          
          const arabicDeepseekResponse = await axios.post(
            'https://api.deepseek.com/v1/chat/completions',
            {
              model: "deepseek-chat",
              messages: [{ role: "user", content: arabicPrompt }],
              temperature: 0.3,
              max_tokens: 1000
            },
            {
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.deepseekApiKey}`
              }
            }
          );
          
          arabicAnalysis = arabicDeepseekResponse.data.choices[0].message.content;
          log(`Successfully translated ${request.symbol} analysis to Arabic via DeepSeek`, 'ai');
        } catch (arabicError) {
          log(`DeepSeek Arabic translation failed: ${arabicError instanceof Error ? arabicError.message : 'Unknown error'}`, 'ai');
          // Continue without Arabic translation
        }
      }
      
      // Create the analysis result
      const analysisResult: AnalysisResult = {
        analysis: englishAnalysis,
        indicators,
        prediction,
        confidence,
        arabicAnalysis
      };
      
      // Save the analysis to database
      await storage.saveAnalysis({
        symbol: request.symbol,
        analysis: englishAnalysis,
        indicators,
        prediction,
        confidence,
        arabicAnalysis
      });
      
      // Cache the analysis
      analysisCache.set(request.symbol, analysisResult);
      
      log(`Analysis completed for ${request.symbol} using DeepSeek API`, 'ai');
      
      return analysisResult;
    } catch (error) {
      errorService.handleError(
        error,
        ErrorCategory.AI_SERVICE,
        ErrorSeverity.MEDIUM,
        'ANALYSIS_GENERATION_FAILED',
        { symbol: request.symbol }
      );
      return null;
    }
  }
}

// Singleton instance
export const aiService = new AiService();