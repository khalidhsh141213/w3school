"use client";

import { 
  DollarSign, 
  Wallet, 
  TrendingUp, 
  ArrowUpRight,
  Loader2,
  Shield,
  ExternalLink,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { usePortfolioData } from "@/hooks/use-portfolio-data";
import { useEffect, useState, useRef } from "react";
import WebSocketManagerSingleton, { ConnectionStatus } from '@/services/WebSocketManagerSingleton';

type AccountSummaryProps = {
  user: any;
};

export default function AccountSummary({ user }: AccountSummaryProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [wsStatus, setWsStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  
  // Use the shared portfolio data hook
  const { portfolio: portfolioData, isLoading, refetch, isFetching } = usePortfolioData(user?.id);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    // Don't setup WebSocket if no user is provided
    if (!user?.id) return;
    
    // Use dynamic WebSocket URL based on current window location
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws`;
    
    console.log('[AccountSummary] Setting up WebSocket connection to:', wsUrl);
    
    try {
      // Use the WebSocketManagerSingleton
      const manager = WebSocketManagerSingleton.getInstance();
      
      // Handle WebSocket messages for portfolio updates
      const handleMessage = (data: any) => {
        if (data.type === 'portfolioUpdate' && data.userId === user?.id) {
          console.log('[AccountSummary] Received portfolio update, refetching data');
          refetch();
        }
      };
      
      // Subscribe to portfolio updates
      manager.subscribe(wsUrl, handleMessage);
      
      // Update connection status
      const statusHandler = (status: ConnectionStatus) => {
        setWsStatus(status);
      };
      
      // Subscribe to status updates
      manager.onStatusChange(statusHandler);
      
      // Connect if not already connected
      if (!manager.isConnected()) {
        manager.connect(wsUrl);
      }
      
      // Cleanup on unmount
      return () => {
        manager.unsubscribe(wsUrl, handleMessage);
        manager.offStatusChange(statusHandler);
      };
    } catch (error) {
      console.error('[AccountSummary] WebSocket setup error:', error);
    }
  }, [user?.id, refetch]);
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0, // No decimal places for compact display
    }).format(value);
  };
  
  // Handle manual refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };
  
  if (isLoading) {
    return (
      <div className="flex h-20 w-full items-center justify-center bg-gradient-to-r from-gray-900/95 to-gray-800/95 backdrop-blur-sm border border-gray-700/50 rounded-lg px-6 py-4 shadow-lg">
        <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
        <span className="text-sm">Loading account data...</span>
      </div>
    );
  }
  
  // Use real data from portfolio query, or default values if not available
  const accountBalance = portfolioData?.totalValue || 0;
  const equity = portfolioData?.totalValue || 0;
  const unrealizedPnL = portfolioData?.unrealizedPL || 0;
  const availableMargin = portfolioData?.availableBalance || 0;
  
  return (
    <div className="flex h-20 w-full items-center justify-between bg-gradient-to-r from-gray-900/95 to-gray-800/95 backdrop-blur-sm border border-gray-700/50 rounded-lg px-6 py-4 shadow-lg animate-fadeIn">
      <div className="flex items-center space-x-10">
        {/* Balance */}
        <div className="flex items-center group cursor-default hover:scale-[1.03] transition-all duration-300">
          <div className="w-10 h-10 rounded-full bg-[#00C06D]/20 flex items-center justify-center text-[#00C06D] mr-3 shadow group-hover:shadow-[#00C06D]/20 transition-all duration-300">
            <Wallet className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none mb-1">Balance</div>
            <div className="font-bold text-base leading-tight group-hover:text-[#00C06D] transition-colors">{formatCurrency(accountBalance)}</div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-12" />
        
        {/* Equity */}
        <div className="flex items-center group cursor-default hover:scale-[1.03] transition-all duration-300">
          <div className="w-10 h-10 rounded-full bg-[#2A5CFF]/20 flex items-center justify-center text-[#2A5CFF] mr-3 shadow group-hover:shadow-[#2A5CFF]/20 transition-all duration-300">
            <DollarSign className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none mb-1">Equity</div>
            <div className="font-bold text-base leading-tight group-hover:text-[#2A5CFF] transition-colors">{formatCurrency(equity)}</div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-12" />
        
        {/* P/L */}
        <div className="flex items-center group cursor-default hover:scale-[1.03] transition-all duration-300">
          <div className={`w-10 h-10 rounded-full ${unrealizedPnL >= 0 ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'} flex items-center justify-center mr-3 shadow group-hover:shadow-md transition-all duration-300`}>
            <TrendingUp className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none mb-1">P/L</div>
            <div className={`font-bold text-base leading-tight ${unrealizedPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {formatCurrency(unrealizedPnL)}
            </div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-12" />
        
        {/* Margin */}
        <div className="flex items-center group cursor-default hover:scale-[1.03] transition-all duration-300">
          <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-500 mr-3 shadow group-hover:shadow-purple-500/20 transition-all duration-300">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none mb-1">Margin</div>
            <div className="font-bold text-base leading-tight group-hover:text-purple-500 transition-colors">{formatCurrency(availableMargin)}</div>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        {/* Refresh button */}
        <Button
          size="icon"
          variant="ghost"
          onClick={handleRefresh}
          disabled={isRefreshing || isFetching}
          className="h-10 w-10 transition-all duration-300 hover:bg-gray-700/30"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing || isFetching ? 'animate-spin' : ''}`} />
        </Button>
        
        {/* Deposit button */}
        <div className="transition-transform hover:scale-105 active:scale-95 duration-300">
          <Button 
            size="default" 
            variant="outline"
            className="h-10 px-5 text-sm bg-gradient-to-r from-[#00C06D] to-[#2A5CFF] hover:from-[#00A055] hover:to-[#2240B0] text-white border-none shadow-lg transition-all duration-300" 
            asChild
          >
            <Link to="/wallet">
              Deposit
              <ExternalLink className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}