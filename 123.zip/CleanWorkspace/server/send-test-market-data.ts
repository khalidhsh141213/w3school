/**
 * هذا الملف يُستخدم لإرسال بيانات السوق الاختبارية عبر WebSocket
 * لاختبار وظائف WebSocket وضمان عمل الاتصالات بشكل صحيح
 * مع مراعاة حالة السوق (مفتوح أم مغلق)
 */
import { WebSocketServer } from 'ws';
import { db } from './db.js';
import { assets } from '../shared/schema.js';
import { eq, or } from 'drizzle-orm';
import { 
  MarketType, 
  MarketStatus, 
  getMarketTypeForAsset, 
  getMarketStatus, 
  isMarketOpen 
} from './services/marketStatusService.js';

// تعليق: تم إزالة قائمة الأصول المالية للاختبار بناءً على طلب المستخدم لتجنب إعادة إنشائها
// const testSymbols = ['TEST_BTC', 'TEST_ETH', 'TEST_AAPL', 'TEST_MSFT', 'TEST_AMZN', 'TEST_TSLA'];

// تكوين أنماط تغيير السعر
const PRICE_PATTERNS = {
  RANDOM: 'random',          // تغيير عشوائي
  UPTREND: 'uptrend',        // اتجاه صعودي
  DOWNTREND: 'downtrend',    // اتجاه هبوطي
  VOLATILE: 'volatile',      // تقلبات كبيرة
  STABLE: 'stable'           // مستقر نسبياً
};

/**
 * توليد تغير سعر عشوائي بناءً على نمط معين
 * @param basePrice السعر الأساسي
 * @param pattern نمط تغير السعر
 * @returns السعر الجديد
 */
function generatePriceChange(basePrice: number, pattern = PRICE_PATTERNS.RANDOM): number {
  const price = parseFloat(basePrice.toString());
  
  switch (pattern) {
    case PRICE_PATTERNS.UPTREND:
      // اتجاه صعودي: تغير إيجابي غالباً (+0.05% إلى +0.5%)
      return price * (1 + (Math.random() * 0.005 + 0.0005));
      
    case PRICE_PATTERNS.DOWNTREND:
      // اتجاه هبوطي: تغير سلبي غالباً (-0.05% إلى -0.5%)
      return price * (1 - (Math.random() * 0.005 + 0.0005));
      
    case PRICE_PATTERNS.VOLATILE:
      // متقلب: تغير كبير في أي من الاتجاهين (-1% إلى +1%)
      return price * (1 + (Math.random() * 0.02 - 0.01));
      
    case PRICE_PATTERNS.STABLE:
      // مستقر: تغير طفيف جداً (-0.02% إلى +0.02%)
      return price * (1 + (Math.random() * 0.0004 - 0.0002));
      
    case PRICE_PATTERNS.RANDOM:
    default:
      // عشوائي: تغير في أي من الاتجاهين (-0.2% إلى +0.2%)
      return price * (1 + (Math.random() * 0.004 - 0.002));
  }
}

/**
 * إرسال بيانات السوق الاختبارية عبر WebSocket
 * @param wss خادم WebSocket
 */
export async function sendTestMarketData(wss: WebSocketServer) {
  try {
    // تم تعطيل إرسال بيانات السوق التجريبية بناءً على طلب المستخدم
    console.log('[websocket-test] Test market data sending has been disabled by user request');
    
    // إرسال حالة الأسواق الحقيقية
    const realAssets = await db.select()
      .from(assets)
      .where(
        or(
          eq(assets.type, 'stock'),
          eq(assets.type, 'crypto')
        )
      );
    
    if (realAssets.length === 0) {
      console.error('[websocket-test] No real assets found in database');
      return;
    }
    
    console.log(`[websocket-test] Sending real market status to ${wss.clients.size} connected clients`);
    
    // إرسال حالة السوق للأصول الحقيقية
    realAssets.forEach(asset => {
      // تحديد نوع الأصل (stock/crypto)
      const assetType = asset.type;
      
      // التحقق من حالة السوق
      const marketOpen = isMarketOpen(assetType);
      
      // الحصول على حالة السوق
      const marketType = getMarketTypeForAsset(assetType);
      const marketStatus = getMarketStatus(marketType);
      
      // إنشاء بيانات التحديث مع معلومات حالة السوق فقط (بدون تغيير الأسعار)
      const updateData = {
        type: 'market_status_update',
        symbol: asset.symbol,
        assetType: assetType,
        marketStatus: marketStatus,
        isMarketOpen: marketOpen,
        timestamp: Date.now()
      };
      
      // إرسال تحديث إلى العملاء المتصلين
      wss.clients.forEach(client => {
        if (client.readyState === 1) { // WebSocket.OPEN
          try {
            client.send(JSON.stringify(updateData));
          } catch (error) {
            console.error('[websocket-test] Error sending market status to client:', error);
          }
        }
      });
    });
    
  } catch (error) {
    console.error('[websocket-test] Error sending market status data:', error);
  }
}

/**
 * وظيفة لبدء اختبار WebSocket عبر إرسال بيانات اختبارية دورياً
 * @param wss خادم WebSocket المراد اختباره
 */
export async function startWebSocketTest(wss: WebSocketServer) {
  console.log('[websocket-test] Starting WebSocket test...');
  
  // إرسال بيانات اختبار على الفور
  await sendTestMarketData(wss);
  
  // إرسال بيانات اختبار كل 10 ثوانٍ
  const intervalId = setInterval(async () => {
    await sendTestMarketData(wss);
  }, 10000);
  
  // إرجاع معرف الفاصل الزمني ليتم استخدامه في إيقاف الاختبار إذا لزم الأمر
  return intervalId;
}