#!/usr/bin/env node

/**
 * WebSocket Usage Identification Script
 *
 * This script scans the codebase for components that use WebSockets
 * and may need to be updated to use the centralized WebSocket manager.
 */

const fs = require('fs');
const path = require('path');
const glob = require('glob');

// Configuration
const sourceDir = path.resolve(__dirname, '../src');
const componentsGlob = `${sourceDir}/**/*.{tsx,ts,jsx,js}`;

// Parse command line arguments
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');

// Patterns to look for
const websocketPatterns = [
  'new WebSocket',
  'WebSocket(',
  'useWebSocket',
  'createWebSocket',
  'socket.send',
  'socket.close',
  'socket.onmessage',
  'socket.onopen',
  'socket.onclose',
  'socket.onerror',
  'addEventListener("message"',
  'addEventListener(\'message\'',
  'addEventListener("open"',
  'addEventListener(\'open\'',
  'addEventListener("close"',
  'addEventListener(\'close\'',
  'addEventListener("error"',
  'addEventListener(\'error\'',
];

// Check if a file contains WebSocket usage
function containsWebSocketUsage(content) {
  return websocketPatterns.some(pattern => content.includes(pattern));
}

// Check if a file already uses the WebSocket manager
function usesWebSocketManager(content) {
  return content.includes('WebSocketManager') || 
         content.includes('wsManager') || 
         content.includes('useWebSocketManager');
}

// Main function
async function main() {
  try {
    // Find all component files
    const files = glob.sync(componentsGlob);
    console.log(`Scanning ${files.length} files for WebSocket usage...`);
    
    const needsUpdateList = [];
    const alreadyUpdatedList = [];
    
    for (const file of files) {
      // Skip files in the node_modules directory
      if (file.includes('node_modules') || file.includes('lib/websocket')) {
        continue;
      }
      
      const content = fs.readFileSync(file, 'utf8');
      
      if (containsWebSocketUsage(content)) {
        const isAlreadyUpdated = usesWebSocketManager(content);
        
        if (isAlreadyUpdated) {
          alreadyUpdatedList.push(file);
        } else {
          needsUpdateList.push(file);
        }
      }
    }
    
    // Print results
    console.log('\n=== WebSocket Usage Report ===\n');
    
    console.log(`Found ${needsUpdateList.length + alreadyUpdatedList.length} files with WebSocket usage.`);
    console.log(`- ${needsUpdateList.length} files need to be updated to use the WebSocket manager`);
    console.log(`- ${alreadyUpdatedList.length} files already use the WebSocket manager\n`);
    
    if (needsUpdateList.length > 0) {
      console.log('Files that need to be updated:');
      needsUpdateList.forEach(file => {
        const relativePath = path.relative(process.cwd(), file);
        console.log(`- ${relativePath}`);
      });
      console.log();
    }
    
    if (alreadyUpdatedList.length > 0) {
      console.log('Files already using the WebSocket manager:');
      alreadyUpdatedList.forEach(file => {
        const relativePath = path.relative(process.cwd(), file);
        console.log(`- ${relativePath}`);
      });
      console.log();
    }
    
    // Output actionable items
    if (needsUpdateList.length > 0) {
      console.log('Next steps:');
      console.log('1. Update the components above to use the WebSocketManager from lib/websocket/WebSocketManager.ts');
      console.log('2. Refer to the WEBSOCKET_USAGE.md guide for implementation details');
      console.log('3. Check the examples in src/components/examples for patterns to follow');
    } else {
      console.log('✅ All WebSocket usage in the codebase is using the centralized WebSocketManager!');
    }
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Run the script
main(); 