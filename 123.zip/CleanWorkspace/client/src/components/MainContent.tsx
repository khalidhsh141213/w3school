import { useContext } from 'react';
import { AppContext } from '../context/AppContext';
import MarketOverview from './MarketOverview';
import MarketSentiment from './MarketSentiment';
import Watchlist from './Watchlist';
import ChartComponent from './ChartComponent';
import AiAnalysis from './AiAnalysis';
import NewsComponent from './NewsComponent';
import TradingComponent from './TradingComponent';
import PortfolioSummary from './PortfolioSummary';
import AiRecommendations from './AiRecommendations';

interface MainContentProps {
  marketData: Record<string, any>;
}

const MainContent = ({ marketData }: MainContentProps) => {
  const { appState } = useContext(AppContext);

  return (
    <main className="flex-1 container mx-auto p-4">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Sidebar */}
        <div className="lg:col-span-3 space-y-4">
          <MarketOverview marketData={marketData} />
          <MarketSentiment />
          <Watchlist marketData={marketData} />
        </div>

        {/* Main Content */}
        <div className="lg:col-span-6 space-y-4">
          <ChartComponent 
            symbol={appState.selectedSymbol} 
            marketData={marketData[appState.selectedSymbol]} 
          />
          <AiAnalysis symbol={appState.selectedSymbol} />
          <NewsComponent symbol={appState.selectedSymbol} />
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-3 space-y-4">
          <TradingComponent 
            symbol={appState.selectedSymbol} 
            marketData={marketData[appState.selectedSymbol]} 
          />
          <PortfolioSummary marketData={marketData} />
          <AiRecommendations />
        </div>
      </div>
    </main>
  );
};

export default MainContent;
