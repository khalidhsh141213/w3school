import { useState, useEffect } from 'react';
import { useTranslation } from '../lib/useTranslation';
import { useQuery } from '@tanstack/react-query';

interface Recommendation {
  symbol: string;
  name: string;
  action: 'Buy' | 'Sell' | 'Hold';
  reason: string;
}

const AiRecommendations = () => {
  const { t } = useTranslation();

  // Fetch recommendations from the API
  const { data: recommendations, isLoading } = useQuery({
    queryKey: ['/api/recommendations'],
    queryFn: async () => {
      // In a real app, this would call an actual API
      // For now, we'll return mock data
      return [
        {
          symbol: 'NVDA',
          name: 'NVIDIA Corporation',
          action: 'Buy',
          reason: 'Strong growth potential in AI sector'
        },
        {
          symbol: 'JPM',
          name: 'JPMorgan Chase & Co.',
          action: 'Hold',
          reason: 'Stable performance amid rising rates'
        },
        {
          symbol: 'NKE',
          name: 'Nike, Inc.',
          action: 'Sell',
          reason: 'Facing increased competition and margin pressure'
        }
      ] as Recommendation[];
    },
    retry: false,
    staleTime: 300000 // 5 minutes
  });

  // Get the appropriate color and text based on the recommendation action
  const getActionStyles = (action: string) => {
    switch (action) {
      case 'Buy':
        return {
          bgColor: 'bg-secondary',
          text: t('buy')
        };
      case 'Sell':
        return {
          bgColor: 'bg-accent',
          text: t('sell')
        };
      case 'Hold':
        return {
          bgColor: 'bg-neutral',
          text: t('hold')
        };
      default:
        return {
          bgColor: 'bg-primary',
          text: action
        };
    }
  };

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <h2 className="text-lg font-condensed font-bold mb-3">
        {t('aiRecommendations')}
      </h2>
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-2 text-neutral">Loading recommendations...</div>
        ) : recommendations && recommendations.length > 0 ? (
          recommendations.map((rec, index) => {
            const actionStyle = getActionStyles(rec.action);
            
            return (
              <div 
                className="p-3 border rounded-lg bg-neutral-50 dark:bg-neutral-dark" 
                key={`${rec.symbol}-${index}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-semibold">{rec.symbol}</div>
                    <div className="text-xs text-neutral">{rec.name}</div>
                  </div>
                  <div className={`${actionStyle.bgColor} text-white text-xs py-1 px-2 rounded`}>
                    {actionStyle.text}
                  </div>
                </div>
                <div className="mt-2 text-sm">
                  {rec.reason}
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-2 text-neutral">No recommendations available</div>
        )}
      </div>
    </div>
  );
};

export default AiRecommendations;
