"use client";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Trade } from "@shared/schema";
import { 
  Download, 
  Filter, 
  Search, 
  ArrowDownUp, 
  Calendar, 
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format } from "date-fns";

type TradeHistoryProps = {
  userId: string | undefined;
};

type SortField = "date" | "symbol" | "type" | "price" | "quantity" | "status";
type SortDirection = "asc" | "desc";
type Filter = "buy" | "sell" | "open" | "closed" | "all";

export default function TradeHistory({ userId }: TradeHistoryProps) {
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<SortField>("date");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [dateFilter, setDateFilter] = useState<Date | null>(null);
  const [statusFilter, setStatusFilter] = useState<Filter>("all");
  
  // Fetch user trade history
  const { 
    data: trades,
    isLoading,
    error
  } = useQuery<Trade[]>({
    queryKey: [`/api/trades/user/${userId}`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!userId,
  });
  
  // No need to fetch assets separately or prepare a symbol lookup table
  // since we now have the symbol directly on each trade record
  
  // Filter and sort trades
  const filteredAndSortedTrades = () => {
    if (!trades) return [];
    
    let filtered = [...trades];
    
    // Filter by search term
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(trade => 
        trade.assetId.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (statusFilter !== "all") {
      if (statusFilter === "buy" || statusFilter === "sell") {
        filtered = filtered.filter(trade => trade.tradeType === statusFilter);
      } else {
        filtered = filtered.filter(trade => trade.status === statusFilter);
      }
    }
    
    // Apply date filter
    if (dateFilter) {
      const filterDate = new Date(dateFilter);
      filtered = filtered.filter(trade => {
        const tradeDate = new Date(trade.openedAt || new Date());
        return (
          tradeDate.getDate() === filterDate.getDate() &&
          tradeDate.getMonth() === filterDate.getMonth() &&
          tradeDate.getFullYear() === filterDate.getFullYear()
        );
      });
    }
    
    // Sort trades
    return filtered.sort((a, b) => {
      let compareResult = 0;
      
      switch (sortField) {
        case "date":
          const aDate = a.openedAt ? new Date(a.openedAt).getTime() : 0;
          const bDate = b.openedAt ? new Date(b.openedAt).getTime() : 0;
          compareResult = aDate - bDate;
          break;
        case "symbol":
          compareResult = a.assetId.localeCompare(b.assetId);
          break;
        case "type":
          compareResult = a.tradeType.localeCompare(b.tradeType);
          break;
        case "price":
          compareResult = a.entryPrice - b.entryPrice;
          break;
        case "quantity":
          compareResult = a.quantity - b.quantity;
          break;
        case "status":
          compareResult = a.status.localeCompare(b.status);
          break;
      }
      
      return sortDirection === "asc" ? compareResult : -compareResult;
    });
  };
  
  // Download trade history as CSV
  const downloadCSV = () => {
    if (!trades || trades.length === 0) return;
    
    const headers = ["Date", "Symbol", "Type", "Entry Price", "Exit Price", "Quantity", "Status", "P/L"];
    
    const rows = trades.map(trade => {
      const tradeDate = new Date(trade.openedAt || new Date()).toLocaleString();
      const symbol = trade.assetSymbol || trade.assetId;
      const entryPrice = trade.entryPrice;
      const exitPrice = trade.exitPrice || entryPrice;
      
      // Calculate P/L
      let pnl = 0;
      if (trade.tradeType === "buy") {
        pnl = (exitPrice - entryPrice) * trade.quantity * (trade.leverage || 1);
      } else {
        pnl = (entryPrice - exitPrice) * trade.quantity * (trade.leverage || 1);
      }
      
      return [
        tradeDate,
        symbol,
        trade.tradeType,
        entryPrice.toString(),
        exitPrice.toString(),
        trade.quantity.toString(),
        trade.status,
        pnl.toFixed(2)
      ];
    });
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    
    link.setAttribute("href", url);
    link.setAttribute("download", `trade_history_${format(new Date(), "yyyy-MM-dd")}.csv`);
    link.style.display = "none";
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };
  
  // Toggle sort direction
  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };
  
  // Reset all filters
  const resetFilters = () => {
    setSearch("");
    setDateFilter(null);
    setStatusFilter("all");
    setSortField("date");
    setSortDirection("desc");
  };
  
  const sortedTrades = filteredAndSortedTrades();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-4 text-center text-red-500">
        Error loading trade history
      </div>
    );
  }
  
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Trade History</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={downloadCSV}
          disabled={!trades || trades.length === 0}
        >
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by symbol..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
        
        <div className="flex gap-2 flex-wrap md:flex-nowrap">
          <Select 
            value={statusFilter} 
            onValueChange={(value) => setStatusFilter(value as Filter)}
          >
            <SelectTrigger className="w-[100px] md:w-28">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="buy">Buy</SelectItem>
              <SelectItem value="sell">Sell</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button 
                variant="outline" 
                size="icon"
                className={dateFilter ? "border-primary" : ""}
              >
                <Calendar className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <CalendarComponent
                mode="single"
                selected={dateFilter}
                onSelect={setDateFilter}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={resetFilters}
            className="text-xs md:text-sm"
          >
            Reset
          </Button>
        </div>
      </div>
      
      {/* Table Header */}
      <div className="hidden md:grid grid-cols-5 gap-4 p-2 bg-muted/50 rounded-t-md text-sm font-medium">
        <button 
          className="flex items-center justify-start"
          onClick={() => toggleSort("date")}
        >
          Date
          <ArrowDownUp className="h-3 w-3 ml-1" />
        </button>
        <button 
          className="flex items-center justify-start"
          onClick={() => toggleSort("symbol")}
        >
          Symbol
          <ArrowDownUp className="h-3 w-3 ml-1" />
        </button>
        <button 
          className="flex items-center justify-start"
          onClick={() => toggleSort("type")}
        >
          Type
          <ArrowDownUp className="h-3 w-3 ml-1" />
        </button>
        <button 
          className="flex items-center justify-end"
          onClick={() => toggleSort("price")}
        >
          Price
          <ArrowDownUp className="h-3 w-3 ml-1" />
        </button>
        <button 
          className="flex items-center justify-end"
          onClick={() => toggleSort("quantity")}
        >
          Qty
          <ArrowDownUp className="h-3 w-3 ml-1" />
        </button>
      </div>
      
      {/* Trade list */}
      <div className="border rounded-md overflow-hidden">
        {sortedTrades.length > 0 ? (
          <div className="divide-y">
            {sortedTrades.map((trade) => {
              // Safely handle missing properties and use appropriate properties from schema
              const tradeDate = trade.openedAt || new Date();
              // Use assetId to identify asset since schema doesn't have assetSymbol
              const assetId = trade.assetId || 'Unknown';
              const entryPrice = trade.entryPrice || 0;
              
              return (
                <div key={trade.id} className="p-3 hover:bg-muted/50 transition-colors">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2 md:gap-4">
                    <div className="flex flex-col">
                      <span className="font-medium md:hidden text-xs">Date</span>
                      <span className="text-sm">
                        {format(new Date(tradeDate), "MMM dd, yyyy")}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(tradeDate), "hh:mm a")}
                      </span>
                    </div>
                    
                    <div className="flex flex-col">
                      <span className="font-medium md:hidden text-xs">Symbol</span>
                      <span className="text-sm">
                        {trade.assetSymbol || "Unknown"}
                      </span>
                    </div>
                    
                    <div className="flex flex-col">
                      <span className="font-medium md:hidden text-xs">Type</span>
                      <Badge 
                        variant={trade.tradeType === "buy" ? "default" : "destructive"}
                        className="w-fit text-xs"
                      >
                        {trade.tradeType.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="flex flex-col md:items-end">
                      <span className="font-medium md:hidden text-xs">Price</span>
                      <span className="text-sm">{formatCurrency(entryPrice)}</span>
                    </div>
                    
                    <div className="flex flex-col md:items-end">
                      <span className="font-medium md:hidden text-xs">Quantity</span>
                      <span className="text-sm">{trade.quantity}</span>
                      <Badge 
                        variant={trade.status === "open" ? "outline" : "secondary"}
                        className="mt-1 md:ml-2 text-xs whitespace-nowrap"
                      >
                        {trade.status.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 md:p-8 text-center">
            <p className="text-muted-foreground mb-2">No trade history found</p>
            <p className="text-sm text-muted-foreground">
              {search || dateFilter || statusFilter !== "all" 
                ? "Try adjusting your filters" 
                : "Your trading activity will appear here"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}