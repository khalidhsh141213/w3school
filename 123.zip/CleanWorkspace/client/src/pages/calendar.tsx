import { useMutation, useQuery } from '@tanstack/react-query';
import { eachDayOfInterval, endOfMonth, format, getDay, isToday, startOfMonth } from 'date-fns';
import {
    AlertCircle,
    BarChart,
    Calendar,
    ChevronLeft,
    ChevronRight,
    DollarSign,
    Filter,
    PieChart,
    RefreshCw,
    Search
} from 'lucide-react';
import { useEffect, useState } from 'react';

// UI Components
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

// Import the EventCard if it exists already in your components

// Event type definition
interface Event {
  id: string;
  type: 'earnings' | 'dividend' | 'economic' | 'other';
  title: string;
  symbol: string;
  date: Date;
  time: string;
  country?: string;
  impactLevel?: 'low' | 'medium' | 'high';
  actualValue?: string;
  forecastValue?: string;
  previousValue?: string;
  source?: string;
  sourceId?: string;
  affectedMarkets?: string[];
  predictedImpact?: {
    direction: 'positive' | 'negative' | 'neutral';
    impact?: 'bullish' | 'bearish' | 'neutral';
    confidence: number;
    analysis: string;
    tradingImplications?: string;
  };
  description?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

// Add this utility function at the top of the file after imports
const safeDate = (dateInput: any): Date | null => {
  // Handle null/undefined
  if (!dateInput) return null;
  
  // Handle numeric strings (timestamps)
  if (typeof dateInput === 'string' && !isNaN(Number(dateInput))) {
    dateInput = parseInt(dateInput);
  }
  
  // Create the date object
  const date = new Date(dateInput);
  
  // Validate the date is valid
  if (isNaN(date.getTime())) {
    console.warn(`Invalid date detected: ${dateInput}`);
    return null;
  }
  
  return date;
};

// Safe date formatting function
const safeFormat = (date: Date | null | undefined, formatString: string, fallback: string = ''): string => {
  if (!date) return fallback;
  try {
    // Verify the date is valid before formatting
    if (isNaN(date.getTime())) {
      return fallback;
    }
    return format(date, formatString);
  } catch (error) {
    console.error('Date formatting error:', error);
    return fallback;
  }
};

// Function to sync events with Polygon with improved error handling
const syncEventsWithPolygon = async (month: string): Promise<void> => {
  try {
    console.log(`Syncing economic events for month: ${month}`);
    
    // Get the auth token from localStorage
    const token = localStorage.getItem('token');
    
    const response = await fetch('/api/sync-economic-calendar', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Add authorization header if token exists
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify({ month }),
    });
    
    // Get content type header to ensure it's JSON
    const contentType = response.headers.get('content-type');
    console.log(`Response status: ${response.status}, content-type: ${contentType}`);
    
    if (!response.ok) {
      // Handle error based on content type
      if (contentType && contentType.includes('application/json')) {
        try {
          const errorData = await response.json();
          console.error('Server returned JSON error:', errorData);
          
          // Better error messages for 404 errors
          if (response.status === 404 && errorData.message && errorData.message.includes('404')) {
            throw new Error(`No economic events found for the selected period. This is normal for future months or weekends.`);
          } else {
            throw new Error(errorData.message || errorData.error || 'Failed to sync economic events');
          }
        } catch (jsonError) {
          // If JSON parsing fails, fall back to text
          const errorText = await response.text();
          console.error('Failed to parse JSON error response:', errorText.substring(0, 200));
          throw new Error(`Server error (${response.status}): ${errorText.substring(0, 100)}...`);
        }
      } else {
        // Handle non-JSON responses (likely HTML error pages)
        const errorText = await response.text();
        console.error('Server returned non-JSON error:', {
          status: response.status,
          statusText: response.statusText,
          contentType,
          preview: errorText.substring(0, 200)
        });
        throw new Error(`Server returned ${response.status} ${response.statusText || ''}`);
      }
    }
    
    // Successfully got response, check if it's JSON as expected
    if (contentType && contentType.includes('application/json')) {
      try {
        const result = await response.json();
        console.log(`Sync successful: ${result.message || 'Events synced successfully'}`);
        return result;
      } catch (parseError) {
        console.error('Error parsing successful response as JSON:', parseError);
        throw new Error('Unexpected error: Server returned invalid JSON with status 200');
      }
    } else {
      // This is unexpected - we should always get JSON from our API
      const responseText = await response.text();
      console.warn('Non-JSON response received from server with status 200:', responseText.substring(0, 200));
      throw new Error('Unexpected response format from server');
    }
  } catch (error) {
    console.error('Sync error details:', error);
    if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
      throw new Error('Network error: Please check your connection and try again');
    }
    throw error; // Re-throw the error for the mutation to handle
  }
};

export default function CalendarPage() {
  // State
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarView, setCalendarView] = useState('month');
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOptions, setFilterOptions] = useState({
    showEconomic: true,
    showEarnings: true,
    showDividend: true,
    showOther: true,
    impactLevels: {
      low: true,
      medium: true,
      high: true
    },
    countries: [] as string[],
    sources: [] as string[]
  });

  // Fetch economic events from the database
  const fetchEconomicEvents = async (): Promise<Event[]> => {
    try {
      const formattedMonth = format(currentDate, 'yyyy-MM');
      const res = await fetch(`/api/economic-events?month=${formattedMonth}`);

      if (!res.ok) {
        throw new Error(`Error fetching economic events: ${res.status}`);
      }

      const economicEvents = await res.json();

      return economicEvents.map((event: any) => {
        // Parse the stored impact analysis if available
        let predictedImpact = null;
        let affectedMarkets = [];
        
        try {
          if (event.asset_impact) {
            predictedImpact = JSON.parse(event.asset_impact);
          }
          if (event.affected_markets) {
            affectedMarkets = JSON.parse(event.affected_markets);
          }
        } catch (e) {
          console.error('Error parsing market impact data:', e);
        }
        
        // Safely handle the event date
        let eventDate = safeDate(event.event_date);
        if (!eventDate) {
          eventDate = new Date(); // Fallback to current date
          console.warn(`Invalid event date for event ${event.id || 'unknown'}, using current date as fallback`);
        }
        
        // Safely handle the event time
        let eventTime = '00:00';
        try {
          if (event.event_time && typeof event.event_time === 'string' && event.event_time.trim() !== '') {
            eventTime = event.event_time.trim();
          } else if (eventDate) {
            eventTime = safeFormat(eventDate, 'HH:mm', '00:00');
          }
        } catch (error) {
          console.error('Time formatting error:', error);
        }
        
        return {
          id: event.id || `temp-${Date.now()}`,
          type: 'economic',
          title: event.event_name || 'Unnamed Event',
          symbol: event.country || 'ECON',
          date: eventDate,
          time: eventTime,
          country: event.country,
          impactLevel: event.importance_level || 'medium',
          actualValue: event.actual_value,
          forecastValue: event.forecast_value,
          previousValue: event.previous_value,
          source: event.source,
          sourceId: event.source_id,
          affectedMarkets: affectedMarkets,
          predictedImpact: predictedImpact,
          description: event.description,
          createdAt: safeDate(event.created_at),
          updatedAt: safeDate(event.updated_at)
        };
      });
    } catch (error) {
      console.error('Failed to fetch economic events:', error);
      setFetchError('Failed to load economic events. Please try again later.');
      return [];
    }
  };

  // Fetch company events (earnings, dividends)
  const fetchCompanyEvents = async (): Promise<Event[]> => {
    try {
      const res = await fetch(`/api/company-events?month=${format(currentDate, 'yyyy-MM')}`);

      if (!res.ok) {
        throw new Error(`Error fetching company events: ${res.status}`);
      }

      const companyEvents = await res.json();

      return companyEvents.map((event: any) => ({
        id: event.id,
        type: event.eventType as Event['type'],
        title: event.title,
        symbol: event.symbol,
        date: new Date(event.date),
        time: format(new Date(event.date), 'hh:mm a'),
        description: event.description
      }));
    } catch (error) {
      console.error('Failed to fetch company events:', error);
      setFetchError('Failed to load company events. Please try again later.');
      return [];
    }
  };

  // Mutation for syncing events
  const syncMutation = useMutation({
    mutationFn: (month: string) => syncEventsWithPolygon(month),
    onMutate: () => {
      setIsRefreshing(true);
      setFetchError(null);
    },
    onSuccess: () => {
      refetch(); // Refetch events after sync
    },
    onError: (error: any) => {
      console.error('Error syncing events:', error);
      
      // Simplified error message for users
      if (error.message && error.message.includes('404')) {
        setFetchError(`No economic events found. This is normal for future months or weekends.`);
      } else if (error.message && error.message.includes('network')) {
        setFetchError(`Network error: Please check your connection and try again.`);
      } else {
        setFetchError(`Unable to update economic events: ${error.message}`);
      }
    },
    onSettled: () => {
      setIsRefreshing(false);
    }
  });

  // تحسين استراتيجية استرداد البيانات للسماح بعرض جزئي للبيانات حتى عند حدوث أخطاء
  const { data: events = [], isLoading, refetch, error: queryError } = useQuery({
    queryKey: ['/api/events', format(currentDate, 'yyyy-MM')],
    staleTime: 300000, // 5 minutes
    queryFn: async () => {
      try {
        // نقوم بمسح أي أخطاء سابقة في بداية الاستعلام
        setFetchError(null);
        
        // نستخدم الـ allSettled لاستمرار التنفيذ حتى لو فشل أحد الاستعلامات
        const [economicEventsResult, companyEventsResult] = await Promise.allSettled([
          fetchEconomicEvents(),
          fetchCompanyEvents()
        ]);
        
        // جمع البيانات الناجحة
        const economicEvents = economicEventsResult.status === 'fulfilled' ? economicEventsResult.value : [];
        const companyEvents = companyEventsResult.status === 'fulfilled' ? companyEventsResult.value : [];
        
        // سجل معلومات التصحيح
        console.log('Calendar data loading status:', {
          economicEvents: {
            status: economicEventsResult.status,
            count: economicEvents.length,
            error: economicEventsResult.status === 'rejected' ? economicEventsResult.reason : null
          },
          companyEvents: {
            status: companyEventsResult.status,
            count: companyEvents.length,
            error: companyEventsResult.status === 'rejected' ? companyEventsResult.reason : null
          }
        });
        
        // إذا فشلت جميع الاستعلامات، نعرض خطأ عام
        if (economicEventsResult.status === 'rejected' && companyEventsResult.status === 'rejected') {
          setFetchError('Failed to load any calendar events. Please try again later.');
        } 
        // إذا فشل بعض الاستعلامات، نعرض تحذير
        else if (economicEventsResult.status === 'rejected' || companyEventsResult.status === 'rejected') {
          setFetchError('Some calendar data could not be loaded. The view may be incomplete.');
        }
        
        // دمج وتصفية الأحداث الصالحة
        return [...economicEvents, ...companyEvents].filter(e => e && typeof e === 'object');
      } catch (error) {
        console.error('Error fetching events:', error);
        setFetchError('Failed to load calendar events. Please try again later.');
        return [];
      }
    }
  });

  // Filter events based on search and filter options
  const filteredEvents = events.filter(event => {
    // Type filter
    if ((event.type === 'economic' && !filterOptions.showEconomic) ||
        (event.type === 'earnings' && !filterOptions.showEarnings) ||
        (event.type === 'dividend' && !filterOptions.showDividend) ||
        (event.type === 'other' && !filterOptions.showOther)) {
      return false;
    }

    // Impact level filter
    if (event.impactLevel && !filterOptions.impactLevels[event.impactLevel]) {
      return false;
    }

    // Country filter
    if (filterOptions.countries.length > 0 && event.country && 
        !filterOptions.countries.includes(event.country)) {
      return false;
    }
    
    // Source filter
    if (filterOptions.sources.length > 0 && event.source && 
        !filterOptions.sources.includes(event.source)) {
      return false;
    }

    // Search filter
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      return (
        event.title.toLowerCase().includes(searchLower) ||
        event.symbol.toLowerCase().includes(searchLower) ||
        (event.country?.toLowerCase().includes(searchLower) || false) ||
        (event.description?.toLowerCase().includes(searchLower) || false) ||
        (event.source?.toLowerCase().includes(searchLower) || false) ||
        (event.actualValue?.toLowerCase().includes(searchLower) || false) ||
        (event.forecastValue?.toLowerCase().includes(searchLower) || false) ||
        (event.previousValue?.toLowerCase().includes(searchLower) || false) ||
        (event.predictedImpact?.analysis?.toLowerCase().includes(searchLower) || false)
      );
    }

    return true;
  });

  // Helper functions
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentDate),
    end: endOfMonth(currentDate)
  });

  const firstDayOfMonth = startOfMonth(currentDate);
  const startingDayIndex = getDay(firstDayOfMonth); 

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const goToPrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const getEventsForDay = (day: Date): Event[] => {
    return filteredEvents.filter(event => 
      event.date.getDate() === day.getDate() &&
      event.date.getMonth() === day.getMonth() &&
      event.date.getFullYear() === day.getFullYear()
    );
  };

  const filterEventsByType = (type: Event['type']): Event[] => {
    return filteredEvents.filter(event => event.type === type);
  };

  const refreshEvents = () => {
    syncMutation.mutate(format(currentDate, 'yyyy-MM'));
  };

  // Get unique countries from events for filtering
  const uniqueCountries = Array.from(new Set(
    events.filter(e => e.country).map(e => e.country as string)
  )).sort();

  // Effect to update countries filter options when events change
  useEffect(() => {
    if (filterOptions.countries.length === 0 && uniqueCountries.length > 0) {
      setFilterOptions(prev => ({
        ...prev,
        countries: uniqueCountries
      }));
    }
  }, [uniqueCountries]);

  // Render enhanced event card with tooltip and safer rendering
  const EnhancedEventCard = (event: Event) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div onClick={() => setSelectedEvent(event)} className="cursor-pointer">
            <div className={`border-l-2 border-l-${
              event.type === 'economic' ? 'amber-600' :
              event.type === 'earnings' ? 'indigo-600' :
              event.type === 'dividend' ? 'primary' : 'gray-600'
            } p-2 mb-2 rounded-r-md hover:bg-gray-50 transition-colors`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className={`p-1 rounded-md mr-2 ${
                    event.type === 'economic' ? 'bg-amber-100 text-amber-600' :
                    event.type === 'earnings' ? 'bg-indigo-100 text-indigo-600' :
                    event.type === 'dividend' ? 'bg-primary-100 text-primary' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {event.type === 'economic' ? <PieChart className="h-4 w-4" /> :
                     event.type === 'earnings' ? <BarChart className="h-4 w-4" /> :
                     event.type === 'dividend' ? <DollarSign className="h-4 w-4" /> : null}
                  </div>
                  <div className="truncate">
                    <div className="font-medium text-sm">{event.symbol || 'Unknown'}</div>
                    <div className="text-xs text-gray-500 truncate">{event.title || 'No title'}</div>
                    <div className="text-xs text-gray-400">{event.time || '--:--'}</div>
                  </div>
                </div>
                {event.predictedImpact?.direction && (
                  <div>
                    <Badge className={
                      event.predictedImpact?.direction === 'positive' ? 'bg-green-100 text-green-800' :
                      event.predictedImpact?.direction === 'negative' ? 'bg-red-100 text-red-800' :
                      'bg-amber-100 text-amber-800'
                    }>
                      {event.predictedImpact?.direction === 'positive' ? 'Positive' :
                      event.predictedImpact?.direction === 'negative' ? 'Negative' : 'Neutral'}
                    </Badge>
                  </div>
                )}
              </div>
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">
          <div className="space-y-2">
            <div className="font-medium">{event.title || 'No title'}</div>
            {event.description && (
              <div className="text-xs text-gray-500">{
                event.description.length > 100 
                  ? `${event.description.substring(0, 100)}...` 
                  : event.description
              }</div>
            )}
            <div className="flex items-center text-xs">
              <Calendar className="h-3 w-3 mr-1 text-gray-400" />
              {safeFormat(event.date, 'PPP', 'Unknown date')}
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-textDark">Economic Calendar</h1>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refreshEvents} 
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Syncing...' : 'Sync Events'}
          </Button>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-1" />
                Filters
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Filter Calendar Events</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div>
                  <h3 className="font-medium mb-2">Event Types</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="showEconomic" 
                        checked={filterOptions.showEconomic}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({...prev, showEconomic: !!checked}))}
                      />
                      <Label htmlFor="showEconomic">Economic</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="showEarnings" 
                        checked={filterOptions.showEarnings}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({...prev, showEarnings: !!checked}))}
                      />
                      <Label htmlFor="showEarnings">Earnings</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="showDividend" 
                        checked={filterOptions.showDividend}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({...prev, showDividend: !!checked}))}
                      />
                      <Label htmlFor="showDividend">Dividends</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="showOther" 
                        checked={filterOptions.showOther}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({...prev, showOther: !!checked}))}
                      />
                      <Label htmlFor="showOther">Other</Label>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Impact Level</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="impactLow" 
                        checked={filterOptions.impactLevels.low}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({
                            ...prev, 
                            impactLevels: {...prev.impactLevels, low: !!checked}
                          }))}
                      />
                      <Label htmlFor="impactLow">Low</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="impactMedium" 
                        checked={filterOptions.impactLevels.medium}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({
                            ...prev, 
                            impactLevels: {...prev.impactLevels, medium: !!checked}
                          }))}
                      />
                      <Label htmlFor="impactMedium">Medium</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="impactHigh" 
                        checked={filterOptions.impactLevels.high}
                        onCheckedChange={(checked) => 
                          setFilterOptions(prev => ({
                            ...prev, 
                            impactLevels: {...prev.impactLevels, high: !!checked}
                          }))}
                      />
                      <Label htmlFor="impactHigh">High</Label>
                    </div>
                  </div>
                </div>
                
                {uniqueCountries.length > 0 && (
                  <div>
                    <h3 className="font-medium mb-2">Countries</h3>
                    <ScrollArea className="h-40">
                      <div className="space-y-2">
                        {uniqueCountries.map(country => (
                          <div key={country} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`country-${country}`} 
                              checked={filterOptions.countries.includes(country)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setFilterOptions(prev => ({
                                    ...prev,
                                    countries: [...prev.countries, country]
                                  }));
                                } else {
                                  setFilterOptions(prev => ({
                                    ...prev,
                                    countries: prev.countries.filter(c => c !== country)
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={`country-${country}`}>{country}</Label>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                )}

                <div>
                  <h3 className="font-medium mb-2">Sources</h3>
                  <ScrollArea className="h-32 border rounded-md p-2">
                    <div className="space-y-2">
                      {Array.from(new Set(events.filter(e => e.source).map(e => e.source))).sort().map(
                        source => source && (
                          <div key={source} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`source-${source}`}
                              checked={filterOptions.sources.includes(source)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setFilterOptions(prev => ({
                                    ...prev, 
                                    sources: [...prev.sources, source]
                                  }));
                                } else {
                                  setFilterOptions(prev => ({
                                    ...prev, 
                                    sources: prev.sources.filter(s => s !== source)
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={`source-${source}`}>{source}</Label>
                          </div>
                        )
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* تحسين طريقة عرض رسائل الخطأ */}
      {fetchError && (
        <Alert variant={fetchError.includes('Some calendar data') ? 'default' : 'destructive'}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {fetchError}
            <div className="flex gap-2 mt-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={refreshEvents} 
                disabled={isRefreshing}
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                {isRefreshing ? 'Refreshing...' : 'Refresh Data'}
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex items-center mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search events..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        
        <div className="ml-4">
          <Tabs value={calendarView} onValueChange={setCalendarView}>
            <TabsList>
              <TabsTrigger value="month">Month</TabsTrigger>
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="day">Day</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <Card className="shadow-md">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg text-textDark">Market Events</CardTitle>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon" onClick={goToPrevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Select 
                value={currentDate.getMonth().toString()} 
                onValueChange={(value) => setCurrentDate(new Date(currentDate.getFullYear(), parseInt(value), 1))}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue>{format(currentDate, 'MMMM yyyy')}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }).map((_, index) => (
                    <SelectItem key={index} value={index.toString()}>
                      {format(new Date(currentDate.getFullYear(), index, 1), 'MMMM yyyy')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon" onClick={goToNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={() => setCurrentDate(new Date())}>
                Today
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-7 gap-1">
              {/* Weekday Headers */}
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
                <div key={i} className="text-center text-gray-500 text-sm py-2 font-medium">
                  {day}
                </div>
              ))}
              
              {/* Skeleton loading state */}
              {Array.from({ length: 35 }).map((_, i) => (
                <div key={i} className="h-32 border border-gray-200 rounded-md p-1">
                  <Skeleton className="h-4 w-8 mb-2 float-right" />
                  <div className="space-y-2 mt-6">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {calendarView === 'month' && (
                <div className="grid grid-cols-7 gap-1">
                  {/* Weekday Headers */}
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
                    <div key={i} className="text-center text-gray-500 text-sm py-2 font-medium">
                      {day}
                    </div>
                  ))}

                  {/* Empty spaces for days from previous month */}
                  {Array.from({ length: startingDayIndex }).map((_, i) => (
                    <div key={`empty-start-${i}`} className="h-32 p-1 bg-gray-50 rounded-md"></div>
                  ))}

                  {/* Actual days of the month */}
                  {daysInMonth.map((day, i) => {
                    const dayEvents = getEventsForDay(day);
                    const isCurrentDay = isToday(day);

                    return (
                      <div 
                        key={i} 
                        className={`h-32 border border-gray-200 rounded-md overflow-hidden ${
                          isCurrentDay ? 'bg-blue-50 border-blue-200' : ''
                        }`}
                      >
                        <div className={`text-right p-1 text-sm font-medium ${
                          isCurrentDay ? 'bg-blue-100 text-blue-700' : 'bg-gray-50'
                        }`}>
                          {format(day, 'd')}
                        </div>
                        <div className="p-1 overflow-y-auto h-[calc(100%-24px)]">
                          {dayEvents.length > 0 ? (
                            dayEvents.map(event => (
                              <div key={event.id}>
                                {EnhancedEventCard(event)}
                              </div>
                            ))
                          ) : null}
                        </div>
                      </div>
                    );
                  })}

                  {/* Empty spaces for days from next month */}
                  {Array.from({ length: (7 - ((daysInMonth.length + startingDayIndex) % 7)) % 7 }).map((_, i) => (
                    <div key={`empty-end-${i}`} className="h-32 p-1 bg-gray-50 rounded-md"></div>
                  ))}
                </div>
              )}

              {calendarView === 'week' && (
                <div className="space-y-2">
                  <Tabs defaultValue="all">
                    <TabsList>
                      <TabsTrigger value="all">All Events</TabsTrigger>
                      <TabsTrigger value="economic">Economic</TabsTrigger>
                      <TabsTrigger value="earnings">Earnings</TabsTrigger>
                      <TabsTrigger value="dividend">Dividends</TabsTrigger>
                    </TabsList>

                    <TabsContent value="all" className="mt-4">
                      <div className="space-y-2">
                        {filteredEvents.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">No events for this week</div>
                        ) : (
                          filteredEvents.map(event => (
                            <Card key={event.id} className="overflow-hidden">
                              <CardContent className="p-3 flex items-center">
                                {EnhancedEventCard(event)}
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="economic" className="mt-4">
                      <div className="space-y-2">
                        {filterEventsByType('economic').length === 0 ? (
                          <div className="text-center py-8 text-gray-500">No economic events for this week</div>
                        ) : (
                          filterEventsByType('economic').map(event => (
                            <Card key={event.id} className="overflow-hidden">
                              <CardContent className="p-3 flex items-center">
                                {EnhancedEventCard(event)}
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="earnings" className="mt-4">
                      <div className="space-y-2">
                        {filterEventsByType('earnings').length === 0 ? (
                          <div className="text-center py-8 text-gray-500">No earnings events for this week</div>
                        ) : (
                          filterEventsByType('earnings').map(event => (
                            <Card key={event.id} className="overflow-hidden">
                              <CardContent className="p-3 flex items-center">
                                {EnhancedEventCard(event)}
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="dividend" className="mt-4">
                      <div className="space-y-2">
                        {filterEventsByType('dividend').length === 0 ? (
                          <div className="text-center py-8 text-gray-500">No dividend events for this week</div>
                        ) : (
                          filterEventsByType('dividend').map(event => (
                            <Card key={event.id} className="overflow-hidden">
                              <CardContent className="p-3 flex items-center">
                                {EnhancedEventCard(event)}
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}

              {calendarView === 'day' && (
                <div className="space-y-4">
                  <div className="text-center text-lg font-medium">
                    {format(currentDate, 'EEEE, MMMM d, yyyy')}
                  </div>

                  <div className="space-y-2">
                    {getEventsForDay(currentDate).length === 0 ? (
                      <div className="text-center py-8 text-gray-500">No events for this day</div>
                    ) : (
                      getEventsForDay(currentDate).map(event => (
                        <Card key={event.id} className="overflow-hidden">
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              {EnhancedEventCard(event)}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Event detail modal */}
      {selectedEvent && (
        <Dialog open={!!selectedEvent} onOpenChange={(open) => !open && setSelectedEvent(null)}>
          <DialogContent className="sm:max-w-md md:max-w-lg">
            <DialogHeader>
              <DialogTitle>Event Details</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="col-span-4 flex items-center space-x-2">
                  {selectedEvent.type === 'economic' && (
                    <Badge className={
                      selectedEvent.impactLevel === 'high' ? 'bg-red-100 text-red-800 border-red-200' :
                      selectedEvent.impactLevel === 'medium' ? 'bg-amber-100 text-amber-800 border-amber-200' :
                      'bg-green-100 text-green-800 border-green-200'
                    }>
                      {selectedEvent.impactLevel?.toUpperCase()}
                    </Badge>
                  )}
                  {selectedEvent.country && (
                    <Badge variant="outline">{selectedEvent.country}</Badge>
                  )}
                </div>
                <h2 className="col-span-4 text-lg font-semibold">{selectedEvent.title}</h2>
                <p className="col-span-4 text-sm text-gray-500">
                  {safeFormat(selectedEvent.date, 'PPP', 'Unknown date')} • {selectedEvent.time || '--:--'}
                </p>
                
                {selectedEvent.description && (
                  <div className="col-span-4">
                    <Label className="text-sm font-medium">Description</Label>
                    <p className="text-sm mt-1">{selectedEvent.description}</p>
                  </div>
                )}
                
                {/* New enhanced fields display */}
                {selectedEvent.type === 'economic' && (
                  <>
                    <div className="col-span-4 grid grid-cols-3 gap-4 mt-2">
                      {selectedEvent.actualValue && (
                        <div>
                          <Label className="text-sm font-medium text-gray-500">Actual</Label>
                          <p className="text-sm font-semibold">{selectedEvent.actualValue}</p>
                        </div>
                      )}
                      {selectedEvent.forecastValue && (
                        <div>
                          <Label className="text-sm font-medium text-gray-500">Forecast</Label>
                          <p className="text-sm">{selectedEvent.forecastValue}</p>
                        </div>
                      )}
                      {selectedEvent.previousValue && (
                        <div>
                          <Label className="text-sm font-medium text-gray-500">Previous</Label>
                          <p className="text-sm">{selectedEvent.previousValue}</p>
                        </div>
                      )}
                    </div>
                    
                    {selectedEvent.source && (
                      <div className="col-span-4">
                        <Label className="text-sm font-medium text-gray-500">Source</Label>
                        <p className="text-sm">{selectedEvent.source}</p>
                      </div>
                    )}
                    
                    {selectedEvent.predictedImpact && (
                      <div className="col-span-4 border p-3 rounded-md bg-gray-50 mt-2">
                        <h3 className="font-medium mb-2">Market Impact Analysis</h3>
                        
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className={
                            selectedEvent.predictedImpact.direction === 'positive' ? 'bg-green-100 text-green-800 border-green-200' :
                            selectedEvent.predictedImpact.direction === 'negative' ? 'bg-red-100 text-red-800 border-red-200' :
                            'bg-gray-100 text-gray-800 border-gray-200'
                          }>
                            {selectedEvent.predictedImpact.impact || selectedEvent.predictedImpact.direction?.toUpperCase()}
                          </Badge>
                          
                          <Badge variant="outline">
                            Confidence: {(selectedEvent.predictedImpact.confidence * 100).toFixed(0)}%
                          </Badge>
                        </div>
                        
                        {selectedEvent.predictedImpact.analysis && (
                          <div className="text-sm mt-1">{selectedEvent.predictedImpact.analysis}</div>
                        )}
                        
                        {selectedEvent.predictedImpact.tradingImplications && (
                          <div className="mt-2">
                            <Label className="text-sm font-medium text-gray-500">Trading Implications</Label>
                            <p className="text-sm">{selectedEvent.predictedImpact.tradingImplications}</p>
                          </div>
                        )}
                        
                        {selectedEvent.affectedMarkets && selectedEvent.affectedMarkets.length > 0 && (
                          <div className="mt-2">
                            <Label className="text-sm font-medium text-gray-500">Affected Markets</Label>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {selectedEvent.affectedMarkets.map((market, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {market}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}