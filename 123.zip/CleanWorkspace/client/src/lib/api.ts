/**
 * API Client
 * 
 * A typed API client for making requests to the backend API.
 * Uses the shared types for proper request/response typing.
 */

import { 
  ApiResponse, 
  Asset, 
  MarketData, 
  Order, 
  OrderType, 
  Portfolio, 
  Position, 
  PaginatedResponse,
  User
} from '@/types';

// Base API URL from environment
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '';

// Error class for API errors
export class ApiError extends Error {
  code: string;
  details?: Record<string, any>;
  status: number;

  constructor(message: string, code: string, status: number, details?: Record<string, any>) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

// Default request options
const DEFAULT_OPTIONS: RequestInit = {
  headers: {
    'Content-Type': 'application/json',
  },
  credentials: 'include', // Include cookies
};

// Helper function to build URLs with query parameters
function buildUrl(path: string, params?: Record<string, any>): string {
  const url = new URL(`${API_BASE_URL}${path}`);
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        url.searchParams.append(key, String(value));
      }
    });
  }
  
  return url.toString();
}

// Core fetch function with error handling
async function fetchApi<T>(
  path: string, 
  options?: RequestInit, 
  params?: Record<string, any>
): Promise<T> {
  try {
    const url = buildUrl(path, params);
    const response = await fetch(url, {
      ...DEFAULT_OPTIONS,
      ...options,
    });
    
    // Handle non-JSON responses
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      if (!response.ok) {
        throw new ApiError(
          'Network response was not ok', 
          'NOT_OK', 
          response.status
        );
      }
      return {} as T;
    }
    
    // Parse JSON response
    const data = await response.json();
    
    // Handle API errors
    if (!response.ok) {
      throw new ApiError(
        data.error?.message || 'An error occurred', 
        data.error?.code || 'UNKNOWN_ERROR', 
        response.status,
        data.error?.details
      );
    }
    
    // Handle wrapped API responses
    if ('success' in data && 'data' in data) {
      return data.data as T;
    }
    
    return data as T;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    
    throw new ApiError(
      error instanceof Error ? error.message : 'An unknown error occurred',
      'FETCH_ERROR',
      500
    );
  }
}

// API Client functions
export const api = {
  // Auth endpoints
  auth: {
    login: (email: string, password: string): Promise<ApiResponse<User>> => {
      return fetchApi<ApiResponse<User>>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
    },
    
    register: (username: string, email: string, password: string): Promise<ApiResponse<User>> => {
      return fetchApi<ApiResponse<User>>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ username, email, password }),
      });
    },
    
    logout: (): Promise<ApiResponse<null>> => {
      return fetchApi<ApiResponse<null>>('/api/auth/logout', {
        method: 'POST',
      });
    },
    
    me: (): Promise<ApiResponse<User>> => {
      return fetchApi<ApiResponse<User>>('/api/auth/me');
    },
  },
  
  // User endpoints
  users: {
    getProfile: (userId: string): Promise<ApiResponse<User>> => {
      return fetchApi<ApiResponse<User>>(`/api/users/${userId}`);
    },
    
    updateProfile: (userId: string, data: Partial<User>): Promise<ApiResponse<User>> => {
      return fetchApi<ApiResponse<User>>(`/api/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
  },
  
  // Asset endpoints
  assets: {
    getAll: (params?: { type?: string; active?: boolean }): Promise<ApiResponse<Asset[]>> => {
      return fetchApi<ApiResponse<Asset[]>>('/api/assets', undefined, params);
    },
    
    getById: (assetId: string): Promise<ApiResponse<Asset>> => {
      return fetchApi<ApiResponse<Asset>>(`/api/assets/${assetId}`);
    },
    
    getBySymbol: (symbol: string): Promise<ApiResponse<Asset>> => {
      return fetchApi<ApiResponse<Asset>>('/api/assets/symbol', undefined, { symbol });
    },
  },
  
  // Market data endpoints
  market: {
    getLatestPrice: (symbol: string): Promise<ApiResponse<MarketData>> => {
      return fetchApi<ApiResponse<MarketData>>('/api/market/price', undefined, { symbol });
    },
    
    getHistoricalData: (
      symbol: string, 
      interval: string, 
      from?: string, 
      to?: string
    ): Promise<ApiResponse<MarketData[]>> => {
      return fetchApi<ApiResponse<MarketData[]>>('/api/market/historical', undefined, {
        symbol,
        interval,
        from,
        to,
      });
    },
  },
  
  // Portfolio endpoints
  portfolio: {
    getSummary: (userId: string): Promise<ApiResponse<Portfolio>> => {
      return fetchApi<ApiResponse<Portfolio>>(`/api/portfolio/${userId}`);
    },
    
    getPositions: (userId: string): Promise<ApiResponse<Position[]>> => {
      return fetchApi<ApiResponse<Position[]>>(`/api/portfolio/${userId}/positions`);
    },
    
    getPosition: (userId: string, positionId: string): Promise<ApiResponse<Position>> => {
      return fetchApi<ApiResponse<Position>>(`/api/portfolio/${userId}/positions/${positionId}`);
    },
  },
  
  // Order endpoints
  orders: {
    create: (orderData: Partial<Order>): Promise<ApiResponse<Order>> => {
      return fetchApi<ApiResponse<Order>>('/api/orders', {
        method: 'POST',
        body: JSON.stringify(orderData),
      });
    },
    
    getAll: (
      userId: string, 
      params?: { 
        status?: string; 
        page?: number; 
        limit?: number;
      }
    ): Promise<ApiResponse<PaginatedResponse<Order>>> => {
      return fetchApi<ApiResponse<PaginatedResponse<Order>>>(`/api/orders/user/${userId}`, undefined, params);
    },
    
    getById: (orderId: string): Promise<ApiResponse<Order>> => {
      return fetchApi<ApiResponse<Order>>(`/api/orders/${orderId}`);
    },
    
    cancel: (orderId: string): Promise<ApiResponse<Order>> => {
      return fetchApi<ApiResponse<Order>>(`/api/orders/${orderId}/cancel`, {
        method: 'POST',
      });
    },
  },
};

export default api; 