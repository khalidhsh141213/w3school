/**
 * Service for interacting with the Polygon.io REST API
 * This service handles historical data and ticker information.
 * For real-time data, see polygonWebSocket.ts
 */

import axios from 'axios';
import { log } from '../vite';

const POLYGON_API_KEY = process.env.POLYGON_API_KEY;
const POLYGON_BASE_URL = 'https://api.polygon.io';

if (!POLYGON_API_KEY) {
  log('Warning: POLYGON_API_KEY environment variable is not set. Polygon API will not work correctly.', 'polygon');
} else {
  log(`Using Polygon API key: ${POLYGON_API_KEY.substring(0, 4)}...`, 'polygon');
}

// Create axios instance for Polygon API
const polygonClient = axios.create({
  baseURL: POLYGON_BASE_URL
});

// Configure axios to add the API key to every request
polygonClient.interceptors.request.use(config => {
  // Ensure params object exists
  config.params = config.params || {};
  
  // Add apiKey to URL query parameter (as required by Polygon API)
  // The parameter is apiKey according to Polygon.io docs (not api_key)
  config.params.apiKey = POLYGON_API_KEY;
  
  // Also add an authorization header as a fallback
  if (!config.headers) {
    config.headers = {};
  }
  config.headers.Authorization = `Bearer ${POLYGON_API_KEY}`;
  
  return config;
});

/**
 * Interface for ticker details from Polygon API
 */
interface PolygonTickerDetails {
  ticker: string;
  name: string;
  market: string;
  locale: string;
  primary_exchange: string;
  type: string;
  active: boolean;
  currency_name: string;
  last_updated_utc: string;
  description: string;
  homepage_url?: string;
  total_employees?: number;
  weighted_shares_outstanding?: number;
  market_cap?: number;
  phone_number?: string;
  address?: {
    address1?: string;
    city?: string;
    state?: string;
    postal_code?: string;
  };
  sic_code?: string;
  sic_description?: string;
  ticker_root?: string;
  ticker_suffix?: string;
  cik?: string;
  bloomberg_ticker?: string;
}

/**
 * Interface for ticker price from Polygon API
 */
interface PolygonTickerPrice {
  ticker: string;
  todaysChange: number;
  todaysChangePerc: number;
  updated: number;
  day: {
    c: number;
    h: number;
    l: number;
    o: number;
    v: number;
  };
  lastTrade: {
    c: number[];
    p: number;
    s: number;
    t: number;
  };
  min: {
    c: number;
    h: number;
    l: number;
    o: number;
    v: number;
  };
  prevDay: {
    c: number;
    h: number;
    l: number;
    o: number;
    v: number;
  };
}

/**
 * Service for interacting with the Polygon.io API
 */
class PolygonService {
  /**
   * Get ticker details from Polygon API
   * @param ticker - The ticker symbol
   * @returns Ticker details or null if not found
   */
  async getTickerDetails(ticker: string): Promise<PolygonTickerDetails | null> {
    try {
      const response = await polygonClient.get(`/v3/reference/tickers/${ticker}`);
      return response.data.results;
    } catch (error) {
      log(`Error fetching ticker details for ${ticker}: ${error}`, 'polygon');
      return null;
    }
  }

  /**
   * Get current price for a ticker from Polygon API
   * @param ticker - The ticker symbol
   * @returns Current price data or null if not found
   */
  async getCurrentPrice(ticker: string): Promise<PolygonTickerPrice | null> {
    try {
      // For stocks use the previous close endpoint
      const response = await polygonClient.get(`/v2/aggs/ticker/${ticker}/prev`);
      if (response.data.results && response.data.results.length > 0) {
        // Transform the response to match the expected format
        const result = response.data.results[0];
        return {
          ticker: ticker,
          todaysChange: 0, // We don't have this from prev endpoint
          todaysChangePerc: 0, // We don't have this from prev endpoint
          updated: new Date().getTime(),
          day: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          lastTrade: {
            c: [],
            p: result.c, // Use close as the price
            s: result.v, // Use volume as the size
            t: new Date().getTime()
          },
          min: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          prevDay: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          }
        };
      }
      return null;
    } catch (error) {
      log(`Error fetching current price for ${ticker}: ${error}`, 'polygon');
      return null;
    }
  }

  /**
   * Get crypto price from Polygon API
   * @param ticker - The crypto ticker symbol (e.g., X:BTCUSD)
   * @returns Current crypto price data or null if not found
   */
  async getCryptoPrice(ticker: string): Promise<any | null> {
    try {
      // No need to format - use the ticker exactly as stored in polygon_symbol
      // Use the prev endpoint as documented
      const response = await polygonClient.get(`/v2/aggs/ticker/${ticker}/prev`);
      
      if (response.data.results && response.data.results.length > 0) {
        // Transform the response to match the expected format
        const result = response.data.results[0];
        return {
          ticker: ticker,
          todaysChange: 0,
          todaysChangePerc: 0,
          updated: new Date().getTime(),
          day: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          // Add lastTrade field with price to ensure it's extracted correctly
          lastTrade: {
            c: [],
            p: result.c, // Use close as the price
            s: result.v, // Use volume as the size
            t: new Date().getTime()
          },
          min: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          prevDay: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          }
        };
      }
      return null;
    } catch (error) {
      log(`Error fetching crypto price for ${ticker}: ${error}`, 'polygon');
      return null;
    }
  }

  /**
   * Get forex price from Polygon API
   * @param ticker - The forex ticker symbol (e.g., C:EURUSD)
   * @returns Current forex price data or null if not found
   */
  async getForexPrice(ticker: string): Promise<any | null> {
    try {
      // No need to format - use the ticker exactly as stored in polygon_symbol
      // Use the prev endpoint as documented
      const response = await polygonClient.get(`/v2/aggs/ticker/${ticker}/prev`);
      
      if (response.data.results && response.data.results.length > 0) {
        // Transform the response to match the expected format
        const result = response.data.results[0];
        return {
          ticker: ticker,
          todaysChange: 0,
          todaysChangePerc: 0,
          updated: new Date().getTime(),
          day: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          // Add lastTrade field with price to ensure it's extracted correctly
          lastTrade: {
            c: [],
            p: result.c, // Use close as the price
            s: result.v, // Use volume as the size
            t: new Date().getTime()
          },
          min: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          },
          prevDay: {
            c: result.c,
            h: result.h,
            l: result.l,
            o: result.o,
            v: result.v
          }
        };
      }
      return null;
    } catch (error) {
      log(`Error fetching forex price for ${ticker}: ${error}`, 'polygon');
      return null;
    }
  }

  /**
   * Get daily OHLC data for a ticker
   * @param ticker - The ticker symbol (should be the exact polygon_symbol from database)
   * @param from - Start date in format YYYY-MM-DD
   * @param to - End date in format YYYY-MM-DD
   * @returns Daily OHLC data or null if not found
   */
  async getDailyOHLC(ticker: string, from: string, to: string): Promise<any | null> {
    try {
      // Use the ticker exactly as provided (from polygonSymbol in database)
      const response = await polygonClient.get(`/v2/aggs/ticker/${ticker}/range/1/day/${from}/${to}`);
      return response.data.results;
    } catch (error) {
      log(`Error fetching daily OHLC for ${ticker}: ${error}`, 'polygon');
      return null;
    }
  }

  /**
   * Search for tickers matching a query
   * @param query - Search query
   * @returns Array of matching tickers or empty array if none found
   */
  async searchTickers(query: string): Promise<any[]> {
    try {
      const response = await polygonClient.get(`/v3/reference/tickers`, {
        params: {
          search: query,
          active: true,
          sort: 'ticker',
          order: 'asc',
          limit: 10
        }
      });
      return response.data.results || [];
    } catch (error) {
      log(`Error searching tickers for "${query}": ${error}`, 'polygon');
      return [];
    }
  }
}

export const polygonService = new PolygonService();