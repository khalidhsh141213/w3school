import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";

interface PortfolioSummaryWidgetProps {
  title: string;
  description?: string;
  value: number;
  change?: number;
  changePercent?: number;
  isLoading?: boolean;
  className?: string;
}

export default function PortfolioSummaryWidget({
  title,
  description,
  value,
  change = 0,
  changePercent = 0,
  isLoading = false,
  className = "",
}: PortfolioSummaryWidgetProps) {
  const isPositive = change >= 0;
  const changeColor = isPositive ? 'text-green-600' : 'text-red-600';
  const Icon = isPositive ? ArrowUpIcon : ArrowDownIcon;

  if (isLoading) {
    return (
      <Card className={`overflow-hidden ${className}`}>
        <CardHeader className="pb-2">
          <Skeleton className="h-4 w-28" />
          {description && <Skeleton className="h-3 w-36 mt-1" />}
        </CardHeader>
        <CardContent>
          <Skeleton className="h-7 w-24 mb-1" />
          <Skeleton className="h-4 w-16" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`overflow-hidden ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {description && <CardDescription className="text-xs">{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{formatCurrency(value)}</div>
        {(change !== undefined && changePercent !== undefined) && (
          <div className={`flex items-center text-sm ${changeColor}`}>
            <Icon className="mr-1 h-4 w-4" />
            <span>{formatCurrency(change)}</span>
            <span className="mx-1">•</span>
            <span>{formatPercentage(changePercent)}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}