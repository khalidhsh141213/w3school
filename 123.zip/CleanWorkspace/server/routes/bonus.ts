/**
 * API واجهة نظام المكافآت والإحالات
 */

import { Router, Request, Response } from 'express';
import { db } from '../db';
import { bonuses, activities, referrals, users } from '../../shared/schema';
import { eq, and, lt, gt, or, isNull } from 'drizzle-orm';
import { BonusManager } from '../utils/bonus-manager';
import { logUserActivity } from '../utils/activity-logger';
import { z } from 'zod';

const router = Router();

// المصادقة الأساسية للتأكد من أن المستخدم مسجل دخول
function requireAuth(req: Request, res: Response, next: Function) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'يرجى تسجيل الدخول للوصول إلى هذه الميزة' });
  }
  next();
}

/**
 * الحصول على جميع المكافآت النشطة للمستخدم الحالي
 * GET /api/bonuses
 */
router.get('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    const now = new Date();
    
    const userBonuses = await db.select()
      .from(bonuses)
      .where(
        and(
          eq(bonuses.userId, userId),
          or(
            eq(bonuses.status, 'active'),
            and(
              eq(bonuses.status, 'active'),
              or(
                isNull(bonuses.expiryDate),
                gt(bonuses.expiryDate, now)
              )
            )
          )
        )
      )
      .orderBy(bonuses.createdAt);

    return res.status(200).json(userBonuses);
  } catch (error) {
    console.error('خطأ في الحصول على المكافآت:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء جلب المكافآت' });
  }
});

/**
 * الحصول على تاريخ المكافآت للمستخدم الحالي (متضمنة المنتهية والمستخدمة)
 * GET /api/bonuses/history
 */
router.get('/history', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    
    const bonusHistory = await db.select()
      .from(bonuses)
      .where(eq(bonuses.userId, userId))
      .orderBy(bonuses.createdAt, 'desc');

    return res.status(200).json(bonusHistory);
  } catch (error) {
    console.error('خطأ في الحصول على تاريخ المكافآت:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء جلب تاريخ المكافآت' });
  }
});

/**
 * الحصول على تفاصيل مكافأة محددة
 * GET /api/bonuses/:id
 */
router.get('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    const bonusId = req.params.id;
    
    const [bonus] = await db.select()
      .from(bonuses)
      .where(
        and(
          eq(bonuses.id, bonusId),
          eq(bonuses.userId, userId)
        )
      );

    if (!bonus) {
      return res.status(404).json({ error: 'المكافأة غير موجودة' });
    }

    return res.status(200).json(bonus);
  } catch (error) {
    console.error('خطأ في الحصول على تفاصيل المكافأة:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء جلب تفاصيل المكافأة' });
  }
});

/**
 * إنشاء مكافأة جديدة (لإدارة النظام فقط)
 * POST /api/bonuses
 */
router.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    
    // التحقق من أن المستخدم له صلاحيات إدارة
    if (!req.session.user.role || req.session.user.role !== 'admin') {
      return res.status(403).json({ error: 'ليس لديك صلاحية لإنشاء مكافآت' });
    }
    
    // التحقق من صحة بيانات الطلب
    const createBonusSchema = z.object({
      targetUserId: z.number(),
      amount: z.string(),
      type: z.string(),
      description: z.string(),
      currency: z.string().default('USD'),
      expiryDays: z.number().default(30),
      conditions: z.record(z.any()).optional().default({})
    });
    
    const validationResult = createBonusSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ error: 'بيانات غير صالحة', details: validationResult.error });
    }
    
    const { targetUserId, amount, type, description, currency, expiryDays, conditions } = validationResult.data;
    
    const bonus = await BonusManager.createBonus(
      targetUserId,
      amount,
      type,
      description,
      currency,
      expiryDays,
      conditions
    );
    
    // تسجيل النشاط
    await logUserActivity({
      userId,
      type: 'admin_create_bonus',
      description: `إنشاء مكافأة ${type} بقيمة ${amount} ${currency} للمستخدم ${targetUserId}`,
      relatedEntityType: 'bonus',
      relatedEntityId: bonus.id.toString(),
      metadata: {
        bonusId: bonus.id,
        targetUserId,
        amount,
        type,
        adminId: userId
      }
    });

    return res.status(201).json(bonus);
  } catch (error) {
    console.error('خطأ في إنشاء مكافأة جديدة:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء إنشاء مكافأة جديدة' });
  }
});

/**
 * إنشاء رمز إحالة للمستخدم الحالي
 * POST /api/bonuses/referral-code
 */
router.post('/referral-code', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    
    // إنشاء رمز إحالة فريد
    const referralCode = `REF${userId}${Date.now().toString().slice(-6)}`;
    
    // تحديث رمز الإحالة للمستخدم
    await db.update(users)
      .set({ 
        referralCode,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
    
    // تسجيل النشاط
    await logUserActivity({
      userId,
      type: 'generate_referral_code',
      description: `إنشاء رمز إحالة جديد: ${referralCode}`,
      metadata: {
        referralCode
      }
    });

    return res.status(200).json({ referralCode });
  } catch (error) {
    console.error('خطأ في إنشاء رمز إحالة:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء إنشاء رمز إحالة' });
  }
});

/**
 * استخدام رمز إحالة (للمستخدمين الجدد)
 * POST /api/bonuses/use-referral
 */
router.post('/use-referral', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.user.id;
    
    // التحقق من صحة بيانات الطلب
    const useReferralSchema = z.object({
      referralCode: z.string()
    });
    
    const validationResult = useReferralSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ error: 'بيانات غير صالحة', details: validationResult.error });
    }
    
    const { referralCode } = validationResult.data;
    
    // التحقق من أن المستخدم ليس لديه إحالة بالفعل
    const [user] = await db.select()
      .from(users)
      .where(eq(users.id, userId));
      
    if (user.referredBy) {
      return res.status(400).json({ error: 'لديك إحالة بالفعل' });
    }
    
    // البحث عن المستخدم صاحب رمز الإحالة
    const [referrer] = await db.select()
      .from(users)
      .where(eq(users.referralCode, referralCode));
      
    if (!referrer) {
      return res.status(404).json({ error: 'رمز الإحالة غير صالح' });
    }
    
    if (referrer.id === userId) {
      return res.status(400).json({ error: 'لا يمكنك استخدام رمز الإحالة الخاص بك' });
    }
    
    // إنشاء سجل إحالة جديد
    const [referral] = await db.insert(referrals).values({
      referrerId: referrer.id,
      referredId: userId,
      referralCode,
      status: 'pending',
      createdAt: new Date()
    }).returning();
    
    // تحديث المستخدم بمعرف المحيل
    await db.update(users)
      .set({ 
        referredBy: referrer.id,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
    
    // تسجيل النشاط
    await logUserActivity({
      userId,
      type: 'use_referral_code',
      description: `استخدام رمز إحالة: ${referralCode}`,
      relatedEntityType: 'referral',
      relatedEntityId: referral.id.toString(),
      metadata: {
        referralId: referral.id,
        referralCode,
        referrerId: referrer.id
      }
    });

    return res.status(200).json({ success: true, message: 'تم استخدام رمز الإحالة بنجاح' });
  } catch (error) {
    console.error('خطأ في استخدام رمز إحالة:', error);
    return res.status(500).json({ error: 'حدث خطأ أثناء استخدام رمز إحالة' });
  }
});

export default router;