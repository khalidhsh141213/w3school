import { useTranslation } from '../lib/useTranslation';
import { useQuery } from '@tanstack/react-query';

interface NewsProps {
  symbol: string;
}

// Sample news items for demonstration
const mockNewsItems = [
  {
    id: 1,
    title: 'Apple Reports Record Q3 Earnings, Exceeding Wall Street Expectations',
    source: 'Bloomberg',
    time: '2 hours ago',
    imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=100&h=80&q=80',
    symbols: ['AAPL']
  },
  {
    id: 2,
    title: 'Federal Reserve Signals Potential Rate Hikes in Response to Inflation Concerns',
    source: 'CNBC',
    time: '5 hours ago',
    imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=100&h=80&q=80',
    symbols: ['SPX', 'NDX', 'DJI']
  },
  {
    id: 3,
    title: 'Tesla Unveils New Battery Technology, Promising 20% Increase in Range',
    source: 'MarketWatch',
    time: 'Yesterday',
    imageUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=100&h=80&q=80',
    symbols: ['TSLA']
  },
  {
    id: 4,
    title: 'Microsoft Cloud Revenue Surges as Enterprise Demand Remains Strong',
    source: 'Reuters',
    time: 'Yesterday',
    imageUrl: 'https://images.unsplash.com/photo-1530893609608-32a9af3aa95c?auto=format&fit=crop&w=100&h=80&q=80',
    symbols: ['MSFT']
  },
  {
    id: 5,
    title: 'Amazon Expands Same-Day Delivery to New Markets, Challenging Retail Competitors',
    source: 'Wall Street Journal',
    time: '2 days ago',
    imageUrl: 'https://images.unsplash.com/photo-1531985765804-5ceece06d24a?auto=format&fit=crop&w=100&h=80&q=80',
    symbols: ['AMZN']
  }
];

const NewsComponent = ({ symbol }: NewsProps) => {
  const { t } = useTranslation();
  
  // In a real app, this would fetch from a news API
  const { data: newsItems, isLoading } = useQuery({
    queryKey: ['/api/news', symbol],
    queryFn: async () => {
      // Simulate API call - in a real app, this would be a real API call
      return new Promise(resolve => {
        setTimeout(() => {
          // Filter news related to the selected symbol or show all if no symbol is selected
          if (symbol) {
            resolve(mockNewsItems.filter(item => item.symbols.includes(symbol)));
          } else {
            resolve(mockNewsItems);
          }
        }, 500);
      });
    }
  });

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <h2 className="text-lg font-condensed font-bold mb-3">
        {t('latestNews')}
      </h2>
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-2 text-neutral">Loading news...</div>
        ) : newsItems && newsItems.length > 0 ? (
          newsItems.slice(0, 3).map((item: any) => (
            <div className="flex space-x-3 pb-3 border-b" key={item.id}>
              <div className="flex-none">
                <svg
                  className="w-20 h-16 bg-gray-200 rounded"
                  viewBox="0 0 80 64"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect width="80" height="64" fill="#E5E7EB" />
                  <text
                    x="40"
                    y="32"
                    fontFamily="sans-serif"
                    fontSize="10"
                    textAnchor="middle"
                    alignmentBaseline="middle"
                    fill="#6B7280"
                  >
                    News
                  </text>
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{item.title}</h3>
                <div className="text-sm text-neutral">
                  <span>{item.source} • </span>
                  <span>{item.time}</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-2 text-neutral">No news available</div>
        )}
      </div>
      <button className="mt-4 text-primary text-sm font-semibold flex items-center">
        {t('viewAllNews')}
        <span className="material-icons ml-1 text-sm">arrow_forward</span>
      </button>
    </div>
  );
};

export default NewsComponent;
