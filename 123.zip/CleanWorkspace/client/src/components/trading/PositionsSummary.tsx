"use client";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Trade } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowUp, 
  ArrowDown,
  MoreHorizontal,
  X,
  RefreshCw,
  Clock,
  Loader2
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type PositionsSummaryProps = {
  userId: string | undefined;
  marketData: Record<string, any>;
};

export default function PositionsSummary({ userId, marketData }: PositionsSummaryProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("open");
  
  // Fetch user trades
  const { 
    data: trades,
    isLoading,
    error,
    refetch
  } = useQuery<Trade[]>({
    queryKey: [`/api/trades/user/${userId}`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!userId,
  });
  
  // Filter open trades
  const openTrades = trades?.filter(trade => trade.status === "open") || [];
  
  // Calculate total P/L
  const calculateTotalPnL = () => {
    if (!openTrades.length) return 0;
    
    return openTrades.reduce((total, trade) => {
      const pnl = calculatePositionPnL(trade);
      return total + pnl;
    }, 0);
  };
  
  // Calculate P/L for a position
  const calculatePositionPnL = (trade: Trade) => {
    // First try to use the current price from the trade object (updated by the server)
    // Then fall back to marketData price, then finally use entry price
    const currentPrice = trade.currentPrice || 
                         (marketData[trade.assetId]?.price) || 
                         trade.entryPrice;
    
    const entryPrice = trade.entryPrice;
    const quantity = trade.quantity;
    const leverage = trade.leverage || 1;
    
    if (trade.tradeType === "buy") {
      return (currentPrice - entryPrice) * quantity * leverage;
    } else {
      return (entryPrice - currentPrice) * quantity * leverage;
    }
  };
  
  // Calculate P/L percentage
  const calculatePnLPercentage = (trade: Trade) => {
    const pnl = calculatePositionPnL(trade);
    const positionValue = trade.entryPrice * trade.quantity;
    return (pnl / positionValue) * 100;
  };
  
  // Handle position close
  const handleClosePosition = async (tradeId: string) => {
    try {
      // Use the correct endpoint for closing a position 
      const response = await apiRequest("POST", `/api/trades/${tradeId}/close`, {});
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to close position");
      }
      
      toast({
        title: "Position closed",
        description: "Your position has been closed successfully and profit/loss added to your account",
      });
      
      // Refetch trades
      refetch();
    } catch (error) {
      console.error("Error closing position:", error);
      toast({
        title: "Error closing position",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-4 text-center">
        <p className="text-red-500">Error loading positions</p>
        <Button 
          variant="outline" 
          size="sm" 
          className="mt-2"
          onClick={() => refetch()}
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }
  
  const totalPnL = calculateTotalPnL();
  
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Positions</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => refetch()}
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="open">Open Positions</TabsTrigger>
          <TabsTrigger value="closed">Closed Positions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="open">
          {openTrades.length > 0 ? (
            <div>
              <div className="bg-muted/30 p-3 rounded-md mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-muted-foreground">Total P/L</span>
                  <span className={`font-semibold ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(totalPnL)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Open Positions</span>
                  <span>{openTrades.length}</span>
                </div>
              </div>
              
              <div className="space-y-3">
                {openTrades.map((trade) => {
                  // Get all price information  
                  const entryPrice = trade.entryPrice;
                  const assetId = trade.assetId;
                  // Use the denormalized assetSymbol field first, then fall back to marketData
                  const assetSymbol = trade.assetSymbol || 
                                     marketData[assetId]?.symbol || 
                                     `Asset #${assetId.substring(0, 6)}`;
                  
                  // Use trade.currentPrice first (from server), then fall back to marketData, then entry price
                  const currentPrice = trade.currentPrice || 
                                     marketData[assetId]?.price || 
                                     entryPrice;
                  
                  // Safely calculate P&L
                  const quantity = trade.quantity || 0;
                  const leverage = trade.leverage || 1;
                  let pnl = 0;
                  let pnlPercentage = 0;
                  
                  if (trade.tradeType === "buy") {
                    pnl = (currentPrice - entryPrice) * quantity * leverage;
                  } else {
                    pnl = (entryPrice - currentPrice) * quantity * leverage;
                  }
                  
                  if (entryPrice && quantity) {
                    pnlPercentage = (pnl / (entryPrice * quantity)) * 100;
                  }
                  
                  const openDate = trade.openedAt || new Date();
                  
                  // Check if stop loss or take profit is close to triggering
                  const stopLossDistance = trade.stopLoss ? 
                    Math.abs(((currentPrice - trade.stopLoss) / currentPrice) * 100) : 0;
                  
                  const takeProfitDistance = trade.takeProfit ? 
                    Math.abs(((currentPrice - trade.takeProfit) / currentPrice) * 100) : 0;
                  
                  const isStopLossClose = stopLossDistance < 5; // Warning if SL within 5%
                  const isTakeProfitClose = takeProfitDistance < 5; // Warning if TP within 5%
                  
                  return (
                    <div 
                      key={trade.id} 
                      className="p-3 bg-card rounded-lg border"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center">
                          <Badge 
                            variant={trade.tradeType === "buy" ? "default" : "destructive"}
                            className="mr-2 whitespace-nowrap"
                          >
                            {trade.tradeType === "buy" ? "LONG" : "SHORT"}
                          </Badge>
                          <div className="min-w-0">
                            <div className="font-medium truncate">{assetSymbol}</div>
                            <div className="text-xs text-muted-foreground flex items-center">
                              <Clock className="h-3 w-3 mr-1 flex-shrink-0" />
                              <span className="truncate">{new Date(openDate).toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Position Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleClosePosition(trade.id)}>
                              <X className="h-4 w-4 mr-2" />
                              Close Position
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div>
                          <div className="text-xs text-muted-foreground">Entry Price</div>
                          <div className="font-medium">{formatCurrency(entryPrice)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Current Price</div>
                          <div className="font-medium">{formatCurrency(currentPrice)}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div>
                          <div className="text-xs text-muted-foreground">Quantity</div>
                          <div className="font-medium">{quantity}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Leverage</div>
                          <div className="font-medium">{leverage}x</div>
                        </div>
                      </div>
                      
                      {/* Add stop loss and take profit information */}
                      {(trade.stopLoss || trade.takeProfit) && (
                        <div className="grid grid-cols-2 gap-2 mb-2">
                          {trade.stopLoss && (
                            <div>
                              <div className="text-xs text-muted-foreground">Stop Loss</div>
                              <div className={`font-medium ${isStopLossClose ? 'text-orange-500' : ''}`}>
                                {formatCurrency(trade.stopLoss)}
                                {isStopLossClose && (
                                  <span className="ml-1 text-xs">(!)</span>
                                )}
                              </div>
                            </div>
                          )}
                          {trade.takeProfit && (
                            <div>
                              <div className="text-xs text-muted-foreground">Take Profit</div>
                              <div className={`font-medium ${isTakeProfitClose ? 'text-green-500' : ''}`}>
                                {formatCurrency(trade.takeProfit)}
                                {isTakeProfitClose && (
                                  <span className="ml-1 text-xs">(!)</span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div className="border-t pt-2 mt-2">
                        <div className="flex justify-between items-center">
                          <div className="text-sm">Profit/Loss</div>
                          <div className="flex items-center">
                            <span className={`font-semibold ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(pnl)}
                            </span>
                            <span className={`ml-2 text-xs ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {pnl >= 0 ? (
                                <ArrowUp className="h-3 w-3 inline" />
                              ) : (
                                <ArrowDown className="h-3 w-3 inline" />
                              )}
                              {Math.abs(pnlPercentage).toFixed(2)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center">
              <p className="text-muted-foreground mb-2">You don't have any open positions</p>
              <p className="text-sm text-muted-foreground">
                Place a trade to open a position
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="closed">
          {trades?.filter(trade => trade.status === "closed").length ? (
            <div className="space-y-3">
              {trades?.filter(trade => trade.status === "closed").map((trade) => (
                <div 
                  key={trade.id} 
                  className="p-3 bg-card rounded-lg border"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center">
                      <Badge 
                        variant={trade.tradeType === "buy" ? "default" : "destructive"}
                        className="mr-2"
                      >
                        {trade.tradeType === "buy" ? "LONG" : "SHORT"}
                      </Badge>
                      <div>
                        <div className="font-medium">
                          {marketData[trade.assetId]?.symbol || `Asset #${trade.assetId.substring(0, 6)}`}
                        </div>
                        <div className="text-xs text-muted-foreground flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {new Date(trade.closedAt || trade.openedAt || new Date()).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <div className="text-xs text-muted-foreground">Entry Price</div>
                      <div className="font-medium">{formatCurrency(trade.entryPrice)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Close Price</div>
                      <div className="font-medium">{formatCurrency(trade.exitPrice || trade.entryPrice)}</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <div className="text-xs text-muted-foreground">Quantity</div>
                      <div className="font-medium">{trade.quantity}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">P/L</div>
                      {/* Calculate P/L based on entry and exit prices */}
                      {(() => {
                        const exitPrice = trade.exitPrice || trade.entryPrice;
                        const pnl = trade.tradeType === "buy" 
                          ? (exitPrice - trade.entryPrice) * trade.quantity * (trade.leverage || 1)
                          : (trade.entryPrice - exitPrice) * trade.quantity * (trade.leverage || 1);
                        
                        return (
                          <div className={`font-medium ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(pnl)}
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center">
              <p className="text-muted-foreground mb-2">No closed positions yet</p>
              <p className="text-sm text-muted-foreground">
                Your closed positions will appear here
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}