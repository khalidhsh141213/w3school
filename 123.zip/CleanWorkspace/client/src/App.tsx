import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useContext, useEffect, lazy, Suspense } from "react";
import { AppContext } from "./context/AppContext";
import { AuthProvider, useAuth } from "./lib/authContext";
import NotFound from "@/pages/not-found";
import WebSocketTestPage from "./pages/websocket-test";
import MainLayout from "@/components/layout/MainLayout";

// Eager loaded components 
import Dashboard from "./pages/dashboard";
import Trading from "./pages/trading-improved"; // Use the improved version
import LandingPage from "./pages/landing";
import AuthPage from "./pages/auth-page";

// Lazy loaded components
const Portfolio = lazy(() => import("./pages/portfolio"));
const WatchList = lazy(() => import("./pages/watchlist"));
const Settings = lazy(() => import("./pages/settings"));
const Discover = lazy(() => import("./pages/discover"));
const CopyTrading = lazy(() => import("./pages/copy-trading"));
const Calendar = lazy(() => import("./pages/calendar"));
const Support = lazy(() => import("./pages/support"));
const Wallet = lazy(() => import("./pages/wallet"));
const AdminPage = lazy(() => import("./pages/admin/AdminPage").then(mod => ({ default: mod.AdminPage })));

// Protected route wrapper
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/auth?tab=signin');
    }
  }, [isAuthenticated, isLoading, navigate]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return isAuthenticated ? <Component /> : null;
}

// Public route wrapper that redirects to dashboard if logged in
function PublicRoute({ component: Component, redirectIfAuthenticated = true }: { 
  component: React.ComponentType, 
  redirectIfAuthenticated?: boolean 
}) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && isAuthenticated && redirectIfAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, isLoading, navigate, redirectIfAuthenticated]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (!isAuthenticated || !redirectIfAuthenticated) ? <Component /> : null;
}

function Router() {
  const { appState } = useContext(AppContext);
  const { isAuthenticated } = useAuth();
  const [location] = useLocation();

  // Set document direction based on language
  useEffect(() => {
    document.documentElement.setAttribute('dir', appState.language === 'ar' ? 'rtl' : 'ltr');

    // Handle theme changes
    if (appState.theme === 'dark') {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [appState.language, appState.theme]);

  // Check if we're on a public route like landing or auth
  const isPublicRoute = location === '/' || location.startsWith('/auth');

  // Render content based on auth state and route
  const renderContent = () => {
    const ErrorBoundary = ({ children }) => {
      return <>{children}</>
    }
    return (
      <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
        <ErrorBoundary>
          <Switch>
            <Route path="/" component={() => <PublicRoute component={LandingPage} />} />
            <Route path="/auth" component={() => <PublicRoute component={AuthPage} />} />
            <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
            <Route path="/trading" component={() => <ProtectedRoute component={Trading} />} />
            <Route path="/trading-improved" component={() => <ProtectedRoute component={Trading} />} />
            <Route path="/portfolio" component={() => <ProtectedRoute component={Portfolio} />} />
            <Route path="/watchlist" component={() => <ProtectedRoute component={WatchList} />} />
            <Route path="/settings" component={() => <ProtectedRoute component={Settings} />} />
            <Route path="/discover" component={() => <ProtectedRoute component={Discover} />} />
            <Route path="/copy-trading" component={() => <ProtectedRoute component={CopyTrading} />} />
            <Route path="/calendar" component={() => <ProtectedRoute component={Calendar} />} />
            <Route path="/support" component={() => <ProtectedRoute component={Support} />} />
            <Route path="/wallet" component={() => <ProtectedRoute component={Wallet} />} />
            <Route path="/websocket-test" component={() => <WebSocketTestPage />} />
            <Route path="/ws-test" component={() => <WebSocketTestPage />} />
            <Route path="/admin/assets" component={() => <ProtectedRoute component={AdminPage} />} />
            <Route path="/admin/trades" component={() => <ProtectedRoute component={AdminPage} />} />
            <Route path="/admin/finances" component={() => <ProtectedRoute component={AdminPage} />} />
            <Route path="/admin/kyc" component={() => <ProtectedRoute component={AdminPage} />} />
            <Route path="/admin" component={() => <ProtectedRoute component={AdminPage} />} />
            <Route component={NotFound} />
          </Switch>
        </ErrorBoundary>
      </Suspense>
    );
  };

  // Use MainLayout for authenticated routes and direct rendering for public routes
  return isAuthenticated && !isPublicRoute ? (
    <MainLayout>{renderContent()}</MainLayout>
  ) : (
    renderContent()
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;