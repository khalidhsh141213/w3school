#!/usr/bin/env node

/**
 * Import Reference Update Script
 * 
 * This script scans the src directory for components that import deprecated components
 * and updates them to use the consolidated versions instead.
 * 
 * Usage:
 *   node scripts/update-imports.js
 */

const fs = require('fs');
const path = require('path');
const util = require('util');
const readdir = util.promisify(fs.readdir);
const readFile = util.promisify(fs.readFile);
const writeFile = util.promisify(fs.writeFile);
const stat = util.promisify(fs.stat);

// Configuration
const SRC_DIR = path.resolve(__dirname, '../src');
const EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx'];
const IMPORT_MAPPINGS = [
  {
    oldImport: /import\s+(?:{\s*)?(\w+)?(?:,\s*)?(?:(\w+))?(?:,\s*)?(?:(\w+))?(?:\s*})?\s+from\s+['"](?:\.\.\/)*(?:components\/)?(?:portfolio\/)?PortfolioSummaryWidget['"].*;/g,
    newImport: "import { PortfolioSummary } from '@/components/portfolio/PortfolioSummary';",
    componentUpdates: [
      {
        pattern: /<PortfolioSummaryWidget([^>]*)>/g,
        replacement: '<PortfolioSummary$1 variant="widget">'
      },
      {
        pattern: /<\/PortfolioSummaryWidget>/g,
        replacement: '</PortfolioSummary>'
      }
    ]
  },
  {
    oldImport: /import\s+(?:{\s*)?(\w+)?(?:,\s*)?(?:(\w+))?(?:,\s*)?(?:(\w+))?(?:\s*})?\s+from\s+['"](?:\.\.\/)*(?:components\/)?(?:trading\/)?OrderPlacementImproved['"].*;/g,
    newImport: "import { OrderPlacement } from '@/components/trading/OrderPlacement';",
    componentUpdates: [
      {
        pattern: /<OrderPlacementImproved([^>]*)>/g,
        replacement: '<OrderPlacement$1>'
      },
      {
        pattern: /<\/OrderPlacementImproved>/g,
        replacement: '</OrderPlacement>'
      }
    ]
  }
];

// Main function
async function main() {
  console.log('🔍 Scanning for files that need import updates...');
  
  let updatedFiles = 0;
  const filesToProcess = await findFiles(SRC_DIR);
  
  console.log(`Found ${filesToProcess.length} files to process.`);
  
  for (const file of filesToProcess) {
    const wasUpdated = await processFile(file);
    if (wasUpdated) {
      updatedFiles++;
    }
  }
  
  console.log(`✅ Done! Updated ${updatedFiles} files.`);
}

// Find all source files in the given directory
async function findFiles(dir) {
  const result = [];
  const items = await readdir(dir);
  
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stats = await stat(fullPath);
    
    if (stats.isDirectory()) {
      const subDirFiles = await findFiles(fullPath);
      result.push(...subDirFiles);
    } else if (stats.isFile() && EXTENSIONS.includes(path.extname(fullPath))) {
      result.push(fullPath);
    }
  }
  
  return result;
}

// Process a single file
async function processFile(filePath) {
  try {
    let content = await readFile(filePath, 'utf8');
    const originalContent = content;
    
    // Check for imports that need updating
    for (const mapping of IMPORT_MAPPINGS) {
      if (mapping.oldImport.test(content)) {
        // Replace import statement
        content = content.replace(mapping.oldImport, mapping.newImport);
        
        // Update component usage
        for (const update of mapping.componentUpdates) {
          content = content.replace(update.pattern, update.replacement);
        }
      }
    }
    
    if (content !== originalContent) {
      await writeFile(filePath, content, 'utf8');
      console.log(`Updated imports in: ${path.relative(SRC_DIR, filePath)}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`Error processing file ${filePath}:`, error);
    return false;
  }
}

// Run the script
main().catch(error => {
  console.error('Error:', error);
  process.exit(1);
}); 