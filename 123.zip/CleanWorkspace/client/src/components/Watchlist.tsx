import { useContext, useEffect, useState } from 'react';
import { AppContext } from '../context/AppContext';
import { useTranslation } from '../lib/useTranslation';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';

interface WatchlistItem {
  id: number;
  userId: number;
  symbol: string;
  name: string;
  price?: string;
  change?: string;
  changePercent?: string;
}

interface WatchlistProps {
  marketData: Record<string, any>;
}

const Watchlist = ({ marketData }: WatchlistProps) => {
  const { appState, setSelectedSymbol } = useContext(AppContext);
  const { t } = useTranslation();
  const [newSymbol, setNewSymbol] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Fetch watchlist items
  const { data: watchlistItems, isLoading } = useQuery({
    queryKey: ['/api/watchlist', appState.userId],
    queryFn: async () => {
      if (!appState.userId) return [];
      const response = await fetch(`/api/watchlist?userId=${appState.userId}`);
      if (!response.ok) throw new Error('Failed to fetch watchlist');
      return await response.json();
    },
    enabled: !!appState.userId,
  });

  // Add item to watchlist
  const addMutation = useMutation({
    mutationFn: async (item: { userId: number, symbol: string, name: string }) => {
      return apiRequest('POST', '/api/watchlist', item);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/watchlist', appState.userId] });
      setNewSymbol('');
      setShowAddForm(false);
    },
  });

  // Remove item from watchlist
  const removeMutation = useMutation({
    mutationFn: async (symbol: string) => {
      if (!appState.userId) throw new Error('User not logged in');
      return apiRequest('DELETE', `/api/watchlist/${appState.userId}/${symbol}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/watchlist', appState.userId] });
    },
  });

  // Combine watchlist items with market data
  const [enrichedItems, setEnrichedItems] = useState<WatchlistItem[]>([]);

  useEffect(() => {
    if (watchlistItems && marketData) {
      const enriched = watchlistItems.map((item: WatchlistItem) => {
        const marketInfo = marketData[item.symbol];
        if (marketInfo) {
          return {
            ...item,
            price: marketInfo.price,
            change: marketInfo.change,
            changePercent: marketInfo.changePercent
          };
        }
        return item;
      });
      setEnrichedItems(enriched);
    }
  }, [watchlistItems, marketData]);

  // Handle adding new symbol
  const handleAddSymbol = () => {
    if (!newSymbol || !appState.userId) return;
    
    addMutation.mutate({
      userId: appState.userId,
      symbol: newSymbol.toUpperCase(),
      name: getSymbolName(newSymbol.toUpperCase())
    });
  };

  // Helper to get a company name for a symbol
  const getSymbolName = (symbol: string): string => {
    const names: Record<string, string> = {
      'AAPL': 'Apple Inc.',
      'MSFT': 'Microsoft Corporation',
      'GOOGL': 'Alphabet Inc.',
      'AMZN': 'Amazon.com Inc.',
      'META': 'Meta Platforms, Inc.',
      'TSLA': 'Tesla Inc.',
      'NVDA': 'NVIDIA Corporation',
      'JPM': 'JPMorgan Chase & Co.',
      'NKE': 'Nike, Inc.'
    };
    return names[symbol] || symbol;
  };

  // Handle clicking on a watchlist item
  const handleItemClick = (symbol: string) => {
    setSelectedSymbol(symbol);
  };

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-condensed font-bold">
          {t('watchlist')}
        </h2>
        <button 
          className="text-primary"
          onClick={() => setShowAddForm(prev => !prev)}
        >
          <span className="material-icons">{showAddForm ? 'close' : 'add'}</span>
        </button>
      </div>
      
      {showAddForm && (
        <div className="mb-3 flex">
          <input
            type="text"
            value={newSymbol}
            onChange={(e) => setNewSymbol(e.target.value)}
            placeholder="AAPL, MSFT, etc."
            className="flex-1 border rounded-l px-2 py-1 text-sm dark:bg-neutral-dark dark:border-gray-700"
          />
          <button 
            onClick={handleAddSymbol}
            disabled={addMutation.isPending}
            className="bg-primary text-white px-3 py-1 rounded-r text-sm flex items-center"
          >
            {addMutation.isPending ? 'Adding...' : 'Add'}
          </button>
        </div>
      )}
      
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-2 text-neutral">Loading watchlist...</div>
        ) : enrichedItems && enrichedItems.length > 0 ? (
          enrichedItems.map((item) => (
            <div 
              className="flex justify-between items-center py-2 border-b cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
              key={item.id}
              onClick={() => handleItemClick(item.symbol)}
            >
              <div>
                <div className="font-semibold">{item.symbol}</div>
                <div className="text-xs text-neutral">{item.name}</div>
              </div>
              <div className="text-right">
                <div className="font-semibold">${item.price || '—'}</div>
                <div className={`text-xs ${parseFloat(item.changePercent || '0') >= 0 ? 'text-secondary-light' : 'text-accent-light'}`}>
                  {parseFloat(item.changePercent || '0') >= 0 ? '+' : ''}{item.changePercent || '0'}%
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-2 text-neutral">
            {appState.userId ? 'No items in watchlist' : 'Login to use watchlist'}
          </div>
        )}
      </div>
    </div>
  );
};

export default Watchlist;
