import React, { useEffect, useState } from 'react';
import { useApi } from '../hooks/useApi';
import { AssetsApi } from '../services/ApiService';
import { Asset } from '../types/schemas';

interface AssetSearchProps {
  onSelect?: (asset: Asset) => void;
  placeholder?: string;
}

/**
 * AssetSearch Component
 * 
 * A component that allows users to search for assets and select one
 */
const AssetSearch: React.FC<AssetSearchProps> = ({
  onSelect,
  placeholder = 'Search for assets...',
}) => {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [selected, setSelected] = useState<Asset | null>(null);
  
  // Setup debounce effect for search query
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(query);
    }, 300);
    
    return () => {
      clearTimeout(handler);
    };
  }, [query]);
  
  // API request for asset search
  const { data: assets, loading, error } = useApi({
    apiMethod: () => AssetsApi.search(debouncedQuery),
    dependencies: [debouncedQuery],
    skip: debouncedQuery.length < 2,
  });
  
  // API request for trending assets (shown when no search query)
  const { 
    data: trendingAssets, 
    loading: trendingLoading 
  } = useApi({
    apiMethod: AssetsApi.getTrending,
    skip: debouncedQuery.length >= 2,
  });
  
  // Handler for selecting an asset
  const handleSelect = (asset: Asset) => {
    setSelected(asset);
    setQuery(asset.symbol);
    if (onSelect) {
      onSelect(asset);
    }
  };
  
  // Determine which assets to display
  const displayAssets = debouncedQuery.length >= 2 ? assets : trendingAssets;
  const isLoading = debouncedQuery.length >= 2 ? loading : trendingLoading;
  
  return (
    <div className="asset-search">
      <div className="search-input-container">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={placeholder}
          className="search-input"
        />
        {isLoading && (
          <div className="spinner"></div>
        )}
      </div>
      
      {error && (
        <div className="error-message">
          Failed to load assets. Please try again.
        </div>
      )}
      
      {query.length > 0 && displayAssets && displayAssets.length === 0 && !isLoading && (
        <div className="no-results">
          No assets found for "{query}"
        </div>
      )}
      
      {displayAssets && displayAssets.length > 0 && (
        <ul className="asset-list">
          {displayAssets.map((asset) => (
            <li 
              key={asset.symbol} 
              className={`asset-item ${selected?.symbol === asset.symbol ? 'selected' : ''}`}
              onClick={() => handleSelect(asset)}
            >
              <div className="asset-icon">
                {asset.logo ? (
                  <img src={asset.logo} alt={asset.name} />
                ) : (
                  <div className="asset-icon-placeholder">
                    {asset.symbol.substring(0, 2)}
                  </div>
                )}
              </div>
              <div className="asset-info">
                <div className="asset-symbol">{asset.symbol}</div>
                <div className="asset-name">{asset.name}</div>
              </div>
              <div className="asset-type">
                <span className={`badge badge-${asset.type}`}>
                  {asset.type}
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}
      
      {debouncedQuery.length < 2 && !trendingLoading && (
        <div className="search-hint">
          {trendingAssets && trendingAssets.length > 0 
            ? 'Trending assets' 
            : 'Type at least 2 characters to search'}
        </div>
      )}
    </div>
  );
};

export default AssetSearch; 