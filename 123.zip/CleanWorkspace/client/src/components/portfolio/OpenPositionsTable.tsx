import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { ArrowDown, ArrowUp, MoreHorizontal, X, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useEffect, useState } from "react";

interface OpenPositionsTableProps {
  positions: any[];
  marketData: Record<string, any>;
  onRefresh: () => void;
}

export default function OpenPositionsTable({ 
  positions, 
  marketData, 
  onRefresh 
}: OpenPositionsTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [localMarketData, setLocalMarketData] = useState<Record<string, any>>(marketData || {});
  
  useEffect(() => {
    setLocalMarketData(marketData);
    
    const handleMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'price_update') {
          const relevantPosition = positions.find(
            pos => pos.assetSymbol === data.symbol || 
                   localMarketData[pos.assetId]?.symbol === data.symbol
          );
          
          if (relevantPosition) {
            setLocalMarketData(prev => ({
              ...prev,
              [relevantPosition.assetId]: {
                ...prev[relevantPosition.assetId],
                price: data.price
              }
            }));
            
            console.log(`Updated price for ${data.symbol}: ${data.price}`);
          }
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    };
    
    window.addEventListener('message', handleMessage);
    
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [marketData, positions]);
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };
  
  // Handle close position
  const handleClosePosition = async (positionId: string) => {
    try {
      const response = await apiRequest('POST', `/api/trades/${positionId}/close`, {});
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to close position');
      }
      
      // Show success message
      toast({
        title: "Position closed successfully",
        description: "Your position has been closed and P/L has been added to your account.",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/trades/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio'] });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio-summary'] });
      
      // Call onRefresh callback
      onRefresh();
    } catch (error) {
      console.error('Error closing position:', error);
      toast({
        title: "Error closing position",
        description: error instanceof Error ? error.message : 'An unexpected error occurred',
        variant: "destructive",
      });
    }
  };
  
  // Calculate position P/L
  const calculatePnL = (position: any) => {
    // Get the current price 
    const currentPrice = position.currentPrice || 
                       localMarketData[position.assetId]?.price || 
                       position.entryPrice;
    
    const entryPrice = position.entryPrice;
    const quantity = position.quantity;
    const leverage = position.leverage || 1;
    
    if (position.tradeType === "buy") {
      return (currentPrice - entryPrice) * quantity * leverage;
    } else {
      return (entryPrice - currentPrice) * quantity * leverage;
    }
  };
  
  // Calculate P/L percentage
  const calculatePnLPercentage = (position: any) => {
    const pnl = calculatePnL(position);
    const positionValue = position.entryPrice * position.quantity;
    return (pnl / positionValue) * 100;
  };
  
  // Calculate total P/L
  const totalPnL = positions.reduce((total, position) => {
    const pnl = calculatePnL(position);
    return total + pnl;
  }, 0);
  
  // Get status indicator color
  const getStatusColor = (pnl: number) => {
    if (pnl > 0) return "text-green-500";
    if (pnl < 0) return "text-red-500";
    return "text-gray-500";
  };
  
  // Add debug logging to help diagnose position data issues
  console.log("Rendering positions:", positions);
  
  // Improve the error handling by adding fallbacks for missing data
  if (!positions || !Array.isArray(positions)) {
    console.error("Invalid positions data:", positions);
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Error loading positions data</p>
        <Button 
          variant="outline" 
          size="sm" 
          className="mt-2"
          onClick={onRefresh}
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }
  
  if (positions.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No open positions</p>
        <p className="text-sm text-muted-foreground mt-2">
          Open a trade to see your positions here
        </p>
      </div>
    );
  }
  
  const getAssetSymbol = (position: any) => {
    if (position.assetSymbol) {
      return position.assetSymbol;
    }
    
    if (localMarketData[position.assetId]?.symbol) {
      return localMarketData[position.assetId].symbol;
    }
    
    return `Asset #${position.assetId.substring(0, 6)}`;
  };
  
  return (
    <div>
      <div className="bg-muted/30 p-3 rounded-md mb-4">
        <div className="flex justify-between mb-1">
          <span className="text-sm text-muted-foreground">Total P/L</span>
          <span className={`font-semibold ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(totalPnL)}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm text-muted-foreground">Open Positions</span>
          <span>{positions.length}</span>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">Asset</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="text-right">Entry Price</TableHead>
              <TableHead className="text-right">Current Price</TableHead>
              <TableHead className="text-right">Quantity</TableHead>
              <TableHead className="text-right">P/L</TableHead>
              <TableHead className="text-right">P/L %</TableHead>
              <TableHead className="text-right">SL/TP</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {positions.map((position) => {
              // Calculate time ago
              const timeAgo = position.openedAt 
                ? formatDistanceToNow(new Date(position.openedAt), { addSuffix: true })
                : '';
                
              // Get asset symbol
              const assetSymbol = getAssetSymbol(position);
              
              // Calculate P/L
              const pnl = calculatePnL(position);
              const pnlPercentage = calculatePnLPercentage(position);
              
              // Get updated price (from trade or market data)
              const currentPrice = position.currentPrice || 
                                  localMarketData[position.assetId]?.price || 
                                  position.entryPrice;
              
              return (
                <TableRow key={position.id}>
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span>{assetSymbol}</span>
                      <span className="text-xs text-muted-foreground">{timeAgo}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={position.tradeType === "buy" ? "default" : "destructive"}>
                      {position.tradeType === "buy" ? "LONG" : "SHORT"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {formatCurrency(position.entryPrice)}
                  </TableCell>
                  <TableCell className={`text-right font-mono ${
                    currentPrice > position.entryPrice ? 'text-green-500' : 
                    currentPrice < position.entryPrice ? 'text-red-500' : ''
                  }`}>
                    {formatCurrency(currentPrice)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex flex-col items-end">
                      <span>{position.quantity}</span>
                      {position.leverage > 1 && (
                        <span className="text-xs text-muted-foreground">{position.leverage}x</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className={`text-right font-medium ${getStatusColor(pnl)}`}>
                    {formatCurrency(pnl)}
                  </TableCell>
                  <TableCell className={`text-right ${getStatusColor(pnl)}`}>
                    <div className="flex items-center justify-end">
                      {pnl >= 0 ? (
                        <ArrowUp className="h-3 w-3 mr-1" />
                      ) : (
                        <ArrowDown className="h-3 w-3 mr-1" />
                      )}
                      {Math.abs(pnlPercentage).toFixed(2)}%
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex flex-col items-end text-xs">
                      {position.stopLoss && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-orange-500">
                                SL: {formatCurrency(position.stopLoss)}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Stop Loss at {formatCurrency(position.stopLoss)}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                      {position.takeProfit && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-green-500">
                                TP: {formatCurrency(position.takeProfit)}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Take Profit at {formatCurrency(position.takeProfit)}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleClosePosition(position.id)}>
                          <X className="h-4 w-4 mr-2" />
                          Close Position
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
} 