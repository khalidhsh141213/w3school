/**
 * Utility functions for formatting values
 */

/**
 * Format a number to a specified precision with commas
 * @param value Value to format
 * @param precision Number of decimal places
 * @returns Formatted number as string
 */
export function formatNumber(value: number, precision: number = 2): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  }).format(value);
}

/**
 * Format a value as currency
 * @param value Value to format
 * @param currency Currency code (default: USD)
 * @returns Formatted currency string
 */
export function formatCurrency(value: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(value);
}

/**
 * Format a value as percentage
 * @param value Value to format (e.g., 0.1542 for 15.42%)
 * @param precision Number of decimal places
 * @returns Formatted percentage string
 */
export function formatPercentage(
  value: number,
  precision: number = 2
): string {
  return new Intl.NumberFormat('en-US', {
    style: 'percent',
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  }).format(value);
}

/**
 * Format a date in a specific format
 * @param date Date to format
 * @param format Format style
 * @returns Formatted date string
 */
export function formatDate(
  date: Date | string,
  format: 'short' | 'medium' | 'long' = 'medium'
): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: format,
  }).format(dateObj);
}

/**
 * Format a date and time
 * @param date Date to format
 * @param dateFormat Date format style
 * @param timeFormat Time format style
 * @returns Formatted date and time string
 */
export function formatDateTime(
  date: Date | string,
  dateFormat: 'short' | 'medium' | 'long' = 'medium',
  timeFormat: 'short' | 'medium' | 'long' = 'short'
): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: dateFormat,
    timeStyle: timeFormat,
  }).format(dateObj);
}

/**
 * Format a time
 * @param date Date to format
 * @param format Time format style
 * @returns Formatted time string
 */
export function formatTime(
  date: Date | string,
  format: 'short' | 'medium' | 'long' = 'short'
): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  return new Intl.DateTimeFormat('en-US', {
    timeStyle: format,
  }).format(dateObj);
}

/**
 * Format a file size
 * @param bytes Size in bytes
 * @param precision Number of decimal places
 * @returns Formatted file size string
 */
export function formatFileSize(bytes: number, precision: number = 2): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(precision))} ${sizes[i]}`;
}

/**
 * Format a relative time (e.g., "2 hours ago")
 * @param date Date to format
 * @returns Formatted relative time string
 */
export function formatRelativeTime(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffInMs = now.getTime() - dateObj.getTime();
  
  // Convert milliseconds to seconds
  const diffInSecs = Math.floor(diffInMs / 1000);
  
  // Less than a minute
  if (diffInSecs < 60) {
    return diffInSecs < 5 ? 'just now' : `${diffInSecs} seconds ago`;
  }
  
  // Less than an hour
  if (diffInSecs < 3600) {
    const minutes = Math.floor(diffInSecs / 60);
    return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
  }
  
  // Less than a day
  if (diffInSecs < 86400) {
    const hours = Math.floor(diffInSecs / 3600);
    return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
  }
  
  // Less than a week
  if (diffInSecs < 604800) {
    const days = Math.floor(diffInSecs / 86400);
    return `${days} ${days === 1 ? 'day' : 'days'} ago`;
  }
  
  // Less than a month (approximation)
  if (diffInSecs < 2592000) {
    const weeks = Math.floor(diffInSecs / 604800);
    return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
  }
  
  // Less than a year (approximation)
  if (diffInSecs < 31536000) {
    const months = Math.floor(diffInSecs / 2592000);
    return `${months} ${months === 1 ? 'month' : 'months'} ago`;
  }
  
  // More than a year
  const years = Math.floor(diffInSecs / 31536000);
  return `${years} ${years === 1 ? 'year' : 'years'} ago`;
}

/**
 * Format a phone number
 * @param phoneNumber Phone number to format
 * @returns Formatted phone number
 */
export function formatPhoneNumber(phoneNumber: string): string {
  // Remove all non-digit characters
  const cleaned = phoneNumber.replace(/\D/g, '');
  
  // Format based on length (US format)
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  } else if (cleaned.length === 11 && cleaned[0] === '1') {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }
  
  // Return as is if it doesn't match expected format
  return phoneNumber;
}

/**
 * Format a number with appropriate suffix (e.g., 1st, 2nd, 3rd)
 * @param n Number to format
 * @returns Formatted number with ordinal suffix
 */
export function formatOrdinal(n: number): string {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Format a compact number (e.g., 1.2k, 1.3M)
 * @param value Number to format
 * @param precision Number of decimal places
 * @returns Formatted compact number
 */
export function formatCompactNumber(value: number, precision: number = 1): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: precision,
  }).format(value);
} 