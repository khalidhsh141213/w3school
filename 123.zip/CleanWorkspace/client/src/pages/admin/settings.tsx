import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
    Database,
    DollarSign,
    MailCheck,
    Network,
    RefreshCw,
    Save,
    Settings,
    Shield
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

// Platform settings interface
interface PlatformSettings {
  maintenanceMode: boolean;
  allowNewRegistrations: boolean;
  allowDeposits: boolean;
  allowWithdrawals: boolean;
  systemNotification: string | null;
  minimumDeposit: number;
  maximumWithdrawal: number;
  defaultLeverageOptions: number[];
  tradingFeePercentage: number;
  withdrawalFeePercentage: number;
  apiKeys: {
    polygonApiKey: string;
  };
  emailSettings: {
    smtpHost: string;
    smtpPort: number;
    smtpUser: string;
    smtpPassword: string;
    fromEmail: string;
  };
}

export default function AdminSettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<string>("general");
  
  // Initial empty settings
  const initialSettings: PlatformSettings = {
    maintenanceMode: false,
    allowNewRegistrations: true,
    allowDeposits: true,
    allowWithdrawals: true,
    systemNotification: null,
    minimumDeposit: 100,
    maximumWithdrawal: 10000,
    defaultLeverageOptions: [1, 2, 5, 10, 20, 50, 100],
    tradingFeePercentage: 0.1,
    withdrawalFeePercentage: 0.5,
    apiKeys: {
      polygonApiKey: '',
    },
    emailSettings: {
      smtpHost: '',
      smtpPort: 587,
      smtpUser: '',
      smtpPassword: '',
      fromEmail: 'noreply@example.com',
    }
  };
  
  const [settings, setSettings] = useState<PlatformSettings>(initialSettings);
  
  // Check if user is admin
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access this page.",
        variant: "destructive"
      });
      location("/");
    }
  }, [user, location, toast]);

  // Fetch platform settings
  const { data: platformSettings, isLoading: isLoadingSettings, refetch } = useQuery({
    queryKey: ["/api/admin/settings"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user && user.userRole === "admin",
    onSuccess: (data) => {
      if (data) {
        setSettings({
          ...initialSettings,
          ...data
        });
      }
    }
  });

  // Update settings mutation
  const updateSettings = useMutation({
    mutationFn: async (updatedSettings: PlatformSettings) => {
      const response = await apiRequest(
        'PUT', 
        '/api/admin/settings',
        updatedSettings
      );
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update settings');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Platform settings updated successfully",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Handle form submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings.mutate(settings);
  };

  // Handle input change
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const nameParts = name.split('.');
    
    if (nameParts.length === 1) {
      setSettings({
        ...settings,
        [name]: e.target.type === 'number' ? parseFloat(value) : value
      });
    } else if (nameParts.length === 2) {
      const [section, field] = nameParts;
      setSettings({
        ...settings,
        [section]: {
          ...settings[section as keyof PlatformSettings],
          [field]: e.target.type === 'number' ? parseFloat(value) : value
        }
      });
    }
  };

  // Handle switch change
  const handleSwitchChange = (name: string, checked: boolean) => {
    setSettings({
      ...settings,
      [name]: checked
    });
  };

  // Handle leverage options change
  const handleLeverageOptionsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const options = e.target.value.split(',').map(value => parseInt(value.trim())).filter(value => !isNaN(value));
    setSettings({
      ...settings,
      defaultLeverageOptions: options
    });
  };

  // Test email settings
  const testEmailSettings = async () => {
    try {
      const response = await apiRequest(
        'POST',
        '/api/admin/settings/test-email',
        settings.emailSettings
      );
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to test email settings');
      }
      
      toast({
        title: "Success",
        description: "Test email sent successfully",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : 'Failed to test email settings',
        variant: "destructive"
      });
    }
  };

  // Loading state
  if (isLoadingSettings || !user) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-6">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          
          <Skeleton className="h-12 w-full max-w-md" />
          
          <div className="grid gap-6">
            {Array(4).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
        </div>
      </AdminLayout>
    );
  }

  // If user is not admin, don't render the page
  if (user.userRole !== "admin") {
    return null;
  }

  return (
    <AdminLayout>
      <Helmet>
        <title>Platform Settings | Admin Dashboard</title>
      </Helmet>
      
      <div className="container mx-auto p-4 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold">Platform Settings</h1>
            <p className="text-muted-foreground">Configure and manage platform settings</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="default" size="sm" onClick={handleSubmit}>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-4">
            <TabsTrigger value="general">
              <Settings className="h-4 w-4 mr-2" />
              General
            </TabsTrigger>
            <TabsTrigger value="security">
              <Shield className="h-4 w-4 mr-2" />
              Security
            </TabsTrigger>
            <TabsTrigger value="finance">
              <DollarSign className="h-4 w-4 mr-2" />
              Finance
            </TabsTrigger>
            <TabsTrigger value="integration">
              <Database className="h-4 w-4 mr-2" />
              Integrations
            </TabsTrigger>
            <TabsTrigger value="email">
              <MailCheck className="h-4 w-4 mr-2" />
              Email
            </TabsTrigger>
          </TabsList>

          <form onSubmit={handleSubmit}>
            {/* General Settings */}
            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Site Status</CardTitle>
                  <CardDescription>Control the overall availability of the platform</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="maintenanceMode">Maintenance Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        When enabled, only admins can access the site
                      </p>
                    </div>
                    <Switch
                      id="maintenanceMode"
                      checked={settings.maintenanceMode}
                      onCheckedChange={(checked) => handleSwitchChange('maintenanceMode', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="allowNewRegistrations">Allow New Registrations</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable or disable new user registrations
                      </p>
                    </div>
                    <Switch
                      id="allowNewRegistrations"
                      checked={settings.allowNewRegistrations}
                      onCheckedChange={(checked) => handleSwitchChange('allowNewRegistrations', checked)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label htmlFor="systemNotification">System Notification</Label>
                    <Textarea
                      id="systemNotification"
                      name="systemNotification"
                      placeholder="Enter a system-wide notification message (leave empty for none)"
                      value={settings.systemNotification || ''}
                      onChange={handleChange}
                      className="min-h-[100px]"
                    />
                    <p className="text-xs text-muted-foreground">
                      This message will be displayed to all users at the top of every page
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Settings */}
            <TabsContent value="security" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>Configure security-related settings for the platform</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="passwordPolicy">Password Policy</Label>
                    <Select defaultValue="strong">
                      <SelectTrigger>
                        <SelectValue placeholder="Select password policy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic (minimum 8 characters)</SelectItem>
                        <SelectItem value="medium">Medium (minimum 10 characters, mixed case)</SelectItem>
                        <SelectItem value="strong">Strong (minimum 12 characters, mixed case, numbers, symbols)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      name="sessionTimeout"
                      type="number"
                      min="15"
                      max="1440"
                      placeholder="60"
                      defaultValue="60"
                    />
                    <p className="text-xs text-muted-foreground">
                      Time in minutes before an inactive session is automatically logged out
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enable2FA">Require 2FA for Admin</Label>
                      <p className="text-sm text-muted-foreground">
                        Force two-factor authentication for all admin accounts
                      </p>
                    </div>
                    <Switch
                      id="enable2FA"
                      defaultChecked={true}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Finance Settings */}
            <TabsContent value="finance" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Financial Settings</CardTitle>
                  <CardDescription>Configure deposit, withdrawal, and trading settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="allowDeposits">Allow Deposits</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable or disable deposit functionality platform-wide
                      </p>
                    </div>
                    <Switch
                      id="allowDeposits"
                      checked={settings.allowDeposits}
                      onCheckedChange={(checked) => handleSwitchChange('allowDeposits', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="allowWithdrawals">Allow Withdrawals</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable or disable withdrawal functionality platform-wide
                      </p>
                    </div>
                    <Switch
                      id="allowWithdrawals"
                      checked={settings.allowWithdrawals}
                      onCheckedChange={(checked) => handleSwitchChange('allowWithdrawals', checked)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="minimumDeposit">Minimum Deposit (USD)</Label>
                      <Input
                        id="minimumDeposit"
                        name="minimumDeposit"
                        type="number"
                        min="0"
                        step="0.01"
                        value={settings.minimumDeposit}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="maximumWithdrawal">Maximum Withdrawal (USD)</Label>
                      <Input
                        id="maximumWithdrawal"
                        name="maximumWithdrawal"
                        type="number"
                        min="0"
                        step="0.01"
                        value={settings.maximumWithdrawal}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="tradingFeePercentage">Trading Fee Percentage</Label>
                      <Input
                        id="tradingFeePercentage"
                        name="tradingFeePercentage"
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        value={settings.tradingFeePercentage}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="withdrawalFeePercentage">Withdrawal Fee Percentage</Label>
                      <Input
                        id="withdrawalFeePercentage"
                        name="withdrawalFeePercentage"
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        value={settings.withdrawalFeePercentage}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="defaultLeverageOptions">Default Leverage Options (comma-separated)</Label>
                      <Input
                        id="defaultLeverageOptions"
                        name="defaultLeverageOptions"
                        value={settings.defaultLeverageOptions.join(', ')}
                        onChange={handleLeverageOptionsChange}
                      />
                      <p className="text-xs text-muted-foreground">
                        List of leverage options available to users when trading
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* API Integration Settings */}
            <TabsContent value="integration" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>API Integrations</CardTitle>
                  <CardDescription>Configure external API keys and services</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiKeys.polygonApiKey">Polygon.io API Key</Label>
                    <Input
                      id="apiKeys.polygonApiKey"
                      name="apiKeys.polygonApiKey"
                      type="password"
                      value={settings.apiKeys.polygonApiKey}
                      onChange={handleChange}
                    />
                    <p className="text-xs text-muted-foreground">
                      API key for Polygon.io market data service
                    </p>
                  </div>

                  <Button variant="outline" size="sm" className="mt-2">
                    <Network className="h-4 w-4 mr-2" />
                    Test API Connection
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Email Settings */}
            <TabsContent value="email" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Email Configuration</CardTitle>
                  <CardDescription>Configure email sending settings for the platform</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="emailSettings.smtpHost">SMTP Host</Label>
                      <Input
                        id="emailSettings.smtpHost"
                        name="emailSettings.smtpHost"
                        value={settings.emailSettings.smtpHost}
                        onChange={handleChange}
                        placeholder="smtp.example.com"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="emailSettings.smtpPort">SMTP Port</Label>
                      <Input
                        id="emailSettings.smtpPort"
                        name="emailSettings.smtpPort"
                        type="number"
                        value={settings.emailSettings.smtpPort}
                        onChange={handleChange}
                        placeholder="587"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="emailSettings.smtpUser">SMTP Username</Label>
                      <Input
                        id="emailSettings.smtpUser"
                        name="emailSettings.smtpUser"
                        value={settings.emailSettings.smtpUser}
                        onChange={handleChange}
                        placeholder="username@example.com"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="emailSettings.smtpPassword">SMTP Password</Label>
                      <Input
                        id="emailSettings.smtpPassword"
                        name="emailSettings.smtpPassword"
                        type="password"
                        value={settings.emailSettings.smtpPassword}
                        onChange={handleChange}
                        placeholder="Your password"
                      />
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="emailSettings.fromEmail">From Email Address</Label>
                      <Input
                        id="emailSettings.fromEmail"
                        name="emailSettings.fromEmail"
                        type="email"
                        value={settings.emailSettings.fromEmail}
                        onChange={handleChange}
                        placeholder="noreply@example.com"
                      />
                      <p className="text-xs text-muted-foreground">
                        Email address that will appear in the "From" field of outgoing emails
                      </p>
                    </div>
                  </div>

                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={testEmailSettings}
                  >
                    <MailCheck className="h-4 w-4 mr-2" />
                    Test Email Settings
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </form>
        </Tabs>
      </div>
    </AdminLayout>
  );
} 