/**
 * Script to check if a specific port is in use (ESM version)
 * Usage: node check-port.mjs [port]
 */

// Simple script to check if a port is in use
import net from 'net';

// Get port from command line args
const port = parseInt(process.argv[2] || '0', 10);

if (!port) {
  console.error('Please provide a port number: node check-port.mjs [port]');
  process.exit(1);
}

// Check if port is in use
function isPortInUse(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    
    server.once('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        // Port is in use
        resolve(true);
      } else {
        // Error is not related to port being in use
        resolve(false);
      }
    });
    
    server.once('listening', () => {
      // Port is free, close the server and return false
      server.close();
      resolve(false);
    });
    
    server.listen(port, '0.0.0.0');
  });
}

// Check the port and print the result
(async () => {
  try {
    const inUse = await isPortInUse(port);
    
    if (inUse) {
      console.log('PORT_IN_USE');
      process.exit(0);
    } else {
      console.log('PORT_FREE');
      process.exit(0);
    }
  } catch (error) {
    console.error('ERROR:', error.message);
    process.exit(1);
  }
})(); 