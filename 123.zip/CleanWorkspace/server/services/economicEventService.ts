import { db } from '../db.js';
import { economicEvents, assets, marketData, priceHistory, portfolio, type EconomicEvent } from '../../shared/schema.js';
import { economicEventsCache } from '../cache.js';
import { desc, eq, and, sql, inArray, between, gte, lte, or } from 'drizzle-orm';
import { errorHandler, ErrorType, ErrorSeverity } from './errorHandlingService.js';
import { log } from '../vite.js';

// Cache keys with prefix to avoid collisions
const CACHE_KEY_PREFIX = 'economic_events';

/**
 * Find market price movement around an economic event
 * @param symbol Asset symbol
 * @param eventDate Event date
 * @param windowDays Days around event to analyze (before and after)
 */
export async function findMarketMovementAroundEvent(
  symbol: string, 
  eventDate: Date, 
  windowDays: number = 3
): Promise<{ 
  priceChange: number, 
  percentChange: number,
  volatility: number, 
  volumeChange: number,
  beforePrices: any[], 
  afterPrices: any[] 
}> {
  try {
    // Get price data before and after the event
    const startDate = new Date(eventDate);
    startDate.setDate(startDate.getDate() - windowDays);
    
    const endDate = new Date(eventDate);
    endDate.setDate(endDate.getDate() + windowDays);
    
    // Get daily price history
    const prices = await db
      .select()
      .from(priceHistory)
      .where(
        and(
          eq(priceHistory.symbol, symbol),
          eq(priceHistory.interval, '1d'),
          gte(priceHistory.timestamp, startDate),
          lte(priceHistory.timestamp, endDate)
        )
      )
      .orderBy(priceHistory.timestamp);
    
    // If we don't have enough data
    if (prices.length < 2) {
      return { 
        priceChange: 0, 
        percentChange: 0, 
        volatility: 0, 
        volumeChange: 0,
        beforePrices: [],
        afterPrices: []
      };
    }
    
    // Split into before and after the event
    const beforeEvent = prices.filter(p => new Date(p.timestamp) < eventDate);
    const afterEvent = prices.filter(p => new Date(p.timestamp) >= eventDate);
    
    // Calculate price change
    const beforePrice = beforeEvent.length > 0 ? parseFloat(beforeEvent[beforeEvent.length - 1].close.toString()) : 0;
    const afterPrice = afterEvent.length > 0 ? parseFloat(afterEvent[0].close.toString()) : 0;
    
    const priceChange = afterPrice - beforePrice;
    const percentChange = beforePrice > 0 ? (priceChange / beforePrice) * 100 : 0;
    
    // Calculate volatility (standard deviation of daily returns)
    let returns: number[] = [];
    for (let i = 1; i < prices.length; i++) {
      const prevClose = parseFloat(prices[i-1].close.toString());
      const currClose = parseFloat(prices[i].close.toString());
      if (prevClose > 0) {
        returns.push((currClose - prevClose) / prevClose);
      }
    }
    
    const volatility = calculateStandardDeviation(returns) * 100; // As percentage
    
    // Calculate volume change
    const beforeVolume = beforeEvent.length > 0 
      ? beforeEvent.reduce((sum, p) => sum + parseFloat(p.volume.toString()), 0) / beforeEvent.length 
      : 0;
    const afterVolume = afterEvent.length > 0 
      ? afterEvent.reduce((sum, p) => sum + parseFloat(p.volume.toString()), 0) / afterEvent.length 
      : 0;
    
    const volumeChange = beforeVolume > 0 ? ((afterVolume - beforeVolume) / beforeVolume) * 100 : 0;
    
    return {
      priceChange,
      percentChange,
      volatility,
      volumeChange,
      beforePrices: beforeEvent,
      afterPrices: afterEvent
    };
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'economicEventService',
        operation: 'findMarketMovementAroundEvent',
        symbol,
        eventDate: eventDate.toISOString()
      }
    );
    
    return { 
      priceChange: 0, 
      percentChange: 0, 
      volatility: 0, 
      volumeChange: 0,
      beforePrices: [],
      afterPrices: []
    };
  }
}

/**
 * Find events that have significantly impacted an asset
 * @param symbol Asset symbol
 * @param threshold Minimum percent change to consider significant
 * @param limit Max number of events to return
 */
export async function findSignificantEventsForAsset(
  symbol: string, 
  threshold: number = 2.0,
  limit: number = 10
): Promise<Array<EconomicEvent & { impact: string, percentChange: number }>> {
  const cacheKey = `${CACHE_KEY_PREFIX}_significant_${symbol}_${threshold}`;
  
  // Try to get from cache first
  const cached = economicEventsCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  
  try {
    // Get all events from last 6 months that might affect this asset
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    // First, get the asset to determine its country and sector
    const [asset] = await db
      .select()
      .from(assets)
      .where(eq(assets.symbol, symbol));
    
    if (!asset) {
      return [];
    }
    
    // Find events that might impact this asset
    const allEvents = await db
      .select()
      .from(economicEvents)
      .where(
        and(
          gte(economicEvents.eventDate, sixMonthsAgo),
          or(
            // Events from the same country
            eq(economicEvents.country, asset.country),
            // Global events (US, EU, Global)
            inArray(economicEvents.country, ['US', 'EU', 'Global']),
            // Events with high impact
            eq(economicEvents.impact, 'High')
          )
        )
      )
      .orderBy(desc(economicEvents.eventDate));
    
    // Calculate impact for each event
    const eventsWithImpact = await Promise.all(
      allEvents.map(async (event) => {
        const movement = await findMarketMovementAroundEvent(symbol, new Date(event.eventDate));
        return {
          ...event,
          percentChange: movement.percentChange
        };
      })
    );
    
    // Filter to significant events and sort by impact
    const significantEvents = eventsWithImpact
      .filter(event => Math.abs(event.percentChange) >= threshold)
      .sort((a, b) => Math.abs(b.percentChange) - Math.abs(a.percentChange))
      .slice(0, limit);
    
    // Cache the results
    economicEventsCache.set(cacheKey, significantEvents);
    
    return significantEvents;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'economicEventService',
        operation: 'findSignificantEventsForAsset',
        symbol
      }
    );
    
    return [];
  }
}

/**
 * Get upcoming high-impact economic events
 * @param days Number of days to look ahead
 * @param impactLevel Minimum impact level to include
 */
export async function getUpcomingEvents(
  days: number = 7,
  impactLevel: string = 'Medium'
): Promise<EconomicEvent[]> {
  const cacheKey = `${CACHE_KEY_PREFIX}_upcoming_${days}_${impactLevel}`;
  
  // Try to get from cache first
  const cached = economicEventsCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  
  try {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);
    
    // Use the requested number of days to look ahead (default is 7)
    // But we'll use a minimum of 30 days to ensure we get some results
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(startDate.getDate() + Math.max(days, 30)); // Look at least 30 days ahead
    
    let query = db
      .select()
      .from(economicEvents)
      .where(
        and(
          gte(economicEvents.eventDate, startDate),
          lte(economicEvents.eventDate, endDate)
        )
      )
      .orderBy(economicEvents.eventDate);
    
    // Add impact level filter if specified
    // Normalize impact level to lowercase to handle case-insensitive inputs
    const normalizedImpact = impactLevel.toLowerCase();
    
    // Apply filter based on normalized impact level
    // Make sure to handle case-insensitivity properly
    if (['low', 'medium', 'high'].includes(normalizedImpact)) {
      if (normalizedImpact === 'high') {
        // Only include high impact events
        query = query.where(sql`LOWER(${economicEvents.impact}) = 'high'`);
      } else if (normalizedImpact === 'medium') {
        // Include medium and high impact events
        query = query.where(sql`LOWER(${economicEvents.impact}) IN ('medium', 'high')`);
      }
      // For 'low', include all impact levels (low, medium, high)
      // No additional filter needed since this should show everything
    }
    
    const events = await query;
    
    // Cache the results
    economicEventsCache.set(cacheKey, events);
    
    return events;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'economicEventService',
        operation: 'getUpcomingEvents',
        days,
        impactLevel
      }
    );
    
    return [];
  }
}

/**
 * Get economic events that might affect a given portfolio
 * @param userId User ID
 * @param days Number of days to look ahead
 */
export async function getEventsForPortfolio(
  userId: number,
  days: number = 7
): Promise<Array<EconomicEvent & { affectedSymbols: string[] }>> {
  const cacheKey = `${CACHE_KEY_PREFIX}_portfolio_${userId}_${days}`;
  
  // Try to get from cache first
  const cached = economicEventsCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  
  try {
    // Get user's portfolio
    const portfolioItems = await db
      .select({
        symbol: portfolio.symbol,
        country: assets.country,
        sector: assets.sector,
        type: assets.type
      })
      .from(portfolio)
      .leftJoin(assets, eq(portfolio.symbol, assets.symbol))
      .where(eq(portfolio.userId, userId));
    
    if (portfolioItems.length === 0) {
      return [];
    }
    
    // Extract unique countries and sectors
    const countries = [...new Set(portfolioItems.map(item => item.country).filter(Boolean))];
    const sectors = [...new Set(portfolioItems.map(item => item.sector).filter(Boolean))];
    const symbols = portfolioItems.map(item => item.symbol);
    
    // Get upcoming events
    // Use a minimum of 30 days for consistency with the upcoming events function
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + Math.max(days, 30));
    
    const events = await db
      .select()
      .from(economicEvents)
      .where(
        and(
          gte(economicEvents.eventDate, today),
          lte(economicEvents.eventDate, futureDate),
          or(
            // Events from countries in the portfolio
            countries.length > 0 ? inArray(economicEvents.country, countries) : sql`1=0`,
            // Global events that affect everyone
            inArray(economicEvents.country, ['US', 'EU', 'Global']),
            // High impact events (with case-insensitive comparison)
            sql`LOWER(${economicEvents.impact}) = 'high'`
          )
        )
      )
      .orderBy(economicEvents.eventDate);
    
    // For each event, determine which portfolio symbols it might affect
    const eventsWithSymbols = events.map(event => {
      // Check affected assets JSON if it exists
      let affectedSymbols: string[] = [];
      
      if (event.affectedAssets) {
        try {
          const jsonAffectedAssets = Array.isArray(event.affectedAssets) 
            ? event.affectedAssets 
            : JSON.parse(event.affectedAssets as string);
          
          // Filter to only symbols in user's portfolio
          affectedSymbols = symbols.filter(s => 
            jsonAffectedAssets.includes(s)
          );
        } catch (e) {
          // Invalid JSON, ignore
        }
      }
      
      // If no explicit affected assets, use country as a proxy
      if (affectedSymbols.length === 0) {
        affectedSymbols = portfolioItems
          .filter(item => 
            // Match on country
            item.country === event.country ||
            // Global events affect everything
            ['US', 'EU', 'Global'].includes(event.country)
          )
          .map(item => item.symbol);
      }
      
      return {
        ...event,
        affectedSymbols
      };
    }).filter(event => event.affectedSymbols.length > 0);
    
    // Cache the results
    economicEventsCache.set(cacheKey, eventsWithSymbols);
    
    return eventsWithSymbols;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'economicEventService',
        operation: 'getEventsForPortfolio',
        userId,
        days
      }
    );
    
    return [];
  }
}

// Helper function to calculate standard deviation
function calculateStandardDeviation(values: number[]): number {
  if (values.length === 0) return 0;
  
  // Calculate mean
  const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
  
  // Calculate variance
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  
  // Return standard deviation
  return Math.sqrt(variance);
}

// Helper function to calculate standard deviation is defined above