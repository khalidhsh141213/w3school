
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  AlertCircle, 
  Clock 
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface EventCardProps {
  type: 'earnings' | 'dividend' | 'economic' | 'other';
  symbol: string;
  title: string;
  time: string;
  impact?: 'positive' | 'neutral' | 'negative';
  confidence?: number;
  analysis?: string;
}

export const EventCard = ({ 
  type, 
  symbol, 
  title, 
  time, 
  impact = 'neutral',
  confidence = 0,
  analysis = ''
}: EventCardProps) => {
  const getEventStyles = () => {
    const baseStyles = {
      icon: <Clock className="h-4 w-4" />,
      bgColor: 'bg-gray-100',
      textColor: 'text-gray-600',
      borderColor: 'border-l-gray-600'
    };

    if (type === 'economic') {
      return {
        icon: impact === 'positive' ? <TrendingUp className="h-4 w-4" /> :
              impact === 'negative' ? <TrendingDown className="h-4 w-4" /> :
              <Minus className="h-4 w-4" />,
        bgColor: impact === 'positive' ? 'bg-green-100' :
                impact === 'negative' ? 'bg-red-100' :
                'bg-amber-100',
        textColor: impact === 'positive' ? 'text-green-600' :
                  impact === 'negative' ? 'text-red-600' :
                  'text-amber-600',
        borderColor: impact === 'positive' ? 'border-l-green-600' :
                    impact === 'negative' ? 'border-l-red-600' :
                    'border-l-amber-600'
      };
    }

    return baseStyles;
  };
  
  const styles = getEventStyles();
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`border-l-2 ${styles.borderColor} p-2 mb-2 rounded-r-md hover:bg-gray-50 cursor-pointer transition-colors`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className={`${styles.bgColor} ${styles.textColor} p-1 rounded-md mr-2`}>
                  {styles.icon}
                </div>
                <div className="truncate">
                  <div className="font-medium text-sm">{symbol}</div>
                  <div className="text-xs text-gray-500 truncate">{title}</div>
                  <div className="text-xs text-gray-400">{time}</div>
                </div>
              </div>
              {confidence > 0 && (
                <div className="text-xs font-medium text-gray-500">
                  {Math.round(confidence * 100)}% confidence
                </div>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <div className="max-w-xs">
            <h4 className="font-medium mb-1">{title}</h4>
            {analysis && <p className="text-sm text-gray-500">{analysis}</p>}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default EventCard;
