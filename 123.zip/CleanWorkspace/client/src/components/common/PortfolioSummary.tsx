import { Badge } from "@/components/ui/badge";
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolioData } from "@/hooks/use-portfolio-data";
import { useAuth } from '@/lib/authContext';
import { getQueryFn } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { useWebSocket } from '@/services/WebSocketManager';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowDownRight, ArrowUp, ArrowUpRight, BarChart3, Clock, DollarSign, PieChart, Wallet } from "lucide-react";
import { useEffect, useRef } from "react";
import { Link } from 'wouter';

interface PortfolioSummaryData {
  id: string;
  userId: string;
  totalBalance: number;
  totalEquity: number;
  totalProfit: number;
  totalLoss: number;
  openPositions: number;
  totalInvestedAmount: number;
  availableBalance: number;
  marginUtilization: number;
  unrealizedPL: number;
  totalReturn: number;
  lastUpdated: string;
  totalValue?: number; // For backward compatibility
}

interface PortfolioSummaryProps {
  userId?: string;
  variant?: 'compact' | 'detailed' | 'dashboard' | 'widget'; // Added widget variant
  className?: string;
}

export default function PortfolioSummary({ 
  userId, 
  variant = 'detailed',
  className = '' 
}: PortfolioSummaryProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userIdToUse = userId || user?.id;
  
  // Reference to track if component is mounted
  const isMounted = useRef(true);
  
  // Use portfolio data hook when userId is provided
  const { portfolio, isLoading: isLoadingFromHook } = usePortfolioData(userIdToUse);
  
  // Fetch directly for dashboard and widget variants
  const { data: portfolioFromQuery, isLoading: isLoadingFromQuery } = useQuery({
    queryKey: ['/api/portfolio-summary', userIdToUse],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!userIdToUse && (variant === 'dashboard' || variant === 'widget'), 
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Use the WebSocket manager hook instead of direct WebSocket connection
  const { subscribe, status } = useWebSocket(
    `${process.env.NEXT_PUBLIC_WS_URL}/portfolio/${userId}`,
    {
      reconnectAttempts: 3,
      reconnectInterval: 2000,
    },
    [userId]
  );
  
  // Setup WebSocket listener for real-time updates for widget variant
  useEffect(() => {
    if (!userIdToUse || variant !== 'widget') return;
    
    // Function to handle WebSocket messages
    const handleMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        // If we receive a trade update with summary data, update the summary data
        if (data.type === 'trade_update' && data.summary && data.userId === userIdToUse) {
          console.log('Received summary update from WebSocket:', data.summary);
          
          // Update the cache with new summary data
          queryClient.setQueryData(['/api/portfolio-summary'], data.summary);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    };
    
    // Add event listener to existing WebSocket connection
    window.addEventListener('message', handleMessage);
    
    // Clean up on unmount
    return () => {
      isMounted.current = false;
      window.removeEventListener('message', handleMessage);
    };
  }, [userIdToUse, queryClient, variant]);

  // Determine which data source to use
  const portfolioData = variant === 'dashboard' || variant === 'widget' ? portfolioFromQuery : portfolio;
  const isLoading = variant === 'dashboard' || variant === 'widget' ? isLoadingFromQuery : isLoadingFromHook;
  
  // Format currency for display
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };
  
  // Format percentage for display
  const formatPercentage = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'percent',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value / 100);
  };
  
  // Loading state
  if (isLoading) {
    if (variant === 'widget') {
      return (
        <Card className={cn("w-full", className)}>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Portfolio Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {Array(8).fill(0).map((_, index) => (
                <div key={index} className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-32" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      );
    }
    
    return (
      <Card className={`border-gray-200 shadow-sm ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">
            <Skeleton className="h-6 w-32" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-5 w-24" />
          </div>
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-5 w-24" />
          </div>
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-5 w-24" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Error or no data state - for widget variant
  if ((variant === 'widget') && (!portfolioData)) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Portfolio Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            Error loading portfolio summary. Please try again later.
          </div>
        </CardContent>
      </Card>
    );
  }

  // Handle case where portfolio data isn't found - show default portfolio summary
  if (!portfolioData) {
    return (
      <Card className={`shadow-md ${className}`}>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-textDark">Portfolio Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center mb-2">
                <Wallet className="h-6 w-6 text-primary mr-2" />
                <div className="text-2xl font-bold text-textDark">
                  $50,000.00
                </div>
              </div>
              <div className="flex items-center text-sm">
                <div className="text-muted-foreground">
                  Your initial trading balance
                </div>
              </div>
              <div className="mt-2 text-sm flex items-center">
                <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-muted-foreground">Updated just now</span>
              </div>
            </div>
            
            <div className="flex flex-col md:items-end justify-center">
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">
                  <DollarSign className="h-4 w-4 mr-1" />
                  Deposit
                </Button>
                <Link href="/portfolio">
                  <Button variant="default" size="sm">
                    <BarChart3 className="h-4 w-4 mr-1" />
                    View Portfolio
                  </Button>
                </Link>
              </div>
              <div className="mt-2 text-xs text-muted-foreground md:text-right">
                Start trading to see your portfolio grow
              </div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-muted-foreground">Open Positions</div>
              <div className="font-medium">0</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Total Trades</div>
              <div className="font-medium">0</div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Widget variant (from PortfolioSummaryWidget.tsx)
  if (variant === 'widget') {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Portfolio Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Balance</p>
              <p className="text-lg font-medium">{formatCurrency(portfolioData.totalBalance)}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Equity</p>
              <p className="text-lg font-medium">{formatCurrency(portfolioData.totalEquity)}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Unrealized P/L</p>
              <p className={cn(
                "text-lg font-medium",
                portfolioData.unrealizedPL > 0 ? "text-green-500" : 
                portfolioData.unrealizedPL < 0 ? "text-red-500" : ""
              )}>
                {formatCurrency(portfolioData.unrealizedPL)}
              </p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Available Balance</p>
              <p className="text-lg font-medium">{formatCurrency(portfolioData.availableBalance)}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Profit</p>
              <p className="text-lg font-medium text-green-500">{formatCurrency(portfolioData.totalProfit)}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Loss</p>
              <p className="text-lg font-medium text-red-500">{formatCurrency(portfolioData.totalLoss)}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Open Positions</p>
              <p className="text-lg font-medium">{portfolioData.openPositions}</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Return</p>
              <p className={cn(
                "text-lg font-medium",
                portfolioData.totalReturn > 0 ? "text-green-500" : 
                portfolioData.totalReturn < 0 ? "text-red-500" : ""
              )}>
                {formatPercentage(portfolioData.totalReturn)}
              </p>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Margin Utilization</p>
              <p className="text-lg font-medium">{formatPercentage(portfolioData.marginUtilization)}</p>
            </div>
          </div>
          
          <div className="mt-4 text-xs text-muted-foreground">
            Last Updated: {new Date(portfolioData.lastUpdated).toLocaleTimeString()}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Compact variant for use in trading pages
  if (variant === 'compact') {
    return (
      <Card className={`bg-white shadow-sm border-gray-200 hover:shadow-md transition-shadow ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center">
            <BarChart3 className="h-4 w-4 mr-2 text-blue-500" />
            Portfolio Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {/* Total Value */}
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-blue-500" />
                <span className="text-sm text-gray-600">Total Value</span>
              </div>
              <span className="font-semibold text-gray-800">{formatCurrency(portfolioData.totalBalance || portfolioData.totalValue || 0)}</span>
            </div>
            
            {/* Available Balance */}
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <PieChart className="h-4 w-4 text-green-500" />
                <span className="text-sm text-gray-600">Available Balance</span>
              </div>
              <span className="font-semibold text-gray-800">{formatCurrency(portfolioData.availableBalance || 0)}</span>
            </div>
            
            {/* Unrealized P/L */}
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                {(portfolioData.unrealizedPL || 0) >= 0 ? (
                  <ArrowUp className="h-4 w-4 text-green-500" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-500" />
                )}
                <span className="text-sm text-gray-600">Unrealized P/L</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`font-semibold ${(portfolioData.unrealizedPL || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(portfolioData.unrealizedPL || 0)}
                </span>
                <Badge variant={(portfolioData.unrealizedPL || 0) >= 0 ? 'success' : 'destructive'} className="h-6 px-2">
                  {formatPercentage(portfolioData.totalReturn || 0)}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Detailed dashboard variant
  return (
    <Card className={`shadow-md ${className}`}>
      <CardHeader>
        <CardTitle className="text-xl font-bold text-textDark">Portfolio Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center mb-2">
              <DollarSign className="h-6 w-6 text-primary mr-2" />
              <div className="text-2xl font-bold text-textDark">
                {formatCurrency(portfolioData.totalBalance || portfolioData.totalValue || 0)}
              </div>
            </div>
            <div className="flex items-center text-sm">
              <div className={`flex items-center ${(portfolioData.unrealizedPL || 0) >= 0 ? 'text-green-600' : 'text-red-600'} mr-2`}>
                {(portfolioData.unrealizedPL || 0) >= 0 ? (
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 mr-1" />
                )}
                <span>{Math.abs(portfolioData.unrealizedPL || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="text-gray-500">
                {(portfolioData.totalReturn || 0) > 0 ? "+" : ""}{(portfolioData.totalReturn || 0).toFixed(2)}% overall
              </div>
            </div>
            <div className="mt-2 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
              <span className="text-muted-foreground">Updated {portfolioData.lastUpdated ? new Date(portfolioData.lastUpdated).toLocaleTimeString() : 'recently'}</span>
            </div>
          </div>
          
          <div className="flex flex-col md:items-end justify-center">
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <DollarSign className="h-4 w-4 mr-1" />
                Deposit
              </Button>
              <Link href="/portfolio">
                <Button variant="default" size="sm">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  View Portfolio
                </Button>
              </Link>
            </div>
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-muted-foreground">Open Positions</div>
            <div className="font-medium">{portfolioData.openPositions || 0}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Total P/L</div>
            <div className={`font-medium ${(portfolioData.unrealizedPL || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(portfolioData.unrealizedPL || 0)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 