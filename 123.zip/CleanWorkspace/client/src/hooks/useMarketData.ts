/**
 * useMarketData Hook
 * 
 * A specialized hook for subscribing to and managing real-time market data.
 * Built on top of the WebSocket connection hook with additional features for market data.
 * 
 * @example
 * ```tsx
 * function StockPrice({ symbol }) {
 *   const { 
 *     data, 
 *     isLoading, 
 *     error 
 *   } = useMarketData(symbol);
 *   
 *   if (isLoading) return <div>Loading...</div>;
 *   if (error) return <div>Error: {error.message}</div>;
 *   
 *   return (
 *     <div>
 *       <h2>{symbol}</h2>
 *       <div>Price: ${data.price.toFixed(2)}</div>
 *       <div>Change: {data.changePercent.toFixed(2)}%</div>
 *     </div>
 *   );
 * }
 * ```
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { ConnectionStatus, Priority } from '../services/WebSocketService';
import useWebSocketConnection from './useWebSocketConnection';
import { validateApiResponse } from '../lib/validation';
import api from '../lib/api';

// Market data interface
export interface MarketData {
  symbol: string;
  price: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  volume?: number;
  change?: number;
  changePercent: number;
  bid?: number;
  ask?: number;
  spread?: number;
  timestamp: number | string;
  lastUpdate?: number;
}

// Interface for hook options
export interface MarketDataOptions {
  // How often to poll for updates even if WebSocket is unavailable (0 to disable)
  pollingInterval?: number;
  // Whether to fetch initial data via API call
  fetchInitialData?: boolean;
  // Throttle updates to avoid too many renders (milliseconds, 0 to disable)
  throttleUpdates?: number;
  // Cache behavior
  cache?: {
    // Whether to use cached data if available
    enabled: boolean;
    // Max age of cached data in milliseconds
    maxAge: number;
  };
  // Automatically subscribe to all symbols in the array
  subscriptionSymbols?: string[];
  // Timeframe for data (e.g. '1m', '5m', '1d')
  timeframe?: string;
}

// Default options
const DEFAULT_OPTIONS: MarketDataOptions = {
  pollingInterval: 30000, // 30 seconds
  fetchInitialData: true,
  throttleUpdates: 500, // 500ms
  cache: {
    enabled: true,
    maxAge: 60000 // 1 minute
  },
  timeframe: '1m'
};

// Local cache for market data
const marketDataCache = new Map<string, {
  data: MarketData;
  timestamp: number;
}>();

/**
 * Hook for subscribing to real-time market data
 * @param symbol Symbol to subscribe to (e.g. 'AAPL', 'BTC-USD')
 * @param options Options for the hook
 * @returns Object with market data and status
 */
export function useMarketData(
  symbol?: string | string[],
  options: Partial<MarketDataOptions> = {}
) {
  // Merge options with defaults
  const mergedOptions: MarketDataOptions = {
    ...DEFAULT_OPTIONS,
    ...options,
    cache: {
      ...DEFAULT_OPTIONS.cache,
      ...options.cache
    }
  };
  
  // Store symbols as an array
  const symbols = useRef<string[]>(
    Array.isArray(symbol) ? symbol : (symbol ? [symbol] : [])
  );
  
  // If additional subscription symbols are provided, merge them
  if (mergedOptions.subscriptionSymbols) {
    symbols.current = [...new Set([
      ...symbols.current,
      ...mergedOptions.subscriptionSymbols
    ])];
  }
  
  // Store market data in state
  const [marketData, setMarketData] = useState<Record<string, MarketData>>({});
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  
  // Use WebSocket connection hook with market data endpoint
  const { 
    status, 
    subscribe, 
    send 
  } = useWebSocketConnection('/market', {
    onError: (err) => setError(err)
  });
  
  // For throttling updates
  const lastUpdateTimeRef = useRef<Record<string, number>>({});
  const pendingUpdatesRef = useRef<Record<string, MarketData>>({});
  const updateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Process pending updates
  const processPendingUpdates = useCallback(() => {
    if (Object.keys(pendingUpdatesRef.current).length === 0) {
      return;
    }
    
    setMarketData(prev => ({
      ...prev,
      ...pendingUpdatesRef.current
    }));
    
    // Clear pending updates
    pendingUpdatesRef.current = {};
    
    // Clear timeout
    updateTimeoutRef.current = null;
  }, []);
  
  // Handle market data update
  const handleMarketUpdate = useCallback((data: any) => {
    // Ensure the data is valid
    if (!data || !data.symbol) {
      console.warn('[useMarketData] Received invalid market data update:', data);
      return;
    }
    
    const now = Date.now();
    const symbol = data.symbol;
    
    // Update cache if caching is enabled
    if (mergedOptions.cache?.enabled) {
      marketDataCache.set(symbol, {
        data: data,
        timestamp: now
      });
    }
    
    // Apply throttling if enabled
    if (mergedOptions.throttleUpdates && mergedOptions.throttleUpdates > 0) {
      // Store the pending update
      pendingUpdatesRef.current[symbol] = {
        ...data,
        lastUpdate: now
      };
      
      // Check if we should schedule an update
      const lastUpdate = lastUpdateTimeRef.current[symbol] || 0;
      const timeSinceLastUpdate = now - lastUpdate;
      
      if (timeSinceLastUpdate >= mergedOptions.throttleUpdates) {
        // Update immediately if throttle time has passed
        if (updateTimeoutRef.current) {
          clearTimeout(updateTimeoutRef.current);
        }
        
        lastUpdateTimeRef.current[symbol] = now;
        processPendingUpdates();
      } else if (!updateTimeoutRef.current) {
        // Schedule an update for remaining throttle time
        const remainingTime = mergedOptions.throttleUpdates - timeSinceLastUpdate;
        updateTimeoutRef.current = setTimeout(() => {
          lastUpdateTimeRef.current[symbol] = now;
          processPendingUpdates();
        }, remainingTime);
      }
    } else {
      // No throttling, update immediately
      setMarketData(prev => ({
        ...prev,
        [symbol]: {
          ...data,
          lastUpdate: now
        }
      }));
    }
    
    // Mark as loaded
    setIsLoading(false);
  }, [mergedOptions.cache?.enabled, mergedOptions.throttleUpdates, processPendingUpdates]);
  
  // Fetch initial data via API
  const fetchInitialData = useCallback(async (symbol: string) => {
    try {
      // Check cache first if enabled
      if (mergedOptions.cache?.enabled) {
        const cached = marketDataCache.get(symbol);
        if (cached && (Date.now() - cached.timestamp) < mergedOptions.cache.maxAge) {
          handleMarketUpdate(cached.data);
          return;
        }
      }
      
      // Fetch from API otherwise
      const response = await api.market.getLatestPrice(symbol);
      
      if (response?.data) {
        handleMarketUpdate(response.data);
      } else {
        console.warn(`[useMarketData] No data returned for symbol: ${symbol}`);
      }
    } catch (err) {
      console.error(`[useMarketData] Error fetching initial data for ${symbol}:`, err);
      setError(err instanceof Error ? err : new Error(String(err)));
    }
  }, [handleMarketUpdate, mergedOptions.cache]);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    // If we have no symbols, we don't need to subscribe
    if (symbols.current.length === 0) {
      setIsLoading(false);
      return;
    }
    
    // If WebSocket is connected, subscribe to updates
    if (status === ConnectionStatus.CONNECTED) {
      // Subscribe to market updates
      const unsub = subscribe('marketUpdate', (data) => {
        // Only process if it's for a symbol we care about
        if (symbols.current.length === 0 || symbols.current.includes(data.symbol)) {
          handleMarketUpdate(data);
        }
      });
      
      // Send subscription message for each symbol
      symbols.current.forEach(sym => {
        send('subscribe', {
          channel: 'market',
          symbol: sym,
          timeframe: mergedOptions.timeframe
        }, Priority.HIGH);
      });
      
      return unsub;
    }
    
    // Fetch initial data if requested and not connected via WebSocket
    if (mergedOptions.fetchInitialData) {
      symbols.current.forEach(fetchInitialData);
    }
  }, [
    status, 
    subscribe, 
    send, 
    mergedOptions.fetchInitialData,
    mergedOptions.timeframe,
    handleMarketUpdate,
    fetchInitialData
  ]);
  
  // Set up polling if needed
  useEffect(() => {
    if (mergedOptions.pollingInterval && mergedOptions.pollingInterval > 0) {
      // Don't poll if WebSocket is connected
      if (status === ConnectionStatus.CONNECTED) {
        return;
      }
      
      const interval = setInterval(() => {
        symbols.current.forEach(fetchInitialData);
      }, mergedOptions.pollingInterval);
      
      return () => clearInterval(interval);
    }
  }, [status, mergedOptions.pollingInterval, fetchInitialData]);
  
  // Clean up timeouts on unmount
  useEffect(() => {
    return () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, []);
  
  // If we're dealing with a single symbol, return its data directly
  const data = useMemo(() => {
    if (symbols.current.length === 1) {
      return marketData[symbols.current[0]] || null;
    }
    
    // Otherwise return all data
    return marketData;
  }, [marketData]);
  
  // Determine if data is stale (older than cache max age)
  const isStale = useMemo(() => {
    if (!data) return false;
    
    const now = Date.now();
    
    if (symbols.current.length === 1) {
      const singleData = data as MarketData;
      if (!singleData.lastUpdate) return false;
      return (now - singleData.lastUpdate) > (mergedOptions.cache?.maxAge || 0);
    }
    
    // Check if any of the data is stale
    return Object.values(data as Record<string, MarketData>).some(item => {
      if (!item.lastUpdate) return false;
      return (now - item.lastUpdate) > (mergedOptions.cache?.maxAge || 0);
    });
  }, [data, mergedOptions.cache?.maxAge]);
  
  return {
    data,
    marketData, // Full data record
    isLoading: isLoading && !data,
    isStale,
    error,
    isConnected: status === ConnectionStatus.CONNECTED,
    connectionStatus: status,
    
    // Helper to subscribe to a new symbol at runtime
    subscribeToSymbol: useCallback((newSymbol: string) => {
      if (symbols.current.includes(newSymbol)) {
        return; // Already subscribed
      }
      
      // Add to symbols list
      symbols.current.push(newSymbol);
      
      // Send subscription if connected
      if (status === ConnectionStatus.CONNECTED) {
        send('subscribe', {
          channel: 'market',
          symbol: newSymbol,
          timeframe: mergedOptions.timeframe
        }, Priority.HIGH);
      } else if (mergedOptions.fetchInitialData) {
        // Fetch initial data if not connected
        fetchInitialData(newSymbol);
      }
    }, [status, send, mergedOptions.fetchInitialData, mergedOptions.timeframe, fetchInitialData]),
    
    // Helper to unsubscribe from a symbol
    unsubscribeFromSymbol: useCallback((symbolToRemove: string) => {
      const index = symbols.current.indexOf(symbolToRemove);
      if (index === -1) {
        return; // Not subscribed
      }
      
      // Remove from symbols list
      symbols.current.splice(index, 1);
      
      // Send unsubscribe if connected
      if (status === ConnectionStatus.CONNECTED) {
        send('unsubscribe', {
          channel: 'market',
          symbol: symbolToRemove
        }, Priority.NORMAL);
      }
      
      // Remove from market data
      setMarketData(prev => {
        const newData = { ...prev };
        delete newData[symbolToRemove];
        return newData;
      });
    }, [status, send])
  };
}

export default useMarketData;