import {
    InsertMarketEvent,
    InsertPortfolio,
    InsertStock,
    InsertTrader,
    InsertUser,
    InsertWatchlist,
    MarketEvent,
    marketEvents,
    Portfolio,
    portfolios,
    Stock,
    stocks,
    Trader,
    traders,
    User,
    users,
    Watchlist,
    watchlists
} from '@shared/schema';
import connectPgSimple from 'connect-pg-simple';
import { and, between, eq } from 'drizzle-orm';
import session from 'express-session';
import pkg from 'pg';
import { db } from './db';
import { IStorage } from './storage';
const { Pool } = pkg;

export class PgStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    const PostgresSessionStore = connectPgSimple(session);
    
    // Create a pg Pool to be used by connect-pg-simple
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: {
        rejectUnauthorized: false
      }
    });
    
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async getStock(id: number): Promise<Stock | undefined> {
    const result = await db.select().from(stocks).where(eq(stocks.id, id));
    return result[0];
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    const result = await db.select().from(stocks).where(eq(stocks.symbol, symbol));
    return result[0];
  }

  async getAllStocks(): Promise<Stock[]> {
    return await db.select().from(stocks);
  }

  async createStock(stock: InsertStock): Promise<Stock> {
    const result = await db.insert(stocks).values(stock).returning();
    return result[0];
  }

  async updateStock(id: number, updates: Partial<Stock>): Promise<Stock | undefined> {
    const result = await db.update(stocks)
      .set(updates)
      .where(eq(stocks.id, id))
      .returning();
    return result[0];
  }

  async getPortfolio(id: number): Promise<Portfolio | undefined> {
    const result = await db.select().from(portfolios).where(eq(portfolios.id, id));
    return result[0];
  }

  async getPortfolioByUserId(userId: number): Promise<Portfolio | undefined> {
    const result = await db.select().from(portfolios).where(eq(portfolios.userId, userId));
    return result[0];
  }

  async createPortfolio(portfolio: InsertPortfolio): Promise<Portfolio> {
    const result = await db.insert(portfolios).values(portfolio).returning();
    return result[0];
  }

  async updatePortfolio(id: number, updates: Partial<Portfolio>): Promise<Portfolio | undefined> {
    const result = await db.update(portfolios)
      .set(updates)
      .where(eq(portfolios.id, id))
      .returning();
    return result[0];
  }

  async getWatchlistsByUserId(userId: number): Promise<Watchlist[]> {
    return await db.select()
      .from(watchlists)
      .where(eq(watchlists.userId, userId));
  }

  async addToWatchlist(watchlist: InsertWatchlist): Promise<Watchlist> {
    const result = await db.insert(watchlists).values(watchlist).returning();
    return result[0];
  }

  async removeFromWatchlist(userId: number, stockId: number): Promise<boolean> {
    const result = await db.delete(watchlists)
      .where(
        and(
          eq(watchlists.userId, userId),
          eq(watchlists.stockId, stockId)
        )
      )
      .returning();
    return result.length > 0;
  }

  async getMarketEvents(startDate: Date, endDate: Date): Promise<MarketEvent[]> {
    return await db.select()
      .from(marketEvents)
      .where(
        between(marketEvents.date, startDate, endDate)
      );
  }

  async getMarketEventsByStock(stockId: number): Promise<MarketEvent[]> {
    return await db.select()
      .from(marketEvents)
      .where(eq(marketEvents.stockId, stockId));
  }

  async createMarketEvent(event: InsertMarketEvent): Promise<MarketEvent> {
    const result = await db.insert(marketEvents).values(event).returning();
    return result[0];
  }

  async getAllTraders(): Promise<Trader[]> {
    return await db.select().from(traders);
  }

  async getFeaturedTraders(): Promise<Trader[]> {
    return await db.select()
      .from(traders)
      .where(eq(traders.isFeatured, true));
  }

  async getTraderByUserId(userId: number): Promise<Trader | undefined> {
    const result = await db.select()
      .from(traders)
      .where(eq(traders.userId, userId));
    return result[0];
  }

  async createTrader(trader: InsertTrader): Promise<Trader> {
    const result = await db.insert(traders).values(trader).returning();
    return result[0];
  }

  async updateTrader(id: number, updates: Partial<Trader>): Promise<Trader | undefined> {
    const result = await db.update(traders)
      .set(updates)
      .where(eq(traders.id, id))
      .returning();
    return result[0];
  }
}