import * as React from "react"
import {
  Legend,
  Line,
  LineChart as RechartsLineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
  Bar,
  BarChart as RechartsBarChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { cn } from "@/lib/utils"

interface LineChartProps extends React.HTMLAttributes<HTMLDivElement> {
  data: any[]
  xKey: string
  yKey: string
  title?: string
  description?: string
  showXAxis?: boolean
  showYAxis?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  lineColor?: string
  height?: number | string
}

export function LineChart({
  data,
  xKey,
  yKey,
  title,
  description,
  showXAxis = true,
  showYAxis = true,
  showGrid = false,
  showTooltip = true,
  lineColor = "var(--color-primary)",
  height = "100%",
  className,
  ...props
}: LineChartProps) {
  const config = {
    [yKey]: {
      label: title,
      color: lineColor,
    },
  }

  return (
    <div className={cn("w-full space-y-2", className)} {...props}>
      {title && <h3 className="text-lg font-semibold">{title}</h3>}
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
      <div style={{ height }}>
        <ChartContainer config={config}>
          <RechartsLineChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} />}
            {showXAxis && <XAxis dataKey={xKey} tickLine={false} axisLine={false} />}
            {showYAxis && <YAxis tickLine={false} axisLine={false} />}
            {showTooltip && (
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <ChartTooltipContent
                        active={active}
                        payload={payload}
                        formatter={(value: any) => `${value}`}
                      />
                    )
                  }
                  return null
                }}
              />
            )}
            <Line
              type="monotone"
              dataKey={yKey}
              stroke={lineColor}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6, style: { fill: lineColor } }}
            />
          </RechartsLineChart>
        </ChartContainer>
      </div>
    </div>
  )
}

interface BarChartProps extends React.HTMLAttributes<HTMLDivElement> {
  data: any[]
  xKey: string
  yKey: string
  title?: string
  description?: string
  showXAxis?: boolean
  showYAxis?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  barColor?: string
  height?: number | string
}

export function BarChart({
  data,
  xKey,
  yKey,
  title,
  description,
  showXAxis = true,
  showYAxis = true,
  showGrid = false,
  showTooltip = true,
  barColor = "var(--color-primary)",
  height = "100%",
  className,
  ...props
}: BarChartProps) {
  const config = {
    [yKey]: {
      label: title,
      color: barColor,
    },
  }

  return (
    <div className={cn("w-full space-y-2", className)} {...props}>
      {title && <h3 className="text-lg font-semibold">{title}</h3>}
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
      <div style={{ height }}>
        <ChartContainer config={config}>
          <RechartsBarChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" vertical={false} />}
            {showXAxis && <XAxis dataKey={xKey} tickLine={false} axisLine={false} />}
            {showYAxis && <YAxis tickLine={false} axisLine={false} />}
            {showTooltip && (
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <ChartTooltipContent
                        active={active}
                        payload={payload}
                        formatter={(value: any) => `${value}`}
                      />
                    )
                  }
                  return null
                }}
              />
            )}
            <Bar dataKey={yKey} fill={barColor} radius={4} />
          </RechartsBarChart>
        </ChartContainer>
      </div>
    </div>
  )
}

interface PieChartProps extends React.HTMLAttributes<HTMLDivElement> {
  data: { name: string; value: number; color?: string }[]
  title?: string
  description?: string
  showTooltip?: boolean
  colors?: string[]
  height?: number | string
}

export function PieChart({
  data,
  title,
  description,
  showTooltip = true,
  colors = ["#0ea5e9", "#6366f1", "#f43f5e", "#10b981", "#f59e0b"],
  height = "100%",
  className,
  ...props
}: PieChartProps) {
  const config = data.reduce((acc, item) => {
    acc[item.name] = {
      label: item.name,
      color: item.color || colors[Object.keys(acc).length % colors.length],
    }
    return acc
  }, {} as Record<string, { label: string; color: string }>)

  return (
    <div className={cn("w-full space-y-2", className)} {...props}>
      {title && <h3 className="text-lg font-semibold">{title}</h3>}
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
      <div style={{ height }}>
        <ChartContainer config={config}>
          <RechartsPieChart margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
            {showTooltip && (
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <ChartTooltipContent
                        active={active}
                        payload={payload}
                        formatter={(value: any, name: string) => `${name}: ${value}`}
                      />
                    )
                  }
                  return null
                }}
              />
            )}
            <Legend />
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              outerRadius={80}
              dataKey="value"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color || colors[index % colors.length]} 
                />
              ))}
            </Pie>
          </RechartsPieChart>
        </ChartContainer>
      </div>
    </div>
  )
}