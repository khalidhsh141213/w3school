import { useState, useEffect } from 'react';
import axios from 'axios';

interface AiRequestOptions {
  max_length?: number;
  temperature?: number;
  num_return_sequences?: number;
}

// Define API response types
export interface AiCompletionResponse {
  text: string;
  id?: string;
  model?: string;
  timestamp?: number;
}

export interface AiChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AiChatResponse {
  response: string;
  messages: AiChatMessage[];
  id?: string;
  model?: string;
}

/**
 * Generate text using the Arabic LLM
 * @param prompt The prompt to send to the LLM
 * @param options Optional parameters for generation
 * @returns The generated text
 */
export async function generateText(
  prompt: string, 
  options: AiRequestOptions = {}
): Promise<string> {
  try {
    const response = await axios.post('/api/ai/generate', {
      prompt,
      max_length: options.max_length,
      temperature: options.temperature,
      num_return_sequences: options.num_return_sequences
    });

    return response.data.result;
  } catch (error) {
    console.error('Error generating AI response:', error);
    throw new Error('Failed to generate AI response');
  }
}

/**
 * Check if the AI service is healthy
 * @returns Whether the AI service is healthy
 */
export async function checkAiServiceHealth(): Promise<boolean> {
  try {
    const response = await axios.get('/api/ai/health');
    return response.data.success === true;
  } catch (error) {
    console.error('Error checking AI service health:', error);
    return false;
  }
}

/**
 * Get completion from AI service
 * @param prompt Text prompt to send to AI
 * @param options Optional configuration
 * @returns Promise with completion response
 */
export async function getAiCompletion(
  prompt: string,
  options: {
    model?: string;
    maxTokens?: number;
    temperature?: number;
    language?: string;
  } = {}
): Promise<AiCompletionResponse> {
  try {
    const { model = 'default', maxTokens = 500, temperature = 0.7, language = 'en' } = options;
    
    const response = await fetch('/api/ai/completion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        model,
        max_tokens: maxTokens,
        temperature,
        language,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to get AI completion');
    }

    return await response.json();
  } catch (error) {
    console.error('AI Completion error:', error);
    throw error;
  }
}

/**
 * Send chat messages to AI service
 * @param messages Array of chat messages
 * @param options Optional configuration
 * @returns Promise with chat response
 */
export async function getAiChatResponse(
  messages: AiChatMessage[],
  options: {
    model?: string;
    temperature?: number;
    language?: string;
  } = {}
): Promise<AiChatResponse> {
  try {
    const { model = 'default', temperature = 0.7, language = 'en' } = options;
    
    const response = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages,
        model,
        temperature,
        language,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to get AI chat response');
    }

    return await response.json();
  } catch (error) {
    console.error('AI Chat error:', error);
    throw error;
  }
}

/**
 * Custom hook for using AI chat functionality
 * @param initialMessages Optional initial messages
 * @param options Optional configuration
 * @returns Chat state and functions
 */
export function useAiChat(
  initialMessages: AiChatMessage[] = [],
  options: {
    model?: string;
    temperature?: number;
    language?: string;
  } = {}
) {
  const [messages, setMessages] = useState<AiChatMessage[]>(initialMessages);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  // Send user message and get AI response
  const sendMessage = async (userMessage: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Add user message to state
      const newMessages = [
        ...messages,
        { role: 'user', content: userMessage },
      ];
      setMessages(newMessages);
      
      // Get AI response
      const chatResponse = await getAiChatResponse(newMessages, options);
      
      // Add AI response to state
      setMessages([
        ...newMessages,
        { role: 'assistant', content: chatResponse.response },
      ]);
      
      return chatResponse;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Unknown error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Clear chat history
  const clearChat = () => {
    setMessages([]);
    setError(null);
  };

  return {
    messages,
    isLoading,
    error,
    sendMessage,
    clearChat,
  };
}

/**
 * Generate economic analysis for given data
 * @param data Data to analyze
 * @param options Optional configuration
 * @returns Promise with analysis response
 */
export async function generateEconomicAnalysis(
  data: any,
  options: {
    model?: string;
    type?: 'technical' | 'fundamental' | 'sentiment';
    language?: string;
  } = {}
): Promise<AiCompletionResponse> {
  try {
    const { model = 'default', type = 'technical', language = 'en' } = options;
    
    const response = await fetch('/api/ai/analysis', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        data,
        model,
        analysisType: type,
        language,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to generate economic analysis');
    }

    return await response.json();
  } catch (error) {
    console.error('AI Analysis error:', error);
    throw error;
  }
} 