#!/usr/bin/env node

/**
 * Script to scan components for API calls and add validation utilities
 *
 * This script:
 * 1. Scans components for API client usage
 * 2. Identifies response handling without validation
 * 3. Adds the appropriate import for validation utilities
 * 4. Inserts validation code for each API response
 */

const fs = require('fs');
const path = require('path');
const glob = require('glob');

// Configuration
const sourceDir = path.resolve(__dirname, '../src');
const componentsGlob = `${sourceDir}/**/*.{tsx,ts}`;
const validationImportStatement = "import { validateApiResponse } from '../lib/validation';";
const validatorImportStatement = "import { marketDataValidator, userValidator, portfolioValidator } from '../lib/validation';";

// Utility to determine relative path for imports
function getRelativeImportPath(filePath) {
  const relativePath = path.relative(path.dirname(filePath), path.join(sourceDir, 'lib'));
  return relativePath.startsWith('.') ? relativePath : `./${relativePath}`;
}

// Function to check if file contains API client usage
function containsApiClientUsage(content) {
  return content.includes('api.') && 
    (content.includes('.then(') || content.includes('await api.'));
}

// Function to check if file already has validation utilities
function hasValidationUtilities(content) {
  return content.includes('validateApiResponse') || 
         content.includes('marketDataValidator') || 
         content.includes('userValidator') || 
         content.includes('portfolioValidator');
}

// Function to detect the API endpoint being used
function detectApiEndpoint(line) {
  const endpoints = {
    'api.market': 'marketDataValidator',
    'api.users': 'userValidator',
    'api.portfolio': 'portfolioValidator',
    'api.auth': null,
    'api.assets': null,
    'api.orders': null
  };

  for (const [endpoint, validator] of Object.entries(endpoints)) {
    if (line.includes(endpoint)) {
      return { endpoint, validator };
    }
  }
  
  return { endpoint: null, validator: null };
}

// Function to add validation to API calls
function addValidationToApiCalls(content, filePath) {
  // Split the content into lines
  const lines = content.split('\n');
  const modifiedLines = [];
  let modified = false;
  let importsModified = false;
  let needsValidatorImport = false;
  
  // Track required validators
  const requiredValidators = new Set();
  
  // First pass: scan for API calls and determine required validators
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('api.') && !line.includes('validateApiResponse')) {
      const { endpoint, validator } = detectApiEndpoint(line);
      if (validator) {
        requiredValidators.add(validator);
      }
    }
  }
  
  // Second pass: add imports and validation code
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Add line to output
    modifiedLines.push(line);
    
    // Add imports after the last import statement
    if (line.includes('import ') && !importsModified && requiredValidators.size > 0) {
      const nextLine = i < lines.length - 1 ? lines[i + 1] : '';
      if (!nextLine.includes('import ')) {
        // Add validation import
        const relativePath = getRelativeImportPath(filePath);
        modifiedLines.push(`import { validateApiResponse${requiredValidators.size > 0 ? ', ' : ''}${Array.from(requiredValidators).join(', ')} } from '${relativePath}/validation';`);
        importsModified = true;
        modified = true;
      }
    }
    
    // Process API calls
    if (line.includes('api.') && !line.includes('validateApiResponse')) {
      const { endpoint, validator } = detectApiEndpoint(line);
      
      // Check if this is an async/await pattern
      if (line.includes('await api.') && validator) {
        // Replace direct assignment with validation
        const responseVarMatch = line.match(/const\s+([a-zA-Z0-9_]+)\s*=\s*await/);
        if (responseVarMatch) {
          const responseVar = responseVarMatch[1];
          const indent = line.match(/^\s*/)[0];
          
          // Replace the current line (keep it as is)
          // Add validation after the API call
          modifiedLines.push(`${indent}// Validate the response`);
          modifiedLines.push(`${indent}const validated${responseVar.charAt(0).toUpperCase() + responseVar.slice(1)} = validateApiResponse(`);
          modifiedLines.push(`${indent}  ${responseVar},`);
          modifiedLines.push(`${indent}  ${validator},`);
          modifiedLines.push(`${indent}  (error) => {`);
          modifiedLines.push(`${indent}    console.error('Validation error:', error);`);
          modifiedLines.push(`${indent}  }`);
          modifiedLines.push(`${indent});`);
          modifiedLines.push('');
          modified = true;
        }
      }
      // Check for .then() pattern
      else if (line.includes('.then(') && validator) {
        // Handle promise chain pattern - much more complex
        // Look ahead to find the .then block
        let j = i;
        let thenBlockStart = -1;
        let thenBlockEnd = -1;
        let paramName = '';
        
        while (j < lines.length) {
          if (lines[j].includes('.then(') && lines[j].match(/\.then\(\s*\(?([a-zA-Z0-9_]+)/)) {
            paramName = lines[j].match(/\.then\(\s*\(?([a-zA-Z0-9_]+)/)[1];
            thenBlockStart = j;
          }
          if (thenBlockStart >= 0 && lines[j].includes('}') && lines[j].includes('.catch(')) {
            thenBlockEnd = j;
            break;
          }
          j++;
        }
        
        if (thenBlockStart >= 0 && thenBlockEnd >= 0 && paramName) {
          // We found a complete .then block - inject validation at the start
          const indentMatch = lines[thenBlockStart + 1].match(/^\s*/);
          const indent = indentMatch ? indentMatch[0] : '  ';
          
          // Insert validation code at the beginning of the then block
          const validationCode = [
            `${indent}// Validate the response`,
            `${indent}const validated${paramName.charAt(0).toUpperCase() + paramName.slice(1)} = validateApiResponse(`,
            `${indent}  ${paramName},`,
            `${indent}  ${validator},`,
            `${indent}  (error) => {`,
            `${indent}    console.error('Validation error:', error);`,
            `${indent}  }`,
            `${indent});`,
            `${indent}if (!validated${paramName.charAt(0).toUpperCase() + paramName.slice(1)}) {`,
            `${indent}  throw new Error('Validation failed');`,
            `${indent}}`,
            ''
          ];
          
          // Insert validation code after the .then( line
          modifiedLines.splice(thenBlockStart + 1, 0, ...validationCode);
          i += validationCode.length;
          modified = true;
        }
      }
    }
  }
  
  return modified ? modifiedLines.join('\n') : null;
}

// Main function
async function main() {
  try {
    // Find all component files
    const files = glob.sync(componentsGlob);
    console.log(`Scanning ${files.length} files for API usage...`);
    
    let modifiedCount = 0;
    let skippedCount = 0;
    
    for (const file of files) {
      // Skip files in the node_modules directory
      if (file.includes('node_modules')) {
        continue;
      }
      
      const content = fs.readFileSync(file, 'utf8');
      
      // Check if file uses the API client
      if (containsApiClientUsage(content)) {
        console.log(`Found API usage in ${file}`);
        
        // Check if validation is already implemented
        if (hasValidationUtilities(content)) {
          console.log(`  ✅ File already has validation utilities`);
          skippedCount++;
          continue;
        }
        
        // Add validation to the file
        const modifiedContent = addValidationToApiCalls(content, file);
        
        if (modifiedContent) {
          // Write the modified content back to the file
          fs.writeFileSync(file, modifiedContent, 'utf8');
          console.log(`  ✅ Added validation to ${file}`);
          modifiedCount++;
        } else {
          console.log(`  ⚠️ Could not add validation to ${file}`);
          skippedCount++;
        }
      }
    }
    
    console.log('\nSummary:');
    console.log(`- Modified ${modifiedCount} files`);
    console.log(`- Skipped ${skippedCount} files (already had validation or couldn't add)`);
    console.log(`- Done!`);
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Run the script
main(); 