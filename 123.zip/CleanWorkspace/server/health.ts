/**
 * Health monitoring system for tracking service availability
 */
import axios from 'axios';
import { log } from './vite.js';
import { DatabaseStorage } from './storage.js';
import { marketDataCache, analysisCache, userCache } from './cache.js';
import pkg from 'pg';
const { Pool } = pkg;

// Service status types
export enum ServiceHealth {
  HEALTHY = 'healthy',
  DEGRADED = 'degraded',
  DOWN = 'down',
  UNKNOWN = 'unknown'
}

// Service component interface
interface ServiceComponent {
  name: string;
  status: ServiceHealth;
  lastChecked: Date;
  message: string;
  responseTime: number;
}

// Overall system health status
interface SystemHealth {
  status: ServiceHealth;
  components: ServiceComponent[];
  timestamp: Date;
  uptime: number;
  version: string;
}

// Database connection pool for health checks
const dbPool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 2, // Minimal pool size for health checks
  idleTimeoutMillis: 10000,
  connectionTimeoutMillis: 5000
});

// Track server start time for uptime calculation
const serverStartTime = new Date();
// Simple version tracking
const serviceVersion = process.env.npm_package_version || '1.0.0';

// Current health status of all components
const healthStatus: Record<string, ServiceComponent> = {
  database: {
    name: 'PostgreSQL Database',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Not checked yet',
    responseTime: 0
  },
  cache: {
    name: 'In-Memory Cache System',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Not checked yet',
    responseTime: 0
  },
  ai_service: {
    name: 'AI Analysis Service',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Not checked yet',
    responseTime: 0
  },
  deepseek_api: {
    name: 'DeepSeek API',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Not checked yet',
    responseTime: 0
  },
  market_data: {
    name: 'Market Data Service',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Not checked yet',
    responseTime: 0
  }
};

/**
 * Check database connectivity
 * @returns Promise with database health status
 */
async function checkDatabaseHealth(): Promise<ServiceComponent> {
  const component = {
    name: 'PostgreSQL Database',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Checking database connection...',
    responseTime: 0
  };
  
  const startTime = Date.now();
  
  try {
    // Use the connection pool to run a simple query
    const client = await dbPool.connect();
    try {
      const result = await client.query('SELECT NOW() as current_time');
      component.status = ServiceHealth.HEALTHY;
      component.message = `Connected successfully. Server time: ${result.rows[0].current_time}`;
    } catch (error) {
      component.status = ServiceHealth.DOWN;
      component.message = `Query error: ${error instanceof Error ? error.message : String(error)}`;
    } finally {
      client.release();
    }
  } catch (error) {
    component.status = ServiceHealth.DOWN;
    component.message = `Connection error: ${error instanceof Error ? error.message : String(error)}`;
  }
  
  component.responseTime = Date.now() - startTime;
  return component;
}

/**
 * Check cache system health
 * @returns Promise with cache health status
 */
async function checkCacheHealth(): Promise<ServiceComponent> {
  const component = {
    name: 'In-Memory Cache System',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Checking cache system...',
    responseTime: 0
  };
  
  const startTime = Date.now();
  
  try {
    // Get cache statistics
    const marketDataStats = marketDataCache.getStats();
    const analysisStats = analysisCache.getStats();
    const userStats = userCache.getStats();
    
    // Check if any cache has too many misses
    const totalHits = marketDataStats.hits + analysisStats.hits + userStats.hits;
    const totalMisses = marketDataStats.misses + analysisStats.misses + userStats.misses;
    const hitRate = totalHits + totalMisses > 0 ? totalHits / (totalHits + totalMisses) : 0;
    
    if (hitRate < 0.5 && (totalHits + totalMisses) > 50) {
      component.status = ServiceHealth.DEGRADED;
      component.message = `Cache hit rate is low (${(hitRate * 100).toFixed(1)}%)`;
    } else {
      component.status = ServiceHealth.HEALTHY;
      component.message = `Caches operating normally. Hit rate: ${(hitRate * 100).toFixed(1)}%`;
    }
  } catch (error) {
    component.status = ServiceHealth.DEGRADED;
    component.message = `Cache check error: ${error instanceof Error ? error.message : String(error)}`;
  }
  
  component.responseTime = Date.now() - startTime;
  return component;
}

/**
 * Check AI service health
 * @returns Promise with AI service health status
 */
async function checkAiServiceHealth(): Promise<ServiceComponent> {
  const component = {
    name: 'AI Analysis Service',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Checking AI service connection...',
    responseTime: 0
  };
  
  const startTime = Date.now();
  const aiServiceUrl = process.env.AI_SERVICE_URL || 'http://0.0.0.0:5000';
  
  try {
    // Try to connect to the AI service health endpoint
    const response = await axios.get(`${aiServiceUrl}/health`, { 
      timeout: 3000 
    });
    
    if (response.status === 200 && response.data.status === 'healthy') {
      component.status = ServiceHealth.HEALTHY;
      component.message = 'AI service is responding normally';
    } else {
      component.status = ServiceHealth.DEGRADED;
      component.message = `AI service returned unexpected status: ${response.data.status || 'unknown'}`;
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.code === 'ECONNREFUSED') {
      component.status = ServiceHealth.DOWN;
      component.message = 'AI service is not running';
    } else {
      component.status = ServiceHealth.DEGRADED;
      component.message = `AI service check error: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
  
  component.responseTime = Date.now() - startTime;
  return component;
}

/**
 * Check DeepSeek API health (without making actual API calls)
 * @returns Promise with DeepSeek API health status
 */
async function checkDeepSeekApiHealth(): Promise<ServiceComponent> {
  const component = {
    name: 'DeepSeek API',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Checking DeepSeek API configuration...',
    responseTime: 0
  };
  
  const deepseekApiKey = process.env.DEEPSEEK_API_KEY;
  
  if (!deepseekApiKey) {
    component.status = ServiceHealth.UNKNOWN;
    component.message = 'DeepSeek API key not configured';
  } else {
    // We don't want to make actual API calls to check health to avoid using quota
    // Just verify we have credentials
    component.status = ServiceHealth.HEALTHY;
    component.message = 'DeepSeek API credentials configured';
  }
  
  return component;
}

/**
 * Check market data service health
 * @returns Promise with market data service health status
 */
async function checkMarketDataHealth(): Promise<ServiceComponent> {
  const component = {
    name: 'Market Data Service',
    status: ServiceHealth.UNKNOWN,
    lastChecked: new Date(),
    message: 'Checking market data...',
    responseTime: 0
  };
  
  const startTime = Date.now();
  
  try {
    // Try to fetch market data
    const storage = new DatabaseStorage();
    const marketData = await storage.getAllMarketData();
    
    if (marketData && marketData.length > 0) {
      // Check how recent the data is
      const mostRecent = marketData.reduce((latest: Date, item: any) => {
        const itemDate = new Date(item.updatedAt);
        return itemDate > latest ? itemDate : latest;
      }, new Date(0));
      
      const now = new Date();
      const diffMinutes = (now.getTime() - mostRecent.getTime()) / (1000 * 60);
      
      if (diffMinutes > 60) {
        // Data is older than 60 minutes
        component.status = ServiceHealth.DEGRADED;
        component.message = `Market data has not been updated in ${Math.round(diffMinutes)} minutes`;
      } else {
        component.status = ServiceHealth.HEALTHY;
        component.message = `Market data is current. Last update: ${diffMinutes.toFixed(1)} minutes ago`;
      }
    } else {
      component.status = ServiceHealth.DEGRADED;
      component.message = 'No market data available';
    }
  } catch (error) {
    component.status = ServiceHealth.DOWN;
    component.message = `Market data service error: ${error instanceof Error ? error.message : String(error)}`;
  }
  
  component.responseTime = Date.now() - startTime;
  return component;
}

/**
 * Run all health checks and update the health status
 */
export async function runHealthChecks(): Promise<SystemHealth> {
  try {
    // Run all health checks in parallel
    const [dbHealth, cacheHealth, aiHealth, deepseekHealth, marketDataHealth] = await Promise.all([
      checkDatabaseHealth(),
      checkCacheHealth(),
      checkAiServiceHealth(),
      checkDeepSeekApiHealth(),
      checkMarketDataHealth()
    ]);
    
    // Update the global health status
    healthStatus.database = dbHealth;
    healthStatus.cache = cacheHealth;
    healthStatus.ai_service = aiHealth;
    healthStatus.deepseek_api = deepseekHealth;
    healthStatus.market_data = marketDataHealth;
    
    // Calculate overall system health
    const components = Object.values(healthStatus);
    let overallStatus = ServiceHealth.HEALTHY;
    
    // If any component is DOWN, system is DOWN
    if (components.some(c => c.status === ServiceHealth.DOWN)) {
      overallStatus = ServiceHealth.DOWN;
    } 
    // Otherwise, if any component is DEGRADED, system is DEGRADED
    else if (components.some(c => c.status === ServiceHealth.DEGRADED)) {
      overallStatus = ServiceHealth.DEGRADED;
    }
    // Otherwise, if any component is UNKNOWN, overall status is DEGRADED
    else if (components.some(c => c.status === ServiceHealth.UNKNOWN)) {
      overallStatus = ServiceHealth.DEGRADED;
    }
    
    // Calculate uptime in seconds
    const uptime = Math.floor((new Date().getTime() - serverStartTime.getTime()) / 1000);
    
    // Return the complete system health
    return {
      status: overallStatus,
      components,
      timestamp: new Date(),
      uptime,
      version: serviceVersion
    };
  } catch (error) {
    log(`Error running health checks: ${error}`, 'health');
    
    // Return a degraded status on error
    return {
      status: ServiceHealth.DEGRADED,
      components: Object.values(healthStatus),
      timestamp: new Date(),
      uptime: Math.floor((new Date().getTime() - serverStartTime.getTime()) / 1000),
      version: serviceVersion
    };
  }
}

// Initialize health monitoring
export function initializeHealthMonitoring(intervalSeconds = 60): NodeJS.Timeout {
  // Run health checks immediately
  runHealthChecks().then(health => {
    log(`Initial health check: System is ${health.status}`, 'health');
  });
  
  // Set up periodic health checks
  return setInterval(async () => {
    try {
      const health = await runHealthChecks();
      // Only log if status changes or if there are issues
      if (health.status !== ServiceHealth.HEALTHY) {
        log(`Health check: System is ${health.status}`, 'health');
        
        // Log details of unhealthy components
        health.components
          .filter(c => c.status !== ServiceHealth.HEALTHY)
          .forEach(c => {
            log(`- ${c.name}: ${c.status} - ${c.message}`, 'health');
          });
      }
    } catch (error) {
      log(`Error in scheduled health check: ${error}`, 'health');
    }
  }, intervalSeconds * 1000);
}

// Cleanup function to close database connections when shutting down
export function cleanupHealthMonitoring(): void {
  dbPool.end().catch(err => {
    log(`Error closing health check DB pool: ${err}`, 'health');
  });
}