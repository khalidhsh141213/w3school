import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/lib/authContext';
import { Bell, LifeBuoy, LogOut, Menu, Search, Settings, TrendingUp, User, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import LanguageSwitcher from './LanguageSwitcher';

interface HeaderProps {
  mobileSidebarOpen: boolean;
  setMobileSidebarOpen: (open: boolean) => void;
}

export default function Header({ mobileSidebarOpen, setMobileSidebarOpen }: HeaderProps) {
  const { t } = useTranslation();
  const { user, logout } = useAuth();
  
  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user || !user.username) return "UT";
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <header className="bg-background/95 backdrop-blur-lg shadow-sm z-20 relative border-b border-border sticky top-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              aria-label={mobileSidebarOpen ? "Close menu" : "Open menu"}
              onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
              className="md:hidden mr-2 text-primary hover:text-primary/80 hover:bg-primary/10"
            >
              {mobileSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            
            <div className="flex-shrink-0 flex items-center">
              <div className="h-9 w-9 rounded-md bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-white shadow-md">
                <TrendingUp className="h-5 w-5" />
              </div>
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent hidden sm:block">TradePro</span>
            </div>
          </div>
          
          <div className="flex-1 mx-6 max-w-md hidden sm:block">
            <div className="w-full relative">
              <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-muted-foreground" />
              </div>
              <Input 
                className="pl-10 h-9 bg-background border-border/50 focus-visible:ring-primary/20 transition-all" 
                placeholder={t('common.search')}
                type="search"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Language Switcher */}
            <LanguageSwitcher />
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative hover:bg-muted/80 transition-all rounded-full h-9 w-9"
                  aria-label={t('common.notifications')}
                >
                  <Bell className="h-5 w-5 text-foreground/80" />
                  <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary/40 opacity-75"></span>
                    <Badge className="h-4 w-4 p-0 flex items-center justify-center text-[10px] bg-primary">3</Badge>
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 p-0 rounded-xl shadow-xl border-border">
                <div className="flex items-center justify-between p-4 border-b border-border/50">
                  <DropdownMenuLabel className="text-base m-0 p-0">{t('common.notifications')}</DropdownMenuLabel>
                  <Badge variant="outline" className="text-xs font-normal">3 {t('common.new')}</Badge>
                </div>
                <div className="max-h-[320px] overflow-auto">
                  <div className="p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">{t('notifications.marketAlert')}</div>
                        <div className="text-xs text-muted-foreground mt-1">{t('notifications.btcReachedTarget')}</div>
                        <div className="text-xs text-muted-foreground/70 mt-1">{t('notifications.timeAgo.minutes', { count: 2 })}</div>
                      </div>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <div className="p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <Bell className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">{t('notifications.tradeCompleted')}</div>
                        <div className="text-xs text-muted-foreground mt-1">{t('notifications.orderFilled')}</div>
                        <div className="text-xs text-muted-foreground/70 mt-1">{t('notifications.timeAgo.hours', { count: 1 })}</div>
                      </div>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <div className="p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                        <Settings className="h-4 w-4 text-amber-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">{t('notifications.accountSecurity')}</div>
                        <div className="text-xs text-muted-foreground mt-1">{t('notifications.newLogin')}</div>
                        <div className="text-xs text-muted-foreground/70 mt-1">{t('notifications.timeAgo.days', { count: 2 })}</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-3 border-t border-border/50">
                  <Button variant="ghost" size="sm" className="w-full justify-center text-xs text-primary">
                    {t('common.viewAll')}
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="rounded-full h-9 px-2 hover:bg-muted/80 transition-all"
                >
                  <Avatar className="h-8 w-8 mr-2 ring-2 ring-primary/20 ring-offset-2 ring-offset-background">
                    <AvatarImage src={user?.profileImage || ''} alt={user?.username || 'User'} />
                    <AvatarFallback className="bg-gradient-to-br from-primary to-blue-500 text-white text-xs">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-medium text-sm hidden md:inline mr-1">{user?.username || 'User'}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 mt-1 p-0 rounded-xl shadow-xl border-border">
                <div className="p-3 border-b border-border/50 bg-muted/30">
                  <div className="font-medium">{user?.username || 'User'}</div>
                  <div className="text-xs text-muted-foreground">{user?.email || 'user@example.com'}</div>
                </div>
                <div className="p-2">
                  <Link href="/portfolio">
                    <DropdownMenuItem className="cursor-pointer rounded-lg mb-1 focus:bg-muted/80">
                      <User className="mr-2 h-4 w-4" />
                      <span>{t('common.profile')}</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/settings">
                    <DropdownMenuItem className="cursor-pointer rounded-lg mb-1 focus:bg-muted/80">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>{t('common.settings')}</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem asChild>
                    <Link href="/support">
                      <LifeBuoy className="mr-2 h-4 w-4" />
                      <span>{t('common.support')}</span>
                    </Link>
                  </DropdownMenuItem>
                </div>
                <DropdownMenuSeparator />
                <div className="p-2">
                  <DropdownMenuItem onClick={logout} className="cursor-pointer rounded-lg text-red-500 focus:text-red-500 focus:bg-red-50/80">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{t('common.logout')}</span>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Mobile search, shown on small screens */}
      <div className="px-4 pb-3 sm:hidden">
        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-muted-foreground" />
          </div>
          <Input 
            className="pl-9 text-sm h-9 bg-background border-border/50" 
            placeholder={t('common.searchMobile')}
            type="search"
          />
        </div>
      </div>
    </header>
  );
}
