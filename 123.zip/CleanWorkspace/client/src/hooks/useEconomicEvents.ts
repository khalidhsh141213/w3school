/**
 * useEconomicEvents Hook
 * 
 * A hook for subscribing to and managing economic event data.
 * Provides real-time updates for economic indicators, news, and calendar events.
 * 
 * @example
 * ```tsx
 * function EconomicCalendar() {
 *   const { 
 *     events, 
 *     isLoading, 
 *     error,
 *     filterByCategory 
 *   } = useEconomicEvents();
 *   
 *   // Filter to show only high-impact events
 *   const highImpactEvents = filterByCategory('high_impact');
 *   
 *   if (isLoading) return <div>Loading...</div>;
 *   if (error) return <div>Error: {error.message}</div>;
 *   
 *   return (
 *     <div>
 *       <h2>Economic Calendar</h2>
 *       <div className="events-list">
 *         {highImpactEvents.map(event => (
 *           <EventCard 
 *             key={event.id} 
 *             event={event} 
 *           />
 *         ))}
 *       </div>
 *     </div>
 *   );
 * }
 * ```
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ConnectionStatus, Priority } from '../services/WebSocketService';
import useWebSocketConnection from './useWebSocketConnection';
import api from '../lib/api';

// Economic event data interface
export interface EconomicEvent {
  id: string;
  title: string;
  description?: string;
  country: string;
  category: string;
  impact: 'low' | 'medium' | 'high';
  date: string;
  time?: string;
  actual?: string | number;
  forecast?: string | number;
  previous?: string | number;
  unit?: string;
  source?: string;
  url?: string;
  relatedAssets?: string[];
  createdAt: string;
  updatedAt: string;
}

// Types of economic event categories
export type EventCategory = 
  'interest_rate' | 
  'gdp' | 
  'employment' | 
  'inflation' | 
  'trade' | 
  'consumer' | 
  'housing' | 
  'central_bank' | 
  'high_impact' | 
  'earnings' | 
  'all';

// Interface for hook options
export interface EconomicEventsOptions {
  // How often to poll for updates even if WebSocket is unavailable (0 to disable)
  pollingInterval?: number;
  // Whether to fetch initial data via API call
  fetchInitialData?: boolean;
  // Throttle updates to avoid too many renders (milliseconds, 0 to disable)
  throttleUpdates?: number;
  // Cache behavior
  cache?: {
    // Whether to use cached data if available
    enabled: boolean;
    // Max age of cached data in milliseconds
    maxAge: number;
  };
  // Filter events by categories
  categories?: EventCategory[];
  // Filter events by date range
  dateRange?: {
    start?: Date;
    end?: Date;
  };
  // Maximum number of events to fetch/keep
  limit?: number;
}

// Default options
const DEFAULT_OPTIONS: EconomicEventsOptions = {
  pollingInterval: 60000, // 1 minute
  fetchInitialData: true,
  throttleUpdates: 1000, // 1 second (economic data doesn't change as rapidly)
  cache: {
    enabled: true,
    maxAge: 300000 // 5 minutes
  },
  categories: ['all'],
  limit: 100
};

// Local cache for economic events
const eventsCache = new Map<string, {
  data: EconomicEvent[];
  timestamp: number;
}>();

// Helper function to create a cache key from options
function createCacheKey(options: EconomicEventsOptions): string {
  const categories = options.categories?.join(',') || 'all';
  const start = options.dateRange?.start?.toISOString().substring(0, 10) || 'none';
  const end = options.dateRange?.end?.toISOString().substring(0, 10) || 'none';
  const limit = options.limit || 100;
  
  return `${categories}:${start}:${end}:${limit}`;
}

/**
 * Hook for working with economic event data
 * @param options Options for the hook
 * @returns Object with economic event data and utility functions
 */
export function useEconomicEvents(options: Partial<EconomicEventsOptions> = {}) {
  // Merge options with defaults
  const mergedOptions: EconomicEventsOptions = {
    ...DEFAULT_OPTIONS,
    ...options,
    cache: {
      ...DEFAULT_OPTIONS.cache,
      ...options.cache
    },
    categories: options.categories || DEFAULT_OPTIONS.categories,
    dateRange: {
      ...options.dateRange
    }
  };
  
  // Generate a cache key for the current options
  const cacheKey = useMemo(() => createCacheKey(mergedOptions), [
    mergedOptions.categories,
    mergedOptions.dateRange?.start,
    mergedOptions.dateRange?.end,
    mergedOptions.limit
  ]);
  
  // State
  const [events, setEvents] = useState<EconomicEvent[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [lastUpdateTime, setLastUpdateTime] = useState<number>(0);
  
  // For throttling updates
  const updateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Use our WebSocket connection hook
  const {
    status,
    subscribe,
    subscribeTopic,
    isConnected
  } = useWebSocketConnection('/economic');
  
  // Handle economic event updates
  const handleEventsUpdate = useCallback((data: any) => {
    if (!data || !Array.isArray(data)) {
      console.warn('[useEconomicEvents] Received invalid events update:', data);
      return;
    }
    
    const now = Date.now();
    
    // Update cache if enabled
    if (mergedOptions.cache?.enabled) {
      eventsCache.set(cacheKey, {
        data: data,
        timestamp: now
      });
    }
    
    // Apply throttling if enabled
    if (mergedOptions.throttleUpdates && mergedOptions.throttleUpdates > 0) {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      
      const timeSinceLastUpdate = now - lastUpdateTime;
      
      if (timeSinceLastUpdate >= mergedOptions.throttleUpdates) {
        // Update immediately
        setEvents(data);
        setLastUpdateTime(now);
      } else {
        // Schedule update
        updateTimeoutRef.current = setTimeout(() => {
          setEvents(data);
          setLastUpdateTime(now);
        }, mergedOptions.throttleUpdates - timeSinceLastUpdate);
      }
    } else {
      // No throttling, update immediately
      setEvents(data);
      setLastUpdateTime(now);
    }
    
    // Mark as loaded
    setIsLoading(false);
  }, [cacheKey, lastUpdateTime, mergedOptions.cache?.enabled, mergedOptions.throttleUpdates]);
  
  // Fetch initial events data
  const fetchEventsData = useCallback(async () => {
    try {
      // Check cache first if enabled
      if (mergedOptions.cache?.enabled) {
        const cached = eventsCache.get(cacheKey);
        if (cached && (Date.now() - cached.timestamp) < mergedOptions.cache.maxAge) {
          handleEventsUpdate(cached.data);
          return;
        }
      }
      
      // Build query parameters
      const params: Record<string, any> = {
        limit: mergedOptions.limit
      };
      
      // Add categories if not 'all'
      if (mergedOptions.categories?.length === 1 && mergedOptions.categories[0] !== 'all') {
        params.category = mergedOptions.categories[0];
      } else if (mergedOptions.categories && mergedOptions.categories.length > 0 && !mergedOptions.categories.includes('all')) {
        params.categories = mergedOptions.categories.join(',');
      }
      
      // Add date range if specified
      if (mergedOptions.dateRange?.start) {
        params.start_date = mergedOptions.dateRange.start.toISOString().substring(0, 10);
      }
      
      if (mergedOptions.dateRange?.end) {
        params.end_date = mergedOptions.dateRange.end.toISOString().substring(0, 10);
      }
      
      // Fetch events from API
      const response = await api.get('/api/economic-events', params);
      
      if (response.data?.items) {
        handleEventsUpdate(response.data.items);
      } else {
        console.warn('[useEconomicEvents] No events returned from API');
        handleEventsUpdate([]);
      }
    } catch (err) {
      console.error('[useEconomicEvents] Error fetching events:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
      setIsLoading(false);
    }
  }, [cacheKey, handleEventsUpdate, mergedOptions]);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    // If WebSocket is connected, subscribe to updates
    if (status === ConnectionStatus.CONNECTED) {
      // Subscribe to economic events updates
      const unsubscribe = subscribe('economicEvents', (data) => {
        if (Array.isArray(data)) {
          // Filter events based on categories if needed
          let filteredEvents = data;
          
          if (mergedOptions.categories && 
              mergedOptions.categories.length > 0 && 
              !mergedOptions.categories.includes('all')) {
            filteredEvents = data.filter(event => 
              mergedOptions.categories?.includes(event.category as EventCategory) ||
              // Special case for high impact events
              (mergedOptions.categories?.includes('high_impact') && event.impact === 'high')
            );
          }
          
          // Filter by date range if needed
          if (mergedOptions.dateRange?.start || mergedOptions.dateRange?.end) {
            filteredEvents = filteredEvents.filter(event => {
              const eventDate = new Date(event.date);
              
              if (mergedOptions.dateRange?.start && eventDate < mergedOptions.dateRange.start) {
                return false;
              }
              
              if (mergedOptions.dateRange?.end && eventDate > mergedOptions.dateRange.end) {
                return false;
              }
              
              return true;
            });
          }
          
          // Apply limit if needed
          if (mergedOptions.limit && filteredEvents.length > mergedOptions.limit) {
            filteredEvents = filteredEvents.slice(0, mergedOptions.limit);
          }
          
          handleEventsUpdate(filteredEvents);
        }
      });
      
      // Subscribe to appropriate categories
      for (const category of mergedOptions.categories || []) {
        subscribeTopic('economic', category);
      }
      
      return unsubscribe;
    }
    
    // Fetch initial data if requested and WebSocket is not connected
    if (mergedOptions.fetchInitialData) {
      fetchEventsData();
    }
  }, [
    status,
    subscribe,
    subscribeTopic,
    mergedOptions.categories,
    mergedOptions.dateRange,
    mergedOptions.limit,
    mergedOptions.fetchInitialData,
    handleEventsUpdate,
    fetchEventsData
  ]);
  
  // Set up polling if needed
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      return; // Skip if WebSocket is connected
    }
    
    if (mergedOptions.pollingInterval && mergedOptions.pollingInterval > 0) {
      const interval = setInterval(() => {
        fetchEventsData();
      }, mergedOptions.pollingInterval);
      
      return () => clearInterval(interval);
    }
  }, [status, mergedOptions.pollingInterval, fetchEventsData]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, []);
  
  // Filter events by category
  const filterByCategory = useCallback((category: EventCategory) => {
    if (category === 'all') {
      return events;
    }
    
    if (category === 'high_impact') {
      return events.filter(event => event.impact === 'high');
    }
    
    return events.filter(event => event.category === category);
  }, [events]);
  
  // Filter events by country
  const filterByCountry = useCallback((country: string) => {
    return events.filter(event => event.country === country);
  }, [events]);
  
  // Filter events by date range
  const filterByDateRange = useCallback((start: Date, end: Date) => {
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate >= start && eventDate <= end;
    });
  }, [events]);
  
  // Get upcoming events
  const getUpcomingEvents = useCallback((count: number = 5) => {
    const now = new Date();
    
    return events
      .filter(event => new Date(event.date) > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, count);
  }, [events]);
  
  // Get high impact events
  const getHighImpactEvents = useCallback(() => {
    return events.filter(event => event.impact === 'high');
  }, [events]);
  
  // Calculate if data is stale
  const isStale = useMemo(() => {
    if (!lastUpdateTime) return false;
    
    return (Date.now() - lastUpdateTime) > (mergedOptions.cache?.maxAge || 0);
  }, [lastUpdateTime, mergedOptions.cache?.maxAge]);
  
  // Return the hook's API
  return {
    events,
    isLoading,
    error,
    isStale,
    isConnected,
    connectionStatus: status,
    lastUpdateTime,
    
    // Filter helpers
    filterByCategory,
    filterByCountry,
    filterByDateRange,
    
    // Utility functions
    getUpcomingEvents,
    getHighImpactEvents,
    
    // Manually refresh data
    refresh: fetchEventsData
  };
}

export default useEconomicEvents;