
# Validation Guide

## API Response Validation
Use the `validateApiResponse` utility for type-safe API responses:

```typescript
import { validateApiResponse } from '@/utils/validation';

const response = await fetch('/api/data');
const data = await validateApiResponse(response);
```

## Shared Types
Import shared types from `@/types` instead of creating custom interfaces:

```typescript
import { User, Asset, Trade } from '@/types';
```

## Custom Validation Rules
Create custom validation rules in `src/validation/rules.ts`.
