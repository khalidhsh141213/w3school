"use client";

import { Clock, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface EmptyStateViewProps {
  title: string;
  backText: string;
  backUrl?: string;
}

export default function EmptyStateView({
  title,
  backText,
  backUrl = "/"
}: EmptyStateViewProps) {
  const [_, setLocation] = useLocation();

  const handleBackClick = () => {
    setLocation(backUrl);
  };

  return (
    <div className="flex flex-col items-center justify-center py-12 px-4">
      <div className="flex flex-col items-center text-center max-w-md">
        {/* Decorative Elements */}
        <div className="relative mb-6 p-6 rounded-full bg-muted/30">
          <Clock className="h-16 w-16 text-muted-foreground" strokeWidth={1.5} />
          <div className="absolute -top-4 -right-2">
            <div className="w-4 h-8 rounded-full bg-muted transform rotate-45" />
          </div>
          <div className="absolute -bottom-2 -left-4">
            <div className="w-4 h-8 rounded-full bg-muted transform -rotate-45" />
          </div>
        </div>

        {/* Message */}
        <h3 className="text-xl font-semibold mb-3 text-foreground">{title}</h3>
        <p className="text-muted-foreground mb-8">
          No pending orders are currently in your portfolio. Start trading to see your orders here.
        </p>

        {/* Back Button */}
        <Button 
          variant="outline" 
          onClick={handleBackClick}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          {backText}
        </Button>
      </div>
    </div>
  );
}