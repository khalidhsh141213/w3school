import postgres from 'postgres';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import 'dotenv/config';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  // Use the same hash method as in auth.ts
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function fixAdminPassword() {
  console.log('Fixing admin password...');
  
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is not set');
  }

  // Establish connection
  const sql = postgres(process.env.DATABASE_URL);
  
  try {
    // Get the admin user
    const adminUsers = await sql`
      SELECT * FROM users 
      WHERE username = 'admin' OR email = 'admin@example.com'
    `;
    
    if (adminUsers.length === 0) {
      console.log('Admin user not found, creating one...');
      
      // Create a new admin user with the correct password hash
      const hashedPassword = await hashPassword('password123');
      const newAdmin = await sql`
        INSERT INTO users (
          username, 
          email, 
          password_hash, 
          full_name, 
          is_verified, 
          verification_status, 
          user_role
        )
        VALUES (
          'admin', 
          'admin@example.com', 
          ${hashedPassword}, 
          'Admin User', 
          true, 
          'verified', 
          'admin'
        )
        RETURNING id
      `;
      
      console.log('Admin user created with ID:', newAdmin[0].id);
    } else {
      // Update the existing admin user
      const adminUser = adminUsers[0];
      console.log('Found admin user:', adminUser.id);
      
      // Update the password hash
      const hashedPassword = await hashPassword('password123');
      await sql`
        UPDATE users 
        SET password_hash = ${hashedPassword}
        WHERE id = ${adminUser.id}
      `;
      
      console.log('Admin password updated successfully');
    }
  } catch (error) {
    console.error('Error fixing admin password:', error);
  } finally {
    await sql.end();
  }
}

fixAdminPassword(); 