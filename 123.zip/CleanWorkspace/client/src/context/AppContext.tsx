import { createContext, useState, ReactNode, useEffect } from 'react';

type Language = 'en' | 'ar';
type Theme = 'light' | 'dark';

interface AppState {
  language: Language;
  theme: Theme;
  userId: number | null;
  username: string | null;
  isLoggedIn: boolean;
  balance: string | null;
  selectedSymbol: string;
}

interface AppContextType {
  appState: AppState;
  toggleLanguage: () => void;
  toggleTheme: () => void;
  login: (userId: number, username: string, balance: string) => void;
  logout: () => void;
  updateBalance: (newBalance: string) => void;
  setSelectedSymbol: (symbol: string) => void;
}

const initialState: AppState = {
  language: 'en',
  theme: 'light',
  userId: null,
  username: null,
  isLoggedIn: false,
  balance: null,
  selectedSymbol: 'AAPL',
};

export const AppContext = createContext<AppContextType>({
  appState: initialState,
  toggleLanguage: () => {},
  toggleTheme: () => {},
  login: () => {},
  logout: () => {},
  updateBalance: () => {},
  setSelectedSymbol: () => {},
});

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider = ({ children }: AppProviderProps) => {
  const [appState, setAppState] = useState<AppState>(() => {
    // Try to load state from localStorage
    const savedState = localStorage.getItem('tradingAppState');
    if (savedState) {
      try {
        return JSON.parse(savedState);
      } catch (error) {
        console.error('Failed to parse saved state:', error);
        return initialState;
      }
    }
    return initialState;
  });

  // Save state to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('tradingAppState', JSON.stringify(appState));
  }, [appState]);

  const toggleLanguage = () => {
    setAppState(prevState => ({
      ...prevState,
      language: prevState.language === 'en' ? 'ar' : 'en'
    }));
  };

  const toggleTheme = () => {
    setAppState(prevState => ({
      ...prevState,
      theme: prevState.theme === 'light' ? 'dark' : 'light'
    }));
  };

  const login = (userId: number, username: string, balance: string) => {
    setAppState(prevState => ({
      ...prevState,
      userId,
      username,
      balance,
      isLoggedIn: true
    }));
  };

  const logout = () => {
    setAppState(prevState => ({
      ...prevState,
      userId: null,
      username: null,
      balance: null,
      isLoggedIn: false
    }));
  };

  const updateBalance = (newBalance: string) => {
    setAppState(prevState => ({
      ...prevState,
      balance: newBalance
    }));
  };

  const setSelectedSymbol = (symbol: string) => {
    setAppState(prevState => ({
      ...prevState,
      selectedSymbol: symbol
    }));
  };

  return (
    <AppContext.Provider value={{ 
      appState, 
      toggleLanguage, 
      toggleTheme,
      login,
      logout,
      updateBalance,
      setSelectedSymbol
    }}>
      {children}
    </AppContext.Provider>
  );
};
