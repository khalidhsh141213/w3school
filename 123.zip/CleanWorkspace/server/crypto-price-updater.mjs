import 'dotenv/config';
import { db } from './db.js';
import { assets } from '@shared/schema';
import { eq } from 'drizzle-orm';
import fetch from 'node-fetch';
import { marketDataService } from './services/marketData.js';

// Configuration
const PRICE_UPDATE_INTERVAL = 10000; // Increase to 10 seconds to reduce API calls
const POLYGON_API_KEY = process.env.POLYGON_API_KEY;
const POLYGON_BASE_URL = 'https://api.polygon.io';
// Flag to indicate this is the primary price update source for crypto assets
const IS_PRIMARY_CRYPTO_SOURCE = true;

// Cache for price data with expiration
const priceCache = new Map();
// Cache expiration time in milliseconds (1 minute)
const CACHE_EXPIRATION = 60000;
// Cache for last update timestamps per asset to avoid too frequent updates
const lastUpdateTime = new Map();
// Minimum time between updates for the same asset (5 seconds)
const MIN_UPDATE_INTERVAL = 5000;
// Rate limiting
const API_CALL_HISTORY = [];
const MAX_CALLS_PER_MINUTE = 5; // Reduce to avoid hitting Polygon API limits
const RATE_LIMIT_WINDOW = 60000; // 1 minute

// Helper to log with timestamp
function logWithTime(message) {
  const now = new Date();
  console.log(`${now.toLocaleTimeString()} [crypto-updater] ${message}`);
}

// Check if we're being rate limited
function isRateLimited() {
  const now = Date.now();
  // Clean up old calls from history
  while (API_CALL_HISTORY.length > 0 && API_CALL_HISTORY[0] < now - RATE_LIMIT_WINDOW) {
    API_CALL_HISTORY.shift();
  }
  
  return API_CALL_HISTORY.length >= MAX_CALLS_PER_MINUTE;
}

// Add an API call to history
function trackApiCall() {
  API_CALL_HISTORY.push(Date.now());
}

// Get crypto assets from database
async function getCryptoAssets() {
  try {
    const cryptoAssets = await db.select()
      .from(assets)
      .where(eq(assets.assetType, 'crypto'));
    
    return cryptoAssets;
  } catch (error) {
    logWithTime(`Error fetching crypto assets: ${error}`);
    return [];
  }
}

// Check cache for price data
function getCachedPrice(symbol) {
  const cacheKey = symbol;
  const cachedData = priceCache.get(cacheKey);
  
  if (cachedData) {
    const now = Date.now();
    if (now - cachedData.timestamp < CACHE_EXPIRATION) {
      logWithTime(`Using cached price for ${symbol}: ${cachedData.data.price}`);
      return cachedData.data;
    } else {
      // Cache expired
      priceCache.delete(cacheKey);
    }
  }
  
  return null;
}

// Store price data in cache
function cachePrice(symbol, data) {
  const cacheKey = symbol;
  priceCache.set(cacheKey, {
    timestamp: Date.now(),
    data
  });
}

// Check if an asset was updated too recently
function wasUpdatedRecently(symbol) {
  const lastUpdate = lastUpdateTime.get(symbol);
  if (!lastUpdate) return false;
  
  return Date.now() - lastUpdate < MIN_UPDATE_INTERVAL;
}

// Mark asset as updated
function markAsUpdated(symbol) {
  lastUpdateTime.set(symbol, Date.now());
}

// Fetch current price for a crypto asset from Polygon REST API
async function fetchCryptoPrice(symbol) {
  // Check cache first
  const cachedPrice = getCachedPrice(symbol);
  if (cachedPrice) return cachedPrice;
  
  // Check if we're updating too frequently
  if (wasUpdatedRecently(symbol)) {
    logWithTime(`Skipping update for ${symbol} - updated too recently`);
    return null;
  }
  
  // Check rate limiting
  if (isRateLimited()) {
    logWithTime(`Rate limited - skipping price update for ${symbol}`);
    return null;
  }
  
  try {
    // Format symbol for Polygon API (if needed)
    let polygonSymbol = symbol;
    if (symbol.includes('/')) {
      const [base, quote] = symbol.split('/');
      polygonSymbol = `X:${base}${quote}`;
    }
    
    // First try to get the very latest data - today's data
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD
    
    const realtimeUrl = `${POLYGON_BASE_URL}/v2/aggs/ticker/${polygonSymbol}/range/1/minute/${todayStr}/${todayStr}?limit=1&sort=desc&apiKey=${POLYGON_API_KEY}`;
    logWithTime(`Fetching latest price for ${symbol} (${polygonSymbol}) from: ${realtimeUrl}`);
    
    // Track API call
    trackApiCall();
    
    let response = await fetch(realtimeUrl);
    
    // Handle rate limiting response
    if (response.status === 429) {
      logWithTime(`Received rate limit (429) from Polygon API for ${symbol}`);
      return null;
    }
    
    let data = await response.json();
    
    // If we got results, use the most recent one
    if (data.results && data.results.length > 0) {
      const result = data.results[0];
      logWithTime(`Got real-time price for ${symbol}: ${result.c}`);
      
      const priceData = {
        price: result.c,
        open: result.o,
        high: result.h,
        low: result.l,
        volume: result.v
      };
      
      // Cache the result
      cachePrice(symbol, priceData);
      
      // Mark as updated
      markAsUpdated(symbol);
      
      return priceData;
    }
    
    // Fallback to prev day data if no real-time data available
    logWithTime(`No real-time data for ${symbol}, falling back to prev endpoint`);
    
    // If we're already rate limited, skip the fallback request
    if (isRateLimited()) {
      logWithTime(`Rate limited - skipping fallback request for ${symbol}`);
      return null;
    }
    
    const fallbackUrl = `${POLYGON_BASE_URL}/v2/aggs/ticker/${polygonSymbol}/prev?apiKey=${POLYGON_API_KEY}`;
    
    // Track API call
    trackApiCall();
    
    response = await fetch(fallbackUrl);
    
    if (!response.ok) {
      logWithTime(`Error response from Polygon: ${response.status} ${response.statusText}`);
      return null;
    }
    
    data = await response.json();
    
    if (data.results && data.results.length > 0) {
      const result = data.results[0];
      logWithTime(`Got previous day price for ${symbol}: ${result.c}`);
      
      const priceData = {
        price: result.c,
        open: result.o,
        high: result.h,
        low: result.l,
        volume: result.v
      };
      
      // Cache the result
      cachePrice(symbol, priceData);
      
      // Mark as updated
      markAsUpdated(symbol);
      
      return priceData;
    }
    
    logWithTime(`No price data available for ${symbol}`);
    return null;
  } catch (error) {
    logWithTime(`Error fetching price for ${symbol}: ${error}`);
    return null;
  }
}

// Update price in database and broadcast to clients
async function updateAssetPrice(asset, priceData) {
  try {
    if (!priceData) {
      logWithTime(`No price data available for ${asset.symbol}`);
      return;
    }
    
    const previousPrice = asset.price || 0;
    const change = priceData.price - previousPrice;
    const changePercent = previousPrice ? (change / previousPrice) * 100 : 0;
    
    // Only update if the price is significantly different (avoid micro-changes)
    const isPriceSignificantlyDifferent = Math.abs(changePercent) > 0.05; // 0.05% threshold
    
    if (isPriceSignificantlyDifferent) {
      // Update in database
      await db.update(assets)
        .set({
          price: priceData.price,
          openPrice: priceData.open,
          highPrice: priceData.high,
          lowPrice: priceData.low,
          volume: priceData.volume,
          priceChange24h: change,
          priceChangePercent: changePercent,
          lastUpdated: new Date(),
          updatedAt: new Date()
        })
        .where(eq(assets.id, asset.id));
      
      logWithTime(`Updated price for ${asset.symbol}: $${priceData.price} (${change >= 0 ? '+' : ''}${changePercent.toFixed(2)}%)`);
      
      // If this is the primary source for crypto prices, broadcast the update
      if (IS_PRIMARY_CRYPTO_SOURCE) {
        // Broadcast to WebSocket clients
        marketDataService.broadcastPriceUpdate(
          asset.symbol, 
          priceData.price, 
          change, 
          changePercent
        );
      }
    } else {
      logWithTime(`Skipping update for ${asset.symbol} - price change (${changePercent.toFixed(2)}%) below threshold`);
    }
  } catch (error) {
    logWithTime(`Error updating price for ${asset.symbol}: ${error}`);
  }
}

// Main update function
async function updateAllCryptoPrices() {
  try {
    const cryptoAssets = await getCryptoAssets();
    logWithTime(`Found ${cryptoAssets.length} crypto assets to update`);
    
    // Sort assets by priority - last updated first
    cryptoAssets.sort((a, b) => {
      const aLastUpdated = a.lastUpdated ? new Date(a.lastUpdated).getTime() : 0;
      const bLastUpdated = b.lastUpdated ? new Date(b.lastUpdated).getTime() : 0;
      return aLastUpdated - bLastUpdated; // Oldest first
    });
    
    // Limit number of updates per cycle to avoid rate limiting
    const assetsToUpdate = cryptoAssets.slice(0, MAX_CALLS_PER_MINUTE);
    
    if (assetsToUpdate.length < cryptoAssets.length) {
      logWithTime(`Rate limiting: updating ${assetsToUpdate.length} of ${cryptoAssets.length} assets this cycle`);
    }
    
    for (const asset of assetsToUpdate) {
      const priceData = await fetchCryptoPrice(asset.polygonSymbol || asset.symbol);
      if (priceData) {
        await updateAssetPrice(asset, priceData);
      }
    }
  } catch (error) {
    logWithTime(`Error in updateAllCryptoPrices: ${error}`);
  }
}

// Start the updater
function startCryptoPriceUpdater() {
  // Run immediately at startup
  updateAllCryptoPrices();
  
  // Then set interval for regular updates
  const intervalId = setInterval(updateAllCryptoPrices, PRICE_UPDATE_INTERVAL);
  
  logWithTime(`Crypto price updater started with interval: ${PRICE_UPDATE_INTERVAL}ms`);
  
  // Return a function to stop the updater if needed
  return () => {
    clearInterval(intervalId);
    logWithTime('Crypto price updater stopped');
  };
}

// Export the function
export { startCryptoPriceUpdater }; 