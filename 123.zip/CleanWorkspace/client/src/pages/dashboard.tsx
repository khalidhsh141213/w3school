import { BarChart, LineChart, PieChart } from '@/components/charts';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/lib/auth';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { useWebSocketManager } from '@/hooks/useWebSocketManager';
import { ConnectionStatus } from '@/services/WebSocketManager';
import { useQuery } from '@tanstack/react-query';
import { AlertCircle, ArrowRight, RotateCcw, TrendingDown, TrendingUp } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'wouter';
import PortfolioSummary from '@/components/common/PortfolioSummary';
import EconomicEventsWidget from '@/components/dashboard/EconomicEventsWidget';

// Define TypeScript interfaces
interface Asset {
  id: string;
  symbol: string;
  name: string;
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  lastUpdated: string;
  type: 'stock' | 'crypto' | 'forex';
}

interface WatchlistItem {
  id: string;
  assetId: string;
  symbol: string;
  name: string;
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  lastUpdated: string;
  type: 'stock' | 'crypto' | 'forex';
}

interface PortfolioSummary {
  id: string;
  userId: string;
  totalBalance: number;
  totalEquity: number;
  totalProfit: number;
  totalLoss: number;
  openPositions: number;
  totalInvestedAmount: number;
  availableBalance: number;
  marginUtilization: number;
  unrealizedPL: number;
  totalReturn: number;
  lastUpdated: string;
}

interface AssetHolding {
  id: string;
  assetId: string;
  symbol: string;
  name: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  value: number;
  totalReturn: number;
  totalReturnPercent: number;
}

interface WebSocketMessage {
  type: string;
  symbol: string;
  price: number;
  changePercent: number;
  timestamp?: number;
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [watchlistSymbols, setWatchlistSymbols] = useState<string[]>([]);
  const [portfolioSymbols, setPortfolioSymbols] = useState<string[]>([]);
  const [priceMap, setPriceMap] = useState<Record<string, number>>({});
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [_, navigate] = useLocation();

  // Use dynamic WebSocket URL based on current window location
  const host = window.location.host;
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${host}/ws`;

  // Use WebSocket hook with WebSocketManager
  const { 
    status: wsStatus, 
    subscribe,
    send,
    connected
  } = useWebSocketManager('ws', {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });

  // تخزين بيانات السوق المستلمة
  const [marketData, setMarketData] = useState<any>({});

  // Fetch trending assets
  const { 
    data: trendingAssets,
    isLoading: isLoadingTrending,
    error: trendingError
  } = useQuery<Asset[]>({
    queryKey: ['assets', 'trending'],
    queryFn: async () => {
      const res = await fetch('/api/assets/trending');
      if (!res.ok) {
        throw new Error('Failed to fetch trending assets');
      }
      return res.json();
    },
    refetchInterval: 60000, // Refetch every minute as a fallback
  });

  // Fetch watchlist
  const { 
    data: watchlist, 
    isLoading: isLoadingWatchlist,
    error: watchlistError
  } = useQuery<WatchlistItem[]>({
    queryKey: ['watchlist', user?.id],
    queryFn: async () => {
      if (!user?.id) {
        throw new Error('User ID is required');
      }
      const res = await fetch(`/api/watchlist?userId=${user.id}`);
      if (!res.ok) {
        throw new Error('Failed to fetch watchlist');
      }
      return res.json();
    },
    enabled: !!user?.id // Only run this query when user ID is available
  });

  // Fetch portfolio summary
  const { 
    data: portfolioSummary,
    isLoading: isLoadingPortfolio, 
    error: portfolioError
  } = useQuery<PortfolioSummary>({
    queryKey: ['/api/portfolio-summary', user?.id],
    queryFn: async () => {
      const res = await fetch('/api/portfolio-summary');
      if (!res.ok) {
        throw new Error('Failed to fetch portfolio summary');
      }
      return res.json();
    },
    enabled: !!user, // Only fetch when user is available
    refetchInterval: 10000, // Match the refresh rate in other components
  });

  // Fetch top holdings
  const { 
    data: holdings, 
    isLoading: isLoadingHoldings,
    error: holdingsError
  } = useQuery<AssetHolding[]>({
    queryKey: ['portfolio', 'holdings', user?.id],
    queryFn: async () => {
      const res = await fetch('/api/portfolio/holdings');
      if (!res.ok) {
        throw new Error('Failed to fetch portfolio holdings');
      }
      return res.json();
    },
    enabled: !!user, // Only fetch when user is available
  });

  // Extract all unique symbols that need to be tracked
  useEffect(() => {
    const symbols: Set<string> = new Set();

    // Add trending symbols
    if (trendingAssets?.length) {
      trendingAssets.forEach(asset => symbols.add(asset.symbol));
    }

    // Add watchlist symbols
    if (watchlist?.length) {
      const watchlistSyms = watchlist.map(item => item.symbol);
      watchlistSyms.forEach(symbol => symbols.add(symbol));
      setWatchlistSymbols(watchlistSyms);
    }

    // Add portfolio symbols
    if (holdings?.length) {
      const portfolioSyms = holdings.map(holding => holding.symbol);
      portfolioSyms.forEach(symbol => symbols.add(symbol));
      setPortfolioSymbols(portfolioSyms);
    }

  }, [trendingAssets, watchlist, holdings]);

  // Subscribe to WebSocket data for all tracked symbols
  useEffect(() => {
    // Combine all unique symbols that need tracking
    const allSymbols = Array.from(new Set([...watchlistSymbols, ...portfolioSymbols]));
    if (allSymbols.length === 0 || wsStatus !== ConnectionStatus.CONNECTED) return;

    // Subscribe to the websocket and handle messages
    const unsubscribe = subscribe((data) => {
      try {
        // Process the data received from websocket
        console.log('WebSocket data received:', data);

        if (data.type === 'price' || data.type === 'priceUpdate') {
          // Handle single price update
          if (data.symbol && allSymbols.includes(data.symbol)) {
            setPriceMap(prev => ({
              ...prev,
              [data.symbol]: data.price
            }));

            setLastUpdated(new Date());
          }
        } 
        else if (data.type === 'bulk' || data.type === 'marketData') {
          // Handle bulk market data updates
          const marketData = data.data || {};

          // Update prices for symbols we're tracking
          for (const symbol in marketData) {
            if (allSymbols.includes(symbol)) {
              // Update our price map with the latest price
              setPriceMap(prev => ({
                ...prev,
                [symbol]: marketData[symbol].price || marketData[symbol].currentPrice
              }));
            }
          }

          if (Object.keys(marketData).length > 0) {
            setLastUpdated(new Date());
          }
        }
      } catch (e) {
        console.error('Error handling WebSocket market data in dashboard:', e);
      }
    });

    // Send subscription request to the server - updated for WebSocketManager format
    send({
      type: 'subscribe',
      symbols: allSymbols
    });

    console.log(`Subscribed to ${allSymbols.length} symbols in dashboard`);

    return () => {
      // Cleanup subscription when component unmounts
      if (unsubscribe) unsubscribe();

      // Unsubscribe from symbols when component unmounts
      send({
        type: 'unsubscribe',
        symbols: allSymbols
      });
    };
  }, [watchlistSymbols, portfolioSymbols, wsStatus, subscribe, send]);

  // Helper function to get the latest price for a symbol (WebSocket price or API price)
  const getLatestPrice = (symbol: string, defaultPrice: number) => {
    return priceMap[symbol] || defaultPrice;
  };

  // Format price change display
  const formatPriceChange = (price: number, prevPrice: number, changePercent?: number) => {
    // Calculate change percent if not provided
    const calculatedChangePercent = changePercent ?? ((price - prevPrice) / prevPrice) * 100;
    const isPositive = calculatedChangePercent >= 0;

    return {
      value: formatCurrency(price - prevPrice),
      percent: formatPercentage(calculatedChangePercent),
      color: isPositive ? 'text-green-600' : 'text-red-600',
      bgColor: isPositive ? 'bg-green-50' : 'bg-red-50',
      icon: isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />,
    };
  };

  // Format trending assets for display
  const formatTrendingAssets = () => {
    if (!trendingAssets) return [];

    return trendingAssets.map(asset => {
      const currentPrice = getLatestPrice(asset.symbol, asset.currentPrice);
      const priceChange = formatPriceChange(currentPrice, asset.previousPrice, asset.changePercent);

      return {
        ...asset,
        currentPrice,
        priceChange,
      };
    });
  };

  // Format watchlist items for display
  const formatWatchlistItems = () => {
    if (!watchlist) return [];

    return watchlist.map(item => {
      const currentPrice = getLatestPrice(item.symbol, item.currentPrice);
      const priceChange = formatPriceChange(currentPrice, item.previousPrice, item.changePercent);

      return {
        ...item,
        currentPrice,
        priceChange,
      };
    });
  };

  // Calculate portfolio data for the pie chart
  const getPortfolioAllocationData = () => {
    if (!holdings || holdings.length === 0) return [];

    const total = holdings.reduce((sum, holding) => sum + (holding.value || 0), 0);

    return holdings
      .map(holding => ({
        name: holding.symbol,
        value: ((holding.value || 0) / total) * 100,
      }))
      .sort((a, b) => b.value - a.value);
  };

  // تحقق من حالة تحميل البيانات وتحسين منطق المعالجة
  const isLoading = isLoadingTrending || isLoadingWatchlist || isLoadingPortfolio || isLoadingHoldings;
  
  // تأكد من أن هذه أخطاء حقيقية وليست فقط بيانات فارغة
  const hasError = (trendingError && watchlistError && portfolioError && holdingsError);
  
  // التحقق من وجود صلاحية جلسة
  const isSessionValid = !!user?.id; 
  
  // إضافة سجلات للتصحيح
  console.log('Dashboard loading state:', {
    isLoading,
    isSessionValid,
    hasErrors: {
      trending: !!trendingError,
      watchlist: !!watchlistError,
      portfolio: !!portfolioError,
      holdings: !!holdingsError
    },
    dataStatus: {
      trending: !!trendingAssets,
      watchlist: !!watchlist,
      portfolio: !!portfolioSummary,
      holdings: !!holdings,
      user: !!user
    }
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-[400px]" />
          <Skeleton className="h-[400px]" />
        </div>
      </div>
    );
  }

  // تغيير المنطق للتحقق بشكل أكثر دقة من حالة الخطأ
  // نعرض خطأً فقط إذا كانت هناك أخطاء متعددة أو مشكلة في الجلسة
  if (hasError || !isSessionValid) {
    // تحقق ما إذا كانت المشكلة في الجلسة أم في البيانات
    const errorType = !isSessionValid 
      ? "Session error" 
      : "Data loading error";
      
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Dashboard</h1>

        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{errorType}</AlertTitle>
          <AlertDescription>
            {!isSessionValid 
              ? "Your session has expired. Please login again."
              : "Failed to load dashboard data. Some services might be temporarily unavailable."
            }
            <div className="flex gap-2 mt-4">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/login'}
              >
                Login Again
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.reload()}
              >
                <RotateCcw className="h-4 w-4 mr-2" /> Refresh
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  // إضافة تحقق من البيانات الأساسية فقط
  // نسمح بعرض اللوحة حتى لو كانت بعض البيانات غير متوفرة
  if (!portfolioSummary && !holdings && !trendingAssets) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-textDark mb-6">Dashboard</h1>
        
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Limited Data Available</AlertTitle>
          <AlertDescription>
            Some market data might be temporarily unavailable. 
            You can still use the dashboard with limited functionality.
            <Button 
              variant="link"
              size="sm"
              onClick={() => window.location.reload()}
              className="mt-2"
            >
              <RotateCcw className="h-3 w-3 mr-1" /> Refresh Data
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Calculate performance metrics
  const portfolioChange = portfolioSummary ? {
    value: formatCurrency(portfolioSummary.unrealizedPL || 0),
    percent: formatPercentage(portfolioSummary.totalReturn || 0),
    color: (portfolioSummary.unrealizedPL || 0) >= 0 ? 'text-green-600' : 'text-red-600',
    icon: (portfolioSummary.unrealizedPL || 0) >= 0 ? 
      <TrendingUp className="h-4 w-4" /> : 
      <TrendingDown className="h-4 w-4" />,
  } : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-textDark">Dashboard</h1>

        {wsStatus === ConnectionStatus.CONNECTED ? (
          <div className="text-xs px-2 py-0.5 bg-green-100 text-green-700 rounded-full flex items-center">
            <span className="block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
            Live Data
          </div>
        ) : (
          <div className="text-xs px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full flex items-center">
            <span className="block w-2 h-2 rounded-full bg-amber-500 mr-1"></span>
            {wsStatus === ConnectionStatus.CONNECTING ? 'Connecting...' : 'Delayed Data'}
          </div>
        )}
      </div>

      {wsStatus === ConnectionStatus.ERROR && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Connection Error</AlertTitle>
          <AlertDescription>
            Real-time data connection failed. Prices may be delayed.
            <Button 
              variant="outline" 
              size="sm" 
              className="ml-2"
              onClick={() => send({ type: 'reconnect' })}
            >
              <RotateCcw className="h-3 w-3 mr-1" /> Reconnect
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Portfolio Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">
              Total Equity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(portfolioSummary?.totalEquity || 0)}
            </div>
            {portfolioChange && (
              <div className={`flex items-center mt-1 ${portfolioChange.color}`}>
                {portfolioChange.icon}
                <span className="text-sm ml-1">
                  {portfolioChange.value} ({portfolioChange.percent})
                </span>
              </div>
            )}
            {portfolioSummary?.lastUpdated && (
              <div className="text-xs text-gray-500 mt-2">
                Last updated: {new Date(portfolioSummary.lastUpdated).toLocaleTimeString()}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">
              Available Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(portfolioSummary?.availableBalance || 0)}
            </div>
            <div className="text-sm text-gray-500 mt-1">
              Available for trading
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">
              Unrealized P/L
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${(portfolioSummary?.unrealizedPL || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(portfolioSummary?.unrealizedPL || 0)}
            </div>
            <div className={`flex items-center mt-1 ${
              (portfolioSummary?.totalReturn || 0) >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {(portfolioSummary?.totalReturn || 0) >= 0 ? 
                <TrendingUp className="h-4 w-4" /> : 
                <TrendingDown className="h-4 w-4" />
              }
              <span className="text-sm ml-1">
                {formatPercentage(portfolioSummary?.totalReturn || 0)} total return
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* Portfolio and Watchlist Section */}
        <Card className="lg:col-span-1 xl:col-span-1">
          <CardHeader>
            <CardTitle>Portfolio & Watchlist</CardTitle>
            <CardDescription>
              Track your investments and market trends
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="portfolio">
              <TabsList className="mb-4">
                <TabsTrigger value="portfolio">My Portfolio</TabsTrigger>
                <TabsTrigger value="watchlist">My Watchlist</TabsTrigger>
              </TabsList>

              <TabsContent value="portfolio">
                {holdings && holdings.length > 0 ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium mb-2">Allocation</h3>
                        <div className="h-[200px]">
                          <PieChart data={getPortfolioAllocationData()} />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium mb-2">Top Holdings</h3>
                        <div className="h-[200px]">
                          <BarChart
                            data={holdings.slice(0, 5).map((holding) => ({
                              name: holding.symbol,
                              value: holding.value,
                            }))}
                            xKey="name"
                            yKey="value"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => navigate('/portfolio')}
                      >
                        View Full Portfolio <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 px-4">
                    <div className="mb-4 text-primary">
                      <TrendingUp className="h-10 w-10 mx-auto mb-2 opacity-70" />
                    </div>
                    <p className="text-gray-700 font-medium mb-2">Your portfolio is ready for investments</p>
                    <p className="text-gray-500 text-sm mb-4">Start trading to build your portfolio and track performance</p>
                    <Button onClick={() => navigate('/discover')}>
                      Manage Investments
                    </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="watchlist">
                {watchlist && watchlist.length > 0 ? (
                  <div className="space-y-4">
                    {formatWatchlistItems().map((item) => (
                      <div 
                        key={item.id}
                        className={`p-3 rounded-lg border ${item.priceChange.bgColor} flex justify-between items-center cursor-pointer hover:bg-opacity-70 transition-colors`}
                        onClick={() => navigate(`/trade/${item.symbol}`)}
                      >
                        <div>
                          <div className="font-medium">{item.symbol}</div>
                          <div className="text-sm text-gray-600">{item.name}</div>
                        </div>
                        <div>
                          <div className="text-right font-medium">
                            {formatCurrency(item.currentPrice)}
                          </div>
                          <div className={`text-sm flex items-center justify-end ${item.priceChange.color}`}>
                            {item.priceChange.icon}
                            <span className="ml-1">{item.priceChange.percent}</span>
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="mt-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => navigate('/watchlist')}
                      >
                        Manage Watchlist <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 px-4">
                    <p className="text-gray-700 font-medium mb-2">Track your favorite assets</p>
                    <p className="text-gray-500 text-sm mb-4">Add assets to your watchlist to monitor price changes</p>
                    <Button onClick={() => navigate('/discover')}>
                      Explore Markets
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Market Trends Section */}
        <Card className="lg:col-span-1 xl:col-span-1">
          <CardHeader>
            <CardTitle>Market Trends</CardTitle>
            <CardDescription>
              Trending assets and market movers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="trending">
              <TabsList className="mb-4">
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="gainers">Top Gainers</TabsTrigger>
                <TabsTrigger value="losers">Top Losers</TabsTrigger>
              </TabsList>

              <TabsContent value="trending" className="space-y-4">
                {formatTrendingAssets().map((asset) => (
                  <div 
                    key={asset.id}
                    className="p-3 rounded-lg border hover:bg-gray-50 flex justify-between items-center cursor-pointer transition-colors"
                    onClick={() => navigate(`/trade/${asset.symbol}`)}
                  >
                    <div>
                      <div className="font-medium">{asset.symbol}</div>
                      <div className="text-sm text-gray-600">{asset.name}</div>
                    </div>
                    <div>
                      <div className="text-right font-medium">
                        {formatCurrency(asset.currentPrice)}
                      </div>
                      <div className={`text-sm flex items-center justify-end ${asset.priceChange.color}`}>
                        {asset.priceChange.icon}
                        <span className="ml-1">{asset.priceChange.percent}</span>
                      </div>
                    </div>
                  </div>
                ))}

                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => navigate('/discover')}
                  >
                    Discover More <ArrowRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="gainers">
                <div className="h-[350px]">
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-500 mb-2">Top market gainers will appear here</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate('/discover')}
                      >
                        View Market Movers
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="losers">
                <div className="h-[350px]">
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-500 mb-2">Top market losers will appear here</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate('/discover')}
                      >
                        View Market Movers
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Economic Events Widget - new section */}
        <div className="lg:col-span-2 xl:col-span-1">
          <EconomicEventsWidget 
            limit={5}
            showHighImpactOnly={true}
          />
        </div>
      </div>
    </div>
  );
}