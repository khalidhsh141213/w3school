-- Add polygon_symbol, tradingview_symbol, price, market_status columns to assets table if they don't exist
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "polygon_symbol" TEXT;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "tradingview_symbol" TEXT;
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "price" NUMERIC(10, 2);
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "market_status" TEXT DEFAULT 'active';

-- Update existing rows to have default market_status if null
UPDATE "assets" SET "market_status" = 'active' WHERE "market_status" IS NULL;

-- Create indexes for efficient lookup
CREATE INDEX IF NOT EXISTS "assets_polygon_symbol_idx" ON "assets" ("polygon_symbol") WHERE "polygon_symbol" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "assets_tradingview_symbol_idx" ON "assets" ("tradingview_symbol") WHERE "tradingview_symbol" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "assets_market_status_idx" ON "assets" ("market_status");

-- Add comment describing the purpose of these changes
COMMENT ON COLUMN "assets"."polygon_symbol" IS 'Symbol used for Polygon API integration';
COMMENT ON COLUMN "assets"."tradingview_symbol" IS 'Symbol used for TradingView charts';
COMMENT ON COLUMN "assets"."price" IS 'Current price from market update';
COMMENT ON COLUMN "assets"."market_status" IS 'Market status: active, suspended, halted, etc.';