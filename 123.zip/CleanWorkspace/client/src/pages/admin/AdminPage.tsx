import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet';
import { useLocation, Route, Switch } from 'wouter';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  BarChart3,
  CircleDollarSign,
  Database,
  FileCheck,
  Home,
  Shield,
  ShoppingCart,
} from 'lucide-react';
import AdminTablePage from '../../components/admin/AdminTablePage';

type AdminPageType = 'assets' | 'trades' | 'finances' | 'kyc';

const AdminNav = () => {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  
  return (
    <div className="border-b">
      <div className="container flex h-16 items-center px-4">
        <div className="flex items-center space-x-6 font-medium">
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-primary" />
            <span className="text-lg font-semibold">{t('admin.adminPanel')}</span>
          </div>
          <Button 
            variant="link" 
            className={location === '/admin' ? 'text-primary font-bold' : 'text-muted-foreground'}
            onClick={() => setLocation('/admin')}
          >
            <BarChart3 className="h-4 w-4 mr-2" />
            {t('admin.dashboard')}
          </Button>
          <Button 
            variant="link" 
            className={location === '/admin/assets' ? 'text-primary font-bold' : 'text-muted-foreground'}
            onClick={() => setLocation('/admin/assets')}
          >
            <Database className="h-4 w-4 mr-2" />
            {t('admin.assets')}
          </Button>
          <Button 
            variant="link" 
            className={location === '/admin/trades' ? 'text-primary font-bold' : 'text-muted-foreground'}
            onClick={() => setLocation('/admin/trades')}
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            {t('admin.trades')}
          </Button>
          <Button 
            variant="link" 
            className={location === '/admin/finances' ? 'text-primary font-bold' : 'text-muted-foreground'}
            onClick={() => setLocation('/admin/finances')}
          >
            <CircleDollarSign className="h-4 w-4 mr-2" />
            {t('admin.finances')}
          </Button>
          <Button 
            variant="link" 
            className={location === '/admin/kyc' ? 'text-primary font-bold' : 'text-muted-foreground'}
            onClick={() => setLocation('/admin/kyc')}
          >
            <FileCheck className="h-4 w-4 mr-2" />
            {t('admin.kyc')}
          </Button>
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setLocation('/')}
          >
            <Home className="h-4 w-4 mr-2" />
            {t('admin.backToDashboard')}
          </Button>
        </div>
      </div>
    </div>
  )
}

export const AdminPage: React.FC = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [location] = useLocation();
  
  return (
    <>
      <Helmet>
        <title>{t('admin.adminPanel')} | Financial Trading Platform</title>
      </Helmet>
      
      <div className="flex min-h-screen flex-col">
        <AdminNav />
        
        <div className="container flex-1 space-y-6 py-6">
          <Switch>
            <Route path="/admin" exact>
              <AdminDashboard />
            </Route>
            <Route path="/admin/assets">
              <AdminTablePage 
                tableType="assets" 
                title={t('admin.assetsManagement')} 
              />
            </Route>
            <Route path="/admin/trades">
              <AdminTablePage 
                tableType="trades" 
                title={t('admin.tradesManagement')} 
              />
            </Route>
            <Route path="/admin/finances">
              <AdminTablePage 
                tableType="finances" 
                title={t('admin.financesManagement')} 
              />
            </Route>
            <Route path="/admin/kyc">
              <AdminTablePage 
                tableType="kyc" 
                title={t('admin.kycManagement')} 
              />
            </Route>
            <Route>
              {/* Fallback route */}
              <div className="flex h-[50vh] items-center justify-center">
                <Card className="w-[600px]">
                  <CardHeader>
                    <CardTitle>{t('admin.pageNotFound')}</CardTitle>
                    <CardDescription>
                      {t('admin.pageNotFoundDesc')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={() => window.location.href = '/admin'}>
                      {t('admin.backToAdminDashboard')}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </Route>
          </Switch>
        </div>
      </div>
    </>
  );
};

const AdminDashboard: React.FC = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Stats for dashboard (would come from API in real implementation)
  const stats = [
    {
      title: t('admin.totalUsers'),
      value: '5,231',
      description: t('admin.activePastMonth'),
      change: '+12%',
      icon: <Shield className="h-4 w-4" />,
    },
    {
      title: t('admin.totalTrades'),
      value: '12,543',
      description: t('admin.pastMonth'),
      change: '+18%',
      icon: <ShoppingCart className="h-4 w-4" />,
    },
    {
      title: t('admin.totalDeposits'),
      value: '$954,321',
      description: t('admin.allTime'),
      change: '+24%',
      icon: <CircleDollarSign className="h-4 w-4" />,
    },
    {
      title: t('admin.pendingKyc'),
      value: '43',
      description: t('admin.requiresReview'),
      change: '-8%',
      icon: <FileCheck className="h-4 w-4" />,
    },
  ];
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">{t('admin.dashboard')}</h2>
        <p className="text-muted-foreground">
          {t('admin.dashboardOverview')}
        </p>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <div className="h-4 w-4 text-muted-foreground">
                {stat.icon}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                {stat.description}
                <span className={stat.change.startsWith('+') ? 'text-green-500 ml-1' : 'text-red-500 ml-1'}>
                  {stat.change}
                </span>
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>{t('admin.recentActivity')}</CardTitle>
            <CardDescription>
              {t('admin.recentActivityDesc')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {i === 0 
                        ? t('admin.userRegistered', { username: 'alex89' })
                        : i === 1
                        ? t('admin.newDeposit', { amount: '$500', username: 'trader123' })
                        : i === 2
                        ? t('admin.kycSubmitted', { username: 'investor22' })
                        : i === 3
                        ? t('admin.largeWithdrawal', { amount: '$2,500', username: 'bigtrader' })
                        : t('admin.newAssetAdded', { symbol: 'AAPL' })
                      }
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(Date.now() - (i * 1000 * 60 * 60)).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('admin.quickActions')}</CardTitle>
            <CardDescription>
              {t('admin.quickActionsDesc')}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full justify-start" onClick={() => window.location.href = '/admin/kyc'}>
              <FileCheck className="mr-2 h-4 w-4" />
              {t('admin.reviewKycRequests')}
            </Button>
            <Button className="w-full justify-start" variant="outline" onClick={() => window.location.href = '/admin/finances'}>
              <CircleDollarSign className="mr-2 h-4 w-4" />
              {t('admin.manageTransactions')}
            </Button>
            <Button className="w-full justify-start" variant="outline" onClick={() => window.location.href = '/admin/assets'}>
              <Database className="mr-2 h-4 w-4" />
              {t('admin.updateAssets')}
            </Button>
            <Button className="w-full justify-start" variant="outline" onClick={() => window.location.href = '/admin/trades'}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              {t('admin.viewTrades')}
            </Button>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="system">
        <TabsList>
          <TabsTrigger value="system">{t('admin.systemStatus')}</TabsTrigger>
          <TabsTrigger value="alerts">{t('admin.alerts')}</TabsTrigger>
          <TabsTrigger value="logs">{t('admin.logs')}</TabsTrigger>
        </TabsList>
        <TabsContent value="system" className="p-4 border rounded-md mt-2">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.databaseStatus')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{t('admin.healthy')}</span>
                    <span className="flex h-2 w-2 rounded-full bg-green-500"></span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.apiStatus')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{t('admin.healthy')}</span>
                    <span className="flex h-2 w-2 rounded-full bg-green-500"></span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.websocketStatus')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{t('admin.healthy')}</span>
                    <span className="flex h-2 w-2 rounded-full bg-green-500"></span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.aiServiceStatus')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{t('admin.degraded')}</span>
                    <span className="flex h-2 w-2 rounded-full bg-yellow-500"></span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="alerts" className="p-4 border rounded-md mt-2">
          <div className="space-y-4">
            <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded">
              <div className="flex">
                <div className="py-1">
                  <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium">{t('admin.aiServiceDegraded')}</p>
                  <p className="text-xs">{t('admin.aiServiceDegradedDesc')}</p>
                </div>
              </div>
            </div>
            <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded">
              <div className="flex">
                <div className="py-1">
                  <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium">{t('admin.databaseBackupComplete')}</p>
                  <p className="text-xs">{t('admin.databaseBackupCompleteDesc')}</p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="logs" className="p-4 border rounded-md mt-2">
          <pre className="bg-gray-100 p-4 rounded text-xs font-mono h-48 overflow-auto">
            {`[2025-03-29 12:04:32] INFO: User login: admin (IP: 192.168.1.1)
[2025-03-29 12:05:17] INFO: Asset updated: BTC (Bitcoin)
[2025-03-29 12:08:42] WARN: Failed login attempt for user: admin (IP: 203.0.113.1)
[2025-03-29 12:15:23] INFO: KYC request approved: user_id=324
[2025-03-29 12:23:11] INFO: New user registration: trader789
[2025-03-29 12:30:45] ERROR: Market data service connection timeout
[2025-03-29 12:31:02] INFO: Market data service reconnected
[2025-03-29 12:42:19] INFO: Deposit processed: $1,000 for user_id=156
[2025-03-29 12:50:38] INFO: System backup initiated
[2025-03-29 12:55:12] INFO: System backup completed successfully`}
          </pre>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminPage;