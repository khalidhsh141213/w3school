import { useEffect } from 'react';
import { useLocation } from 'wouter';

interface RedirectRule {
  from: {
    path: string;
    hash?: string;
  };
  to: string;
}

/**
 * Hook to handle redirects based on predefined rules
 * @param rules Array of redirect rules
 */
export function useRedirect(rules: RedirectRule[] = []) {
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // Default redirect rules
    const defaultRules: RedirectRule[] = [
      {
        from: { path: '/settings', hash: '#support' },
        to: '/support'
      }
    ];
    
    // Combine default rules with custom rules
    const allRules = [...defaultRules, ...rules];
    
    // Check if current URL matches any redirect rule
    for (const rule of allRules) {
      if (
        location === rule.from.path && 
        (!rule.from.hash || window.location.hash === rule.from.hash)
      ) {
        setLocation(rule.to);
        break;
      }
    }
    
    // Also listen for hashchange events for direct hash navigation
    const handleHashChange = () => {
      for (const rule of allRules) {
        if (
          location === rule.from.path && 
          rule.from.hash && 
          window.location.hash === rule.from.hash
        ) {
          setLocation(rule.to);
          break;
        }
      }
    };
    
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [location, setLocation, rules]);
} 