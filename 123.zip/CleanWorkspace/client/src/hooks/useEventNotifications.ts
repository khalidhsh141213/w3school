/**
 * useEventNotifications Hook
 * 
 * A hook for managing economic event notifications and alerts.
 * Allows users to subscribe to notifications for specific event categories,
 * countries, or impact levels.
 * 
 * @example
 * ```tsx
 * function NotificationSettings() {
 *   const { 
 *     notifications, 
 *     subscribeToCategory,
 *     unsubscribeFromCategory,
 *     isSubscribed
 *   } = useEventNotifications();
 *   
 *   return (
 *     <div>
 *       <h2>Notification Settings</h2>
 *       <Switch 
 *         checked={isSubscribed('high_impact')}
 *         onCheckedChange={(checked) => {
 *           if (checked) {
 *             subscribeToCategory('high_impact');
 *           } else {
 *             unsubscribeFromCategory('high_impact');
 *           }
 *         }}
 *       />
 *       <label>High Impact Events</label>
 *     </div>
 *   );
 * }
 * ```
 */

import { useCallback, useEffect, useState } from 'react';
import { EventCategory } from './useEconomicEvents';
import useWebSocketConnection from './useWebSocketConnection';
import { ConnectionStatus } from '../services/WebSocketService';
import api from '../lib/api';
import { useToast } from './use-toast';

// Notification types
export type NotificationChannel = 'app' | 'email' | 'push' | 'sms';

export interface EventNotificationSettings {
  id: string;
  userId: string;
  categories: EventCategory[];
  countries: string[];
  impactLevels: ('low' | 'medium' | 'high')[];
  advanceNotice: number; // minutes before event
  channels: NotificationChannel[];
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface EventNotification {
  id: string;
  eventId: string;
  eventTitle: string;
  eventCategory: EventCategory;
  eventDate: string;
  eventCountry: string;
  eventImpact: 'low' | 'medium' | 'high';
  message: string;
  read: boolean;
  createdAt: string;
}

interface EventNotificationOptions {
  autoMarkAsRead?: boolean;
  showToasts?: boolean;
  fetchOnStart?: boolean;
  pollInterval?: number; // milliseconds, 0 to disable
}

const DEFAULT_OPTIONS: EventNotificationOptions = {
  autoMarkAsRead: false,
  showToasts: true,
  fetchOnStart: true,
  pollInterval: 0 // disabled by default, rely on WebSocket
};

/**
 * Hook for managing economic event notifications
 */
export function useEventNotifications(options: Partial<EventNotificationOptions> = {}) {
  // Merge options with defaults
  const mergedOptions: EventNotificationOptions = {
    ...DEFAULT_OPTIONS,
    ...options
  };
  
  // State
  const [settings, setSettings] = useState<EventNotificationSettings | null>(null);
  const [notifications, setNotifications] = useState<EventNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  
  // Toast for notifications
  const { toast } = useToast();
  
  // WebSocket connection for real-time notifications
  const {
    status: wsStatus,
    isConnected,
    subscribe,
    send
  } = useWebSocketConnection('/notifications');
  
  // Fetch notification settings
  const fetchSettings = useCallback(async () => {
    try {
      const response = await api.get('/api/notifications/settings');
      
      if (response.data) {
        setSettings(response.data);
      } else {
        // Create default settings if none exist
        const defaultSettings: Partial<EventNotificationSettings> = {
          categories: ['high_impact'],
          countries: [],
          impactLevels: ['high'],
          advanceNotice: 60, // 1 hour
          channels: ['app'],
          enabled: true
        };
        
        // Save default settings
        const createResponse = await api.post('/api/notifications/settings', defaultSettings);
        setSettings(createResponse.data);
      }
    } catch (err) {
      console.error('[useEventNotifications] Error fetching notification settings:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
    }
  }, []);
  
  // Fetch notifications
  const fetchNotifications = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await api.get('/api/notifications');
      
      if (response.data?.items) {
        setNotifications(response.data.items);
        setUnreadCount(response.data.items.filter((n: EventNotification) => !n.read).length);
      }
    } catch (err) {
      console.error('[useEventNotifications] Error fetching notifications:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  // Update notification settings
  const updateSettings = useCallback(async (newSettings: Partial<EventNotificationSettings>) => {
    try {
      const response = await api.put('/api/notifications/settings', newSettings);
      
      if (response.data) {
        setSettings(response.data);
        return true;
      }
      return false;
    } catch (err) {
      console.error('[useEventNotifications] Error updating notification settings:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
      return false;
    }
  }, []);
  
  // Subscribe to a category
  const subscribeToCategory = useCallback(async (category: EventCategory) => {
    if (!settings) return false;
    
    // Add category if not already included
    if (!settings.categories.includes(category)) {
      const newCategories = [...settings.categories, category];
      return updateSettings({ categories: newCategories });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Unsubscribe from a category
  const unsubscribeFromCategory = useCallback(async (category: EventCategory) => {
    if (!settings) return false;
    
    // Remove category if included
    if (settings.categories.includes(category)) {
      const newCategories = settings.categories.filter(c => c !== category);
      return updateSettings({ categories: newCategories });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Subscribe to a country
  const subscribeToCountry = useCallback(async (country: string) => {
    if (!settings) return false;
    
    // Add country if not already included
    if (!settings.countries.includes(country)) {
      const newCountries = [...settings.countries, country];
      return updateSettings({ countries: newCountries });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Unsubscribe from a country
  const unsubscribeFromCountry = useCallback(async (country: string) => {
    if (!settings) return false;
    
    // Remove country if included
    if (settings.countries.includes(country)) {
      const newCountries = settings.countries.filter(c => c !== country);
      return updateSettings({ countries: newCountries });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Subscribe to an impact level
  const subscribeToImpactLevel = useCallback(async (impact: 'low' | 'medium' | 'high') => {
    if (!settings) return false;
    
    // Add impact level if not already included
    if (!settings.impactLevels.includes(impact)) {
      const newImpactLevels = [...settings.impactLevels, impact];
      return updateSettings({ impactLevels: newImpactLevels });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Unsubscribe from an impact level
  const unsubscribeFromImpactLevel = useCallback(async (impact: 'low' | 'medium' | 'high') => {
    if (!settings) return false;
    
    // Remove impact level if included
    if (settings.impactLevels.includes(impact)) {
      const newImpactLevels = settings.impactLevels.filter(i => i !== impact);
      return updateSettings({ impactLevels: newImpactLevels });
    }
    
    return true;
  }, [settings, updateSettings]);
  
  // Enable or disable notification channels
  const setNotificationChannels = useCallback(async (channels: NotificationChannel[]) => {
    return updateSettings({ channels });
  }, [updateSettings]);
  
  // Set advance notice time
  const setAdvanceNotice = useCallback(async (minutes: number) => {
    return updateSettings({ advanceNotice: minutes });
  }, [updateSettings]);
  
  // Enable/disable all notifications
  const setNotificationsEnabled = useCallback(async (enabled: boolean) => {
    return updateSettings({ enabled });
  }, [updateSettings]);
  
  // Mark a notification as read
  const markAsRead = useCallback(async (notificationId: string) => {
    try {
      await api.put(`/api/notifications/${notificationId}/read`);
      
      // Update local state
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
      );
      
      // Update unread count
      setUnreadCount(prev => Math.max(0, prev - 1));
      
      return true;
    } catch (err) {
      console.error('[useEventNotifications] Error marking notification as read:', err);
      return false;
    }
  }, []);
  
  // Mark all notifications as read
  const markAllAsRead = useCallback(async () => {
    try {
      await api.put('/api/notifications/read-all');
      
      // Update local state
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
      
      return true;
    } catch (err) {
      console.error('[useEventNotifications] Error marking all notifications as read:', err);
      return false;
    }
  }, []);
  
  // Delete a notification
  const deleteNotification = useCallback(async (notificationId: string) => {
    try {
      await api.delete(`/api/notifications/${notificationId}`);
      
      // Update local state
      const notification = notifications.find(n => n.id === notificationId);
      setNotifications(prev => prev.filter(n => n.id !== notificationId));
      
      // Update unread count if needed
      if (notification && !notification.read) {
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
      
      return true;
    } catch (err) {
      console.error('[useEventNotifications] Error deleting notification:', err);
      return false;
    }
  }, [notifications]);
  
  // Check if subscribed to a category
  const isSubscribed = useCallback((category: EventCategory) => {
    if (!settings) return false;
    return settings.categories.includes(category);
  }, [settings]);
  
  // Check if subscribed to a country
  const isSubscribedToCountry = useCallback((country: string) => {
    if (!settings) return false;
    return settings.countries.includes(country);
  }, [settings]);
  
  // Check if subscribed to an impact level
  const isSubscribedToImpactLevel = useCallback((impact: 'low' | 'medium' | 'high') => {
    if (!settings) return false;
    return settings.impactLevels.includes(impact);
  }, [settings]);
  
  // Handle new notification from WebSocket
  const handleNewNotification = useCallback((notification: EventNotification) => {
    // Add to notifications list if not already present
    setNotifications(prev => {
      if (prev.some(n => n.id === notification.id)) {
        return prev;
      }
      return [notification, ...prev];
    });
    
    // Update unread count
    if (!notification.read) {
      setUnreadCount(prev => prev + 1);
    }
    
    // Show toast if enabled
    if (mergedOptions.showToasts) {
      toast({
        title: 'Economic Event Alert',
        description: notification.message,
        duration: 5000,
      });
    }
    
    // Auto mark as read if enabled
    if (mergedOptions.autoMarkAsRead) {
      markAsRead(notification.id);
    }
  }, [markAsRead, mergedOptions.autoMarkAsRead, mergedOptions.showToasts, toast]);
  
  // Initialize data
  useEffect(() => {
    // Fetch settings first
    fetchSettings().then(() => {
      // Then fetch notifications if needed
      if (mergedOptions.fetchOnStart) {
        fetchNotifications();
      }
    });
  }, [fetchSettings, fetchNotifications, mergedOptions.fetchOnStart]);
  
  // Set up WebSocket subscription
  useEffect(() => {
    if (wsStatus === ConnectionStatus.CONNECTED) {
      // Subscribe to notification events
      const unsubscribe = subscribe('notification', (data) => {
        if (data) {
          handleNewNotification(data);
        }
      });
      
      // Tell the server we're listening for notifications
      send({
        type: 'subscribe',
        channel: 'notifications'
      });
      
      return unsubscribe;
    }
  }, [wsStatus, subscribe, send, handleNewNotification]);
  
  // Set up polling if enabled
  useEffect(() => {
    if (mergedOptions.pollInterval && mergedOptions.pollInterval > 0) {
      const interval = setInterval(() => {
        fetchNotifications();
      }, mergedOptions.pollInterval);
      
      return () => clearInterval(interval);
    }
  }, [fetchNotifications, mergedOptions.pollInterval]);
  
  return {
    // Data
    settings,
    notifications,
    unreadCount,
    
    // Status
    isLoading,
    error,
    isConnected,
    
    // Subscription methods
    subscribeToCategory,
    unsubscribeFromCategory,
    subscribeToCountry,
    unsubscribeFromCountry,
    subscribeToImpactLevel,
    unsubscribeFromImpactLevel,
    
    // Setting methods
    setNotificationChannels,
    setAdvanceNotice,
    setNotificationsEnabled,
    updateSettings,
    
    // Notification management
    markAsRead,
    markAllAsRead,
    deleteNotification,
    
    // Helpers
    isSubscribed,
    isSubscribedToCountry,
    isSubscribedToImpactLevel,
    
    // Manual data fetching
    fetchNotifications,
    fetchSettings
  };
}

export default useEventNotifications;