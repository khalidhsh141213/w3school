import { useEffect, useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowUp, ArrowDown, Globe, RefreshCw, Info, Clock, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { formatDistanceToNow } from 'date-fns';
import { useTranslation } from 'react-i18next';

type MarketItem = {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number | null;
  timestamp?: string | null;
  lastUpdated?: string | null;
  assetType?: string;
  marketStatus?: string;
  isMarketOpen?: boolean;
};

export default function MarketTicker() {
  // Live data polling with react-query - using short polling interval
  const { data: liveAssets, isLoading, isError } = useQuery({
    queryKey: ['/api/assets/live'],
    queryFn: async () => {
      const res = await fetch('/api/assets/live');
      if (!res.ok) throw new Error('Failed to fetch live assets');
      return res.json();
    },
    refetchInterval: 5000, // Poll every 5 seconds
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true
  });
  
  // Fallback to regular assets if live endpoint fails
  const { data: allAssets } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const res = await fetch('/api/assets');
      if (!res.ok) throw new Error('Failed to fetch assets');
      return res.json();
    },
    enabled: isError || !liveAssets // Only run this query if live assets fails
  });
  
  const [tickerItems, setTickerItems] = useState<MarketItem[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  
  // Format large numbers
  const formatNumber = (num?: number | null) => {
    if (num === undefined || num === null || isNaN(Number(num))) return '--';
    
    try {
      // Convert to number if it's a string
      const numValue = Number(num);
      
      if (isNaN(numValue)) {
        console.warn("Not a valid number:", num);
        return '--';
      }
      
      if (numValue >= 1_000_000_000) {
        return `${(numValue / 1_000_000_000).toFixed(1)}B`;
      } else if (numValue >= 1_000_000) {
        return `${(numValue / 1_000_000).toFixed(1)}M`;
      } else if (numValue >= 1_000) {
        return `${(numValue / 1_000).toFixed(1)}K`;
      } else {
        return numValue.toFixed(0);
      }
    } catch (e) {
      console.error("Error formatting number:", num, e);
      return '--';
    }
  };
  
  // Format price safely
  const formatPrice = (price: number | string | null | undefined) => {
    if (price === undefined || price === null || price === '') return '0.00';
    
    try {
      // Convert to number if it's a string
      const priceValue = Number(price);
      
      if (isNaN(priceValue)) {
        console.warn("Not a valid price:", price);
        return '0.00';
      }
      
      return priceValue.toFixed(2);
    } catch (e) {
      console.error("Error formatting price:", price, e);
      return '0.00';
    }
  };
  
  // Format last updated time
  const formatLastUpdated = (dateString?: string | null) => {
    if (!dateString) return '';
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      console.error("Error formatting date:", dateString, e);
      return '';
    }
  };
  
  // Add translation functionality
  const { t } = useTranslation();

  // Update ticker data when live assets are loaded
  useEffect(() => {
    if (liveAssets && Array.isArray(liveAssets)) {
      setTickerItems(
        liveAssets.map((asset: any) => ({
          symbol: asset.symbol,
          price: parseFloat(asset.price) || 0,
          change: parseFloat(asset.priceChange || asset.price_change || '0') || 0,
          changePercent: parseFloat(asset.priceChangePercent || asset.price_change_percentage || '0') || 0,
          volume: asset.volume || asset.daily_volume || null,
          lastUpdated: asset.updatedAt || asset.last_updated_at || new Date().toISOString(),
          assetType: asset.type || null,
          marketStatus: asset.marketStatus || asset.market_status || 'open',
          isMarketOpen: asset.isMarketOpen !== undefined ? asset.isMarketOpen : true
        }))
      );
      setIsConnected(true);
      setLastUpdated(new Date());
    }
  }, [liveAssets]);

  // Fallback to all assets if live assets fails
  useEffect(() => {
    if (isError && allAssets && Array.isArray(allAssets)) {
      setTickerItems(
        allAssets.map((asset: any) => ({
          symbol: asset.symbol,
          price: parseFloat(asset.price) || 0,
          change: parseFloat(asset.priceChange || asset.price_change || '0') || 0,
          changePercent: parseFloat(asset.priceChangePercent || asset.price_change_percentage || '0') || 0,
          volume: asset.volume || asset.daily_volume || null,
          lastUpdated: asset.updatedAt || asset.last_updated_at || null,
          assetType: asset.type || null,
          marketStatus: asset.marketStatus || asset.market_status || null,
          isMarketOpen: asset.isMarketOpen !== undefined ? asset.isMarketOpen : true
        }))
      );
      setIsConnected(false);
    }
  }, [isError, allAssets]);

  // Infinite scroll animation
  useEffect(() => {
    if (!scrollRef.current) return;
    
    const scrollContainer = scrollRef.current;
    
    const scrollContent = () => {
      if (scrollContainer.scrollLeft >= scrollContainer.scrollWidth / 2) {
        scrollContainer.scrollLeft = 0;
      } else {
        scrollContainer.scrollLeft += 1;
      }
    };
    
    const interval = setInterval(scrollContent, 30);
    
    return () => clearInterval(interval);
  }, [tickerItems]);

  return (
    <div className="bg-background/90 backdrop-blur-md border-t border-b border-border/60 py-0.5 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-12 overflow-hidden">
          {/* Live indicator */}
          <div className="flex-shrink-0 mr-4 flex items-center">
            {isConnected ? (
              <div className="flex items-center">
                <span className="relative flex h-3 w-3 mr-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                <span className="text-xs font-medium text-muted-foreground hidden sm:inline-block">LIVE MARKET</span>
              </div>
            ) : (
              <div className="flex items-center text-amber-500">
                <RefreshCw className="h-3 w-3 mr-2 animate-spin" />
                <span className="text-xs font-medium hidden sm:inline-block">UPDATING</span>
              </div>
            )}
          </div>
          
          {/* Global Market Badge */}
          <div className="flex-shrink-0 mr-4 hidden md:flex items-center">
            <Badge variant="outline" className="h-6 bg-muted/30 text-xs flex items-center gap-1.5 font-normal">
              <Globe className="h-3 w-3" /> Global Markets
            </Badge>
          </div>
          
          {/* Ticker items */}
          <div 
            ref={scrollRef}
            className="flex space-x-8 overflow-x-auto no-scrollbar whitespace-nowrap"
            style={{ scrollBehavior: 'smooth' }}
          >
            {/* Duplicate items for seamless looping */}
            {[...tickerItems, ...tickerItems].map((item, index) => (
              <div key={`${item.symbol}-${index}`} className="flex items-center space-x-3 py-1 px-1.5 transition-all duration-200 hover:bg-muted/40 rounded-lg cursor-pointer">
                <div className="flex flex-col min-w-[90px]">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-medium">{item.symbol}</span>
                    {/* Market status indicator */}
                    {item.marketStatus && item.marketStatus !== 'open' && (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className={`inline-flex h-2 w-2 rounded-full ${
                              item.assetType === 'crypto' ? 'bg-green-500' : 'bg-amber-500'
                            }`}></span>
                          </TooltipTrigger>
                          <TooltipContent side="bottom">
                            <div className="text-xs">
                              <p>
                                {item.isMarketOpen 
                                  ? t('market.open')
                                  : t('market.closed')}
                              </p>
                              <p className="text-muted-foreground">{item.assetType === 'crypto' 
                                ? t('market.crypto_247')
                                : t('market.standard_hours')}</p>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                  <div className="flex items-center">
                    <span className="text-xs text-muted-foreground">${formatPrice(item.price)}</span>
                    {/* Display a market closed indicator if appropriate */}
                    {item.isMarketOpen === false && item.assetType !== 'crypto' && (
                      <span className="ml-1 text-[10px] text-amber-500 font-medium uppercase">
                        {t('market.closed')}
                      </span>
                    )}
                    {item.volume && (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="ml-1.5 text-xs text-muted-foreground/60 flex items-center">
                              <Info className="h-2.5 w-2.5 mr-0.5" />
                              <span>Vol: {formatNumber(item.volume)}</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="bottom">
                            <div className="text-xs">
                              <p>Volume: {item.volume?.toLocaleString() || 'N/A'}</p>
                              {item.lastUpdated && (
                                <p className="text-muted-foreground text-xs flex items-center mt-1">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {formatLastUpdated(item.lastUpdated)}
                                </p>
                              )}
                              {item.marketStatus && (
                                <p className="text-muted-foreground text-xs flex items-center mt-1">
                                  <AlertCircle className="h-3 w-3 mr-1" />
                                  {t('market.status')}: {t(item.marketStatus)}
                                </p>
                              )}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                </div>
                
                <div className={`text-xs font-medium ${item.change >= 0 ? 'text-green-500' : 'text-red-500'} flex items-center`}>
                  {item.change >= 0 ? (
                    <ArrowUp className="h-3 w-3 mr-0.5" />
                  ) : (
                    <ArrowDown className="h-3 w-3 mr-0.5" />
                  )}
                  <span>{Math.abs(item.changePercent || 0).toFixed(2)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
