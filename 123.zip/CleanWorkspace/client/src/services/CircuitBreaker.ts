/**
 * Circuit Breaker
 * 
 * Implements the Circuit Breaker pattern for handling failures.
 * This pattern helps prevent repeated attempts to access a failing service,
 * allowing time for the service to recover.
 */

/**
 * Circuit breaker options interface
 */
export interface CircuitBreakerOptions {
  /** The number of failures required to open the circuit */
  failureThreshold: number;
  
  /** The time in milliseconds to wait before transitioning to half-open state */
  resetTimeout: number;
  
  /** Optional event handler for state transitions */
  onStateChange?: (prevState: CircuitState, newState: CircuitState) => void;
}

/**
 * Circuit breaker states
 */
export enum CircuitState {
  /** Circuit is closed, operations proceed normally */
  CLOSED = 'closed',
  
  /** Circuit is open, operations are blocked */
  OPEN = 'open',
  
  /** Circuit is testing if operations can proceed */
  HALF_OPEN = 'half-open'
}

/**
 * Circuit breaker implementation
 */
export class CircuitBreaker {
  /** Current state of the circuit */
  private state: CircuitState = CircuitState.CLOSED;
  
  /** Current failure count */
  private failureCount: number = 0;
  
  /** Successes in half-open state */
  private halfOpenSuccesses: number = 0;
  
  /** Time of the last failure */
  private lastFailureTime: number = 0;
  
  /** Circuit breaker options */
  private readonly options: CircuitBreakerOptions;
  
  /** Timer for transitioning from open to half-open */
  private resetTimer: NodeJS.Timeout | null = null;
  
  /**
   * Constructor
   * @param options Circuit breaker options
   */
  constructor(options: CircuitBreakerOptions) {
    this.options = {
      ...options,
      // Ensure reasonable defaults
      failureThreshold: options.failureThreshold || 5,
      resetTimeout: options.resetTimeout || 60000
    };
  }
  
  /**
   * Record a successful operation
   */
  public recordSuccess(): void {
    const prevState = this.state;
    
    if (this.state === CircuitState.HALF_OPEN) {
      this.halfOpenSuccesses++;
      
      // If we've had enough consecutive successes in half-open state, close the circuit
      if (this.halfOpenSuccesses >= Math.max(1, Math.floor(this.options.failureThreshold / 2))) {
        this.state = CircuitState.CLOSED;
        this.notifyStateChange(prevState, this.state);
      }
    } else if (this.state === CircuitState.CLOSED) {
      // In closed state, reset failure count on success
      this.failureCount = 0;
    }
  }
  
  /**
   * Record a failed operation
   * @returns True if the operation should be retried, false if the circuit is open
   */
  public recordFailure(): boolean {
    const prevState = this.state;
    this.lastFailureTime = Date.now();
    
    if (this.state === CircuitState.HALF_OPEN) {
      // Any failure in half-open state opens the circuit again
      this.state = CircuitState.OPEN;
      this.failureCount++;
      this.halfOpenSuccesses = 0;
      this.scheduleReset();
      this.notifyStateChange(prevState, this.state);
      return false;
    } else if (this.state === CircuitState.CLOSED) {
      this.failureCount++;
      
      // If we've hit the threshold, open the circuit
      if (this.failureCount >= this.options.failureThreshold) {
        this.state = CircuitState.OPEN;
        this.scheduleReset();
        this.notifyStateChange(prevState, this.state);
        return false;
      }
      
      // Still under threshold, allow retry
      return true;
    }
    
    // If already open, don't allow retry
    return false;
  }
  
  /**
   * Check if an operation can be attempted
   * @returns True if the operation can be attempted, false otherwise
   */
  public canAttemptOperation(): boolean {
    if (this.state === CircuitState.CLOSED) {
      return true;
    }
    
    if (this.state === CircuitState.OPEN) {
      // Check if it's time to transition to half-open
      const now = Date.now();
      if (now - this.lastFailureTime >= this.options.resetTimeout) {
        this.transitionToHalfOpen();
        return true;
      }
      return false;
    }
    
    // In half-open state, we allow a limited number of attempts
    return true;
  }
  
  /**
   * Get the current state of the circuit
   * @returns The current state
   */
  public getState(): CircuitState {
    return this.state;
  }
  
  /**
   * Get information about the circuit breaker
   * @returns An object with circuit breaker information
   */
  public getInfo(): {
    state: CircuitState;
    failureCount: number;
    lastFailureTime: number;
    timeSinceLastFailure: number;
    timeUntilReset: number;
  } {
    const now = Date.now();
    return {
      state: this.state,
      failureCount: this.failureCount,
      lastFailureTime: this.lastFailureTime,
      timeSinceLastFailure: now - this.lastFailureTime,
      timeUntilReset: this.state === CircuitState.OPEN 
        ? Math.max(0, this.options.resetTimeout - (now - this.lastFailureTime))
        : 0
    };
  }
  
  /**
   * Reset the circuit breaker to closed state
   */
  public reset(): void {
    const prevState = this.state;
    this.state = CircuitState.CLOSED;
    this.failureCount = 0;
    this.halfOpenSuccesses = 0;
    
    if (this.resetTimer) {
      clearTimeout(this.resetTimer);
      this.resetTimer = null;
    }
    
    this.notifyStateChange(prevState, this.state);
  }
  
  /**
   * Schedule a reset to half-open state
   */
  private scheduleReset(): void {
    if (this.resetTimer) {
      clearTimeout(this.resetTimer);
    }
    
    this.resetTimer = setTimeout(() => {
      this.transitionToHalfOpen();
    }, this.options.resetTimeout);
  }
  
  /**
   * Transition to half-open state
   */
  private transitionToHalfOpen(): void {
    const prevState = this.state;
    this.state = CircuitState.HALF_OPEN;
    this.halfOpenSuccesses = 0;
    
    this.notifyStateChange(prevState, this.state);
  }
  
  /**
   * Notify state change
   * @param prevState Previous state
   * @param newState New state
   */
  private notifyStateChange(prevState: CircuitState, newState: CircuitState): void {
    if (this.options.onStateChange && prevState !== newState) {
      this.options.onStateChange(prevState, newState);
    }
  }
}

/**
 * Create a circuit breaker
 * @param options Circuit breaker options
 * @returns A new circuit breaker
 */
export function createCircuitBreaker(options: CircuitBreakerOptions): CircuitBreaker {
  return new CircuitBreaker(options);
} 