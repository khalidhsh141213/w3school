# Automation Scripts Setup Guide

This guide explains how to set up the necessary dependencies to run the automation scripts for the Trading App refactoring.

## Prerequisites

The automation scripts require Node.js and several npm packages. Make sure you have Node.js installed in your environment.

## Required Packages

The scripts depend on the following packages:

- `glob` - For finding files matching patterns
- `fs` - Built-in Node.js module for file system operations
- `path` - Built-in Node.js module for path manipulations

## Installation

Run the following command in the project root to install the required packages:

```bash
npm install --save-dev glob
```

## Script Usage

The scripts are located in the `client/scripts` directory. You can run them directly using Node.js:

```bash
node scripts/refactor-codebase.js
```

## Available Scripts

- `add-validation.js` - Adds validation to components using the API client
- `find-duplicates.js` - Identifies potential duplicate components
- `identify-websocket-usage.js` - Finds components using WebSockets
- `identify-type-issues.js` - Identifies components with type issues
- `update-imports.js` - Updates import references to use consolidated components
- `refactor-codebase.js` - Master script that runs all other scripts in sequence

## Options

Most scripts support the following options:

- `--dry-run` - Run without making changes, just print what would be changed

The master refactoring script also supports:

- `--components` - Run only component-related transformations
- `--validation` - Run only validation-related transformations
- `--imports` - Run only import-related transformations

## Troubleshooting

If you encounter errors when running the scripts, check:

1. Make sure all required packages are installed
2. Verify you're running the scripts from the project root
3. Check file permissions (scripts should be executable)
4. Review any error messages in the console output

For specific issues, refer to the error message or contact the development team. 