import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Gift, Copy, Share } from 'lucide-react';

export default function ReferralInviteCard() {
  // Referral code
  const referralCode = 'TRADE100';
  
  // Copy referral code function
  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode);
    // Could add toast notification here
    console.log('Referral code copied to clipboard');
  };
  
  return (
    <Card className="shadow-md overflow-hidden">
      <div className="bg-gradient-to-br from-violet-500 to-indigo-600 p-4 text-white">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Refer & Earn</h3>
          <div className="bg-white/20 p-2 rounded-full">
            <Gift className="h-5 w-5" />
          </div>
        </div>
        <p className="mt-2 text-sm">Get $10 for each friend who joins</p>
      </div>
      
      <CardContent className="p-4">
        <div className="mb-4">
          <div className="text-sm font-medium mb-1">Your referral code</div>
          <div className="flex items-center">
            <div className="bg-indigo-50 text-indigo-700 font-mono font-medium rounded py-2 px-3 flex-1">
              {referralCode}
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="ml-2" 
              onClick={copyReferralCode}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <Button className="w-full" variant="outline">
          <Share className="h-4 w-4 mr-2" />
          Share with Friends
        </Button>
      </CardContent>
    </Card>
  );
}