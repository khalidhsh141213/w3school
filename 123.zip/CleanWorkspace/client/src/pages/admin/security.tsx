import AdminLayout from "@/components/admin/AdminLayout";
import RateLimitControl from "@/components/admin/RateLimitControl";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO, subDays } from "date-fns";
import {
    AlertTriangle,
    Ban,
    Calendar,
    Download,
    Eye,
    Filter,
    Lock,
    RefreshCw,
    RotateCw,
    Search,
    Shield,
    ShieldAlert,
    User,
    UserX,
    Zap
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

// Sample data for security logs
const securityLogs = [
  {
    id: "1",
    eventType: "login_failure",
    username: "user123",
    ipAddress: "192.168.1.100",
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "Failed login attempt - incorrect password",
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    severity: "medium"
  },
  {
    id: "2",
    eventType: "login_success",
    username: "admin",
    ipAddress: "192.168.1.101",
    userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "Login Success for admin account",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    severity: "low"
  },
  {
    id: "3",
    eventType: "admin_access",
    username: "admin",
    ipAddress: "192.168.1.101",
    userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "Accessed admin dashboard - user management page",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    severity: "low"
  },
  {
    id: "4",
    eventType: "user_blocked",
    username: "hacker123",
    ipAddress: "45.123.45.123",
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "User blocked after 5 failed login attempts",
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    severity: "high"
  },
  {
    id: "5",
    eventType: "api_rate_limit",
    username: "user456",
    ipAddress: "192.168.1.105",
    userAgent: "PostmanRuntime/7.32.3",
    details: "API rate limit exceeded - 120 requests/minute",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    severity: "medium"
  },
  {
    id: "6",
    eventType: "password_reset",
    username: "user789",
    ipAddress: "192.168.1.106",
    userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
    details: "Password reset requested",
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    severity: "low"
  },
  {
    id: "7",
    eventType: "suspicious_activity",
    username: "user345",
    ipAddress: "98.76.54.32",
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "Suspicious activity - multiple logins from different countries in 24 hours",
    timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    severity: "high"
  },
  {
    id: "8",
    eventType: "permission_change",
    username: "admin",
    ipAddress: "192.168.1.101",
    userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    details: "Changed user123 permissions from regular user to admin",
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    severity: "high"
  }
];

// Sample data for blocked IPs
const blockedIPs = [
  {
    id: "1",
    ipAddress: "45.123.45.123",
    reason: "Multiple failed login attempts",
    blockedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    location: "Unknown",
    blockedBy: "system"
  },
  {
    id: "2",
    ipAddress: "198.51.100.76",
    reason: "API penetration attempt",
    blockedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    location: "Unknown",
    blockedBy: "admin"
  },
  {
    id: "3",
    ipAddress: "203.0.113.45",
    reason: "API rate limit exceeded",
    blockedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    location: "Unknown",
    blockedBy: "system"
  }
];

// Function to get appropriate severity badge
const getSeverityBadge = (severity: string) => {
  switch (severity) {
    case "high":
      return <Badge variant="destructive">High Risk</Badge>;
    case "medium":
      return <Badge variant="warning">Medium Risk</Badge>;
    case "low":
      return <Badge variant="outline">Low Risk</Badge>;
    default:
      return <Badge variant="secondary">Not Specified</Badge>;
  }
};

// Function to get event type icon
const getEventTypeIcon = (eventType: string) => {
  switch (eventType) {
    case "login_failure":
      return <UserX className="h-4 w-4 text-destructive" />;
    case "login_success":
      return <User className="h-4 w-4 text-success" />;
    case "admin_access":
      return <Shield className="h-4 w-4 text-primary" />;
    case "user_blocked":
      return <Ban className="h-4 w-4 text-destructive" />;
    case "api_rate_limit":
      return <AlertTriangle className="h-4 w-4 text-warning" />;
    case "password_reset":
      return <RotateCw className="h-4 w-4 text-muted-foreground" />;
    case "suspicious_activity":
      return <ShieldAlert className="h-4 w-4 text-destructive" />;
    case "permission_change":
      return <Lock className="h-4 w-4 text-primary" />;
    default:
      return <Shield className="h-4 w-4" />;
  }
};

export default function AdminSecurityPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [selectedTab, setSelectedTab] = useState("logs");
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [timeFilter, setTimeFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");
  
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access the admin portal.",
        variant: "destructive"
      });
      location("/dashboard");
    }
  }, [user, location, toast]);

  // Mock API query for security logs
  const { data: logs, isLoading: isLoadingLogs, refetch: refetchLogs } = useQuery({
    queryKey: ["/api/admin/security/logs"],
    queryFn: () => Promise.resolve(securityLogs),
    enabled: !!user && user.userRole === "admin",
  });

  // Mock API query for blocked IPs
  const { data: blockedIPsList, isLoading: isLoadingBlockedIPs, refetch: refetchBlockedIPs } = useQuery({
    queryKey: ["/api/admin/security/blocked-ips"],
    queryFn: () => Promise.resolve(blockedIPs),
    enabled: !!user && user.userRole === "admin",
  });

  // Filter security logs
  const filterLogs = () => {
    if (!logs) return [];
    
    let filtered = [...logs];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(log => 
        log.username.toLowerCase().includes(query) ||
        log.ipAddress.toLowerCase().includes(query) ||
        log.details.toLowerCase().includes(query) ||
        log.eventType.toLowerCase().includes(query)
      );
    }
    
    // Apply time filter
    if (timeFilter !== "all") {
      const now = new Date();
      let cutoff: Date;
      
      switch (timeFilter) {
        case "today":
          cutoff = new Date(now.setHours(0, 0, 0, 0));
          break;
        case "yesterday":
          cutoff = subDays(new Date(now.setHours(0, 0, 0, 0)), 1);
          break;
        case "week":
          cutoff = subDays(new Date(), 7);
          break;
        case "month":
          cutoff = subDays(new Date(), 30);
          break;
        default:
          cutoff = new Date(0);
      }
      
      filtered = filtered.filter(log => {
        const logDate = parseISO(log.timestamp);
        return logDate >= cutoff;
      });
    }
    
    // Apply severity filter
    if (severityFilter !== "all") {
      filtered = filtered.filter(log => log.severity === severityFilter);
    }
    
    return filtered;
  };
  
  const filteredLogs = filterLogs();
  
  // Unblock IP address
  const unblockIP = (ipAddress: string) => {
    // In a real implementation, call API to unblock IP
    toast({
      title: "Unblocked",
      description: `Unblocked IP address ${ipAddress} successfully.`,
      variant: "default"
    });
    
    // Refetch the list of blocked IPs
    refetchBlockedIPs();
  };
  
  // Block new IP
  const blockNewIP = (ipAddress: string, reason: string) => {
    // In a real implementation, call API to block IP
    toast({
      title: "Blocked",
      description: `Blocked IP address ${ipAddress} successfully.`,
      variant: "default"
    });
    
    // Refetch the list of blocked IPs
    refetchBlockedIPs();
  };
  
  // Export logs
  const exportLogs = () => {
    toast({
      title: "Exporting logs",
      description: "Exporting security logs...",
      variant: "default"
    });
    
    // In a real implementation, trigger logs export
  };

  if (!user || loading) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-6 max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          
          <Skeleton className="h-12 w-full" />
          
          <div className="grid grid-cols-1 gap-6">
            {Array(3).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <Helmet>
        <title>Security & Access | Admin Portal</title>
      </Helmet>

      <div className="container mx-auto p-4 space-y-6 max-w-6xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Security & Access</h1>
            <p className="text-muted-foreground">Manage security settings and monitor system access</p>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
          <TabsList className="grid grid-cols-1 md:grid-cols-3 h-auto">
            <TabsTrigger value="logs" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Shield className="h-4 w-4 mr-2" />
              Security Logs
            </TabsTrigger>
            <TabsTrigger value="blocklist" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Ban className="h-4 w-4 mr-2" />
              IP Blocklist
            </TabsTrigger>
            <TabsTrigger value="api" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Zap className="h-4 w-4 mr-2" />
              API Rate Limits
            </TabsTrigger>
          </TabsList>

          {/* Security Logs Tab */}
          <TabsContent value="logs" className="space-y-4">
            <Card className="mb-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-md">Filter Security Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  {/* Search */}
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search logs..."
                      className="pl-9"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  {/* Time filter */}
                  <Select value={timeFilter} onValueChange={setTimeFilter}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <Calendar className="h-4 w-4 ml-2" />
                      <SelectValue placeholder="Filter by time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Time</SelectItem>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="yesterday">Yesterday</SelectItem>
                      <SelectItem value="week">Last 7 Days</SelectItem>
                      <SelectItem value="month">Last 30 Days</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  {/* Severity filter */}
                  <Select value={severityFilter} onValueChange={setSeverityFilter}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <Filter className="h-4 w-4 ml-2" />
                      <SelectValue placeholder="Filter by severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severities</SelectItem>
                      <SelectItem value="high">High Risk</SelectItem>
                      <SelectItem value="medium">Medium Risk</SelectItem>
                      <SelectItem value="low">Low Risk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Results stats */}
            <div className="text-sm text-muted-foreground mb-2">
              Displaying {filteredLogs.length} of {logs?.length || 0} logs
            </div>

            {/* Security logs table */}
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">Time</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="hidden md:table-cell">Details</TableHead>
                      <TableHead className="w-[140px]">Severity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No security logs match the filter criteria
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="font-medium">
                            <div className="text-xs text-muted-foreground">
                              {format(parseISO(log.timestamp), 'yyyy/MM/dd')}
                            </div>
                            <div>
                              {format(parseISO(log.timestamp), 'HH:mm:ss')}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{log.username}</div>
                            <div className="text-xs text-muted-foreground">{log.ipAddress}</div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getEventTypeIcon(log.eventType)}
                              <span className="text-sm">
                                {log.eventType === 'login_failure' && 'Login Failure'}
                                {log.eventType === 'login_success' && 'Login Success'}
                                {log.eventType === 'admin_access' && 'Admin Access'}
                                {log.eventType === 'user_blocked' && 'User Blocked'}
                                {log.eventType === 'api_rate_limit' && 'API Rate Limit Exceeded'}
                                {log.eventType === 'password_reset' && 'Password Reset'}
                                {log.eventType === 'suspicious_activity' && 'Suspicious Activity'}
                                {log.eventType === 'permission_change' && 'Permission Change'}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell max-w-[300px] truncate">
                            {log.details}
                          </TableCell>
                          <TableCell>
                            {getSeverityBadge(log.severity)}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* IP Blocklist Tab */}
          <TabsContent value="blocklist" className="space-y-4">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Block New IP</CardTitle>
                <CardDescription>Add a new IP to block access to the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Label htmlFor="ip-address" className="mb-2">IP Address</Label>
                    <Input
                      id="ip-address"
                      placeholder="Example: 192.168.1.1"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="block-reason" className="mb-2">Block Reason</Label>
                    <Input
                      id="block-reason"
                      placeholder="Reason for blocking this address"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="block-duration" className="mb-2">Block Duration</Label>
                    <Select defaultValue="day">
                      <SelectTrigger id="block-duration">
                        <SelectValue placeholder="Select duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hour">One Hour</SelectItem>
                        <SelectItem value="day">One Day</SelectItem>
                        <SelectItem value="week">One Week</SelectItem>
                        <SelectItem value="month">One Month</SelectItem>
                        <SelectItem value="permanent">Permanent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:self-end mt-2 md:mt-0">
                    <Button 
                      onClick={() => blockNewIP("192.168.1.10", "Manual block")}
                    >
                      <Ban className="h-4 w-4 mr-2" />
                      Block
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Blocked IPs list */}
            <Card>
              <CardHeader>
                <CardTitle>Blocked IPs</CardTitle>
                <CardDescription>List of blocked IP addresses currently preventing access to the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Blocked At</TableHead>
                      <TableHead>Expires At</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {blockedIPsList && blockedIPsList.length > 0 ? (
                      blockedIPsList.map((ip) => (
                        <TableRow key={ip.id}>
                          <TableCell className="font-medium">{ip.ipAddress}</TableCell>
                          <TableCell>{ip.reason}</TableCell>
                          <TableCell>{format(parseISO(ip.blockedAt), 'yyyy/MM/dd HH:mm')}</TableCell>
                          <TableCell>{format(parseISO(ip.expiresAt), 'yyyy/MM/dd HH:mm')}</TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => unblockIP(ip.ipAddress)}
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              Unblock
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No blocked IP addresses found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Rate Limits Tab */}
          <TabsContent value="api" className="space-y-4">
            <RateLimitControl />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
} 