-- Add new columns to economic_events table
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS event_time TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS country TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS source TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS source_id TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS actual_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS forecast_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS previous_value TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS affected_markets TEXT;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL;
ALTER TABLE economic_events ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_economic_events_date ON economic_events(event_date);
CREATE INDEX IF NOT EXISTS idx_economic_events_country ON economic_events(country);
CREATE INDEX IF NOT EXISTS idx_economic_events_importance ON economic_events(importance_level);
CREATE INDEX IF NOT EXISTS idx_economic_events_source ON economic_events(source);

-- Insert test data to ensure the new schema works
INSERT INTO economic_events (
  id,
  event_name,
  event_date,
  event_time,
  country,
  source,
  source_id,
  asset_impact,
  description,
  importance_level,
  actual_value,
  forecast_value,
  previous_value,
  affected_markets
) VALUES (
  'test-event-123',
  'Test Economic Event',
  CURRENT_DATE,
  '12:00:00',
  'TEST',
  'Test Script',
  'TEST123',
  '{"direction":"positive","impact":"positive","confidence":0.85,"analysis":"This is a test analysis"}',
  'Test description',
  'medium',
  '123.45',
  '120.00',
  '118.50',
  '["Global", "TEST"]'
) ON CONFLICT (id) DO NOTHING; 