/**
 * WebSocketStatusIndicator Component
 * 
 * Displays the current WebSocket connection status with visual indicators
 * and detailed diagnostic information.
 */

import { useState } from 'react';
import { 
  WebSocketService, 
  ConnectionStatus, 
  CircuitState 
} from '../services/WebSocketService';
import useWebSocketConnection from '../hooks/useWebSocketConnection';
import { getWebSocketUrl } from '../config/websocket';

// Icons
import { 
  AlertCircle, 
  CheckCircle, 
  RefreshCw, 
  XCircle, 
  ChevronDown, 
  ChevronUp, 
  Clock 
} from 'lucide-react';

interface WebSocketStatusIndicatorProps {
  url?: string;
  showDetails?: boolean;
  compact?: boolean;
  className?: string;
  onReconnect?: () => void;
  showReconnectButton?: boolean;
}

export default function WebSocketStatusIndicator({
  url: customUrl,
  showDetails = false,
  compact = false,
  className = '',
  onReconnect,
  showReconnectButton = true
}: WebSocketStatusIndicatorProps) {
  const url = customUrl || getWebSocketUrl();
  const [expandedView, setExpandedView] = useState(false);
  
  // Use our WebSocket connection hook to monitor the connection
  const { 
    status, 
    reset,
    getHealth 
  } = useWebSocketConnection(customUrl, {
    // Don't auto-connect if we're just monitoring
    autoConnect: false
  });
  
  // Get detailed health information
  const healthInfo = getHealth();
  
  // Format time in ms to a human-readable format
  const formatTime = (ms: number) => {
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${Math.floor(ms / 1000)}s`;
    if (ms < 3600000) return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
    return `${Math.floor(ms / 3600000)}h ${Math.floor((ms % 3600000) / 60000)}m`;
  };
  
  // Format different connection statuses
  const getStatusDisplay = () => {
    let icon;
    let color;
    let text;
    let bgColor;
    
    switch (status) {
      case ConnectionStatus.CONNECTED:
        icon = <CheckCircle className="h-4 w-4" />;
        color = "text-green-600";
        bgColor = "bg-green-100";
        text = "Connected";
        break;
      case ConnectionStatus.CONNECTING:
        icon = <RefreshCw className="h-4 w-4 animate-spin" />;
        color = "text-amber-600";
        bgColor = "bg-amber-100";
        text = "Connecting";
        break;
      case ConnectionStatus.RECONNECTING:
        icon = <RefreshCw className="h-4 w-4 animate-spin" />;
        color = "text-blue-600";
        bgColor = "bg-blue-100";
        text = "Reconnecting";
        break;
      case ConnectionStatus.CIRCUIT_OPEN:
        icon = <AlertCircle className="h-4 w-4" />;
        color = "text-purple-600";
        bgColor = "bg-purple-100";
        text = "Circuit Open";
        break;
      case ConnectionStatus.RATE_LIMITED:
        icon = <Clock className="h-4 w-4" />;
        color = "text-orange-600";
        bgColor = "bg-orange-100";
        text = "Rate Limited";
        break;
      case ConnectionStatus.ERROR:
        icon = <XCircle className="h-4 w-4" />;
        color = "text-red-600";
        bgColor = "bg-red-100";
        text = "Error";
        break;
      default: // DISCONNECTED
        icon = <XCircle className="h-4 w-4" />;
        color = "text-gray-600";
        bgColor = "bg-gray-100";
        text = "Disconnected";
    }
    
    return { icon, color, bgColor, text };
  };
  
  // Get circuit breaker display
  const getCircuitBreakerDisplay = () => {
    if (!healthInfo.circuitBreakerInfo) {
      return null;
    }
    
    const circuitInfo = healthInfo.circuitBreakerInfo;
    const stateColors = {
      [CircuitState.CLOSED]: "text-green-600",
      [CircuitState.HALF_OPEN]: "text-orange-600",
      [CircuitState.OPEN]: "text-red-600"
    };
    
    const stateLabels = {
      [CircuitState.CLOSED]: "Closed (Healthy)",
      [CircuitState.HALF_OPEN]: "Half-Open (Testing)",
      [CircuitState.OPEN]: "Open (Disabled)"
    };
    
    return (
      <div className="mt-2">
        <div className="text-sm font-medium">Circuit Breaker</div>
        <div className="flex justify-between items-center">
          <span className={stateColors[circuitInfo.state]}>
            {stateLabels[circuitInfo.state]}
          </span>
          <span className="text-xs text-gray-500">
            {circuitInfo.failureCount}/{circuitInfo.failureThreshold} failures
          </span>
        </div>
        
        {circuitInfo.state === CircuitState.OPEN && circuitInfo.timeUntilReset > 0 && (
          <div className="text-xs mt-1">
            Reset in {formatTime(circuitInfo.timeUntilReset)}
            <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
              <div
                className="bg-blue-600 h-1 rounded-full"
                style={{
                  width: `${100 - (circuitInfo.timeUntilReset / healthInfo.circuitBreakerInfo.resetTimeout) * 100}%`
                }}
              ></div>
            </div>
          </div>
        )}
      </div>
    );
  };
  
  // Get rate limiter display
  const getRateLimiterDisplay = () => {
    if (!healthInfo.rateLimiterInfo) {
      return null;
    }
    
    const rateLimiterInfo = healthInfo.rateLimiterInfo;
    const isLimited = rateLimiterInfo.isRateLimited;
    const usagePercent = ((rateLimiterInfo.maxOperations - rateLimiterInfo.remainingOperations) / rateLimiterInfo.maxOperations) * 100;
    
    return (
      <div className="mt-2">
        <div className="text-sm font-medium">Rate Limiter</div>
        <div className="flex justify-between items-center">
          <span className={isLimited ? "text-orange-600" : "text-green-600"}>
            {isLimited ? "Limited" : "Normal"}
          </span>
          <span className="text-xs text-gray-500">
            {rateLimiterInfo.remainingOperations}/{rateLimiterInfo.maxOperations} available
          </span>
        </div>
        
        {/* Usage bar */}
        <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
          <div
            className={`h-1 rounded-full ${usagePercent > 80 ? 'bg-red-500' : usagePercent > 50 ? 'bg-yellow-500' : 'bg-green-500'}`}
            style={{ width: `${usagePercent}%` }}
          ></div>
        </div>
        
        {/* Queue information */}
        {rateLimiterInfo.queueLength > 0 && (
          <div className="text-xs mt-1">
            Queue: {rateLimiterInfo.queueLength}/{rateLimiterInfo.maxQueueSize} messages
          </div>
        )}
      </div>
    );
  };
  
  // Compact version (just a status indicator dot)
  if (compact) {
    const { color, icon } = getStatusDisplay();
    
    return (
      <div 
        className={`inline-flex items-center ${className} ${color}`}
        title={`WebSocket: ${getStatusDisplay().text}`}
      >
        {icon}
      </div>
    );
  }
  
  // Standard version
  const { icon, color, bgColor, text } = getStatusDisplay();
  
  return (
    <div className={`websocket-status ${className}`}>
      {/* Status badge */}
      <div 
        className={`flex items-center gap-1 px-3 py-1 rounded-full ${bgColor} ${color} text-sm font-medium`}
        onClick={() => setExpandedView(prev => !prev)}
        style={{ cursor: "pointer" }}
      >
        {icon}
        <span>{text}</span>
        {expandedView ? (
          <ChevronUp className="h-3 w-3" />
        ) : (
          <ChevronDown className="h-3 w-3" />
        )}
      </div>
      
      {/* Detailed information (shown when expanded) */}
      {expandedView && (
        <div className="mt-2 p-3 bg-gray-50 rounded-md text-sm border border-gray-200">
          {/* Server URL */}
          <div className="text-xs text-gray-500 truncate" title={url}>
            {url.length > 40 ? `${url.substring(0, 37)}...` : url}
          </div>
          
          {/* Last activity */}
          {healthInfo.lastMessageReceivedTime !== -1 && (
            <div className="mt-2">
              <div className="text-sm font-medium">Last activity</div>
              <div className="text-sm">
                {formatTime(healthInfo.lastMessageReceivedTime)} ago
              </div>
            </div>
          )}
          
          {/* Circuit breaker status */}
          {getCircuitBreakerDisplay()}
          
          {/* Rate limiter status */}
          {getRateLimiterDisplay()}
          
          {/* Queue information */}
          {healthInfo.queueStats && healthInfo.queueStats.size > 0 && (
            <div className="mt-2">
              <div className="text-sm font-medium">Message Queue</div>
              <div className="text-sm">
                {healthInfo.queueStats.size} pending messages
              </div>
            </div>
          )}
          
          {/* Reconnect button */}
          {showReconnectButton && (
            <div className="mt-3">
              <button
                className={`w-full py-1 text-xs rounded-md border ${
                  status === ConnectionStatus.CIRCUIT_OPEN && 
                  healthInfo.circuitBreakerInfo?.timeUntilReset > 0
                    ? 'bg-gray-100 text-gray-400 border-gray-300 cursor-not-allowed'
                    : 'bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100'
                }`}
                onClick={() => {
                  reset();
                  if (onReconnect) onReconnect();
                }}
                disabled={
                  status === ConnectionStatus.CIRCUIT_OPEN && 
                  healthInfo.circuitBreakerInfo?.timeUntilReset > 0
                }
              >
                {status === ConnectionStatus.CIRCUIT_OPEN && 
                 healthInfo.circuitBreakerInfo?.timeUntilReset > 0
                  ? `Available in ${formatTime(healthInfo.circuitBreakerInfo.timeUntilReset)}`
                  : 'Reconnect'
                }
              </button>
            </div>
          )}
          
          {/* Show additional details if requested */}
          {showDetails && (
            <div className="mt-3 pt-2 border-t border-gray-200 text-xs font-mono text-gray-500">
              <pre className="whitespace-pre-wrap">{JSON.stringify({
                reconnectAttempts: healthInfo.reconnectAttempts,
                circuitState: healthInfo.circuitBreakerInfo?.state,
                failureCount: healthInfo.circuitBreakerInfo?.failureCount,
                queuedMessages: healthInfo.queueStats?.size
              }, null, 2)}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}