/**
 * Rate Limiter
 * 
 * A service for controlling the rate of operations, such as API calls or WebSocket messages.
 * Implements a token bucket algorithm with configurable rate limits and queue management.
 */

// Define the priority levels for operations
export enum Priority {
  LOW = 0,
  NORMAL = 1,
  HIGH = 2,
  CRITICAL = 3
}

// Queue item interface with priority
interface QueueItem<T> {
  operation: () => T;
  priority: Priority;
  timestamp: number;
}

// Rate limiter options interface
export interface RateLimiterOptions {
  maxOperations: number;     // Maximum number of operations allowed
  windowMs: number;          // Time window in milliseconds
  queueExceeded?: boolean;   // Whether to queue operations that exceed the rate limit
  maxQueueSize?: number;     // Maximum queue size (default: 100)
  priorityBasedQueue?: boolean; // Whether to use priority-based queuing (default: true)
}

export class RateLimiter {
  private operations: number[] = [];       // Timestamps of operations
  private queue: QueueItem<any>[] = [];    // Queue of operations that exceeded the rate limit
  private maxOperations: number;           // Maximum operations per window
  private windowMs: number;                // Time window in milliseconds
  private queueExceeded: boolean;          // Whether to queue operations that exceed the rate limit
  private maxQueueSize: number;            // Maximum queue size
  private processingInterval: NodeJS.Timeout | null = null;  // Interval for processing queued operations
  private priorityBasedQueue: boolean;     // Whether to use priority-based queuing

  /**
   * Constructor
   * @param options Rate limiter options
   */
  constructor(options: RateLimiterOptions) {
    this.maxOperations = options.maxOperations;
    this.windowMs = options.windowMs;
    this.queueExceeded = options.queueExceeded ?? true;
    this.maxQueueSize = options.maxQueueSize ?? 100;
    this.priorityBasedQueue = options.priorityBasedQueue ?? true;

    // Start processing queued operations
    this.startProcessingQueue();
  }

  /**
   * Check if an operation can be performed
   * @returns Whether the operation can be performed
   */
  public canPerformOperation(): boolean {
    this.clearOldOperations();
    return this.operations.length < this.maxOperations;
  }

  /**
   * Record a performed operation
   */
  public recordOperation(): void {
    this.operations.push(Date.now());
  }

  /**
   * Try to perform an operation
   * @param operation The operation to perform
   * @param priority The priority of the operation (default: NORMAL)
   * @returns Whether the operation was performed or queued
   */
  public tryOperation<T>(operation: () => T, priority: Priority = Priority.NORMAL): boolean {
    // Check if we can perform the operation
    if (this.canPerformOperation()) {
      // Perform the operation
      operation();
      this.recordOperation();
      return true;
    } else if (this.queueExceeded) {
      // Queue the operation if we're at the rate limit
      return this.queueOperation(operation, priority);
    }
    
    return false;
  }

  /**
   * Queue an operation
   * @param operation The operation to queue
   * @param priority The priority of the operation
   * @returns Whether the operation was queued
   */
  private queueOperation<T>(operation: () => T, priority: Priority): boolean {
    // Check if we've reached the maximum queue size
    if (this.queue.length >= this.maxQueueSize) {
      // If using priority-based queuing, we might remove a lower priority item
      if (this.priorityBasedQueue) {
        // Find the index of the lowest priority item
        const lowestPriorityIndex = this.findLowestPriorityItemIndex();
        
        // If we found a lower priority item, replace it
        if (lowestPriorityIndex !== -1 && 
            this.queue[lowestPriorityIndex].priority < priority) {
          this.queue[lowestPriorityIndex] = {
            operation,
            priority,
            timestamp: Date.now()
          };
          return true;
        }
      }
      
      // If we're not using priority-based queuing or couldn't find a lower priority item
      return false;
    }
    
    // Add the operation to the queue
    this.queue.push({
      operation,
      priority,
      timestamp: Date.now()
    });
    
    return true;
  }

  /**
   * Find the index of the lowest priority item in the queue
   * @returns The index of the lowest priority item, or -1 if the queue is empty
   */
  private findLowestPriorityItemIndex(): number {
    if (this.queue.length === 0) {
      return -1;
    }
    
    let lowestPriorityIndex = 0;
    let lowestPriority = this.queue[0].priority;
    
    for (let i = 1; i < this.queue.length; i++) {
      if (this.queue[i].priority < lowestPriority) {
        lowestPriorityIndex = i;
        lowestPriority = this.queue[i].priority;
      }
    }
    
    return lowestPriorityIndex;
  }

  /**
   * Process queued operations
   */
  private processQueue(): void {
    if (this.queue.length === 0 || !this.canPerformOperation()) {
      return;
    }
    
    // If using priority-based queuing, sort the queue by priority (highest first)
    if (this.priorityBasedQueue) {
      this.queue.sort((a, b) => b.priority - a.priority);
    }
    
    // Perform the next operation
    const item = this.queue.shift();
    if (item) {
      try {
        item.operation();
        this.recordOperation();
      } catch (error) {
        console.error('Error processing queued operation:', error);
      }
    }
  }

  /**
   * Start processing queued operations
   */
  private startProcessingQueue(): void {
    if (this.processingInterval !== null) {
      return;
    }
    
    // Process queued operations every 100ms
    this.processingInterval = setInterval(() => {
      this.processQueue();
    }, 100);
  }

  /**
   * Stop processing queued operations
   */
  private stopProcessingQueue(): void {
    if (this.processingInterval !== null) {
      clearInterval(this.processingInterval);
      this.processingInterval = null;
    }
  }

  /**
   * Clear operations that are outside the time window
   */
  private clearOldOperations(): void {
    const now = Date.now();
    const windowStart = now - this.windowMs;
    
    // Remove operations that are outside the time window
    this.operations = this.operations.filter(timestamp => timestamp >= windowStart);
  }

  /**
   * Clear the queue
   */
  public clearQueue(): void {
    this.queue = [];
  }

  /**
   * Get information about the rate limiter
   * @returns Rate limiter information
   */
  public getInfo(): {
    operationsCount: number;
    windowMs: number;
    maxOperations: number;
    remainingOperations: number;
    queueLength: number;
    maxQueueSize: number;
    isRateLimited: boolean;
    priorityBasedQueue: boolean;
    queuedItemsByPriority?: {
      [key: string]: number;
    };
  } {
    this.clearOldOperations();
    
    const operationsCount = this.operations.length;
    const remainingOperations = Math.max(0, this.maxOperations - operationsCount);
    
    // Count queued items by priority if using priority-based queuing
    let queuedItemsByPriority: { [key: string]: number } | undefined;
    
    if (this.priorityBasedQueue) {
      queuedItemsByPriority = {
        [Priority.LOW]: 0,
        [Priority.NORMAL]: 0,
        [Priority.HIGH]: 0,
        [Priority.CRITICAL]: 0
      };
      
      for (const item of this.queue) {
        queuedItemsByPriority[item.priority]++;
      }
    }
    
    return {
      operationsCount,
      windowMs: this.windowMs,
      maxOperations: this.maxOperations,
      remainingOperations,
      queueLength: this.queue.length,
      maxQueueSize: this.maxQueueSize,
      isRateLimited: operationsCount >= this.maxOperations,
      priorityBasedQueue: this.priorityBasedQueue,
      queuedItemsByPriority
    };
  }

  /**
   * Dispose of the rate limiter
   */
  public dispose(): void {
    this.stopProcessingQueue();
    this.clearQueue();
    this.operations = [];
  }
}

/**
 * Create a new rate limiter
 * @param options Rate limiter options
 * @returns A new rate limiter instance
 */
export function createRateLimiter(options: RateLimiterOptions): RateLimiter {
  return new RateLimiter(options);
} 