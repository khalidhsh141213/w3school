"use client";

import { useEffect, useState } from 'react';
import { CreditCard, TrendingUp, Wallet, LineChart } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface PortfolioSummaryData {
  totalValue: number;
  availableBalance: number;
  investedAmount: number;
  unrealizedPL: number;
  plPercentage: number;
}

interface PortfolioSummaryBarProps {
  userId?: string;
  isLoading?: boolean;
  initialData?: PortfolioSummaryData;
}

export default function PortfolioSummaryBar({ 
  userId, 
  isLoading = false,
  initialData 
}: PortfolioSummaryBarProps) {
  // Default to safe empty values
  const defaultData: PortfolioSummaryData = {
    totalValue: 0,
    availableBalance: 0,
    investedAmount: 0,
    unrealizedPL: 0,
    plPercentage: 0
  };
  
  const [data, setData] = useState<PortfolioSummaryData>(initialData || defaultData);

  useEffect(() => {
    if (initialData) {
      setData(initialData);
      return;
    }

    if (!userId) return;

    const fetchPortfolioData = async () => {
      try {
        // Use the correct endpoint for portfolio summary data
        const response = await fetch(`/api/portfolio-summary?userId=${userId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch portfolio data');
        }
        
        const portfolioData = await response.json();
        
        // Handle potentially null or undefined values safely
        setData({
          totalValue: portfolioData.totalValue || 0,
          availableBalance: portfolioData.availableBalance || 0,
          investedAmount: portfolioData.investedAmount || 0,
          unrealizedPL: portfolioData.unrealizedPL || 0,
          plPercentage: portfolioData.plPercentage || 0
        });
      } catch (error) {
        console.error('Error fetching portfolio data:', error);
        // Maintain existing data on error - don't reset to undefined values
      }
    };

    fetchPortfolioData();
  }, [userId, initialData]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="w-full bg-background border-b shadow-sm z-10 mb-4">
      <div className="container mx-auto px-4 py-3">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Total Value */}
          <SummaryItem
            icon={<CreditCard className="h-5 w-5 text-muted-foreground" />}
            label="Total Value"
            value={isLoading ? null : formatCurrency(data.totalValue)}
            valueClass="text-primary font-semibold"
          />
          
          {/* Available Balance */}
          <SummaryItem
            icon={<Wallet className="h-5 w-5 text-muted-foreground" />}
            label="Available Balance"
            value={isLoading ? null : formatCurrency(data.availableBalance)}
            valueClass="text-foreground"
          />
          
          {/* Invested Amount */}
          <SummaryItem
            icon={<TrendingUp className="h-5 w-5 text-muted-foreground" />}
            label="Invested Amount"
            value={isLoading ? null : formatCurrency(data.investedAmount)}
            valueClass="text-foreground"
          />
          
          {/* Unrealized P/L */}
          <SummaryItem
            icon={<LineChart className="h-5 w-5 text-muted-foreground" />}
            label="Unrealized P/L"
            value={isLoading ? null : formatCurrency(data.unrealizedPL || 0)}
            secondaryValue={isLoading ? null : `${(data.plPercentage || 0) > 0 ? '+' : ''}${(data.plPercentage || 0).toFixed(2)}%`}
            valueClass={(data.unrealizedPL || 0) >= 0 ? "text-green-600" : "text-red-600"}
            secondaryValueClass={(data.plPercentage || 0) >= 0 ? "text-green-600" : "text-red-600"}
          />
        </div>
      </div>
    </div>
  );
}

interface SummaryItemProps {
  icon: React.ReactNode;
  label: string;
  value: string | null;
  secondaryValue?: string | null;
  valueClass?: string;
  secondaryValueClass?: string;
}

function SummaryItem({ 
  icon, 
  label, 
  value, 
  secondaryValue, 
  valueClass = "",
  secondaryValueClass = ""
}: SummaryItemProps) {
  return (
    <div className="flex items-start space-x-2">
      <div className="p-2 rounded-md bg-muted/30">{icon}</div>
      <div className="flex-1">
        <p className="text-xs text-muted-foreground">{label}</p>
        {value === null ? (
          <Skeleton className="h-5 w-24 mt-1" />
        ) : (
          <p className={`text-sm ${valueClass}`}>{value}</p>
        )}
        {secondaryValue && (
          <p className={`text-xs ${secondaryValueClass}`}>{secondaryValue}</p>
        )}
      </div>
    </div>
  );
}