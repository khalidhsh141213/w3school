import { users } from '../../shared/schema';
import { eq } from 'drizzle-orm';
import express, { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { db } from '../db';

// Custom interface to add user to Express Request object
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        username: string;
        email: string;
        userRole: string;
      };
    }
  }
}

/**
 * Middleware to extract user from token but continue regardless of authentication status
 * This is a non-blocking middleware that just populates req.user if a valid token is found
 */
export const verifyToken = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from header or cookies
    const token = req.header('Authorization')?.replace('Bearer ', '') || req.cookies?.token;
    
    if (!token) {
      // No token, but continue anyway
      return next();
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret') as jwt.JwtPayload;
    
    // Get user from database
    const user = await db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      userRole: users.userRole
    }).from(users).where(eq(users.id, decoded.userId));
    
    if (user.length > 0) {
      // Add user to request object
      req.user = user[0];
    }
  } catch (error) {
    // If token is invalid, just continue without setting req.user
    console.log('Invalid token, continuing without authentication');
  }
  
  // Always continue to next middleware
  next();
};

/**
 * Middleware to verify user is authenticated
 */
export const verifyAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from header or cookies
    const token = req.header('Authorization')?.replace('Bearer ', '') || req.cookies?.token;
    
    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret') as jwt.JwtPayload;
    
    // Get user from database
    const user = await db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      userRole: users.userRole
    }).from(users).where(eq(users.id, decoded.userId));
    
    if (user.length === 0) {
      return res.status(401).json({ error: 'User not found' });
    }
    
    // Add user to request object
    req.user = user[0];
    
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ error: 'Invalid token' });
  }
};

/**
 * Middleware to verify user is an admin
 */
export const verifyAdmin = (req: Request, res: Response, next: NextFunction) => {
  // Check for session-based authentication first (passport.js)
  if (typeof req.isAuthenticated === 'function' && req.isAuthenticated() && req.user && req.user.userRole === 'admin') {
    return next();
  }
  
  // If no session, try token-based authentication
  try {
    // Get token from header or cookies
    const token = req.header('Authorization')?.replace('Bearer ', '') || req.cookies?.token;
    
    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret') as jwt.JwtPayload;
    
    // Get user from database
    db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      userRole: users.userRole
    })
    .from(users)
    .where(eq(users.id, decoded.userId))
    .then(results => {
      if (results.length === 0) {
        return res.status(401).json({ error: 'User not found' });
      }
      
      const user = results[0];
      
      // Check if user is an admin
      if (user.userRole !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }
      
      // Add user to request object
      req.user = user;
      
      next();
    })
    .catch(error => {
      console.error('Admin verification error:', error);
      return res.status(500).json({ error: 'Internal server error' });
    });
  } catch (error) {
    console.error('Admin verification error:', error);
    return res.status(401).json({ error: 'Authentication required' });
  }
};

// Add admin access tracking and logging
export const logAdminAccess = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const path = req.path;
  
  // Only track admin routes
  if (!path.startsWith('/api/admin')) {
    return next();
  }
  
  const user = req.user;
  const ip = req.ip || req.socket.remoteAddress || '';
  const method = req.method;
  const userAgent = req.headers['user-agent'] || '';
  
  // Log the access attempt
  console.log(`[ADMIN_ACCESS] ${new Date().toISOString()} | ${ip} | ${method} ${path} | User: ${user?.username || 'unauthenticated'} | ${userAgent}`);
  
  // In a real implementation, you would save this to a database
  
  // Continue processing the request
  next();
};

// Adds rate limiting for admin routes to prevent brute force attacks
export const adminRateLimit = express.Router();

// Simple in-memory rate limiting for demo
const adminAccessAttempts: Record<string, { count: number, lastAttempt: number }> = {};

adminRateLimit.use((req, res, next) => {
  const path = req.path;
  
  // Only rate limit admin routes
  if (!path.startsWith('/api/admin')) {
    return next();
  }
  
  const ip = req.ip || req.socket.remoteAddress || '';
  const now = Date.now();
  
  // Reset count if last attempt was more than 15 minutes ago
  if (adminAccessAttempts[ip] && now - adminAccessAttempts[ip].lastAttempt > 15 * 60 * 1000) {
    delete adminAccessAttempts[ip];
  }
  
  if (!adminAccessAttempts[ip]) {
    adminAccessAttempts[ip] = { count: 1, lastAttempt: now };
  } else {
    adminAccessAttempts[ip].count += 1;
    adminAccessAttempts[ip].lastAttempt = now;
  }
  
  // If too many attempts, block the request
  if (adminAccessAttempts[ip].count > 50) {
    console.log(`[ADMIN_RATE_LIMIT] ${new Date().toISOString()} | ${ip} | Block due to too many requests`);
    return res.status(429).json({ error: "Too many requests. Please try again later." });
  }
  
  next();
}); 