import { useTranslation } from '../lib/useTranslation';

const Footer = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-neutral-dark text-white py-4">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center">
              <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M9 22V12H15V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="ml-2 text-white text-lg font-condensed font-bold">{t('tradingPlatform')}</span>
            </div>
          </div>
          <div className="text-center md:text-right text-sm">
            <div>{t('allRightsReserved')}</div>
            <div className="mt-1">
              <a href="#" className="text-gray-400 hover:text-white mr-4">{t('terms')}</a>
              <a href="#" className="text-gray-400 hover:text-white mr-4">{t('privacy')}</a>
              <a href="#" className="text-gray-400 hover:text-white">{t('help')}</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
