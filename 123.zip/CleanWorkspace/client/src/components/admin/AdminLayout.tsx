import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/lib/authContext";
import { cn } from "@/lib/utils";
import {
    Activity,
    BarChart,
    Bell,
    Database,
    DollarSign,
    FileText,
    Home,
    LogOut,
    Menu,
    RefreshCw,
    Search,
    Settings,
    Shield,
    ShieldCheck,
    Users,
    X
} from "lucide-react";
import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Navigation items for admin sidebar
  const adminNavItems = [
    { 
      name: "Dashboard", 
      path: "/admin", 
      icon: <Home className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "User Management", 
      path: "/admin/users", 
      icon: <Users className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Asset Management", 
      path: "/admin/assets", 
      icon: <Database className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Trade Management", 
      path: "/admin/trades", 
      icon: <Activity className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Financial Control", 
      path: "/admin/finances", 
      icon: <DollarSign className="h-4 w-4 mr-3" />
    },
    { 
      name: "KYC Verification", 
      path: "/admin/kyc", 
      icon: <ShieldCheck className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Reports & Analytics", 
      path: "/admin/reports", 
      icon: <BarChart className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Security & Access", 
      path: "/admin/security", 
      icon: <Shield className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Activity Log", 
      path: "/admin/activity-log", 
      icon: <FileText className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Backup & Restore", 
      path: "/admin/backup", 
      icon: <Database className="h-4 w-4 mr-3" /> 
    },
    { 
      name: "Platform Settings", 
      path: "/admin/settings", 
      icon: <Settings className="h-4 w-4 mr-3" /> 
    },
  ];

  // Close mobile menu when location changes
  useEffect(() => {
    if (isMobileMenuOpen) {
      setIsMobileMenuOpen(false);
    }
  }, [location]);

  // Prevent scrolling when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  // Get current path for active link styling
  const isCurrentPath = (path: string) => {
    if (path === "/admin" && location === "/admin") {
      return true;
    }
    if (path !== "/admin" && location.startsWith(path)) {
      return true;
    }
    return false;
  };

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user || !user.username) return "A";
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar - desktop */}
      <aside className="w-64 border-r border-border hidden md:block">
        <div className="flex flex-col h-full">
          {/* Admin header */}
          <div className="px-4 py-3 border-b border-border flex items-center">
            <div className="h-9 w-9 bg-primary rounded-md flex items-center justify-center text-primary-foreground mr-3">
              <Settings className="h-5 w-5" />
            </div>
            <div>
              <div className="font-semibold">TradePro</div>
              <div className="text-xs text-muted-foreground">Admin Portal</div>
            </div>
          </div>
          
          {/* Search bar */}
          <div className="p-3 border-b border-border">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                type="text" 
                placeholder="Search..."
                className="pl-9 h-9 bg-muted/50"
              />
            </div>
          </div>
          
          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-2">
            <nav className="flex flex-col space-y-1">
              {adminNavItems.map((item) => (
                <div key={item.path}>
                  <Link
                    href={item.path}
                    className={cn(
                      "flex items-center px-3 py-2 rounded-md transition-colors text-sm",
                      isCurrentPath(item.path) 
                        ? "bg-primary text-primary-foreground font-medium" 
                        : "text-foreground hover:bg-muted"
                    )}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                    {item.badge && (
                      <Badge 
                        variant="default" 
                        className="ml-auto text-[10px] h-5 px-1.5 rounded-sm"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                  
                  {/* Sub-navigation items if any */}
                  {item.subpaths && isCurrentPath(item.path) && (
                    <div className="ml-7 mt-1 space-y-1">
                      {item.subpaths.map((subpath) => (
                        <Link
                          key={subpath.path}
                          href={subpath.path}
                          className={cn(
                            "block px-3 py-1.5 rounded-md transition-colors text-xs",
                            location === subpath.path 
                              ? "bg-primary/10 text-primary font-medium" 
                              : "text-muted-foreground hover:bg-muted hover:text-foreground"
                          )}
                        >
                          {subpath.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </nav>
          </ScrollArea>
          
          {/* User profile */}
          <div className="p-3 border-t border-border">
            <div className="flex items-center">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImage || ""} alt={user?.username || "Admin"} />
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="text-sm font-medium">{user?.username || "Admin"}</div>
                <div className="text-xs text-muted-foreground">Administrator</div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="ml-auto h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => logout()}
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
      
      {/* Mobile sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-full max-w-xs transform overflow-auto bg-background border-r border-border p-0 transition-transform duration-200 ease-in-out md:hidden ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Close button */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center">
              <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground mr-2">
                <Settings className="h-4 w-4" />
              </div>
              <div className="text-sm font-semibold">Admin Portal</div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Mobile navigation */}
          <ScrollArea className="flex-1 px-3 py-2">
            <nav className="flex flex-col space-y-1">
              {adminNavItems.map((item) => (
                <div key={item.path}>
                  <Link
                    href={item.path}
                    className={cn(
                      "flex items-center px-3 py-2 rounded-md transition-colors text-sm",
                      isCurrentPath(item.path) 
                        ? "bg-primary text-primary-foreground font-medium" 
                        : "text-foreground hover:bg-muted"
                    )}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                    {item.badge && (
                      <Badge 
                        variant="default" 
                        className="ml-auto text-[10px] h-5 px-1.5 rounded-sm"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                  
                  {/* Sub-navigation items if any */}
                  {item.subpaths && isCurrentPath(item.path) && (
                    <div className="ml-7 mt-1 space-y-1">
                      {item.subpaths.map((subpath) => (
                        <Link
                          key={subpath.path}
                          href={subpath.path}
                          className={cn(
                            "block px-3 py-1.5 rounded-md transition-colors text-xs",
                            location === subpath.path 
                              ? "bg-primary/10 text-primary font-medium" 
                              : "text-muted-foreground hover:bg-muted hover:text-foreground"
                          )}
                        >
                          {subpath.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </nav>
          </ScrollArea>
          
          {/* User profile in mobile menu */}
          <div className="p-3 border-t border-border">
            <div className="flex items-center">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImage || ""} alt={user?.username || "Admin"} />
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="text-sm font-medium">{user?.username || "Admin"}</div>
                <div className="text-xs text-muted-foreground">Administrator</div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="ml-auto h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => logout()}
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main content area */}
      <main className="flex-1 flex flex-col min-h-screen">
        {/* Top navigation bar */}
        <header className="h-14 border-b border-border px-4 flex items-center justify-between">
          <div className="flex items-center md:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 mr-2"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="flex-1 md:flex-none flex justify-end items-center space-x-3">
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8 rounded-full"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8 rounded-full relative"
            >
              <Bell className="h-4 w-4" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-primary"></span>
            </Button>
            
            <Link href="/admin/settings">
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 rounded-full"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </Link>
            
            <Separator orientation="vertical" className="h-6 mx-1" />
            
            <Link href="/dashboard">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs"
              >
                Back to Platform
              </Button>
            </Link>
          </div>
        </header>
        
        {/* Page content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
} 