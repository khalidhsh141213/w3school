
# WebSocket Usage Guide

## Overview
This guide explains how to use the centralized WebSocket manager for real-time data communication.

## WebSocket Manager
The WebSocket manager is located in `lib/websocket/WebSocketManager.ts` and provides a unified interface for WebSocket connections.

### Usage in Components
```tsx
import { useWebSocket } from '@/hooks/useWebSocket';

function MyComponent() {
  const { subscribe, send, status } = useWebSocket();
  
  useEffect(() => {
    const unsubscribe = subscribe(data => {
      // Handle incoming messages
    });
    
    return () => unsubscribe();
  }, []);
}
```

### Connection Status
The WebSocket manager provides connection status updates:
- CONNECTING
- CONNECTED
- DISCONNECTED
- ERROR

### Error Handling
The manager includes automatic reconnection and circuit breaker patterns.
