/*
 * Portfolio Management Migration
 * Implements portfolio tracking functionality:
 * - Creates portfolios table for user balances
 * - Initializes portfolios for existing users
 * - Updates portfolio values based on existing trades
 * - Adds constraints to ensure data integrity
 * 
 * Dependencies: 
 * - 0000_initial_migration.sql (users table)
 * - 0001_add_price_data.sql (price tracking)
 */

-- Create portfolios table
CREATE TABLE IF NOT EXISTS "portfolios" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL REFERENCES "users"("id"),
  "total_value" DOUBLE PRECISION NOT NULL DEFAULT 50000,
  "available_balance" DOUBLE PRECISION NOT NULL DEFAULT 50000,
  "invested_amount" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "unrealized_pl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "pl_percentage" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Add index for faster queries on portfolios
CREATE INDEX IF NOT EXISTS "portfolios_user_id_idx" ON "portfolios"("user_id");

-- Initialize portfolios for existing users
INSERT INTO "portfolios" ("user_id")
SELECT "id" FROM "users"
WHERE NOT EXISTS (
  SELECT 1 FROM "portfolios" WHERE "portfolios"."user_id" = "users"."id"
);

-- Update portfolio values based on existing trades
UPDATE "portfolios" p
SET 
  "invested_amount" = COALESCE(
    (
      SELECT SUM(t.quantity * t.entry_price / t.leverage)
      FROM "trades" t
      WHERE t.user_id = p.user_id AND t.status = 'open'
    ), 
    0
  ),
  "available_balance" = p.total_value - COALESCE(
    (
      SELECT SUM(t.quantity * t.entry_price / t.leverage)
      FROM "trades" t
      WHERE t.user_id = p.user_id AND t.status = 'open'
    ),
    0
  );

-- Add constraint to ensure a user has only one portfolio
ALTER TABLE "portfolios" ADD CONSTRAINT "unique_user_portfolio" UNIQUE ("user_id"); 