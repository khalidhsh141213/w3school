import AdminLayout from "@/components/admin/AdminLayout";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import {
    AlertTriangle,
    Check,
    Database,
    Download,
    FileUp,
    Loader2,
    RotateCw,
    Upload
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

// Sample data for backups
const sampleBackups = [
  {
    id: "backup-1",
    name: "Full Automatic Backup",
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    size: "128.5 MB",
    type: "full",
    status: "completed",
    createdBy: "System",
    tables: ["users", "assets", "transactions", "trades", "settings"],
    records: {
      users: 256,
      assets: 45,
      trades: 1254,
      transactions: 5280
    },
    location: "local"
  },
  {
    id: "backup-2",
    name: "Manual Backup Before System Update",
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    size: "40.2 MB",
    type: "full",
    status: "completed",
    createdBy: "AdminUser",
    tables: ["users", "assets", "trades", "transactions", "settings", "activity_logs"],
    records: {
      users: 1235,
      assets: 153,
      trades: 8621,
      transactions: 5510,
      settings: 38,
      activity_logs: 12124
    },
    location: "local"
  },
  {
    id: "backup-3",
    name: "Full Automatic Backup",
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    size: "38.5 MB",
    type: "full",
    status: "completed",
    createdBy: "System",
    tables: ["users", "assets", "trades", "transactions", "settings", "activity_logs"],
    records: {
      users: 1192,
      assets: 148,
      trades: 8213,
      transactions: 5210,
      settings: 38,
      activity_logs: 11423
    },
    location: "cloud"
  },
  {
    id: "backup-4",
    name: "User-Specific Backup",
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    size: "8.2 MB",
    type: "partial",
    status: "completed",
    createdBy: "SuperAdmin",
    tables: ["users"],
    records: {
      users: 1150
    },
    location: "local"
  },
  {
    id: "backup-5",
    name: "Full Automatic Backup",
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    size: "35.9 MB",
    type: "full",
    status: "completed",
    createdBy: "System",
    tables: ["users", "assets", "trades", "transactions", "settings", "activity_logs"],
    records: {
      users: 1102,
      assets: 142,
      trades: 7632,
      transactions: 4832,
      settings: 38,
      activity_logs: 10245
    },
    location: "cloud"
  }
];

const BackupPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("backups");
  const [isBackupInProgress, setIsBackupInProgress] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);
  const [isRestoreInProgress, setIsRestoreInProgress] = useState(false);
  const [restoreProgress, setRestoreProgress] = useState(0);
  const [confirmRestore, setConfirmRestore] = useState(false);
  const [autoBackupSettings, setAutoBackupSettings] = useState({
    enabled: true,
    frequency: "daily",
    time: "02:00",
    keepLocal: true,
    keepCloud: true,
    retention: 30,
  });
  
  // Check if user is admin
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access this page.",
        variant: "destructive"
      });
      location("/");
    }
  }, [user, location, toast]);

  // In a real implementation, you would fetch backups from API
  const { data: backups, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/backups"],
    queryFn: () => Promise.resolve(sampleBackups), // Mocked data
    enabled: !!user && user.userRole === "admin",
  });

  // Simulate backup process
  const startBackup = (isFullBackup: boolean) => {
    setIsBackupInProgress(true);
    setBackupProgress(0);
    
    // Simulate progress
    const interval = setInterval(() => {
      setBackupProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsBackupInProgress(false);
          
          toast({
            title: "Backup Created",
            description: `Full backup ${isFullBackup ? "created" : "partial"} successfully.`,
          });
          
          // In real implementation, you would refresh the backup list
          refetch();
          
          return 100;
        }
        return prev + 5;
      });
    }, 200);
  };

  // Simulate restore process
  const startRestore = () => {
    if (!selectedBackup || !confirmRestore) return;
    
    setIsRestoreInProgress(true);
    setRestoreProgress(0);
    
    // Simulate progress
    const interval = setInterval(() => {
      setRestoreProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRestoreInProgress(false);
          setConfirmRestore(false);
          
          toast({
            title: "Database Restored",
            description: "The database has been restored from the selected backup successfully.",
          });
          
          return 100;
        }
        return prev + 2;
      });
    }, 100);
  };

  // Delete backup
  const deleteBackup = (backupId: string) => {
    // In real implementation, you would call API to delete
    toast({
      title: "Backup Deleted",
      description: "The backup has been successfully deleted.",
    });
    
    // Refresh list
    refetch();
  };

  // Update auto backup settings
  const saveAutoBackupSettings = () => {
    // In real implementation, you would save to API/DB
    toast({
      title: "Settings Saved",
      description: "Automatic backup settings have been saved successfully.",
    });
  };

  // Loading state
  if (isLoading || !user) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-6">
          <div className="flex justify-between items-center mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          <Skeleton className="h-12 w-full mb-6" />
          <Skeleton className="h-[500px] w-full rounded-md" />
        </div>
      </AdminLayout>
    );
  }

  // If user is not admin, don't render the page
  if (user.userRole !== "admin") {
    return null;
  }

  return (
    <AdminLayout>
      <Helmet>
        <title>Backup & Restore | Admin Panel</title>
      </Helmet>

      <div className="container mx-auto p-4 space-y-6 max-w-6xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Backup & Restore</h1>
            <p className="text-muted-foreground">Manage database backups and restoration</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 w-full md:w-[500px]">
            <TabsTrigger value="backups">Backups</TabsTrigger>
            <TabsTrigger value="restore">Restore</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          {/* Backups Tab */}
          <TabsContent value="backups" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Available Backups</h2>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => startBackup(false)}
                  disabled={isBackupInProgress}
                >
                  <Database className="h-4 w-4 mr-2" />
                  Partial Backup
                </Button>
                <Button 
                  onClick={() => startBackup(true)}
                  disabled={isBackupInProgress}
                >
                  <Database className="h-4 w-4 mr-2" />
                  Full Backup
                </Button>
              </div>
            </div>
            
            {isBackupInProgress && (
              <Card className="mb-4">
                <CardContent className="pt-6">
                  <div className="mb-2 flex justify-between items-center">
                    <span className="text-sm font-medium">Creating backup...</span>
                    <span className="text-sm text-muted-foreground">{backupProgress}%</span>
                  </div>
                  <Progress value={backupProgress} className="h-2" />
                </CardContent>
              </Card>
            )}
            
            <Card>
              <CardHeader>
                <CardTitle>Backup History</CardTitle>
                <CardDescription>Previous backups with download options</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[250px]">Backup</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead className="text-left">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backups && backups.length > 0 ? (
                      backups.map((backup) => (
                        <TableRow key={backup.id}>
                          <TableCell className="font-medium">{backup.name}</TableCell>
                          <TableCell>
                            {format(parseISO(backup.createdAt), 'yyyy/MM/dd HH:mm')}
                          </TableCell>
                          <TableCell>
                            {backup.type === 'full' ? 'Full Backup' : 'Partial Backup'}
                          </TableCell>
                          <TableCell>{backup.size}</TableCell>
                          <TableCell>{backup.createdBy}</TableCell>
                          <TableCell>{backup.location}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDownload(backup.id)}
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Download
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No backups available
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Restore Tab */}
          <TabsContent value="restore" className="space-y-4">
            <Alert variant="warning" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Warning</AlertTitle>
              <AlertDescription>
                Restoring the database will overwrite all current data. Please ensure you have a recent backup before proceeding.
              </AlertDescription>
            </Alert>
            
            <Card>
              <CardHeader>
                <CardTitle>Restore Database</CardTitle>
                <CardDescription>
                  Select the backup version you want to restore from
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="backup-select">Backup Version</Label>
                    <Select
                      value={selectedBackup || ""}
                      onValueChange={setSelectedBackup}
                    >
                      <SelectTrigger id="backup-select">
                        <SelectValue placeholder="Select a backup" />
                      </SelectTrigger>
                      <SelectContent>
                        {backups && backups.map((backup) => (
                          <SelectItem key={backup.id} value={backup.id}>
                            {backup.name} - {format(parseISO(backup.createdAt), 'yyyy/MM/dd HH:mm')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedBackup && (
                    <div className="pt-4">
                      <h3 className="text-md font-semibold mb-2">Backup Details</h3>
                      {backups && (
                        (() => {
                          const backup = backups.find(b => b.id === selectedBackup);
                          if (!backup) return null;
                          
                          return (
                            <div className="space-y-3 text-sm">
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Name:</div>
                                <div>{backup.name}</div>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Creation Date:</div>
                                <div>{format(parseISO(backup.createdAt), 'yyyy/MM/dd HH:mm')}</div>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Type:</div>
                                <div>{backup.type === 'full' ? 'Full Backup' : 'Partial Backup'}</div>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Size:</div>
                                <div>{backup.size}</div>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Tables:</div>
                                <div>{backup.tables.join(', ')}</div>
                              </div>
                              
                              <Separator className="my-2" />
                              
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-muted-foreground">Users:</div>
                                <div>{backup.records.users || 0}</div>
                              </div>
                              {backup.records.assets && (
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="text-muted-foreground">Assets:</div>
                                  <div>{backup.records.assets}</div>
                                </div>
                              )}
                              {backup.records.trades && (
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="text-muted-foreground">Trades:</div>
                                  <div>{backup.records.trades}</div>
                                </div>
                              )}
                              {backup.records.transactions && (
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="text-muted-foreground">Transactions:</div>
                                  <div>{backup.records.transactions}</div>
                                </div>
                              )}
                            </div>
                          );
                        })()
                      )}
                    </div>
                  )}
                  
                  {isRestoreInProgress && (
                    <div className="pt-4">
                      <div className="mb-2 flex justify-between items-center">
                        <span className="text-sm font-medium">Restoring database...</span>
                        <span className="text-sm text-muted-foreground">{restoreProgress}%</span>
                      </div>
                      <Progress value={restoreProgress} className="h-2" />
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox 
                      id="confirm-restore" 
                      checked={confirmRestore}
                      onCheckedChange={(checked) => setConfirmRestore(checked === true)}
                      disabled={!selectedBackup || isRestoreInProgress}
                    />
                    <label
                      htmlFor="confirm-restore"
                      className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I confirm that I want to restore the database from the selected backup
                    </label>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="destructive" 
                  onClick={startRestore}
                  disabled={!selectedBackup || !confirmRestore || isRestoreInProgress}
                  className="w-full"
                >
                  {isRestoreInProgress ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Restoring...
                    </>
                  ) : (
                    <>
                      <RotateCw className="h-4 w-4 mr-2" />
                      Restore Database
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Upload Backup</CardTitle>
                <CardDescription>
                  You can upload a previously downloaded backup file
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center w-full">
                  <label
                    htmlFor="backup-upload"
                    className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-muted/30 hover:bg-muted/50"
                  >
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <FileUp className="w-8 h-8 mb-3 text-muted-foreground" />
                      <p className="mb-2 text-sm text-muted-foreground">
                        <span className="font-semibold">Click to upload</span> or drag and drop
                      </p>
                      <p className="text-xs text-muted-foreground">
                        SQL or JSON backup files
                      </p>
                    </div>
                    <input id="backup-upload" type="file" className="hidden" />
                  </label>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full md:w-auto">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Backup File
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Automatic Backup Settings</CardTitle>
                <CardDescription>
                  Configure automatic system backup operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-backup">Automatic Backup</Label>
                    <p className="text-sm text-muted-foreground">
                      Enable automatic database backup
                    </p>
                  </div>
                  <Switch
                    id="auto-backup"
                    checked={autoBackupSettings.enabled}
                    onCheckedChange={(checked) => setAutoBackupSettings({ ...autoBackupSettings, enabled: checked })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backup-frequency">Backup Frequency</Label>
                  <Select
                    value={autoBackupSettings.frequency}
                    onValueChange={(value) => setAutoBackupSettings({ ...autoBackupSettings, frequency: value })}
                    disabled={!autoBackupSettings.enabled}
                  >
                    <SelectTrigger id="backup-frequency">
                      <SelectValue placeholder="Select backup frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backup-time">Backup Time</Label>
                  <Input
                    id="backup-time"
                    type="time"
                    value={autoBackupSettings.time}
                    onChange={(e) => setAutoBackupSettings({ ...autoBackupSettings, time: e.target.value })}
                    disabled={!autoBackupSettings.enabled || autoBackupSettings.frequency === 'hourly'}
                  />
                  <p className="text-xs text-muted-foreground">
                    Time when the automatic backup will be performed (server local time)
                  </p>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label>Storage Locations</Label>
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="local-storage" 
                        checked={autoBackupSettings.keepLocal}
                        onCheckedChange={(checked) => setAutoBackupSettings({ ...autoBackupSettings, keepLocal: checked === true })}
                        disabled={!autoBackupSettings.enabled}
                      />
                      <div className="grid gap-1">
                        <label
                          htmlFor="local-storage"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Local Storage
                        </label>
                        <p className="text-xs text-muted-foreground">
                          Keep a backup on the local server
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="cloud-storage" 
                        checked={autoBackupSettings.keepCloud}
                        onCheckedChange={(checked) => setAutoBackupSettings({ ...autoBackupSettings, keepCloud: checked === true })}
                        disabled={!autoBackupSettings.enabled}
                      />
                      <div className="grid gap-1">
                        <label
                          htmlFor="cloud-storage"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Cloud Storage
                        </label>
                        <p className="text-xs text-muted-foreground">
                          Upload backup to cloud storage (S3, Google Cloud, etc.)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="retention-period">Retention Period (days)</Label>
                  <Input
                    id="retention-period"
                    type="number"
                    min="1"
                    max="365"
                    value={autoBackupSettings.retention}
                    onChange={(e) => setAutoBackupSettings({ ...autoBackupSettings, retention: parseInt(e.target.value) || 30 })}
                    disabled={!autoBackupSettings.enabled}
                  />
                  <p className="text-xs text-muted-foreground">
                    Number of days backups will be kept before being automatically deleted
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={saveAutoBackupSettings}>
                  <Check className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default BackupPage; 