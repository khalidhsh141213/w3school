import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { WebSocketManager } from './WebSocketManager';

// Mock WebSocket
class MockWebSocket {
  url: string;
  onopen: ((event: any) => void) | null = null;
  onclose: ((event: any) => void) | null = null;
  onmessage: ((event: any) => void) | null = null;
  onerror: ((event: any) => void) | null = null;
  readyState: number = 0;
  CONNECTING: number = 0;
  OPEN: number = 1;
  CLOSING: number = 2;
  CLOSED: number = 3;
  
  constructor(url: string) {
    this.url = url;
    this.readyState = this.CONNECTING;
    
    // Auto connect after a small delay
    setTimeout(() => {
      this.readyState = this.OPEN;
      if (this.onopen) this.onopen({ target: this });
    }, 50);
  }
  
  send(data: string): void {
    // Mock implementation
  }
  
  close(): void {
    this.readyState = this.CLOSING;
    setTimeout(() => {
      this.readyState = this.CLOSED;
      if (this.onclose) this.onclose({ target: this });
    }, 50);
  }
  
  // Helper to simulate receiving a message
  _receiveMessage(data: any): void {
    if (this.onmessage) {
      this.onmessage({ data: JSON.stringify(data) });
    }
  }
  
  // Helper to simulate an error
  _triggerError(error: any): void {
    if (this.onerror) {
      this.onerror({ error });
    }
  }
}

// Replace the global WebSocket with our mock
global.WebSocket = MockWebSocket as any;

describe('WebSocketManager', () => {
  let manager: WebSocketManager;
  
  beforeEach(() => {
    vi.useFakeTimers();
    manager = new WebSocketManager();
  });
  
  afterEach(() => {
    vi.useRealTimers();
    manager.disconnect();
  });
  
  it('should successfully connect to a WebSocket endpoint', async () => {
    const connectSpy = vi.spyOn(manager, 'connect');
    
    manager.connect('crypto');
    
    expect(connectSpy).toHaveBeenCalledWith('crypto');
    expect(manager.isConnected()).toBe(false); // Initially not connected
    
    // Advance timers to trigger the onopen event
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.isConnected()).toBe(true);
  });
  
  it('should properly disconnect from a WebSocket', async () => {
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.isConnected()).toBe(true);
    
    manager.disconnect();
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.isConnected()).toBe(false);
  });
  
  it('should handle subscriptions correctly', async () => {
    const mockCallback = vi.fn();
    
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    manager.subscribe('BTC-USD', mockCallback);
    
    expect(manager.getSubscriptionCount()).toBe(1);
    
    // Simulate receiving a message
    const mockData = { symbol: 'BTC-USD', price: 50000 };
    (manager['ws'] as any)._receiveMessage({
      type: 'price_update',
      data: mockData
    });
    
    expect(mockCallback).toHaveBeenCalledWith(mockData);
    
    // Unsubscribe
    manager.unsubscribe('BTC-USD');
    expect(manager.getSubscriptionCount()).toBe(0);
    
    // Reset mock and send another message
    mockCallback.mockReset();
    (manager['ws'] as any)._receiveMessage({
      type: 'price_update',
      data: mockData
    });
    
    expect(mockCallback).not.toHaveBeenCalled();
  });
  
  it('should handle multiple subscriptions', async () => {
    const btcCallback = vi.fn();
    const ethCallback = vi.fn();
    
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    manager.subscribe('BTC-USD', btcCallback);
    manager.subscribe('ETH-USD', ethCallback);
    
    expect(manager.getSubscriptionCount()).toBe(2);
    
    // Simulate BTC update
    (manager['ws'] as any)._receiveMessage({
      type: 'price_update',
      data: { symbol: 'BTC-USD', price: 50000 }
    });
    
    expect(btcCallback).toHaveBeenCalledTimes(1);
    expect(ethCallback).not.toHaveBeenCalled();
    
    // Simulate ETH update
    (manager['ws'] as any)._receiveMessage({
      type: 'price_update',
      data: { symbol: 'ETH-USD', price: 3000 }
    });
    
    expect(btcCallback).toHaveBeenCalledTimes(1);
    expect(ethCallback).toHaveBeenCalledTimes(1);
  });
  
  it('should handle errors properly', async () => {
    const errorCallback = vi.fn();
    
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    manager.onError(errorCallback);
    
    // Simulate error
    const errorObj = new Error('Connection lost');
    (manager['ws'] as any)._triggerError(errorObj);
    
    expect(errorCallback).toHaveBeenCalledWith(errorObj);
  });
  
  it('should handle reconnection attempts', async () => {
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.isConnected()).toBe(true);
    
    // Simulate unexpected close
    (manager['ws'] as any).onclose?.({ code: 1006, reason: 'Connection lost' });
    
    // Should attempt to reconnect
    await vi.advanceTimersByTimeAsync(2000);
    
    // New connection should be established
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.isConnected()).toBe(true);
  });
  
  it('should maintain subscriptions after reconnection', async () => {
    const callback = vi.fn();
    
    manager.connect('crypto');
    await vi.advanceTimersByTimeAsync(100);
    
    manager.subscribe('BTC-USD', callback);
    expect(manager.getSubscriptionCount()).toBe(1);
    
    // Simulate unexpected close
    (manager['ws'] as any).onclose?.({ code: 1006, reason: 'Connection lost' });
    
    // Should attempt to reconnect
    await vi.advanceTimersByTimeAsync(2000);
    
    // New connection should be established
    await vi.advanceTimersByTimeAsync(100);
    
    expect(manager.getSubscriptionCount()).toBe(1);
    
    // Should still receive messages for the subscription
    (manager['ws'] as any)._receiveMessage({
      type: 'price_update',
      data: { symbol: 'BTC-USD', price: 50000 }
    });
    
    expect(callback).toHaveBeenCalledTimes(1);
  });
}); 