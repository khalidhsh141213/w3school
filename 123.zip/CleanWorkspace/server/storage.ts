import { 
  users, type User, type InsertUser,
  watchlist, type Watchlist, type InsertWatchlist,
  portfolio, type Portfolio, type InsertPortfolio,
  portfolioSummary, type PortfolioSummary, type InsertPortfolioSummary,
  trades, type Trade, type InsertTrade,
  marketData, type MarketData, type InsertMarketData,
  aiAnalysis, type AiAnalysis, type InsertAiAnalysis,
  assets, type Asset, type InsertAsset,
  priceHistory, type PriceHistory, type InsertPriceHistory,
  economicEvents, type EconomicEvent, type InsertEconomicEvent,
  sessions, type Session, type InsertSession,
  transactions, type Transaction, type InsertTransaction,
  kycDocuments, type KycDocument, type InsertKycDocument
} from "../shared/schema.js";
import { db } from "./db.js";
import { eq, and, desc, asc, sql, like, between, not, notLike, inArray, or, notInArray } from "drizzle-orm";
import { marketDataCache, analysisCache, userCache } from "./cache.js";
import { errorHandler, ErrorType, ErrorSeverity } from "./services/errorHandlingService.js";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: string): Promise<User>;
  updateUserPreferences(userId: number, updates: Partial<User>): Promise<User>;

  // Watchlist methods
  getWatchlistItems(userId: number): Promise<Watchlist[]>;
  addToWatchlist(item: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: number, symbol: string): Promise<void>;

  // Portfolio methods
  getPortfolioItems(userId: number): Promise<Portfolio[]>;
  getPortfolioItem(userId: number, symbol: string): Promise<Portfolio | undefined>;
  updatePortfolio(item: InsertPortfolio): Promise<Portfolio>;
  
  // Portfolio Summary methods
  getPortfolioSummary(userId: number): Promise<{
    totalValue: string;
    changePercent: string;
    holdings: Array<{
      symbol: string;
      shares: string;
      value: number;
      avgPrice: string;
    }>;
  }>;
  
  // New Portfolio Summary Table methods
  getDetailedPortfolioSummary(userId: number): Promise<PortfolioSummary | undefined>;
  savePortfolioSummary(summary: InsertPortfolioSummary): Promise<PortfolioSummary>;
  updatePortfolioSummary(userId: number, updates: Partial<InsertPortfolioSummary>): Promise<PortfolioSummary>;
  
  // Trade methods
  createTrade(trade: InsertTrade): Promise<Trade>;
  getUserTrades(userId: number): Promise<Trade[]>;
  
  // Market data methods
  getMarketData(symbol: string): Promise<MarketData | undefined>;
  getAllMarketData(): Promise<MarketData[]>;
  updateMarketData(data: InsertMarketData): Promise<MarketData>;
  
  // AI Analysis methods
  getAnalysisForSymbol(symbol: string): Promise<AiAnalysis | undefined>;
  saveAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;
  
  // Asset methods
  getAsset(symbol: string): Promise<Asset | undefined>;
  getAssetById(id: number): Promise<Asset | undefined>;
  getAllAssets(): Promise<Asset[]>;
  getAssetsByType(type: string): Promise<Asset[]>;
  getAssetsBySymbols(symbols: string[]): Promise<Asset[]>;
  getRecentlyUpdatedAssets(limit?: number): Promise<Asset[]>;
  getAssetsByFilter(filter: { type?: string, sector?: string, country?: string }): Promise<Asset[]>;
  getTrendingAssets(limit?: number): Promise<Asset[]>;
  getFeaturedAssets(limit?: number): Promise<Asset[]>;
  getMovers(limit?: number): Promise<Asset[]>;
  
  // Price History methods
  getPriceHistory(symbol: string, interval: string, limit?: number): Promise<PriceHistory[]>;
  getPriceHistoryByDateRange(symbol: string, startDate: Date, endDate: Date, interval: string): Promise<PriceHistory[]>;
  
  // Economic Events methods
  getEconomicEvents(limit?: number): Promise<EconomicEvent[]>;
  getEconomicEventsByDateRange(startDate: Date, endDate: Date): Promise<EconomicEvent[]>;
  getEconomicEventsByCountry(country: string): Promise<EconomicEvent[]>;
  getEconomicEventsByImpact(impact: string): Promise<EconomicEvent[]>;
  
  // Session methods
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined>;
  deleteSession(id: string): Promise<void>;
  deleteUserSessions(userId: number): Promise<void>;
  
  // Transaction methods
  getTransactions(userId: number, limit?: number): Promise<Transaction[]>;
  getTransactionById(id: string): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: string, status: string): Promise<Transaction>;

  // KYC Document methods
  getKycDocuments(userId: number): Promise<KycDocument[]>;
  getKycDocumentById(id: number): Promise<KycDocument | undefined>;
  createKycDocument(document: InsertKycDocument): Promise<KycDocument>;
  updateKycDocument(id: number, updates: Partial<KycDocument>): Promise<KycDocument | undefined>;
  getPendingKycDocuments(limit?: number): Promise<KycDocument[]>;
  updateKycDocumentStatus(id: number, status: string, adminNotes?: string): Promise<KycDocument>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private watchlists: Map<number, Watchlist[]>;
  private portfolios: Map<number, Portfolio[]>;
  private portfolioSummaries: Map<number, PortfolioSummary>;
  private tradesList: Map<number, Trade[]>;

  async getPortfolioSummary(userId: number) {
    try {
      const portfolio = await this.getPortfolioItems(userId);
      const trades = await this.getUserTrades(userId);
      
      let totalValue = 0;
      let changePercent = 0;
      
      const holdings = portfolio.map(item => ({
        symbol: item.symbol,
        shares: item.shares,
        value: parseFloat(item.shares) * parseFloat(item.avgPrice),
        avgPrice: item.avgPrice
      }));

      totalValue = holdings.reduce((sum, item) => sum + item.value, 0);
      
      return {
        totalValue: totalValue.toFixed(2),
        changePercent: changePercent.toFixed(2),
        holdings
      };
    } catch (error) {
      console.error("Error calculating portfolio summary:", error);
      throw error;
    }
  }
  
  // Portfolio Summary Table methods - for the new portfolio_summary table
  async getDetailedPortfolioSummary(userId: number): Promise<PortfolioSummary | undefined> {
    try {
      return this.portfolioSummaries.get(userId);
    } catch (error) {
      console.error("Error getting detailed portfolio summary:", error);
      throw error;
    }
  }
  
  async savePortfolioSummary(summary: InsertPortfolioSummary): Promise<PortfolioSummary> {
    try {
      // Create a new portfolio summary with additional fields
      const portfolioSummary: PortfolioSummary = {
        ...summary,
        id: Math.floor(Math.random() * 1000000), // Generate ID if not provided
        lastUpdate: new Date(),
        createdAt: new Date()
      };
      
      // Save to the map using userId as the key
      this.portfolioSummaries.set(summary.userId, portfolioSummary);
      
      return portfolioSummary;
    } catch (error) {
      console.error("Error saving portfolio summary:", error);
      throw error;
    }
  }
  
  async updatePortfolioSummary(userId: number, updates: Partial<InsertPortfolioSummary>): Promise<PortfolioSummary> {
    try {
      // Get existing summary
      const existingSummary = this.portfolioSummaries.get(userId);
      
      if (!existingSummary) {
        // If no summary exists, create a new one with the updates
        const newSummary: InsertPortfolioSummary = {
          userId,
          totalBalance: updates.totalBalance || "0.00",
          totalEquity: updates.totalEquity || "0.00", 
          totalProfit: updates.totalProfit || "0.00",
          totalLoss: updates.totalLoss || "0.00",
          openPositions: updates.openPositions || 0,
          totalInvestment: updates.totalInvestment || "0.00",
          availableBalance: updates.availableBalance || "0.00",
          totalReturn: updates.totalReturn || "0.00",
          marginAuthorized: updates.marginAuthorized || "0.00",
          marginUsed: updates.marginUsed || "0.00",
          unauthorizedPnl: updates.unauthorizedPnl || "0.00"
        };
        
        return this.savePortfolioSummary(newSummary);
      }
      
      // Update the existing summary
      const updatedSummary: PortfolioSummary = {
        ...existingSummary,
        ...updates,
        lastUpdate: new Date()
      };
      
      // Save the updated summary
      this.portfolioSummaries.set(userId, updatedSummary);
      
      return updatedSummary;
    } catch (error) {
      console.error("Error updating portfolio summary:", error);
      throw error;
    }
  }
  private marketDataMap: Map<string, MarketData>;
  private analysisMap: Map<string, AiAnalysis>;
  private assetsMap: Map<string, Asset>;
  private assetsIdMap: Map<number, Asset>;
  private priceHistoryMap: Map<string, PriceHistory[]>;
  private economicEventsMap: Map<number, EconomicEvent>;
  private sessionsMap: Map<string, Session>;
  private transactionsMap: Map<number, Transaction[]>;
  private kycDocumentsMap: Map<number, KycDocument[]>;
  
  currentId: number;
  currentWatchlistId: number;
  currentPortfolioId: number;
  currentTradeId: number;
  currentMarketDataId: number;
  currentAnalysisId: number;
  currentAssetId: number;
  currentPriceHistoryId: number;
  currentEconomicEventId: number;
  currentKycDocumentId: number;
  
  constructor() {
    this.users = new Map();
    this.watchlists = new Map();
    this.portfolios = new Map();
    this.portfolioSummaries = new Map();
    this.tradesList = new Map();
    this.marketDataMap = new Map();
    this.analysisMap = new Map();
    this.assetsMap = new Map();
    this.assetsIdMap = new Map();
    this.priceHistoryMap = new Map();
    this.economicEventsMap = new Map();
    this.sessionsMap = new Map();
    this.transactionsMap = new Map();
    this.kycDocumentsMap = new Map();
    
    this.currentId = 1;
    this.currentWatchlistId = 1;
    this.currentPortfolioId = 1;
    this.currentTradeId = 1;
    this.currentMarketDataId = 1;
    this.currentAnalysisId = 1;
    this.currentAssetId = 1;
    this.currentPriceHistoryId = 1;
    this.currentEconomicEventId = 1;
    this.currentKycDocumentId = 1;
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return undefined;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(), 
      updatedAt: new Date(),
      languagePreference: insertUser.languagePreference || 'en',
      currencyPreference: insertUser.currencyPreference || 'USD',
      themePreference: insertUser.themePreference || 'light',
      notificationPreference: insertUser.notificationPreference || {},
      privacySettings: insertUser.privacySettings || {}
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserBalance(userId: number, newBalance: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { ...user, balance: newBalance, updatedAt: new Date() };
    this.users.set(userId, updatedUser);
    
    return updatedUser;
  }
  
  async updateUserPreferences(userId: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Don't allow updating sensitive fields
    const safeUpdates = { ...updates };
    delete safeUpdates.id;
    delete safeUpdates.password;
    delete safeUpdates.createdAt;
    
    const updatedUser = { 
      ...user, 
      ...safeUpdates, 
      updatedAt: new Date() 
    };
    
    this.users.set(userId, updatedUser);
    
    return updatedUser;
  }
  
  // Watchlist methods
  async getWatchlistItems(userId: number): Promise<Watchlist[]> {
    return this.watchlists.get(userId) || [];
  }
  
  async addToWatchlist(item: InsertWatchlist): Promise<Watchlist> {
    const id = this.currentWatchlistId++;
    const watchlistItem: Watchlist = { ...item, id, addedAt: new Date() };
    
    // Get existing watchlist items for the user or create a new array
    const userWatchlist = this.watchlists.get(item.userId) || [];
    
    // Check if the item is already in the watchlist
    const exists = userWatchlist.some(w => w.symbol === item.symbol);
    if (exists) {
      return userWatchlist.find(w => w.symbol === item.symbol) as Watchlist;
    }
    
    // Add the item to the watchlist
    userWatchlist.push(watchlistItem);
    this.watchlists.set(item.userId, userWatchlist);
    
    return watchlistItem;
  }
  
  async removeFromWatchlist(userId: number, symbol: string): Promise<void> {
    const userWatchlist = this.watchlists.get(userId) || [];
    
    // Filter out the item to remove
    const updatedWatchlist = userWatchlist.filter(item => item.symbol !== symbol);
    
    // Update the watchlist
    this.watchlists.set(userId, updatedWatchlist);
  }
  
  // Portfolio methods
  async getPortfolioItems(userId: number): Promise<Portfolio[]> {
    return this.portfolios.get(userId) || [];
  }
  
  async getPortfolioItem(userId: number, symbol: string): Promise<Portfolio | undefined> {
    const userPortfolio = this.portfolios.get(userId) || [];
    return userPortfolio.find(item => item.symbol === symbol);
  }
  
  async updatePortfolio(item: InsertPortfolio): Promise<Portfolio> {
    // Get existing portfolio items for the user or create a new array
    const userPortfolio = this.portfolios.get(item.userId) || [];
    
    // Check if the item is already in the portfolio
    const index = userPortfolio.findIndex(p => p.symbol === item.symbol);
    
    if (index !== -1) {
      // Update existing item
      const updatedItem: Portfolio = { 
        ...userPortfolio[index],
        ...item,
        updatedAt: new Date()
      };
      
      userPortfolio[index] = updatedItem;
      this.portfolios.set(item.userId, userPortfolio);
      
      return updatedItem;
    } else {
      // Add new item
      const id = this.currentPortfolioId++;
      const newItem: Portfolio = { ...item, id, updatedAt: new Date() };
      
      userPortfolio.push(newItem);
      this.portfolios.set(item.userId, userPortfolio);
      
      return newItem;
    }
  }
  
  // Trade methods
  async createTrade(trade: InsertTrade): Promise<Trade> {
    const id = this.currentTradeId++;
    const newTrade: Trade = { ...trade, id, tradeDate: new Date() };
    
    // Get existing trades for the user or create a new array
    const userTrades = this.tradesList.get(trade.userId) || [];
    
    // Add the trade to the list
    userTrades.push(newTrade);
    this.tradesList.set(trade.userId, userTrades);
    
    return newTrade;
  }
  
  async getUserTrades(userId: number): Promise<Trade[]> {
    const userTrades = this.tradesList.get(userId) || [];
    
    // Sort by trade date in descending order (most recent first)
    return [...userTrades].sort((a, b) => b.tradeDate.getTime() - a.tradeDate.getTime());
  }
  
  // Market data methods
  async getMarketData(symbol: string): Promise<MarketData | undefined> {
    return this.marketDataMap.get(symbol);
  }
  
  async getAllMarketData(): Promise<MarketData[]> {
    return Array.from(this.marketDataMap.values());
  }
  
  async updateMarketData(data: InsertMarketData): Promise<MarketData> {
    // Check if we're updating an existing record
    const existingData = this.marketDataMap.get(data.symbol);
    
    if (existingData) {
      // Update existing record
      const updatedData: MarketData = { 
        ...existingData,
        ...data,
        updatedAt: new Date()
      };
      
      this.marketDataMap.set(data.symbol, updatedData);
      
      return updatedData;
    } else {
      // Create new record
      const id = this.currentMarketDataId++;
      const newData: MarketData = { ...data, id, updatedAt: new Date() };
      
      this.marketDataMap.set(data.symbol, newData);
      
      return newData;
    }
  }
  
  // AI Analysis methods
  async getAnalysisForSymbol(symbol: string): Promise<AiAnalysis | undefined> {
    return this.analysisMap.get(symbol);
  }
  
  async saveAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const id = this.currentAnalysisId++;
    const newAnalysis: AiAnalysis = { ...analysis, id, createdAt: new Date() };
    
    this.analysisMap.set(analysis.symbol, newAnalysis);
    
    return newAnalysis;
  }
  
  // Asset methods
  async getAsset(symbol: string): Promise<Asset | undefined> {
    return this.assetsMap.get(symbol);
  }
  
  async getAssetById(id: number): Promise<Asset | undefined> {
    return this.assetsIdMap.get(id);
  }
  
  async getAllAssets(): Promise<Asset[]> {
    return Array.from(this.assetsMap.values());
  }
  
  async getAssetsByType(type: string): Promise<Asset[]> {
    const assets = Array.from(this.assetsMap.values());
    return assets.filter(asset => asset.type === type);
  }
  
  async getAssetsBySymbols(symbols: string[]): Promise<Asset[]> {
    const assets = Array.from(this.assetsMap.values());
    return assets.filter(asset => symbols.includes(asset.symbol));
  }
  
  async getRecentlyUpdatedAssets(limit: number = 20): Promise<Asset[]> {
    const assets = Array.from(this.assetsMap.values());
    return assets
      .sort((a, b) => (b.updatedAt?.getTime() || 0) - (a.updatedAt?.getTime() || 0))
      .slice(0, limit);
  }
  
  async getAssetsByFilter(filter: { type?: string, sector?: string, country?: string }): Promise<Asset[]> {
    const assets = Array.from(this.assetsMap.values());
    
    return assets.filter(asset => {
      let match = true;
      
      if (filter.type && asset.type !== filter.type) {
        match = false;
      }
      
      if (filter.sector && asset.sector !== filter.sector) {
        match = false;
      }
      
      if (filter.country && asset.country !== filter.country) {
        match = false;
      }
      
      return match;
    });
  }
  
  // Get trending assets - these are assets with high trading volume or significant price changes
  async getTrendingAssets(limit: number = 10): Promise<Asset[]> {
    // Get all assets and market data
    const assets = Array.from(this.assetsMap.values());
    const marketData = Array.from(this.marketDataMap.values());
    
    // Create a map of symbols to their market data for faster lookup
    const marketDataBySymbol = new Map<string, MarketData>();
    marketData.forEach(data => {
      marketDataBySymbol.set(data.symbol, data);
    });
    
    // Enrich assets with market data for sorting
    const enrichedAssets = assets.map(asset => {
      const data = marketDataBySymbol.get(asset.symbol);
      return {
        ...asset,
        volume: data?.volume || 0,
        changePercent: data?.changePercent || 0,
        score: (data?.volume || 0) * Math.abs(data?.changePercent || 0) / 100 // Score based on volume and price change
      };
    });
    
    // Sort by the calculated score (volume * abs(change))
    const sortedAssets = enrichedAssets.sort((a, b) => b.score - a.score);
    
    // Return the top N assets
    return sortedAssets.slice(0, limit);
  }
  
  async getFeaturedAssets(limit: number = 8): Promise<Asset[]> {
    // في التنفيذ الواقعي، ستعتمد الأصول المميزة على بعض المنطق التجاري
    // هنا، نختار الأصول التي تم وضع علامة "featured" عليها أو نختار عينة من أفضل الأصول
    const assets = Array.from(this.assetsMap.values());
    
    // تصفية للأصول التي لها خصائص معينة (مثال: الأصول الكريبتو الشائعة أو الأسهم الكبيرة)
    // نعتبر هنا أن الأصول المميزة هي تلك ذات أعلى قيمة سوقية أو أكثر شعبية
    const filteredAssets = assets.filter(asset => 
      asset.symbol && 
      !asset.symbol.startsWith('TEST_') && 
      asset.type !== 'test' &&
      (asset.type === 'crypto' || 
       asset.type === 'stock' || 
       asset.symbol.includes('BTC') || 
       asset.symbol.includes('ETH') ||
       asset.symbol.includes('AAPL') ||
       asset.symbol.includes('MSFT') ||
       asset.symbol.includes('GOOG') ||
       asset.featured === true)
    );
    
    // اختر مجموعة عشوائية من الأصول المصفاة لتجنب إظهار نفس المجموعة في كل مرة
    const shuffled = filteredAssets.sort(() => 0.5 - Math.random());
    
    // عد محدد من الأصول
    return shuffled.slice(0, limit);
  }

  async getMovers(limit: number = 10): Promise<Asset[]> {
    // الهدف هو إيجاد الأصول ذات أكبر تغير في السعر (إيجابياً أو سلبياً)
    const assets = Array.from(this.assetsMap.values());
    const marketData = Array.from(this.marketDataMap.values());
    
    // تصفية الأصول الاختبارية
    const filteredAssets = assets.filter(a => 
      a.symbol && !a.symbol.startsWith('TEST_') && a.type !== 'test'
    );
    
    // إنشاء خريطة من الرموز إلى بيانات السوق الخاصة بها للبحث السريع
    const marketDataBySymbol = new Map<string, MarketData>();
    marketData.forEach(data => {
      marketDataBySymbol.set(data.symbol, data);
    });
    
    // إثراء الأصول ببيانات السوق للفرز
    const enrichedAssets = filteredAssets.map(asset => {
      const data = marketDataBySymbol.get(asset.symbol);
      return {
        ...asset,
        changePercent: data?.changePercent || '0',
        absoluteChange: Math.abs(parseFloat(data?.changePercent || '0'))
      };
    });
    
    // فرز حسب القيمة المطلقة للتغيير (سواء كان الارتفاع أو الانخفاض)
    const sortedAssets = enrichedAssets.sort((a, b) => b.absoluteChange - a.absoluteChange);
    
    // إرجاع أعلى N من الأصول
    return sortedAssets.slice(0, limit);
  }
  
  // Price History methods
  async getPriceHistory(symbol: string, interval: string, limit: number = 100): Promise<PriceHistory[]> {
    const key = `${symbol}_${interval}`;
    const history = this.priceHistoryMap.get(key) || [];
    
    // Sort by timestamp in descending order and apply limit
    return [...history]
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
  
  async getPriceHistoryByDateRange(
    symbol: string, 
    startDate: Date, 
    endDate: Date, 
    interval: string
  ): Promise<PriceHistory[]> {
    const key = `${symbol}_${interval}`;
    const history = this.priceHistoryMap.get(key) || [];
    
    // Filter by date range
    return history.filter(item => {
      const timestamp = item.timestamp.getTime();
      return timestamp >= startDate.getTime() && timestamp <= endDate.getTime();
    });
  }
  
  // Economic Events methods
  async getEconomicEvents(limit: number = 50): Promise<EconomicEvent[]> {
    const events = Array.from(this.economicEventsMap.values());
    
    // Sort by event date in descending order and apply limit
    return [...events]
      .sort((a, b) => b.eventDate.getTime() - a.eventDate.getTime())
      .slice(0, limit);
  }
  
  async getEconomicEventsByDateRange(startDate: Date, endDate: Date): Promise<EconomicEvent[]> {
    const events = Array.from(this.economicEventsMap.values());
    
    // Filter by date range
    return events.filter(event => {
      const eventDate = event.eventDate.getTime();
      return eventDate >= startDate.getTime() && eventDate <= endDate.getTime();
    });
  }
  
  async getEconomicEventsByCountry(country: string): Promise<EconomicEvent[]> {
    const events = Array.from(this.economicEventsMap.values());
    
    // Filter by country
    return events.filter(event => event.country === country);
  }
  
  async getEconomicEventsByImpact(impact: string): Promise<EconomicEvent[]> {
    const events = Array.from(this.economicEventsMap.values());
    
    // Filter by impact level
    return events.filter(event => event.impact === impact);
  }
  
  // Session methods
  async getSession(id: string): Promise<Session | undefined> {
    return this.sessionsMap.get(id);
  }
  
  async createSession(session: InsertSession): Promise<Session> {
    const newSession: Session = {
      ...session,
      id: session.id || crypto.randomUUID(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.sessionsMap.set(newSession.id, newSession);
    
    return newSession;
  }
  
  async updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined> {
    const session = this.sessionsMap.get(id);
    if (!session) {
      return undefined;
    }
    
    const updatedSession: Session = {
      ...session,
      ...updates,
      updatedAt: new Date()
    };
    
    this.sessionsMap.set(id, updatedSession);
    
    return updatedSession;
  }
  
  async deleteSession(id: string): Promise<void> {
    this.sessionsMap.delete(id);
  }
  
  async deleteUserSessions(userId: number): Promise<void> {
    // Find and delete all sessions for the user
    for (const [id, session] of this.sessionsMap.entries()) {
      if (session.userId === userId) {
        this.sessionsMap.delete(id);
      }
    }
  }
  
  // Transaction methods
  async getTransactions(userId: number, limit: number = 50): Promise<Transaction[]> {
    const userTransactions = this.transactionsMap.get(userId) || [];
    
    // Sort by transaction date in descending order and apply limit
    return [...userTransactions]
      .sort((a, b) => b.transactionDate.getTime() - a.transactionDate.getTime())
      .slice(0, limit);
  }
  
  async getTransactionById(id: string): Promise<Transaction | undefined> {
    // Search through all transactions to find the one with matching ID
    for (const transactions of this.transactionsMap.values()) {
      const transaction = transactions.find(t => t.id === id);
      if (transaction) {
        return transaction;
      }
    }
    
    return undefined;
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const newTransaction: Transaction = {
      ...transaction,
      id: crypto.randomUUID(), // Generate a new UUID
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const userTransactions = this.transactionsMap.get(transaction.userId) || [];
    userTransactions.push(newTransaction);
    this.transactionsMap.set(transaction.userId, userTransactions);
    
    return newTransaction;
  }
  
  async updateTransactionStatus(id: string, status: string): Promise<Transaction> {
    // Find the transaction by ID
    for (const [userId, transactions] of this.transactionsMap.entries()) {
      const index = transactions.findIndex(t => t.id === id);
      
      if (index !== -1) {
        // Update the transaction status
        const transaction = transactions[index];
        const updatedTransaction: Transaction = {
          ...transaction,
          status,
          updatedAt: new Date()
        };
        
        // Replace the transaction in the array
        transactions[index] = updatedTransaction;
        this.transactionsMap.set(userId, transactions);
        
        return updatedTransaction;
      }
    }
    
    throw new Error(`Transaction with ID ${id} not found`);
  }

  // KYC Document methods
  async getKycDocuments(userId: number): Promise<KycDocument[]> {
    return this.kycDocumentsMap.get(userId) || [];
  }

  async getKycDocumentById(id: number): Promise<KycDocument | undefined> {
    for (const documents of this.kycDocumentsMap.values()) {
      const document = documents.find(d => d.id === id);
      if (document) {
        return document;
      }
    }
    return undefined;
  }

  async createKycDocument(document: InsertKycDocument): Promise<KycDocument> {
    const id = this.currentKycDocumentId++;
    const newDocument: KycDocument = {
      ...document,
      id,
      submitDate: new Date(),
      updatedAt: new Date(),
      status: document.status || 'pending',
      expiryDate: document.expiryDate || null,
      documentNumber: document.documentNumber || null,
      documentBackUrl: document.documentBackUrl || null,
      documentSelfieUrl: document.documentSelfieUrl || null,
      adminId: document.adminId || null,
      reviewedAt: document.reviewedAt || null,
      adminNotes: document.adminNotes || null
    };

    const userDocuments = this.kycDocumentsMap.get(document.userId) || [];
    userDocuments.push(newDocument);
    this.kycDocumentsMap.set(document.userId, userDocuments);

    return newDocument;
  }

  async updateKycDocument(id: number, updates: Partial<KycDocument>): Promise<KycDocument | undefined> {
    for (const [userId, documents] of this.kycDocumentsMap.entries()) {
      const index = documents.findIndex(d => d.id === id);
      
      if (index !== -1) {
        const document = documents[index];
        const updatedDocument: KycDocument = {
          ...document,
          ...updates,
          updatedAt: new Date()
        };
        
        documents[index] = updatedDocument;
        this.kycDocumentsMap.set(userId, documents);
        
        return updatedDocument;
      }
    }
    
    return undefined;
  }

  async getPendingKycDocuments(limit: number = 50): Promise<KycDocument[]> {
    const allDocuments: KycDocument[] = [];
    
    for (const documents of this.kycDocumentsMap.values()) {
      const pendingDocs = documents.filter(d => d.status === 'pending');
      allDocuments.push(...pendingDocs);
    }
    
    return allDocuments.slice(0, limit);
  }

  async updateKycDocumentStatus(id: number, status: string, adminNotes?: string): Promise<KycDocument> {
    for (const [userId, documents] of this.kycDocumentsMap.entries()) {
      const index = documents.findIndex(d => d.id === id);
      
      if (index !== -1) {
        const document = documents[index];
        const updatedDocument: KycDocument = {
          ...document,
          status,
          adminNotes: adminNotes || document.adminNotes,
          reviewedAt: new Date(),
          updatedAt: new Date()
        };
        
        documents[index] = updatedDocument;
        this.kycDocumentsMap.set(userId, documents);
        
        return updatedDocument;
      }
    }
    
    throw new Error(`KYC Document with ID ${id} not found`);
  }


}

export class DatabaseStorage implements IStorage {
  // Portfolio summary method
  async getPortfolioSummary(userId: number) {
    try {
      const portfolioItems = await this.getPortfolioItems(userId);
      const trades = await this.getUserTrades(userId);
      
      let totalValue = 0;
      let changePercent = 0;
      
      const holdings = portfolioItems.map(item => ({
        symbol: item.symbol,
        shares: item.shares,
        value: Number(parseFloat(item.shares)) * Number(parseFloat(item.avgPrice)),
        avgPrice: item.avgPrice
      }));

      totalValue = holdings.reduce((sum, item) => sum + item.value, 0);
      
      return {
        totalValue: totalValue.toFixed(2),
        changePercent: changePercent.toFixed(2),
        holdings
      };
    } catch (error) {
      console.error("Error calculating portfolio summary:", error);
      throw error;
    }
  }

  // Portfolio Summary Table methods - for the new portfolio_summary table
  async getDetailedPortfolioSummary(userId: number): Promise<PortfolioSummary | undefined> {
    try {
      const result = await db
        .select()
        .from(portfolioSummary)
        .where(eq(portfolioSummary.userId, userId))
        .limit(1);
        
      return result[0];
    } catch (error) {
      console.error("Error getting detailed portfolio summary:", error);
      console.error(error);
      throw error;
    }
  }
  
  async savePortfolioSummary(summary: InsertPortfolioSummary): Promise<PortfolioSummary> {
    try {
      // Check if record already exists
      const existing = await this.getDetailedPortfolioSummary(summary.userId);
      
      if (existing) {
        // Update existing record
        return this.updatePortfolioSummary(summary.userId, summary);
      }
      
      // Create a new portfolio summary
      const now = new Date();
      
      const result = await db
        .insert(portfolioSummary)
        .values({
          ...summary,
          lastUpdate: now,
          createdAt: now
        })
        .returning();
        
      return result[0];
    } catch (error) {
      console.error("Error saving portfolio summary:", error);
      throw error;
    }
  }
  
  async updatePortfolioSummary(userId: number, updates: Partial<InsertPortfolioSummary>): Promise<PortfolioSummary> {
    try {
      const now = new Date();
      
      // Get existing summary
      const existingSummary = await this.getDetailedPortfolioSummary(userId);
      
      if (!existingSummary) {
        // If no summary exists, create a new one with the updates
        const newSummary: InsertPortfolioSummary = {
          userId,
          totalBalance: updates.totalBalance || "0.00",
          totalEquity: updates.totalEquity || "0.00", 
          totalProfit: updates.totalProfit || "0.00",
          totalLoss: updates.totalLoss || "0.00",
          openPositions: updates.openPositions || 0,
          totalInvestment: updates.totalInvestment || "0.00",
          availableBalance: updates.availableBalance || "0.00",
          totalReturn: updates.totalReturn || "0.00",
          marginAuthorized: updates.marginAuthorized || "0.00",
          marginUsed: updates.marginUsed || "0.00",
          unauthorizedPnl: updates.unauthorizedPnl || "0.00"
        };
        
        return this.savePortfolioSummary(newSummary);
      }
      
      // Update the existing summary
      const result = await db
        .update(portfolioSummary)
        .set({
          ...updates,
          lastUpdate: now
        })
        .where(eq(portfolioSummary.userId, userId))
        .returning();
      
      return result[0];
    } catch (error) {
      console.error("Error updating portfolio summary:", error);
      throw error;
    }
  }
  
  // User methods with optimized queries
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'users',
        { id }
      );
      throw new Error(`Failed to get user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'users',
        { username }
      );
      throw new Error(`Failed to get user by username: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'users',
        { email }
      );
      throw new Error(`Failed to get user by email: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db.insert(users).values(insertUser).returning();
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'INSERT',
        'users',
        { ...insertUser, password: '***REDACTED***' }, // Don't log actual password
        ErrorSeverity.ERROR
      );
      throw new Error(`Failed to create user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateUserBalance(userId: number, newBalance: string): Promise<User> {
    try {
      const [user] = await db
        .update(users)
        .set({ balance: newBalance })
        .where(eq(users.id, userId))
        .returning();
      
      if (!user) {
        throw new Error(`User with ID ${userId} not found`);
      }
      
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'users',
        { userId, newBalance }
      );
      throw new Error(`Failed to update user balance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateUserPreferences(userId: number, updates: Partial<User>): Promise<User> {
    try {
      // Don't allow updating sensitive fields
      const safeUpdates = { ...updates };
      delete safeUpdates.id;
      delete safeUpdates.password;
      delete safeUpdates.createdAt;
      
      const [user] = await db
        .update(users)
        .set({ 
          ...safeUpdates,
          updatedAt: new Date() 
        })
        .where(eq(users.id, userId))
        .returning();
      
      if (!user) {
        throw new Error(`User with ID ${userId} not found`);
      }
      
      // Clear user cache
      userCache.delete(`user_${userId}`);
      
      return user;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'users',
        { userId, ...updates, password: updates.password ? '***REDACTED***' : undefined }
      );
      throw new Error(`Failed to update user preferences: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Watchlist methods with optimized queries
  async getWatchlistItems(userId: number): Promise<Watchlist[]> {
    try {
      return await db.select().from(watchlist).where(eq(watchlist.userId, userId));
    } catch (error: unknown) {
      console.error('Database error in getWatchlistItems:', error);
      throw new Error(`Failed to get watchlist items: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async addToWatchlist(item: InsertWatchlist): Promise<Watchlist> {
    try {
      // Check if item already exists to prevent duplicates
      const [existingItem] = await db.select()
        .from(watchlist)
        .where(and(
          eq(watchlist.userId, item.userId),
          eq(watchlist.symbol, item.symbol)
        ))
        .limit(1);
      
      if (existingItem) {
        return existingItem;
      }
      
      const [watchlistItem] = await db.insert(watchlist).values(item).returning();
      return watchlistItem;
    } catch (error: unknown) {
      console.error('Database error in addToWatchlist:', error);
      throw new Error(`Failed to add to watchlist: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async removeFromWatchlist(userId: number, symbol: string): Promise<void> {
    try {
      await db
        .delete(watchlist)
        .where(
          and(
            eq(watchlist.userId, userId),
            eq(watchlist.symbol, symbol)
          )
        );
    } catch (error: unknown) {
      console.error('Database error in removeFromWatchlist:', error);
      throw new Error(`Failed to remove from watchlist: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Portfolio methods with optimized queries and error handling
  async getPortfolioItems(userId: number): Promise<Portfolio[]> {
    try {
      return await db.select().from(portfolio).where(eq(portfolio.userId, userId));
    } catch (error: unknown) {
      console.error('Database error in getPortfolioItems:', error);
      throw new Error(`Failed to get portfolio items: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getPortfolioItem(userId: number, symbol: string): Promise<Portfolio | undefined> {
    try {
      const [item] = await db
        .select()
        .from(portfolio)
        .where(
          and(
            eq(portfolio.userId, userId),
            eq(portfolio.symbol, symbol)
          )
        )
        .limit(1);
      return item;
    } catch (error: unknown) {
      console.error('Database error in getPortfolioItem:', error);
      throw new Error(`Failed to get portfolio item: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updatePortfolio(item: InsertPortfolio): Promise<Portfolio> {
    try {
      // Check if portfolio item exists with a single query
      const [existingItem] = await db
        .select({ id: portfolio.id })
        .from(portfolio)
        .where(
          and(
            eq(portfolio.userId, item.userId),
            eq(portfolio.symbol, item.symbol)
          )
        )
        .limit(1);
      
      if (existingItem) {
        // Update existing item
        const [updatedItem] = await db
          .update(portfolio)
          .set({
            ...item,
            updatedAt: new Date() // Ensure we update the timestamp
          })
          .where(eq(portfolio.id, existingItem.id))
          .returning();
        return updatedItem;
      } else {
        // Insert new item
        const [newItem] = await db
          .insert(portfolio)
          .values(item)
          .returning();
        return newItem;
      }
    } catch (error: unknown) {
      console.error('Database error in updatePortfolio:', error);
      throw new Error(`Failed to update portfolio: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Trade methods with optimized queries
  async createTrade(trade: InsertTrade): Promise<Trade> {
    try {
      const [newTrade] = await db
        .insert(trades)
        .values(trade)
        .returning();
      return newTrade;
    } catch (error: unknown) {
      console.error('Database error in createTrade:', error);
      throw new Error(`Failed to create trade: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserTrades(userId: number): Promise<Trade[]> {
    try {
      return await db
        .select()
        .from(trades)
        .where(eq(trades.userId, userId))
        .orderBy(trades.tradeDate, { direction: 'desc' }); // Most recent first
    } catch (error: unknown) {
      console.error('Database error in getUserTrades:', error);
      throw new Error(`Failed to get user trades: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Market data methods with optimized cache-friendly queries and caching
  async getMarketData(symbol: string): Promise<MarketData | undefined> {
    try {
      // Try to get from cache first
      const cachedData = marketDataCache.get<MarketData>(symbol);
      if (cachedData) {
        return cachedData;
      }
      
      // If not in cache, get from database
      const [data] = await db
        .select()
        .from(marketData)
        .where(eq(marketData.symbol, symbol))
        .limit(1);
      
      // Cache the result if found
      if (data) {
        marketDataCache.set(symbol, data);
      }
      
      return data;
    } catch (error: unknown) {
      // Use error handling service for better error tracking and management
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'market_data',
        { symbol }
      );
      
      console.error('Database error in getMarketData:', error);
      throw new Error(`Failed to get market data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllMarketData(): Promise<MarketData[]> {
    try {
      // Try to get from cache first using a special key
      const cachedData = marketDataCache.get<MarketData[]>('__all_market_data__');
      if (cachedData) {
        return cachedData;
      }
      
      // If not in cache, get from database with optimized query - using assets table as marketData has the issue
      // We're getting data from assets table which has price-related columns integrated
      const data = await db
        .select()
        .from(assets)
        .where(notInArray(assets.symbol, ['MOCK1', 'MOCK2'])) // Exclude any mock symbols if present
        .orderBy(assets.symbol);
      
      // Map assets to market data format
      const marketDataItems = data.map(asset => ({
        id: asset.id,
        symbol: asset.symbol,
        price: asset.lastPrice || 0, 
        dailyChange: asset.priceChange || 0,
        dailyChangePercent: asset.priceChangePercentage || 0,
        intradayChange: 0,
        intradayChangePercent: 0,
        volume: asset.dailyVolume || 0,
        high24h: asset.high24h || 0,
        low24h: asset.low24h || 0,
        updatedAt: asset.updatedAt || new Date()
      }));
      
      // Cache the result
      marketDataCache.set('__all_market_data__', marketDataItems, 30000); // 30 seconds TTL for all market data
      
      // Also cache individual symbols
      marketDataItems.forEach((item: MarketData) => {
        marketDataCache.set(item.symbol, item);
      });
      
      return marketDataItems;
    } catch (error: unknown) {
      console.error('Database error in getAllMarketData:', error);
      throw new Error(`Failed to get all market data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateMarketData(data: InsertMarketData): Promise<MarketData> {
    try {
      // Use upsert pattern for better performance
      const [result] = await db
        .insert(marketData)
        .values({
          ...data,
          updatedAt: new Date()
        })
        .onConflictDoUpdate({
          target: marketData.symbol,
          set: {
            ...data,
            updatedAt: new Date()
          }
        })
        .returning();
      
      return result;
    } catch (error: unknown) {
      console.error('Database error in updateMarketData:', error);
      throw new Error(`Failed to update market data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // AI Analysis methods with optimized queries and caching
  async getAnalysisForSymbol(symbol: string): Promise<AiAnalysis | undefined> {
    try {
      // Try to get from cache first
      const cachedAnalysis = analysisCache.get<AiAnalysis>(symbol);
      if (cachedAnalysis) {
        return cachedAnalysis;
      }
      
      // If not in cache, get from database
      const [analysis] = await db
        .select()
        .from(aiAnalysis)
        .where(eq(aiAnalysis.symbol, symbol))
        .orderBy(aiAnalysis.createdAt, { direction: "desc" })
        .limit(1);
      
      // Cache the result if found
      if (analysis) {
        analysisCache.set(symbol, analysis);
      }
      
      return analysis;
    } catch (error: unknown) {
      console.error('Database error in getAnalysisForSymbol:', error);
      throw new Error(`Failed to get analysis for symbol: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async saveAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    try {
      // First check if analysis for this symbol already exists
      const existingAnalysis = await db
        .select()
        .from(aiAnalysis)
        .where(eq(aiAnalysis.symbol, analysis.symbol))
        .limit(1);

      let result: AiAnalysis;

      if (existingAnalysis.length > 0) {
        // If it exists, update it
        const [updatedAnalysis] = await db
          .update(aiAnalysis)
          .set({
            analysis: analysis.analysis,
            arabicAnalysis: analysis.arabicAnalysis,
            indicators: analysis.indicators,
            prediction: analysis.prediction,
            confidence: analysis.confidence,
            createdAt: new Date() // Update the timestamp to now
          })
          .where(eq(aiAnalysis.symbol, analysis.symbol))
          .returning();
        
        result = updatedAnalysis;
      } else {
        // If it doesn't exist, insert a new record
        const [newAnalysis] = await db
          .insert(aiAnalysis)
          .values(analysis)
          .returning();
        
        result = newAnalysis;
      }
      
      // Update the cache with the new/updated analysis
      analysisCache.set(analysis.symbol, result);
      
      return result;
    } catch (error: unknown) {
      console.error('Database error in saveAnalysis:', error);
      throw new Error(`Failed to save analysis: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Asset methods with optimized queries and caching
  async getAsset(symbol: string): Promise<Asset | undefined> {
    try {
      // Use cache if available
      const cacheKey = `asset_${symbol}`;
      const cachedAsset = marketDataCache.get<Asset>(cacheKey);
      if (cachedAsset) {
        return cachedAsset;
      }
      
      // Get from database if not in cache
      const [asset] = await db
        .select()
        .from(assets)
        .where(eq(assets.symbol, symbol))
        .limit(1);
      
      // Cache the result if found
      if (asset) {
        marketDataCache.set(cacheKey, asset, 300000); // 5 minutes TTL
      }
      
      return asset;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { symbol }
      );
      
      console.error('Database error in getAsset:', error);
      throw new Error(`Failed to get asset: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getAssetById(id: number): Promise<Asset | undefined> {
    try {
      // Use cache if available
      const cacheKey = `asset_id_${id}`;
      const cachedAsset = marketDataCache.get<Asset>(cacheKey);
      if (cachedAsset) {
        return cachedAsset;
      }
      
      // Get from database if not in cache
      const [asset] = await db
        .select()
        .from(assets)
        .where(eq(assets.id, id))
        .limit(1);
      
      // Cache the result if found
      if (asset) {
        marketDataCache.set(cacheKey, asset, 300000); // 5 minutes TTL
      }
      
      return asset;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'assets',
        { id }
      );
      throw new Error(`Failed to get asset by ID: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getAllAssets(): Promise<Asset[]> {
    try {
      // Try to get from cache first
      const cachedAssets = marketDataCache.get<Asset[]>('__all_assets__');
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // If not in cache, get from database
      const allAssets = await db
        .select()
        .from(assets)
        .orderBy(assets.symbol);
      
      // Cache the result
      marketDataCache.set('__all_assets__', allAssets, 300000); // 5 minutes TTL
      
      return allAssets;
    } catch (error: unknown) {
      console.error('Database error in getAllAssets:', error);
      throw new Error(`Failed to get all assets: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getAssetsByType(type: string): Promise<Asset[]> {
    try {
      // Use cache if available
      const cacheKey = `assets_type_${type}`;
      const cachedAssets = marketDataCache.get<Asset[]>(cacheKey);
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // Get from database if not in cache
      const assetsByType = await db
        .select()
        .from(assets)
        .where(eq(assets.type, type))
        .orderBy(assets.symbol);
      
      // Cache the result
      marketDataCache.set(cacheKey, assetsByType, 180000); // 3 minutes TTL
      
      return assetsByType;
    } catch (error: unknown) {
      console.error('Database error in getAssetsByType:', error);
      throw new Error(`Failed to get assets by type: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getAssetsBySymbols(symbols: string[]): Promise<Asset[]> {
    try {
      if (symbols.length === 0) {
        return [];
      }
      
      // Use cache for individual assets and collect
      const assetsFromCache: Asset[] = [];
      const symbolsToFetch: string[] = [];
      
      for (const symbol of symbols) {
        const cachedAsset = marketDataCache.get<Asset>(`asset_${symbol}`);
        if (cachedAsset) {
          assetsFromCache.push(cachedAsset);
        } else {
          symbolsToFetch.push(symbol);
        }
      }
      
      // If all assets were found in cache, return them
      if (symbolsToFetch.length === 0) {
        return assetsFromCache;
      }
      
      // Fetch remaining assets from database using OR conditions instead of inArray
      // Building a dynamic query with multiple OR conditions
      let query = db.select().from(assets);
      
      // Add conditions for each symbol
      if (symbolsToFetch.length > 0) {
        // Start with the first symbol
        let condition = eq(assets.symbol, symbolsToFetch[0]);
        
        // Add OR condition for each additional symbol
        for (let i = 1; i < symbolsToFetch.length; i++) {
          condition = or(condition, eq(assets.symbol, symbolsToFetch[i]));
        }
        
        query = query.where(condition);
      }
      
      const assetsFromDb = await query;
      
      // Cache the individual assets
      assetsFromDb.forEach(asset => {
        marketDataCache.set(`asset_${asset.symbol}`, asset, 180000); // 3 minutes TTL
      });
      
      // Combine assets from cache and database
      return [...assetsFromCache, ...assetsFromDb];
    } catch (error: unknown) {
      console.error('Database error in getAssetsBySymbols:', error);
      throw new Error(`Failed to get assets by symbols: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getRecentlyUpdatedAssets(limit: number = 20): Promise<Asset[]> {
    try {
      // Use cache if available
      const cacheKey = `recent_assets_${limit}`;
      const cachedAssets = marketDataCache.get<Asset[]>(cacheKey);
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // Get from database if not in cache
      const recentAssets = await db
        .select()
        .from(assets)
        .orderBy(desc(assets.updatedAt))
        .limit(limit);
      
      // Cache the result
      marketDataCache.set(cacheKey, recentAssets, 60000); // 1 minute TTL - short because we want recent data
      
      return recentAssets;
    } catch (error: unknown) {
      console.error('Database error in getRecentlyUpdatedAssets:', error);
      throw new Error(`Failed to get recently updated assets: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getAssetsByFilter(filter: { type?: string, sector?: string, country?: string }): Promise<Asset[]> {
    try {
      // Build a dynamic query based on the filter
      let query = db.select().from(assets);
      
      if (filter.type) {
        query = query.where(eq(assets.type, filter.type));
      }
      
      if (filter.sector) {
        query = query.where(eq(assets.sector, filter.sector));
      }
      
      if (filter.country) {
        query = query.where(eq(assets.country, filter.country));
      }
      
      // Execute the query
      const filteredAssets = await query.orderBy(assets.symbol);
      
      return filteredAssets;
    } catch (error: unknown) {
      console.error('Database error in getAssetsByFilter:', error);
      throw new Error(`Failed to get assets by filter: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getTrendingAssets(limit: number = 10): Promise<Asset[]> {
    try {
      // Use cache if available
      const cacheKey = `trending_assets_${limit}`;
      const cachedAssets = marketDataCache.get<Asset[]>(cacheKey);
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // Join assets with market_data to get trending assets based on volume
      // The SQL query joins assets and market_data, filters out test assets,
      // orders by volume, and limits the results
      const trendingAssets = await db.execute<Asset[]>(sql`
        SELECT a.* FROM "assets" a
        JOIN "market_data" md ON a."symbol" = md."symbol"
        WHERE
          a."symbol" NOT LIKE 'TEST_%'
          AND a."type" != 'test'
        ORDER BY md."volume" DESC
        LIMIT ${limit}
      `);
      
      // Cache the result
      marketDataCache.set(cacheKey, trendingAssets, 180000); // 3 minutes TTL
      
      return trendingAssets;
    } catch (error) {
      console.error("Error fetching trending assets:", error);
      throw error;
    }
  }
  
  async getFeaturedAssets(limit: number = 8): Promise<Asset[]> {
    try {
      // Use cache if available
      const cacheKey = `featured_assets_${limit}`;
      const cachedAssets = marketDataCache.get<Asset[]>(cacheKey);
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // Featured assets are typically popular, well-known assets
      // We can select assets that are marked as featured or select popular ones from predefined categories
      const featuredAssets = await db.execute<Asset[]>(sql`
        SELECT a.* FROM "assets" a
        WHERE
          a."symbol" NOT LIKE 'TEST_%'
          AND a."type" != 'test'
          AND (
            a."type" = 'crypto' OR 
            a."type" = 'stock' OR
            a."symbol" LIKE '%BTC%' OR
            a."symbol" LIKE '%ETH%' OR
            a."symbol" LIKE '%AAPL%' OR
            a."symbol" LIKE '%MSFT%' OR
            a."symbol" LIKE '%GOOG%' OR
            a."featured" = true
          )
        ORDER BY random()
        LIMIT ${limit}
      `);
      
      // Cache the result
      marketDataCache.set(cacheKey, featuredAssets, 300000); // 5 minutes TTL
      
      return featuredAssets;
    } catch (error: unknown) {
      console.error('Database error in getFeaturedAssets:', error);
      throw new Error(`Failed to get featured assets: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getMovers(limit: number = 10): Promise<Asset[]> {
    try {
      // Use cache if available
      const cacheKey = `movers_assets_${limit}`;
      const cachedAssets = marketDataCache.get<Asset[]>(cacheKey);
      if (cachedAssets) {
        return cachedAssets;
      }
      
      // الحركة الكبيرة هي الأصول التي تشهد تغيرات كبيرة في السعر (سواء بالزيادة أو النقصان)
      // نستخدم القيمة المطلقة لنسبة التغيير لترتيب الأصول
      const moversAssets = await db.execute<Asset[]>(sql`
        SELECT * FROM "assets"
        WHERE
          "symbol" NOT LIKE 'TEST_%'
          AND "type" != 'test'
          AND "price_change_percentage" IS NOT NULL
        ORDER BY ABS("price_change_percentage"::decimal) DESC
        LIMIT ${limit}
      `);
      
      // Cache the result
      marketDataCache.set(cacheKey, moversAssets, 180000); // 3 minutes TTL
      
      return moversAssets;
    } catch (error: unknown) {
      console.error('Database error in getMovers:', error);
      throw new Error(`Failed to get movers assets: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Price History methods with optimized queries and error handling
  async getPriceHistory(symbol: string, interval: string, limit: number = 100): Promise<PriceHistory[]> {
    try {
      // Query price history with ordering and limit
      return await db
        .select()
        .from(priceHistory)
        .where(
          and(
            eq(priceHistory.symbol, symbol),
            eq(priceHistory.interval, interval)
          )
        )
        .orderBy(priceHistory.timestamp, { direction: 'desc' })
        .limit(limit);
    } catch (error: unknown) {
      console.error('Database error in getPriceHistory:', error);
      throw new Error(`Failed to get price history: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getPriceHistoryByDateRange(
    symbol: string, 
    startDate: Date, 
    endDate: Date, 
    interval: string
  ): Promise<PriceHistory[]> {
    try {
      // Query price history within date range
      return await db
        .select()
        .from(priceHistory)
        .where(
          and(
            eq(priceHistory.symbol, symbol),
            eq(priceHistory.interval, interval),
            between(priceHistory.timestamp, startDate, endDate)
          )
        )
        .orderBy(priceHistory.timestamp);
    } catch (error: unknown) {
      console.error('Database error in getPriceHistoryByDateRange:', error);
      throw new Error(`Failed to get price history by date range: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Economic Events methods with optimized queries and caching
  async getEconomicEvents(limit: number = 50): Promise<EconomicEvent[]> {
    try {
      // Query economic events with ordering and limit
      return await db
        .select()
        .from(economicEvents)
        .orderBy(economicEvents.eventDate, { direction: 'desc' })
        .limit(limit);
    } catch (error: unknown) {
      console.error('Database error in getEconomicEvents:', error);
      throw new Error(`Failed to get economic events: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getEconomicEventsByDateRange(
    startDate: Date, 
    endDate: Date
  ): Promise<EconomicEvent[]> {
    try {
      // Query economic events within date range
      return await db
        .select()
        .from(economicEvents)
        .where(
          between(economicEvents.eventDate, startDate, endDate)
        )
        .orderBy(economicEvents.eventDate);
    } catch (error: unknown) {
      console.error('Database error in getEconomicEventsByDateRange:', error);
      throw new Error(`Failed to get economic events by date range: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getEconomicEventsByCountry(country: string): Promise<EconomicEvent[]> {
    try {
      // Query economic events for a specific country
      return await db
        .select()
        .from(economicEvents)
        .where(eq(economicEvents.country, country))
        .orderBy(economicEvents.eventDate, { direction: 'desc' });
    } catch (error: unknown) {
      console.error('Database error in getEconomicEventsByCountry:', error);
      throw new Error(`Failed to get economic events by country: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getEconomicEventsByImpact(impact: string): Promise<EconomicEvent[]> {
    try {
      // Query economic events by impact level
      return await db
        .select()
        .from(economicEvents)
        .where(eq(economicEvents.impact, impact))
        .orderBy(economicEvents.eventDate, { direction: 'desc' });
    } catch (error: unknown) {
      console.error('Database error in getEconomicEventsByImpact:', error);
      throw new Error(`Failed to get economic events by impact: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Session methods with optimized queries
  async getSession(id: string): Promise<Session | undefined> {
    try {
      const [session] = await db
        .select()
        .from(sessions)
        .where(eq(sessions.id, id))
        .limit(1);
      
      return session;
    } catch (error: unknown) {
      console.error('Database error in getSession:', error);
      throw new Error(`Failed to get session: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async createSession(session: InsertSession): Promise<Session> {
    try {
      const [newSession] = await db
        .insert(sessions)
        .values({
          ...session,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      
      return newSession;
    } catch (error: unknown) {
      console.error('Database error in createSession:', error);
      throw new Error(`Failed to create session: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined> {
    try {
      const [updatedSession] = await db
        .update(sessions)
        .set({
          ...updates,
          updatedAt: new Date()
        })
        .where(eq(sessions.id, id))
        .returning();
      
      return updatedSession;
    } catch (error: unknown) {
      console.error('Database error in updateSession:', error);
      throw new Error(`Failed to update session: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async deleteSession(id: string): Promise<void> {
    try {
      await db
        .delete(sessions)
        .where(eq(sessions.id, id));
    } catch (error: unknown) {
      console.error('Database error in deleteSession:', error);
      throw new Error(`Failed to delete session: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async deleteUserSessions(userId: number): Promise<void> {
    try {
      await db
        .delete(sessions)
        .where(eq(sessions.userId, userId));
    } catch (error: unknown) {
      console.error('Database error in deleteUserSessions:', error);
      throw new Error(`Failed to delete user sessions: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Transaction methods with optimized queries
  async getTransactions(userId: number, limit: number = 50): Promise<Transaction[]> {
    try {
      return await db
        .select()
        .from(transactions)
        .where(eq(transactions.userId, userId))
        .orderBy(transactions.transactionDate, { direction: 'desc' })
        .limit(limit);
    } catch (error: unknown) {
      console.error('Database error in getTransactions:', error);
      throw new Error(`Failed to get transactions: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async getTransactionById(id: string): Promise<Transaction | undefined> {
    try {
      const [transaction] = await db
        .select()
        .from(transactions)
        .where(eq(transactions.id, id))
        .limit(1);
      
      return transaction;
    } catch (error: unknown) {
      console.error('Database error in getTransactionById:', error);
      throw new Error(`Failed to get transaction by ID: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    try {
      const [newTransaction] = await db
        .insert(transactions)
        .values({
          ...transaction,
          id: transaction.id || crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      
      return newTransaction;
    } catch (error: unknown) {
      console.error('Database error in createTransaction:', error);
      throw new Error(`Failed to create transaction: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async updateTransactionStatus(id: string, status: string): Promise<Transaction> {
    try {
      const [updatedTransaction] = await db
        .update(transactions)
        .set({
          status,
          updatedAt: new Date()
        })
        .where(eq(transactions.id, id))
        .returning();
      
      if (!updatedTransaction) {
        throw new Error(`Transaction with ID ${id} not found`);
      }
      
      return updatedTransaction;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'transactions',
        { id, status }
      );
      throw new Error(`Failed to update transaction status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // KYC Document methods
  async getKycDocuments(userId: number): Promise<KycDocument[]> {
    try {
      return await db.select().from(kycDocuments).where(eq(kycDocuments.userId, userId));
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'kyc_documents',
        { userId }
      );
      throw new Error(`Failed to get KYC documents: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getKycDocumentById(id: number): Promise<KycDocument | undefined> {
    try {
      const [document] = await db.select().from(kycDocuments).where(eq(kycDocuments.id, id)).limit(1);
      return document;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'kyc_documents',
        { id }
      );
      throw new Error(`Failed to get KYC document: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createKycDocument(document: InsertKycDocument): Promise<KycDocument> {
    try {
      const [kycDocument] = await db.insert(kycDocuments).values({
        ...document,
        submitDate: new Date(),
        updatedAt: new Date()
      }).returning();
      return kycDocument;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'INSERT',
        'kyc_documents',
        { ...document }
      );
      throw new Error(`Failed to create KYC document: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateKycDocument(id: number, updates: Partial<KycDocument>): Promise<KycDocument | undefined> {
    try {
      // Don't allow updating sensitive fields
      const safeUpdates = { ...updates };
      delete safeUpdates.id;
      delete safeUpdates.userId;
      delete safeUpdates.submitDate;

      const [updatedDocument] = await db
        .update(kycDocuments)
        .set({
          ...safeUpdates,
          updatedAt: new Date()
        })
        .where(eq(kycDocuments.id, id))
        .returning();

      return updatedDocument;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'kyc_documents',
        { id, ...updates }
      );
      throw new Error(`Failed to update KYC document: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getPendingKycDocuments(limit: number = 50): Promise<KycDocument[]> {
    try {
      return await db
        .select()
        .from(kycDocuments)
        .where(eq(kycDocuments.status, 'pending'))
        .orderBy(kycDocuments.submitDate, { direction: 'asc' }) // Oldest first for admin review
        .limit(limit);
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'kyc_documents',
        { status: 'pending', limit }
      );
      throw new Error(`Failed to get pending KYC documents: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateKycDocumentStatus(id: number, status: string, adminNotes?: string): Promise<KycDocument> {
    try {
      const [updatedDocument] = await db
        .update(kycDocuments)
        .set({
          status,
          adminNotes: adminNotes || undefined,
          updatedAt: new Date()
        })
        .where(eq(kycDocuments.id, id))
        .returning();

      if (!updatedDocument) {
        throw new Error(`KYC document with ID ${id} not found`);
      }

      return updatedDocument;
    } catch (error: unknown) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'kyc_documents',
        { id, status, adminNotes }
      );
      throw new Error(`Failed to update KYC document status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

