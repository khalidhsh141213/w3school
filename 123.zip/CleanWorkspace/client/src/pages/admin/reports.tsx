import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import {
    Download,
    RefreshCw
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

// Import chart components
import {
    Bar,
    BarChart,
    CartesianGrid,
    Cell,
    Legend,
    Line,
    Pie,
    LineChart as RechartLineChart,
    PieChart as RechartPieChart,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis
} from "recharts";

export default function AdminReportsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [reportType, setReportType] = useState<string>("user-growth");
  const [timeRange, setTimeRange] = useState<string>("weekly");
  
  // Check if user is admin
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access this page.",
        variant: "destructive"
      });
      location("/");
    }
  }, [user, location, toast]);

  // Fetch metrics data
  const { data: metrics, isLoading: isLoadingMetrics, refetch } = useQuery({
    queryKey: ["/api/admin/metrics"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user && user.userRole === "admin",
  });

  // Sample data for charts
  const userGrowthData = [
    { name: 'Jan', users: 320 },
    { name: 'Feb', users: 420 },
    { name: 'Mar', users: 510 },
    { name: 'Apr', users: 590 },
    { name: 'May', users: 640 },
    { name: 'Jun', users: 710 },
    { name: 'Jul', users: 830 },
    { name: 'Aug', users: 920 },
    { name: 'Sep', users: 990 },
    { name: 'Oct', users: 1050 },
    { name: 'Nov', users: 1130 },
    { name: 'Dec', users: 1250 },
  ];

  const tradeVolumeData = [
    { name: 'Jan', volume: 4000 },
    { name: 'Feb', volume: 3000 },
    { name: 'Mar', volume: 5000 },
    { name: 'Apr', volume: 8000 },
    { name: 'May', volume: 7000 },
    { name: 'Jun', volume: 9000 },
    { name: 'Jul', volume: 11000 },
    { name: 'Aug', volume: 12000 },
    { name: 'Sep', volume: 14000 },
    { name: 'Oct', volume: 13000 },
    { name: 'Nov', volume: 15000 },
    { name: 'Dec', volume: 18000 },
  ];

  const assetDistributionData = [
    { name: 'Crypto', value: 45 },
    { name: 'Stocks', value: 30 },
    { name: 'Forex', value: 15 },
    { name: 'Commodities', value: 10 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  // Loading state
  if (isLoadingMetrics || !user) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-4">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <Skeleton className="h-10 w-full md:w-1/2" />
            <Skeleton className="h-10 w-full md:w-1/2" />
          </div>
          
          <Skeleton className="h-96 w-full" />
        </div>
      </AdminLayout>
    );
  }

  // If user is not admin, don't render the page
  if (user.userRole !== "admin") {
    return null;
  }

  // Render appropriate chart based on selection
  const renderChart = () => {
    switch (reportType) {
      case "user-growth":
        return (
          <ResponsiveContainer width="100%" height={400}>
            <RechartLineChart data={userGrowthData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="users" stroke="#8884d8" activeDot={{ r: 8 }} />
            </RechartLineChart>
          </ResponsiveContainer>
        );
      
      case "trade-volume":
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={tradeVolumeData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="volume" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        );
      
      case "asset-distribution":
        return (
          <ResponsiveContainer width="100%" height={400}>
            <RechartPieChart>
              <Pie
                data={assetDistributionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={150}
                fill="#8884d8"
                dataKey="value"
              >
                {assetDistributionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </RechartPieChart>
          </ResponsiveContainer>
        );
      
      default:
        return (
          <div className="flex items-center justify-center h-64 bg-muted/50 rounded-lg">
            <p className="text-muted-foreground">Select a report type to view data</p>
          </div>
        );
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Reports & Analytics | Admin Dashboard</title>
      </Helmet>

      <div className="container mx-auto p-4 space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Reports & Analytics</h1>
            <p className="text-muted-foreground">View platform growth metrics and analyze trends</p>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="default" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Report controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Select
            value={reportType}
            onValueChange={setReportType}
          >
            <SelectTrigger className="w-full md:w-1/2">
              <SelectValue placeholder="Select report type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="user-growth">User Growth</SelectItem>
              <SelectItem value="trade-volume">Trading Volume</SelectItem>
              <SelectItem value="asset-distribution">Asset Distribution</SelectItem>
            </SelectContent>
          </Select>
          
          <Select
            value={timeRange}
            onValueChange={setTimeRange}
          >
            <SelectTrigger className="w-full md:w-1/2">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Report card */}
        <Card>
          <CardHeader>
            <CardTitle>
              {reportType === "user-growth" && "User Growth Over Time"}
              {reportType === "trade-volume" && "Trading Volume Trends"}
              {reportType === "asset-distribution" && "Asset Distribution"}
            </CardTitle>
            <CardDescription>
              {reportType === "user-growth" && "Track user acquisition and growth"}
              {reportType === "trade-volume" && "Monitor trading volume across the platform"}
              {reportType === "asset-distribution" && "See the distribution of asset types traded"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderChart()}
          </CardContent>
        </Card>

        {/* Summary metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {metrics?.totalUsers || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {metrics?.activeUsers || 0} active users
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Trades</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {metrics?.totalTrades || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {metrics?.openTrades || 0} open trades
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Trade Volume (Monthly)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${metrics?.tradeVolume?.monthly.toLocaleString() || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                ${metrics?.tradeVolume?.today.toLocaleString() || 0} today
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
} 