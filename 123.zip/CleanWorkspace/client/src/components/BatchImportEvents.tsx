import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle, CheckCircle, Upload } from 'lucide-react';
import { useState } from 'react';

interface BatchImportEventsProps {
  onEventsImported?: () => void;
}

export default function BatchImportEvents({ onEventsImported }: BatchImportEventsProps) {
  const [jsonData, setJsonData] = useState('');
  const [csvData, setCsvData] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleJsonImport = async () => {
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      // Parse the JSON data
      let events;
      try {
        events = JSON.parse(jsonData);
        if (!Array.isArray(events)) {
          events = [events]; // If it's a single object, convert to array
        }
      } catch (e) {
        throw new Error('Invalid JSON format. Please check your input.');
      }

      const response = await fetch('/api/batch-import-events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to import events');
      }

      setJsonData('');
      setSuccess(`Successfully imported ${result.events.length} events!`);
      
      if (onEventsImported) {
        onEventsImported();
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unknown error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCsvImport = async () => {
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      // Parse CSV data
      const lines = csvData.trim().split('\n');
      if (lines.length < 2) {
        throw new Error('CSV must contain a header row and at least one data row');
      }

      const headers = lines[0].split(',').map(header => header.trim());
      
      // Check required headers
      if (!headers.includes('event_name') || !headers.includes('event_date')) {
        throw new Error('CSV must include at least event_name and event_date columns');
      }

      const events = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(val => val.trim());
        if (values.length !== headers.length) {
          throw new Error(`Line ${i+1} has incorrect number of fields`);
        }

        const event = {};
        headers.forEach((header, index) => {
          event[header] = values[index];
        });

        events.push(event);
      }

      const response = await fetch('/api/batch-import-events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to import events');
      }

      setCsvData('');
      setSuccess(`Successfully imported ${result.events.length} events!`);
      
      if (onEventsImported) {
        onEventsImported();
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unknown error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, setData: (data: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setData(event.target?.result as string);
    };
    reader.readAsText(file);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Batch Import Economic Events</CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {success && (
          <Alert className="mb-4 bg-green-50 text-green-800 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
        
        <Tabs defaultValue="json">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="json">JSON Import</TabsTrigger>
            <TabsTrigger value="csv">CSV Import</TabsTrigger>
          </TabsList>
          
          <TabsContent value="json" className="space-y-4">
            <div>
              <Label htmlFor="json-file">Upload JSON File</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input 
                  id="json-file"
                  type="file"
                  accept=".json"
                  onChange={(e) => handleFileUpload(e, setJsonData)}
                  className="hidden"
                />
                <Button 
                  onClick={() => document.getElementById('json-file')?.click()}
                  variant="outline"
                  className="w-full"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Or paste JSON data below (array of event objects)
              </p>
            </div>
            
            <div>
              <Textarea
                value={jsonData}
                onChange={(e) => setJsonData(e.target.value)}
                placeholder='[{"event_name": "US GDP Report","event_date": "2023-10-15","importance_level": "high"}]'
                className="min-h-[200px] font-mono text-sm"
              />
            </div>
            
            <Button 
              onClick={handleJsonImport} 
              disabled={isSubmitting || !jsonData}
              className="w-full"
            >
              {isSubmitting ? 'Importing...' : 'Import JSON Data'}
            </Button>
          </TabsContent>
          
          <TabsContent value="csv" className="space-y-4">
            <div>
              <Label htmlFor="csv-file">Upload CSV File</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input 
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => handleFileUpload(e, setCsvData)}
                  className="hidden"
                />
                <Button 
                  onClick={() => document.getElementById('csv-file')?.click()}
                  variant="outline"
                  className="w-full"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                CSV must have headers: event_name, event_date, and optionally importance_level, description, asset_impact
              </p>
            </div>
            
            <div>
              <Textarea
                value={csvData}
                onChange={(e) => setCsvData(e.target.value)}
                placeholder="event_name,event_date,importance_level,description
US GDP Report,2023-10-15,high,Quarterly GDP figures
Fed Rate Decision,2023-10-20,high,Federal Reserve interest rate decision"
                className="min-h-[200px] font-mono text-sm"
              />
            </div>
            
            <Button 
              onClick={handleCsvImport} 
              disabled={isSubmitting || !csvData}
              className="w-full"
            >
              {isSubmitting ? 'Importing...' : 'Import CSV Data'}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Helper Input component for file uploads
function Input(props) {
  return <input {...props} />;
} 