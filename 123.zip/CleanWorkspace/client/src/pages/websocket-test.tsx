import { WebSocketTest } from '../components/WebSocketTest';
import { Helmet } from 'react-helmet';

export default function WebSocketTestPage() {
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <Helmet>
        <title>WebSocket Test | Trading Platform</title>
      </Helmet>
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6 text-center">WebSocket Connection Testing</h1>
        <p className="text-center text-gray-600 mb-8">
          Use this page to test the real-time WebSocket connection to the server.
          Monitor connection status and see live market data updates.
        </p>
        <WebSocketTest />
      </div>
    </div>
  );
}