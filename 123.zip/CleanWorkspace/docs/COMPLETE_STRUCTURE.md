# الخريطة الهيكلية الشاملة للمشروع مع وصف الوظائف

تقدم هذه الوثيقة نظرة شاملة لكل ملف ومجلد في المشروع مع شرح موجز عن وظيفته. تُعتبر هذه الخريطة مرجعاً لتسهيل فهم بنية التطبيق، صيانته، وتطويره مستقبلاً.

---

## 1. الملفات والمجلدات على مستوى الجذر (Root)

- **.env.development**: ملف إعداد متغيرات البيئة (مثل مفاتيح API وبيانات التكوين).
- **.gitignore**: ملفات ومجلدات يستبعدها Git (مثل node_modules، dist، الخ).
- **.replit**: إعدادات بيئة Replit الخاصة بالمشروع.
- **drizzle.config.ts**: إعدادات Drizzle ORM لقاعدة البيانات.
- **hash-password.mjs / hash-password.ts**: سكريبتات لتشفير ومعالجة كلمات المرور.
- **package.json / package-lock.json**: تعريفات المشروع وحزم NPM المطلوبة.
- **postcss.config.js**: إعدادات PostCSS لتعديل CSS.
- **README-WEBSOCKET.md**: توثيق خاص بآلية WebSocket في التطبيق.
- **replit.nix**: إعدادات Nix لإدارة بيئة Replit.
- **requirements.txt**: متطلبات المشروع (قد تُستخدم في بيئات Python أو أدوات مساندة).
- **run-market-update.sh**: سكريبت لتشغيل تحديثات السوق.
- **run.sh**: سكريبت أساسي لتشغيل المشروع.
- **start_node.sh / start.sh**: سكريبتات بدء تشغيل الخادم/التطبيق.
- **tailwind.config.ts**: إعدادات Tailwind CSS للتصميم.
- **test-notification-ws.js / test-websocket-connection.js**: سكريبتات لاختبار وظائف WebSocket.
- **theme.json**: إعدادات الثيم العام للتطبيق.
- **tsconfig.json**: إعدادات TypeScript العامة للمشروع.
- **vite.config.ts**: إعدادات Vite لتجميع وتشغيل الواجهة الأمامية.

---

## 2. مجلد **attached_assets**

- يحتوي على الصور، ملفات CSV، وملفات وسائط أخرى تُستخدم في التطبيق.

---

## 3. مجلد **api**

### 3.1 api/economic
- **events.ts**: معالج API للتعامل مع الأحداث الاقتصادية (GET لجلب الأحداث وPOST لإضافتها).
- **sync-economic-data.js**: سكريبت لمزامنة البيانات الاقتصادية مع مصادر خارجية.

---

## 4. مجلد **client**

### 4.1 **client/docs**
يشمل وثائق متعلقة بالتكامل، الهياكل، والهندسة مثل:
- **API_INTEGRATION.md**: إرشادات تكامل API.
- **best_polygon_duc.md**: ملاحظات وأفضل ممارسات لاستخدام Polygon API.
- **COMPONENT_STRUCTURE.md**: وصف هيكل مكونات الواجهة.
- **MIGRATION_GUIDE.md**: دليل ترحيل البيانات والأنظمة.
- **VALIDATION_GUIDE.md**: إرشادات التحقق من صحة البيانات.
- **WEBSOCKET_BEST_PRACTICES_EN.md / WEBSOCKET_BEST_PRACTICES.md**: أفضل ممارسات استخدام WebSocket.
- **WEBSOCKET_IMPLEMENTATION_EN.md / WEBSOCKET_IMPLEMENTATION.md**: توثيق تنفيذ WebSocket.
- **WEBSOCKET_USAGE.md**: كيفية استخدام WebSocket في التطبيق.

### 4.2 **client/scripts**
تشتمل سكريبتات التطوير والأدوات المساعدة:
- **add-validation.js**: سكريبت لإضافة تدقيق والتحقق للتطوير.
- **find-duplicates.js**: سكريبت لاكتشاف الملفات أو الأكواد المكررة.
- **identify-type-issues.js**: سكريبت لتحديد مشكلات الأنواع في الكود.
- **identify-websocket-usage.js**: تحليل استخدام WebSocket في الكود.
- **refactor-codebase.js**: سكريبت لإعادة هيكلة الكود.
- **SETUP.md**: دليل إعداد بيئة التطوير.
- **update-components.js**: سكريبت لتحديث مكونات الواجهة.
- **update-imports.js**: سكريبت لضبط المسارات والاستيرادات.

### 4.3 **client/src**
يحتوي على الكود الأساسي للواجهة الأمامية، ويشمل:
  
#### 4.3.1 **client/src/app**
- **viteHmrFix.js**: سكريبت لإصلاح مشاكل التحديث أثناء التطوير (HMR).

#### 4.3.2 **client/src/components**
يشمل جميع مكونات React، مصنفة حسب الوظائف:
- **admin**: (إذا كانت مستخدمة سابقاً، قد تم تنظيفها لاحقًا)
- **auth**: مكونات المصادقة مثل:
  - **AdminProtectedRoute.tsx**: حماية طرق الإدارة.
  - **AuthForm.tsx**: نموذج تسجيل الدخول/التسجيل.
  - **ProtectedRoute.tsx**: حماية الطرق الخاصة بالمستخدمين.
  - **SignInForm.tsx / SignUpForm.tsx**: نماذج الدخول والتسجيل.
- **charts**: مكونات الرسوم البيانية (index.tsx).
- **common**: مكونات مساعدة مثل:
  - **AiChatBox.tsx**: صندوق محادثة الذكاء الاصطناعي.
  - **PortfolioSummary.tsx**: ملخص المحفظة.
- **dashboard**: مكونات عرض البيانات الرئيسية (EconomicEventsWidget.tsx، FeaturedCard.tsx، MarketOverview.tsx).
- **economic**: مكونات متعلقة بالأحداث الاقتصادية (EventMarketCorrelation.tsx، EventNotificationSettings.tsx).
- **examples**: أمثلة تعليمية توضيحية مثل:
  - **ApiClientExample.tsx**
  - **AssetTracker.tsx**
  - **EconomicEventsExample.tsx**
  - **ImprovedWebSocketExample.tsx**
  - **ValidatedWebSocketExample.tsx**
  - **ValidationExample.tsx**
  - **WebSocketExample.tsx**
- **landing**: مكونات الصفحة الرئيسية (FeaturesHighlight.tsx، Hero3D.tsx، LandingFooter.tsx، TestimonialsCarousel.tsx).
- **layout**: تنظيم الواجهة مثل:
  - **Header.tsx**: رأس الصفحة.
  - **LanguageSwitcher.tsx**: تبديل اللغة.
  - **MainLayout.tsx**: التخطيط الرئيسي.
  - **MarketTicker.tsx**: شريط مؤشرات السوق.
  - **Sidebar.tsx**: الشريط الجانبي.
- **market**: مكونات تتعلق ببيانات السوق (MarketDataExample.tsx).
- **navigation**: مكونات التنقل.
- **portfolio**: مكونات المحفظة مثل:
  - **DetailedPortfolioSummary.tsx**
  - **EmptyStateView.tsx**
  - **OpenPositionsTable.tsx**
  - **OrdersTabs.tsx**
  - **PortfolioFinancialInfo.tsx**
  - **PortfolioSummaryBar.tsx**
  - **PortfolioSummaryWidget.tsx**
- **settings**: مكونات الإعدادات مثل:
  - **SettingsCard.tsx**
  - **SettingsForm.tsx**
  - **UserSettingsForm.tsx**
  - **VerificationBanner.tsx**
- **trading**: مكونات التداول مثل:
  - **AccountSummary.tsx**
  - **AssetSelector.tsx**
  - **EventCard.tsx**
  - **OrderPlacement.tsx**
  - **PositionsSummary.tsx**
  - **RealTimeChart.tsx**
  - **TradeHistory.tsx**
- **ui**: مكتبة المكونات العامة (accordion.tsx، alert-dialog.tsx، alert.tsx، aspect-ratio.tsx، avatar.tsx، badge.tsx، breadcrumb.tsx، button.tsx، calendar.tsx، card.tsx، carousel.tsx، chart.tsx، checkbox.tsx، collapsible.tsx، command.tsx، context-menu.tsx، dialog.tsx، drawer.tsx، dropdown-menu.tsx، form.tsx، hover-card.tsx، input-otp.tsx، input.tsx، label.tsx، loading-screen.tsx، menubar.tsx، navigation-menu.tsx، pagination.tsx، popover.tsx، progress.tsx، radio-group.tsx، resizable.tsx، scroll-area.tsx، select.tsx، separator.tsx، sheet.tsx، sidebar.tsx، skeleton.tsx، slider.tsx، switch.tsx، table.tsx، tabs.tsx، textarea.tsx، toast.tsx، toaster.tsx، toggle-group.tsx، toggle.tsx، tooltip.tsx).
- **wallet**: مكونات المحفظة الرقمية مثل:
  - **AccountSummaryCard.tsx**
  - **CryptoPromotionCard.tsx**
  - **PortfolioValueCard.tsx**
  - **ReferralInviteCard.tsx**
- **watchlist**: مكون عرض قائمة المراقبة (WatchlistTable.tsx).
- **الملفات الفردية**: مثل:
  - **AddEventForm.tsx**: نموذج إضافة حدث.
  - **AiAnalysis.tsx**: تحليل باستخدام الذكاء الاصطناعي.
  - **AiRecommendations.tsx**: توصيات الذكاء الاصطناعي.
  - **AssetSearch.tsx**: أداة بحث عن الأصول.
  - **BatchImportEvents.tsx**: استيراد دفعي للأحداث.
  - **ChartComponent.tsx**: مكون رسم بياني.
  - **Footer.tsx**: تذييل الصفحة.
  - **Header.tsx**: رأس الصفحة.
  - **MainContent.tsx**: المحتوى الرئيسي.
  - **MarketOverview.tsx**: نظرة عامة على السوق.
  - **MarketSentiment.tsx**: تحليل معنويات السوق.
  - **NewsComponent.tsx**: عرض الأخبار.
  - **Ticker.tsx**: شريط مؤشرات السوق.
  - **TradingComponent.tsx**: مكون التداول.
  - **Watchlist.tsx**: عرض قائمة المراقبة.
  - **WebSocketStatus.tsx / WebSocketStatusIndicator.tsx / WebSocketTest.tsx**: مكونات تتعلق بحالة واختبار WebSocket.

#### 4.3.3 **client/src/config**
- **api.ts**: إعدادات واجهة برمجة التطبيقات (API)، مثل تحديد القاعدة URL.
- **websocket.ts**: إعدادات الاتصال عبر WebSocket.

#### 4.3.4 **client/src/context**
- **AppContext.tsx**: إعداد وتوفير سياق التطبيق (global state management).

#### 4.3.5 **client/src/documentation**
يحتوي على وثائق إضافية متعلقة بالمشروع.

#### 4.3.6 **client/src/examples**
أمثلة تعليمية توضيحية لاستخدام بعض الوظائف مثل WebSocket.

#### 4.3.7 **client/src/hooks**
تحتوي على هوكس React المُخصصة للمشروع:
- **useEconomicEvents.ts**: جلب بيانات الأحداث الاقتصادية.
- **useMarketData.ts**: الحصول على بيانات السوق.
- **useEventMarketCorrelation.ts**: ربط الأحداث الاقتصادية مع بيانات السوق.
- **useEventNotifications.ts**: التعامل مع تنبيهات الأحداث.
- **useWebSocketManager.tsx**: إدارة اتصال WebSocket.
- **use-media-query.ts**: هوك لاكتشاف حجم الشاشة.
- **use-mobile.tsx**: هوك لتحديد إذا كان الجهاز محمول.
- **use-portfolio-data.ts / use-portfolio-summary.ts / use-portfolio-websocket.ts**: هوكس خاصة بمحافظ الاستثمار.
- **use-redirect.ts**: هوك لإعادة التوجيه.
- **use-toast.ts**: هوك لإظهار الإشعارات.
- **useAdmin.tsx**: هوك متعلقة بإدارة واجهة الإدارة.
- **useApi.ts**: هوك للتواصل مع الـ API.

#### 4.3.8 **client/src/lib**
يحتوي على المكتبات المساعدة:
- **websocket/**:
  - ملفات تتعلق بـ WebSocket، بما في ذلك اختبارات (WebSocketManager.test.ts).
- **api.test.ts**: اختبارات لوظائف API.
- **api.ts**: وظائف مساعدة للتواصل مع واجهة برمجة التطبيقات.
- **auth.ts**: وظائف مساعدة للمصادقة.
- **authContext.tsx**: إعدادات سياق المصادقة.
- **i18n.ts**: إعدادات الترجمة واللغات.
- **queryClient.ts**: إعداد عميل الاستعلامات (مثل React Query).
- **useNotifications.ts / useTradeNotifications.ts**: وظائف مساعدة للتنبيهات.
- **useTranslation.ts**: دعم الترجمة.
- **utils.ts**: وظائف مساعدة عامة.
- **validation.test.ts / validation.ts**: وظائف التحقق من صحة البيانات.

#### 4.3.9 **client/src/locales**
- **ar/**: ملفات الترجمة العربية (common.json، translation.json).
- **en/**: ملفات الترجمة الإنجليزية (common.json، translation.json).

#### 4.3.10 **client/src/pages**
يحتوي على صفحات التطبيق:
- **admin/** (مجلد إدارة، قد يكون متكرر أو غير مستخدم إذا تمت إزالته لاحقاً).
- **assets.tsx**: صفحة لإدارة الأصول.
- **auth-page.tsx**: صفحة تسجيل الدخول/المصادقة.
- **calendar.tsx**: صفحة التقويم.
- **copy-trading.tsx**: صفحة التداول النسخي.
- **dashboard.tsx**: لوحة القيادة الرئيسية.
- **discover.tsx**: صفحة الاستكشاف.
- **economic-calendar.tsx**: صفحة عرض التقويم الاقتصادي.
- **examples.tsx**: صفحة الأمثلة.
- **index.tsx**: الصفحة الرئيسية.
- **landing.tsx**: صفحة الهبوط.
- **not-found.tsx**: صفحة الخطأ (صفحة 404).
- **portfolio.tsx**: صفحة المحفظة.
- **settings.tsx**: صفحة الإعدادات.
- **support.tsx**: صفحة الدعم.
- **trade.tsx**: صفحة التداول.
- **trading-improved.tsx**: صفحة التداول المحسنة.
- **wallet.tsx**: صفحة المحفظة الرقمية.
- **watchlist.tsx**: صفحة قائمة المراقبة.
- **websocket-test.tsx**: صفحة اختبار WebSocket.

#### 4.3.11 **client/src/services**
يحتوي على خدمات التواصل:
- **aiService.ts**: وظائف التواصل مع خدمات الذكاء الاصطناعي (إذا كانت مستخدمة).
- **ApiClient.ts / ApiService.ts**: وظائف إنشاء اتصالات API والطلبات.
- **CircuitBreaker.ts**: آلية التوقف الآمن في حالة الفشل.
- **MessageQueue.ts**: إدارة قائمة الرسائل.
- **RateLimiter.ts**: تحديد معدل الطلبات.
- **WebSocketManagerSingleton.ts**: إدارة اتصال WebSocket كـ Singleton.

#### 4.3.12 **client/src/styles**
يشمل ملفات CSS المخصصة:
- **ApiClientExample.css**
- **Examples.css**
- **WebSocketExample.css**

#### 4.3.13 **client/src/types**
يحتوي على تعريفات TypeScript:
- **global.d.ts**: تعريفات عامة.
- **index.ts**: تصدير التعريفات.
- **schemas.ts**: تعريفات المخططات.
- **trader.ts**: تعريفات متعلقة بالتداول.

#### 4.3.14 **client/src/utils**
- **formatters.ts**: وظائف تنسيق البيانات.

#### 4.3.15 **client/src/App.tsx, index.css, main.tsx, index.html**
- **App.tsx**: المكون الرئيسي للتطبيق.
- **index.css**: أنماط عامة للواجهة.
- **main.tsx**: نقطة بداية تشغيل التطبيق.
- **index.html**: الصفحة الرئيسية للعرض في المتصفح.

---

## 5. مجلد **components** (على مستوى الجذر)
- قد يحتوي على مكونات مشتركة إضافية خارج مجلد client/src/components (إن وجدت).

---

## 6. مجلد **docs**
يشمل وثائق المشروع:
- **APPLICATION_ARCHITECTURE.md**: وثيقة توضح هيكل التطبيق العام.
- **ARCHITECTURE_MAP.md**: خريطة مفصلة لهندسة التطبيق.
- **COMPREHENSIVE_DB_SCHEMA.md**: الخريطة الشاملة لقاعدة البيانات.
- **DATABASE_SCHEMA.md**: وثيقة مخطط قاعدة البيانات.
- **README.md**: ملف القراءة الرئيسية للمشروع.
- بالإضافة إلى ملفات أخرى في مجلدات (client, architecture, general, technical).

---

## 7. مجلد **drizzle**
يشمل ملفات الترحيل والميتاداتا الخاصة بقاعدة البيانات:
- **migrations/**: مجموعة من ملفات الترحيل:
  - **0000_initial_migration.sql**: إنشاء الجداول الأساسية.
  - **0001_add_price_data.sql**: إضافة أعمدة بيانات الأسعار.
  - **0002_add_portfolios.sql**: إنشاء جدول المحافظ.
  - **0003_add_asset_columns.sql**: إضافة أعمدة خاصة بالأصول.
  - **0003_add_trades_currentprice_and_summary.sql**: تحديث بيانات التداول.
  - **0004_optimize_database_schema.sql**: تحسين بنية قاعدة البيانات.
  - **0005_upgrade_economic_events.sql**: تحديث هيكل أحداث الاقتصاد.
  - **0006_add_verification_notes.sql**: إضافة ملاحظات التحقق.
- **meta/**:
  - **_journal.json**: سجل الترحيل والميتاداتا.

---

## 8. مجلد **logs**
يحتوي على ملفات السجلات (Logs):
- سجلات أخطاء، سجلات عمليات التحديث، سجلات الخوادم، إلخ.

---

## 9. مجلد **pages**
يحتوي على صفحات الموقع المستقلة (إن كانت موجودة خارج مجلد client).

---

## 10. مجلد **scripts** (على مستوى الجذر)
يحتوي على سكريبتات مساعدة للتشغيل والصيانة.

---

## 11. مجلد **server**
يشمل الكود الخاص بالخادم:
- **tsconfig.json**: إعدادات TypeScript للخادم.
- **ai/**: ملفات متعلقة بالذكاء الاصطناعي.
- **api/**:
  - **economic/**:
    - **events.ts**: معالجة طلبات API للأحداث الاقتصادية.
    - **sync-economic-data.js**: سكريبت لمزامنة البيانات الاقتصادية.
- **main/**:
  - **check-polygon-api.js**: فحص تكامل Polygon API.
  - **check-port.mjs**: التحقق من المنافذ المستخدمة.
  - **create-portfolio.js**: إنشاء المحافظ الاستثمارية.
  - **server.mjs**: الملف الرئيسي لتشغيل الخادم.
- **middleware/**:
  - **auth.ts**: التحقق من هوية المستخدم.
  - **redirects.ts**: إدارة إعادة التوجيه.
- **public/**:
  - **index.html**: الصفحة الرئيسية للملفات الثابتة.
- **routes/**:
  - **admin/**:
    - **index.ts**: مسارات الإدارة.
  - **ai.ts**: مسار الذكاء الاصطناعي.
  - **bonus.ts**: مسار المكافآت.
  - **economic-calendar.ts**: مسار التقويم الاقتصادي.
  - **trade.ts**: مسار التداول.
  - **routes.ts**: تعريف جميع المسارات.
- **seed/**:
  - **assets.json**: بيانات بداية حول الأصول.
  - **economic_events.json**: بيانات أحداث الاقتصاد.
  - **market_data.json**: بيانات السوق.
  - **price_history.json**: بيانات تاريخ الأسعار.
- **services/**:
  - **aiService.ts**: خدمات الذكاء الاصطناعي (إن كانت مستخدمة).
  - **assetService.ts**: خدمات معالجة بيانات الأصول.
  - **economicEventService.ts**: خدمات إدارة الأحداث الاقتصادية.
  - **errorHandlingService.ts**: إدارة أخطاء الخادم.
  - **marketData.ts**: استرجاع ومعالجة بيانات السوق.
  - **marketDataService.ts**: خدمات متقدمة لمعالجة بيانات السوق.
  - **marketDataUpdater.ts**: تحديث بيانات السوق.
  - **marketStatusService.ts**: فحص حالة السوق.
  - **notificationService.ts**: إدارة التنبيهات.
  - **polygon.ts**: تكامل مع Polygon API.
  - **polygonWebSocket.ts**: التعامل مع WebSocket الخاص بـ Polygon.
  - **tradingService.ts**: خدمات التداول.
- **sql/**:
  - **create-new-tables.sql**: سكريبت إنشاء جداول جديدة.
- **types/**:
  - **session.d.ts**: تعريف أنواع الجلسات.
- **utils/**:
  - **activity-logger.ts**: تسجيل نشاطات الخادم.
  - **bonus-manager.ts**: إدارة المكافآت.
  - **cache.js**: إعدادات الكاش.
  - **logger.js**: تسجيل الأخطاء والنشاط.
- ملفات أخرى في **server/**:
  - **.npmrc**: إعدادات NPM الخاصة بالخادم.
  - **apply-migration.js**: تطبيق ملفات الترحيل.
  - **auth.ts**: وظائف المصادقة.
  - **cache.ts**: إدارة الكاش.
  - **create-bonus-system.ts**: إنشاء نظام المكافآت.
  - **crypto-price-updater.mjs**: تحديث أسعار العملات الرقمية.
  - **db.ts**: إعداد الاتصال بقاعدة البيانات.
  - **fix-admin-password.ts**: سكريبت لتعديل كلمة مرور المسؤول.
  - **fix-schema.sql**: إصلاح مخطط قاعدة البيانات.
  - **health.ts**: فحص الحالة الصحية للخادم.
  - **index.ts**: نقطة دخول الخادم.
  - **migrate.ts**: تنفيذ عمليات الترحيل.
  - **package-lock.json / package.json**: تعريف حزم الخادم.
  - **pgStorage.ts**: إعداد تخزين PostgreSQL.
  - **reset-admin-password.ts**: إعادة تعيين كلمة مرور المسؤول.
  - **routes.ts**: تجميع جميع المسارات.
  - **send-test-market-data.ts**: إرسال بيانات سوق تجريبية للاختبار.
  - **storage.ts**: إدارة التخزين.
  - **tsconfig.json**: إعدادات TypeScript للخادم.
  - **tsx.config.json**: إعدادات TSX (إن وجدت).
  - **utils.ts**: وظائف مساعدة عامة.
  - **validation.ts**: التحقق من صحة البيانات.
  - **verify-db.ts**: التحقق من صحة قاعدة البيانات.
  - **verify-optimizations.ts**: التحقق من تحسينات النظام.
  - **vite.ts**: إعدادات Vite الخاصة بالخادم.
  - **websocket.ts**: إدارة WebSocket على الخادم.

---

## 12. مجلد **servers**
يحتوي على خوادم إضافية:
- **ai/**: خادم مخصص للذكاء الاصطناعي (إن وُجد).
- **main/**: خادم رئيسي إضافي.

---

## 13. مجلد **shared**
- **schema.ts**: تعريفات ومخططات تُستخدم عبر المشروع.

---

## 14. ملاحظات إضافية
- **.qodo**: ملف أو مجلد يُستخدم (غير موضح بالضبط)؛ يجب مراجعته لتحديد الوظيفة.
- **~**: قد يمثل اختصار أو ملف نظام؛ يرجى التحقق منه.
- في **drizzle/**: تم تجميع ملفات الترحيل (migrations) وبيانات الميتا (meta) الخاصة بقاعدة البيانات.
- **logs/**: يحتوي على سجلات تشغيل المشروع.
- **pages/**: يحتوي على الصفحات الثابتة للموقع خارج تطبيق React (إن وُجد).
- **scripts/**: سكريبتات مساعدة على مستوى الجذر لتنفيذ مهام مختلفة.
  
---

## الخلاصة

تم بناء هذه الخريطة التفصيلية لتشمل كل ملف ومجلد موجود في المشروع مع وصف وظيفته، مما يوفر مرجعاً كاملاً لفهم هيكلة المشروع والوظائف المرتبطة بكل جزء منه. هذه الوثيقة ستساعد المطورين على تحديد الملفات المهمة، فهم وظائفها، وضمان صيانة وتنظيم المشروع بكفاءة.
