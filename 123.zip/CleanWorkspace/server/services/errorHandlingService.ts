/**
 * Error Handling Service
 * Provides centralized error logging, categorization, and handling for database operations
 */

import fs from 'fs';
import path from 'path';
import { log } from '../vite';

// Types of errors we track
export enum ErrorType {
  DATABASE = 'database',
  NETWORK = 'network',
  API = 'api',
  AUTH = 'auth',
  VALIDATION = 'validation',
  WEBSOCKET = 'websocket',
  CACHE = 'cache',
  UNKNOWN = 'unknown'
}

// Error severity levels
export enum ErrorSeverity {
  INFO = 'info',
  WARNING = 'warning',
  ERROR = 'error',
  CRITICAL = 'critical'
}

// Structure for error logs
interface ErrorLog {
  timestamp: string;
  type: ErrorType;
  severity: ErrorSeverity;
  message: string;
  details?: any;
  stack?: string;
  userId?: number | string;
  requestPath?: string;
  code?: string;
}

export class ErrorHandler {
  private static instance: ErrorHandler;
  private errorLogPath: string;
  private errorCount: Record<ErrorType, number> = {
    [ErrorType.DATABASE]: 0,
    [ErrorType.NETWORK]: 0,
    [ErrorType.API]: 0,
    [ErrorType.AUTH]: 0,
    [ErrorType.VALIDATION]: 0,
    [ErrorType.WEBSOCKET]: 0,
    [ErrorType.CACHE]: 0,
    [ErrorType.UNKNOWN]: 0
  };
  private errorsByCode: Map<string, number> = new Map();
  private recentErrors: ErrorLog[] = [];
  private maxRecentErrors: number = 50;

  private constructor() {
    this.errorLogPath = process.env.ERROR_LOG_PATH || 'logs/errors.log';
    
    // Ensure logs directory exists
    const logsDir = path.dirname(this.errorLogPath);
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }
    
    log('Error handling service initialized', 'error');
  }

  public static getInstance(): ErrorHandler {
    if (!ErrorHandler.instance) {
      ErrorHandler.instance = new ErrorHandler();
    }
    return ErrorHandler.instance;
  }

  /**
   * Log an error with relevant metadata
   */
  public logError(
    error: Error | unknown,
    type: ErrorType = ErrorType.UNKNOWN,
    severity: ErrorSeverity = ErrorSeverity.ERROR,
    details: any = {},
    userId?: number | string,
    requestPath?: string
  ): void {
    // Normalize error to standard Error object
    const err = error instanceof Error ? error : new Error(String(error));
    
    // Extract error code if available
    const errorCode = (error as any).code || 'UNKNOWN';
    
    // Update error counts
    this.errorCount[type]++;
    this.errorsByCode.set(errorCode, (this.errorsByCode.get(errorCode) || 0) + 1);
    
    // Create error log entry
    const errorLog: ErrorLog = {
      timestamp: new Date().toISOString(),
      type,
      severity,
      message: err.message,
      details,
      stack: err.stack,
      userId,
      requestPath,
      code: errorCode
    };
    
    // Add to recent errors (maintaining maximum size)
    this.recentErrors.unshift(errorLog);
    if (this.recentErrors.length > this.maxRecentErrors) {
      this.recentErrors.pop();
    }
    
    // Log to console
    log(`${severity.toUpperCase()} [${type}]: ${err.message}${errorCode ? ` (${errorCode})` : ''}`, 'error');
    
    // Write to log file
    this.writeToLogFile(errorLog);
    
    // For critical errors, take additional actions
    if (severity === ErrorSeverity.CRITICAL) {
      this.handleCriticalError(errorLog);
    }
  }

  /**
   * Specialized handler for database errors
   */
  public logDatabaseError(
    error: Error | unknown,
    operation: string,
    table: string,
    params?: any,
    severity: ErrorSeverity = ErrorSeverity.ERROR
  ): void {
    const details = {
      operation,
      table,
      params
    };
    
    this.logError(error, ErrorType.DATABASE, severity, details);
  }

  /**
   * Get statistics about errors
   */
  public getErrorStats(): {
    counts: Record<ErrorType, number>,
    total: number,
    topErrorCodes: Array<{ code: string, count: number }>
  } {
    // Calculate total errors
    const total = Object.values(this.errorCount).reduce((sum, count) => sum + count, 0);
    
    // Get top error codes
    const topErrorCodes = Array.from(this.errorsByCode.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([code, count]) => ({ code, count }));
    
    return {
      counts: { ...this.errorCount },
      total,
      topErrorCodes
    };
  }

  /**
   * Get recent errors
   */
  public getRecentErrors(limit: number = 20): ErrorLog[] {
    return this.recentErrors.slice(0, Math.min(limit, this.recentErrors.length));
  }

  /**
   * Reset error statistics
   */
  public resetStats(): void {
    Object.keys(this.errorCount).forEach(key => {
      this.errorCount[key as ErrorType] = 0;
    });
    this.errorsByCode.clear();
    log('Error statistics reset', 'error');
  }

  /**
   * Write error to log file
   */
  private writeToLogFile(errorLog: ErrorLog): void {
    try {
      const logEntry = JSON.stringify(errorLog) + '\n';
      fs.appendFileSync(this.errorLogPath, logEntry);
    } catch (e) {
      // If logging itself fails, at least try to output to console
      console.error('Failed to write to error log file:', e);
    }
  }

  /**
   * Handle critical errors with special actions
   */
  private handleCriticalError(errorLog: ErrorLog): void {
    // Here we could implement notifications (email, SMS, etc.)
    // For now, just log with high visibility
    console.error('======= CRITICAL ERROR =======');
    console.error(JSON.stringify(errorLog, null, 2));
    console.error('==============================');
  }
}

// Export singleton instance
export const errorHandler = ErrorHandler.getInstance();