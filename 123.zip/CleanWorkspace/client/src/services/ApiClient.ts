/**
 * API Client
 * 
 * A standardized client for making API requests with error handling, retry logic, and caching.
 */

import { z } from 'zod';
import { validate } from '../lib/validation';

// API error types
export enum ApiErrorType {
  NETWORK = 'network',
  SERVER = 'server',
  AUTHENTICATION = 'authentication',
  VALIDATION = 'validation',
  NOT_FOUND = 'not_found',
  TIMEOUT = 'timeout',
  UNKNOWN = 'unknown',
}

// API error class
export class ApiError extends Error {
  type: ApiErrorType;
  status?: number;
  data?: any;
  
  constructor(type: ApiErrorType, message: string, status?: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.type = type;
    this.status = status;
    this.data = data;
  }
}

// Request options
export interface RequestOptions {
  // Common options
  headers?: Record<string, string>;
  timeout?: number;
  
  // Retry options
  retry?: {
    maxRetries?: number;
    initialDelay?: number;
    maxDelay?: number;
    backoffFactor?: number;
    retryCondition?: (error: ApiError, retryCount: number) => boolean;
  };
  
  // Caching options
  cache?: {
    enabled?: boolean;
    ttl?: number; // time to live in milliseconds
    key?: string; // custom cache key (default: url + method + body hash)
    burstProtection?: boolean; // protect against cache stampede
  };
  
  // Validation options
  validation?: {
    schema?: z.ZodSchema<any>;
    skipValidation?: boolean;
  };
  
  // Cancellation token
  signal?: AbortSignal;
}

// Default request options
const DEFAULT_OPTIONS: RequestOptions = {
  timeout: 30000, // 30 seconds
  
  retry: {
    maxRetries: 3,
    initialDelay: 1000, // 1 second
    maxDelay: 10000, // 10 seconds
    backoffFactor: 2,
    retryCondition: (error, retryCount) => {
      // Retry on network errors and 5xx server errors, but not on client errors
      return (
        error.type === ApiErrorType.NETWORK ||
        error.type === ApiErrorType.TIMEOUT ||
        (error.type === ApiErrorType.SERVER && (error.status ?? 0) >= 500)
      );
    },
  },
  
  cache: {
    enabled: false,
    ttl: 5 * 60 * 1000, // 5 minutes
    burstProtection: true,
  },
  
  validation: {
    skipValidation: false,
  },
};

// Cache storage
interface CacheEntry {
  data: any;
  timestamp: number;
  ttl: number;
}

class CacheStorage {
  private cache: Map<string, CacheEntry> = new Map();
  private pendingRequests: Map<string, Promise<any>> = new Map();
  
  // Set a cache entry
  set(key: string, data: any, ttl: number): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl,
    });
  }
  
  // Get a cache entry
  get(key: string): any | null {
    const entry = this.cache.get(key);
    
    // Check if entry exists and hasn't expired
    if (entry && Date.now() - entry.timestamp < entry.ttl) {
      return entry.data;
    }
    
    // Entry doesn't exist or has expired
    this.cache.delete(key);
    return null;
  }
  
  // Check if a request is pending
  isPending(key: string): boolean {
    return this.pendingRequests.has(key);
  }
  
  // Set a pending request
  setPending(key: string, promise: Promise<any>): void {
    this.pendingRequests.set(key, promise);
  }
  
  // Get a pending request
  getPending(key: string): Promise<any> | null {
    return this.pendingRequests.get(key) || null;
  }
  
  // Clear a pending request
  clearPending(key: string): void {
    this.pendingRequests.delete(key);
  }
  
  // Clear all expired entries
  clearExpired(): void {
    const now = Date.now();
    
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
  }
  
  // Clear all cache entries
  clear(): void {
    this.cache.clear();
    this.pendingRequests.clear();
  }
}

/**
 * API Client class
 */
export class ApiClient {
  private baseUrl: string;
  private defaultOptions: RequestOptions;
  private cacheStorage: CacheStorage;
  
  /**
   * Constructor
   * @param baseUrl The base URL for all requests
   * @param defaultOptions Default options for all requests
   */
  constructor(baseUrl: string, defaultOptions: RequestOptions = {}) {
    this.baseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    this.defaultOptions = { ...DEFAULT_OPTIONS, ...defaultOptions };
    this.cacheStorage = new CacheStorage();
    
    // Periodically clean up expired cache entries
    setInterval(() => {
      this.cacheStorage.clearExpired();
    }, 60 * 1000); // Every minute
  }
  
  /**
   * Generate a cache key for a request
   * @param url The request URL
   * @param method The request method
   * @param body The request body
   * @param customKey A custom cache key
   * @returns The cache key
   */
  private generateCacheKey(url: string, method: string, body?: any, customKey?: string): string {
    if (customKey) {
      return customKey;
    }
    
    const bodyString = body ? JSON.stringify(body) : '';
    return `${method}:${url}:${bodyString}`;
  }
  
  /**
   * Make a request with retries and caching
   * @param method The request method
   * @param endpoint The endpoint to request
   * @param body The request body
   * @param options Request options
   * @returns The response data
   */
  private async request<T>(
    method: string,
    endpoint: string,
    body?: any,
    options: RequestOptions = {}
  ): Promise<T> {
    // Merge options with defaults
    const mergedOptions: RequestOptions = {
      ...this.defaultOptions,
      ...options,
      headers: {
        ...this.defaultOptions.headers,
        ...options.headers,
      },
      retry: {
        ...this.defaultOptions.retry,
        ...options.retry,
      },
      cache: {
        ...this.defaultOptions.cache,
        ...options.cache,
      },
      validation: {
        ...this.defaultOptions.validation,
        ...options.validation,
      },
    };
    
    // Determine full URL
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
    
    // For GET requests, check cache
    if (
      method === 'GET' &&
      mergedOptions.cache?.enabled &&
      !mergedOptions.signal?.aborted
    ) {
      // Generate cache key
      const cacheKey = this.generateCacheKey(
        url,
        method,
        undefined,
        mergedOptions.cache.key
      );
      
      // Check if the response is cached
      const cachedData = this.cacheStorage.get(cacheKey);
      if (cachedData) {
        // Validate cached data if schema is provided
        if (mergedOptions.validation?.schema && !mergedOptions.validation.skipValidation) {
          try {
            return validate(cachedData, mergedOptions.validation.schema) as T;
          } catch (error) {
            // Cached data is invalid, remove it from cache
            this.cacheStorage.clearPending(cacheKey);
            console.warn('Cached data validation failed:', error);
          }
        } else {
          // Return cached data
          return cachedData as T;
        }
      }
      
      // Check if there's a pending request for this cache key
      if (mergedOptions.cache.burstProtection && this.cacheStorage.isPending(cacheKey)) {
        // Return the pending request to avoid duplicate requests
        try {
          return await this.cacheStorage.getPending(cacheKey) as T;
        } catch (error) {
          // If the pending request fails, clear it and continue
          this.cacheStorage.clearPending(cacheKey);
        }
      }
    }
    
    // Set up retry mechanism
    let retryCount = 0;
    const maxRetries = mergedOptions.retry?.maxRetries ?? 0;
    
    // Create a promise for the request
    const makeRequestWithRetry = async (): Promise<T> => {
      try {
        const response = await this.makeRequest<T>(method, url, body, mergedOptions);
        return response;
      } catch (error) {
        const apiError = this.normalizeError(error);
        
        // Check if we should retry
        const shouldRetry =
          retryCount < maxRetries &&
          mergedOptions.retry?.retryCondition?.(apiError, retryCount) &&
          !mergedOptions.signal?.aborted;
        
        if (shouldRetry) {
          // Calculate backoff delay
          const initialDelay = mergedOptions.retry?.initialDelay ?? 1000;
          const backoffFactor = mergedOptions.retry?.backoffFactor ?? 2;
          const maxDelay = mergedOptions.retry?.maxDelay ?? 10000;
          
          const delay = Math.min(
            initialDelay * Math.pow(backoffFactor, retryCount),
            maxDelay
          );
          
          // Wait for backoff delay
          await new Promise(resolve => setTimeout(resolve, delay));
          
          // Increment retry count and try again
          retryCount++;
          return makeRequestWithRetry();
        }
        
        // No more retries, propagate error
        throw apiError;
      }
    };
    
    // For GET requests with caching, store the request promise
    if (
      method === 'GET' &&
      mergedOptions.cache?.enabled &&
      mergedOptions.cache.burstProtection &&
      !mergedOptions.signal?.aborted
    ) {
      const cacheKey = this.generateCacheKey(
        url,
        method,
        undefined,
        mergedOptions.cache.key
      );
      
      // Create the request promise
      const requestPromise = makeRequestWithRetry().then(response => {
        // Store in cache if successful
        if (mergedOptions.cache?.enabled) {
          this.cacheStorage.set(
            cacheKey,
            response,
            mergedOptions.cache.ttl ?? DEFAULT_OPTIONS.cache!.ttl!
          );
        }
        
        // Clear pending request
        this.cacheStorage.clearPending(cacheKey);
        
        // Return response
        return response;
      }).catch(error => {
        // Clear pending request
        this.cacheStorage.clearPending(cacheKey);
        
        // Propagate error
        throw error;
      });
      
      // Store the promise
      this.cacheStorage.setPending(cacheKey, requestPromise);
      
      // Return the promise
      return requestPromise;
    }
    
    // For non-GET requests or without caching, just make the request
    return makeRequestWithRetry();
  }
  
  /**
   * Make a fetch request
   * @param method The request method
   * @param url The request URL
   * @param body The request body
   * @param options Request options
   * @returns The response data
   */
  private async makeRequest<T>(
    method: string,
    url: string,
    body?: any,
    options: RequestOptions = {}
  ): Promise<T> {
    // Prepare request init
    const init: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...options.headers,
      },
      signal: options.signal,
    };
    
    // Add body for non-GET requests
    if (method !== 'GET' && body !== undefined) {
      init.body = JSON.stringify(body);
    }
    
    try {
      // Create fetch Promise
      const fetchPromise = fetch(url, init);
      
      // Create timeout Promise
      const timeoutPromise = new Promise<never>((_, reject) => {
        const timeoutId = setTimeout(() => {
          reject(new ApiError(
            ApiErrorType.TIMEOUT,
            `Request timed out after ${options.timeout}ms`,
            undefined,
            { url, method }
          ));
        }, options.timeout ?? DEFAULT_OPTIONS.timeout);
        
        // Clear timeout if AbortSignal is aborted
        if (options.signal) {
          options.signal.addEventListener('abort', () => {
            clearTimeout(timeoutId);
          });
        }
      });
      
      // Race between fetch and timeout
      const response = await Promise.race([fetchPromise, timeoutPromise]);
      
      // Handle response
      const contentType = response.headers.get('content-type');
      let data;
      
      // Parse response body
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }
      
      // Handle error responses
      if (!response.ok) {
        throw this.createErrorFromResponse(response, data);
      }
      
      // Validate response data
      if (options.validation?.schema && !options.validation.skipValidation) {
        try {
          return validate(data, options.validation.schema) as T;
        } catch (error) {
          throw new ApiError(
            ApiErrorType.VALIDATION,
            'Response failed validation',
            response.status,
            { validationError: error, data }
          );
        }
      }
      
      // Return data
      return data as T;
    } catch (error) {
      // Convert error to ApiError
      throw this.normalizeError(error);
    }
  }
  
  /**
   * Create an ApiError from a Response object
   * @param response The Response object
   * @param data The response data
   * @returns An ApiError
   */
  private createErrorFromResponse(response: Response, data: any): ApiError {
    const status = response.status;
    let type: ApiErrorType;
    let message: string;
    
    switch (true) {
      case status === 404:
        type = ApiErrorType.NOT_FOUND;
        message = 'Resource not found';
        break;
      case status === 401 || status === 403:
        type = ApiErrorType.AUTHENTICATION;
        message = 'Authentication error';
        break;
      case status >= 400 && status < 500:
        type = ApiErrorType.VALIDATION;
        message = 'Client error';
        break;
      case status >= 500:
        type = ApiErrorType.SERVER;
        message = 'Server error';
        break;
      default:
        type = ApiErrorType.UNKNOWN;
        message = 'Unknown error';
    }
    
    // Use error message from response if available
    if (data && typeof data === 'object' && data.message) {
      message = data.message;
    } else if (typeof data === 'string' && data.trim()) {
      message = data.trim();
    }
    
    return new ApiError(type, message, status, data);
  }
  
  /**
   * Normalize an error to an ApiError
   * @param error The error to normalize
   * @returns An ApiError
   */
  private normalizeError(error: any): ApiError {
    // Error is already an ApiError
    if (error instanceof ApiError) {
      return error;
    }
    
    // Error is a fetch AbortError
    if (error && error.name === 'AbortError') {
      return new ApiError(
        ApiErrorType.UNKNOWN,
        'Request was aborted',
        undefined,
        { originalError: error }
      );
    }
    
    // Error is a network error
    if (error instanceof TypeError && error.message.includes('fetch')) {
      return new ApiError(
        ApiErrorType.NETWORK,
        'Network error',
        undefined,
        { originalError: error }
      );
    }
    
    // Other errors
    return new ApiError(
      ApiErrorType.UNKNOWN,
      error?.message || 'Unknown error',
      undefined,
      { originalError: error }
    );
  }
  
  /**
   * Clear the cache
   */
  public clearCache(): void {
    this.cacheStorage.clear();
  }
  
  /**
   * Make a GET request
   * @param endpoint The endpoint to request
   * @param options Request options
   * @returns The response data
   */
  public get<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    return this.request<T>('GET', endpoint, undefined, options);
  }
  
  /**
   * Make a POST request
   * @param endpoint The endpoint to request
   * @param body The request body
   * @param options Request options
   * @returns The response data
   */
  public post<T>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>('POST', endpoint, body, options);
  }
  
  /**
   * Make a PUT request
   * @param endpoint The endpoint to request
   * @param body The request body
   * @param options Request options
   * @returns The response data
   */
  public put<T>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>('PUT', endpoint, body, options);
  }
  
  /**
   * Make a PATCH request
   * @param endpoint The endpoint to request
   * @param body The request body
   * @param options Request options
   * @returns The response data
   */
  public patch<T>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>('PATCH', endpoint, body, options);
  }
  
  /**
   * Make a DELETE request
   * @param endpoint The endpoint to request
   * @param options Request options
   * @returns The response data
   */
  public delete<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    return this.request<T>('DELETE', endpoint, undefined, options);
  }
  
  /**
   * Create an abort controller
   * @param timeoutMs Timeout in milliseconds
   * @returns An abort controller
   */
  public createAbortController(timeoutMs?: number): AbortController {
    const controller = new AbortController();
    
    if (timeoutMs) {
      setTimeout(() => {
        controller.abort();
      }, timeoutMs);
    }
    
    return controller;
  }
}

// Create a singleton instance
let apiClientInstance: ApiClient | null = null;

/**
 * Get or create the API client instance
 * @param baseUrl The base URL for all requests
 * @param options Default options for all requests
 * @returns The API client instance
 */
export function getApiClient(baseUrl?: string, options?: RequestOptions): ApiClient {
  if (!apiClientInstance && baseUrl) {
    apiClientInstance = new ApiClient(baseUrl, options);
  }
  
  if (!apiClientInstance) {
    throw new Error('API client not initialized. Call getApiClient with baseUrl first.');
  }
  
  return apiClientInstance;
}

/**
 * Create a new API client instance
 * @param baseUrl The base URL for all requests
 * @param options Default options for all requests
 * @returns A new API client instance
 */
export function createApiClient(baseUrl: string, options?: RequestOptions): ApiClient {
  return new ApiClient(baseUrl, options);
} 