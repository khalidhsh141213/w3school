import { assets, trades, users } from '../../../shared/schema.js';
import { randomBytes, scrypt } from 'crypto';
import { and, eq, gte } from 'drizzle-orm';
import { Router } from 'express';
import { db } from '../../db.js';
import { verifyAdmin } from '../../middleware/auth.js';
import { economicEventsService } from '../../services/economicEventsService.js';
import { 
  checkForEconomicEventNotifications, 
  checkEconomicEventCorrelations, 
  checkUpcomingVolatilityEvents,
  runAllNotificationChecks
} from '../../services/notificationService.js';

const router = Router();

// Middleware to check if user is admin
router.use(verifyAdmin);

// Get admin dashboard metrics
router.get('/metrics', async (req, res) => {
  try {
    // Get user counts
    const userCount = await db.select({ count: users.id }).from(users);
    const activeUsers = await db.select({ count: users.id }).from(users)
      .where(eq(users.isVerified, true));
    
    // Get trade counts
    const totalTrades = await db.select({ count: trades.id }).from(trades);
    const openTrades = await db.select({ count: trades.id }).from(trades)
      .where(eq(trades.status, 'open'));
    
    // Get asset counts
    const assetCount = await db.select({ count: assets.id }).from(assets);
    
    // Get transaction counts
    const pendingDeposits = await db.select({ count: transactions.id }).from(transactions)
      .where(and(
        eq(transactions.type, 'deposit'),
        eq(transactions.status, 'pending')
      ));
    
    const pendingWithdrawals = await db.select({ count: transactions.id }).from(transactions)
      .where(and(
        eq(transactions.type, 'withdrawal'),
        eq(transactions.status, 'pending')
      ));
    
    // Get users with pending KYC
    const pendingKyc = await db.select({ count: users.id }).from(users)
      .where(eq(users.verificationStatus, 'pending'));
    
    // Get recent trade volume
    const now = new Date();
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    // Daily volume - using proper date comparison
    const dailyTrades = await db.select({
      quantity: trades.quantity,
      entryPrice: trades.entryPrice
    }).from(trades)
      .where(gte(trades.openedAt, dayAgo));
    
    // Weekly volume  
    const weeklyTrades = await db.select({
      quantity: trades.quantity,
      entryPrice: trades.entryPrice
    }).from(trades)
      .where(gte(trades.openedAt, weekAgo));
    
    // Monthly volume
    const monthlyTrades = await db.select({
      quantity: trades.quantity,
      entryPrice: trades.entryPrice
    }).from(trades)
      .where(gte(trades.openedAt, monthAgo));
    
    // Calculate volumes
    const calculateVolume = (tradeList: any[]) => {
      return tradeList.reduce((total, trade) => total + (trade.quantity * trade.entryPrice), 0);
    };
    
    const metrics = {
      totalUsers: userCount[0]?.count || 0,
      activeUsers: activeUsers[0]?.count || 0,
      totalTrades: totalTrades[0]?.count || 0,
      openTrades: openTrades[0]?.count || 0,
      totalAssets: assetCount[0]?.count || 0,
      pendingKyc: pendingKyc[0]?.count || 0,
      pendingDeposits: pendingDeposits[0]?.count || 0,
      pendingWithdrawals: pendingWithdrawals[0]?.count || 0,
      tradeVolume: {
        today: calculateVolume(dailyTrades),
        weekly: calculateVolume(weeklyTrades),
        monthly: calculateVolume(monthlyTrades)
      },
      // Placeholder for user growth data
      userGrowth: {
        data: [23, 34, 56, 78, 45, 67, 89],
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
      }
    };
    
    res.json(metrics);
  } catch (error) {
    console.error("Error fetching admin metrics:", error);
    res.status(500).json({ error: "Failed to fetch admin metrics" });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const allUsers = await db.select().from(users).orderBy(users.createdAt, { order: "desc" });
    res.json(allUsers);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

// Get minimal user data (for dropdowns and references)
// NOTE: This route MUST be placed before the /users/:id route to avoid conflict
router.get('/users/minimal', async (req, res) => {
  try {
    const minimalUsers = await db.select({
      id: users.id,
      username: users.username,
      email: users.email
    }).from(users);
    
    res.json(minimalUsers);
  } catch (error) {
    console.error("Error fetching minimal user data:", error);
    res.status(500).json({ error: "Failed to fetch minimal user data" });
  }
});

// Get user by ID
router.get('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const user = await db.select().from(users).where(eq(users.id, id));
    
    if (user.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    res.json(user[0]);
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Failed to fetch user" });
  }
});

// Update user
router.put('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { username, email, fullName, phoneNumber, isVerified, verificationStatus, userRole } = req.body;
    
    // Check if user exists
    const existingUser = await db.select({ id: users.id }).from(users).where(eq(users.id, id));
    
    if (existingUser.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Update user
    await db.update(users).set({
      username,
      email,
      fullName,
      phoneNumber,
      isVerified,
      verificationStatus,
      userRole,
      updatedAt: new Date()
    }).where(eq(users.id, id));
    
    res.json({ message: "User updated successfully" });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ error: "Failed to update user" });
  }
});

// Delete user
router.delete('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if user exists
    const existingUser = await db.select({ id: users.id }).from(users).where(eq(users.id, id));
    
    if (existingUser.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Delete user
    await db.delete(users).where(eq(users.id, id));
    
    res.json({ message: "User deleted successfully" });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ error: "Failed to delete user" });
  }
});

// Update user verification status
router.patch('/users/:id/verification', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!['pending', 'verified', 'rejected'].includes(status)) {
      return res.status(400).json({ error: "Invalid verification status" });
    }
    
    // Update user verification status
    await db.update(users).set({
      verificationStatus: status,
      isVerified: status === 'verified',
      updatedAt: new Date()
    }).where(eq(users.id, id));
    
    res.json({ message: "User verification status updated successfully" });
  } catch (error) {
    console.error("Error updating user verification status:", error);
    res.status(500).json({ error: "Failed to update user verification status" });
  }
});

// Reset user password (send reset link)
router.post('/users/:id/reset-password', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if user exists
    const user = await db.select({ email: users.email }).from(users).where(eq(users.id, id));
    
    if (user.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // In a real implementation, you would:
    // 1. Generate a password reset token
    // 2. Store it in the database with expiration
    // 3. Send an email with the reset link
    
    // For now, we'll just return success
    res.json({ message: "Password reset email sent successfully", email: user[0].email });
  } catch (error) {
    console.error("Error sending password reset:", error);
    res.status(500).json({ error: "Failed to send password reset" });
  }
});

// Bulk action on users
router.post('/users/bulk-action', async (req, res) => {
  try {
    const { userIds, action } = req.body;
    
    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: "No user IDs provided" });
    }
    
    if (!['delete', 'verify', 'reject'].includes(action)) {
      return res.status(400).json({ error: "Invalid action" });
    }
    
    if (action === 'delete') {
      // Delete users
      await db.delete(users).where(users.id.in(userIds));
      res.json({ message: `Successfully deleted ${userIds.length} users` });
    } else if (action === 'verify') {
      // Verify users
      await db.update(users).set({
        verificationStatus: 'verified',
        isVerified: true,
        updatedAt: new Date()
      }).where(users.id.in(userIds));
      res.json({ message: `Successfully verified ${userIds.length} users` });
    } else if (action === 'reject') {
      // Reject users verification
      await db.update(users).set({
        verificationStatus: 'rejected',
        isVerified: false,
        updatedAt: new Date()
      }).where(users.id.in(userIds));
      res.json({ message: `Successfully rejected verification for ${userIds.length} users` });
    }
  } catch (error) {
    console.error("Error performing bulk action:", error);
    res.status(500).json({ error: "Failed to perform bulk action" });
  }
});

// Get all assets
router.get('/assets', async (req, res) => {
  try {
    const allAssets = await db.select().from(assets).orderBy(assets.symbol);
    res.json(allAssets);
  } catch (error) {
    console.error("Error fetching assets:", error);
    res.status(500).json({ error: "Failed to fetch assets" });
  }
});

// Get asset by ID
router.get('/assets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const asset = await db.select().from(assets).where(eq(assets.id, id));
    
    if (asset.length === 0) {
      return res.status(404).json({ error: "Asset not found" });
    }
    
    res.json(asset[0]);
  } catch (error) {
    console.error("Error fetching asset:", error);
    res.status(500).json({ error: "Failed to fetch asset" });
  }
});

// Create new asset
router.post('/assets', async (req, res) => {
  try {
    const {
      symbol,
      name,
      assetType,
      description,
      logoUrl,
      polygonSymbol,
      tradingviewSymbol,
      price,
      marketStatus,
    } = req.body;
    
    // Check required fields
    if (!symbol || !name || !assetType) {
      return res.status(400).json({ error: "Symbol, name, and assetType are required" });
    }
    
    // Check if asset with same symbol already exists
    const existingAsset = await db.select({ id: assets.id }).from(assets).where(eq(assets.symbol, symbol));
    
    if (existingAsset.length > 0) {
      return res.status(409).json({ error: "Asset with this symbol already exists" });
    }
    
    // Create new asset
    const [newAsset] = await db.insert(assets).values({
      symbol,
      name,
      assetType,
      description,
      logoUrl,
      polygonSymbol,
      tradingviewSymbol,
      price: price || 0,
      priceChangePercent: 0,
      priceChange24h: 0,
      volume: 0,
      marketStatus: marketStatus || 'active',
      lastUpdated: new Date(),
    }).returning();
    
    res.status(201).json(newAsset);
  } catch (error) {
    console.error("Error creating asset:", error);
    res.status(500).json({ error: "Failed to create asset" });
  }
});

// Update asset
router.put('/assets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      symbol,
      name,
      assetType,
      description,
      logoUrl,
      polygonSymbol,
      tradingviewSymbol,
      price,
      marketStatus,
    } = req.body;
    
    // Check if asset exists
    const existingAsset = await db.select({ id: assets.id }).from(assets).where(eq(assets.id, id));
    
    if (existingAsset.length === 0) {
      return res.status(404).json({ error: "Asset not found" });
    }
    
    // Update asset
    await db.update(assets).set({
      symbol,
      name,
      assetType,
      description,
      logoUrl,
      polygonSymbol,
      tradingviewSymbol,
      price,
      marketStatus,
      updatedAt: new Date(),
    }).where(eq(assets.id, id));
    
    res.json({ message: "Asset updated successfully" });
  } catch (error) {
    console.error("Error updating asset:", error);
    res.status(500).json({ error: "Failed to update asset" });
  }
});

// Delete asset
router.delete('/assets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if asset exists
    const existingAsset = await db.select({ id: assets.id }).from(assets).where(eq(assets.id, id));
    
    if (existingAsset.length === 0) {
      return res.status(404).json({ error: "Asset not found" });
    }
    
    // Delete asset
    await db.delete(assets).where(eq(assets.id, id));
    
    res.json({ message: "Asset deleted successfully" });
  } catch (error) {
    console.error("Error deleting asset:", error);
    res.status(500).json({ error: "Failed to delete asset" });
  }
});

// Get all financial transactions
router.get('/finances', async (req, res) => {
  try {
    // This is a placeholder for the real implementation
    // In a real application, you would fetch transactions from the database
    const sampleTransactions = [
      {
        id: "fin-1",
        userId: 1,
        type: "deposit",
        amount: "1000.00",
        status: "completed",
        currency: "USD",
        createdAt: new Date(Date.now() - 86400000 * 5),
        processedAt: new Date(Date.now() - 86400000 * 4)
      },
      {
        id: "fin-2",
        userId: 2,
        type: "withdrawal",
        amount: "500.00",
        status: "pending",
        currency: "USD",
        createdAt: new Date(Date.now() - 86400000 * 2)
      },
      {
        id: "fin-3",
        userId: 3,
        type: "deposit",
        amount: "2500.00",
        status: "completed",
        currency: "USD",
        createdAt: new Date(Date.now() - 86400000 * 1),
        processedAt: new Date(Date.now() - 86400000 * 1)
      }
    ];
    
    res.json(sampleTransactions);
  } catch (error) {
    console.error("Error fetching financial transactions:", error);
    res.status(500).json({ error: "Failed to fetch financial transactions" });
  }
});

// Get financial transaction by ID
router.get('/finances/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // This is a placeholder for the real implementation
    // In a real application, you would fetch the transaction from the database
    const transaction = {
      id,
      userId: 1,
      type: "deposit",
      amount: "1000.00",
      status: "completed",
      currency: "USD",
      createdAt: new Date(Date.now() - 86400000 * 5),
      processedAt: new Date(Date.now() - 86400000 * 4)
    };
    
    res.json(transaction);
  } catch (error) {
    console.error("Error fetching financial transaction:", error);
    res.status(500).json({ error: "Failed to fetch financial transaction" });
  }
});

// Update financial transaction
router.put('/finances/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;
    
    // This is a placeholder for the real implementation
    // In a real application, you would update the transaction in the database
    res.json({ 
      message: "Financial transaction updated successfully",
      transaction: {
        id,
        status,
        notes,
        updatedAt: new Date()
      }
    });
  } catch (error) {
    console.error("Error updating financial transaction:", error);
    res.status(500).json({ error: "Failed to update financial transaction" });
  }
});

// Delete financial transaction
router.delete('/finances/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // This is a placeholder for the real implementation
    // In a real application, you would delete the transaction from the database
    res.json({ message: "Financial transaction deleted successfully" });
  } catch (error) {
    console.error("Error deleting financial transaction:", error);
    res.status(500).json({ error: "Failed to delete financial transaction" });
  }
});

// Update asset status
router.patch('/assets/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { marketStatus } = req.body;
    
    if (!['active', 'suspended'].includes(marketStatus)) {
      return res.status(400).json({ error: "Invalid market status" });
    }
    
    // Update asset status
    await db.update(assets).set({
      marketStatus,
      updatedAt: new Date()
    }).where(eq(assets.id, id));
    
    res.json({ message: "Asset status updated successfully" });
  } catch (error) {
    console.error("Error updating asset status:", error);
    res.status(500).json({ error: "Failed to update asset status" });
  }
});

// Get all trades
router.get('/trades', async (req, res) => {
  try {
    // Fix SQL syntax by using proper select statement
    const allTrades = await db.select().from(trades)
      .orderBy(trades.openedAt, { order: "desc" });
    res.json(allTrades);
  } catch (error) {
    console.error("Error fetching trades:", error);
    res.status(500).json({ error: "Failed to fetch trades" });
  }
});

// Get specific trade
router.get('/trades/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const trade = await db.select().from(trades).where(eq(trades.id, id));
    
    if (trade.length === 0) {
      return res.status(404).json({ error: "Trade not found" });
    }
    
    res.json(trade[0]);
  } catch (error) {
    console.error("Error fetching trade:", error);
    res.status(500).json({ error: "Failed to fetch trade" });
  }
});

// Update trade
router.put('/trades/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, exitPrice, profitLoss, stopLoss, takeProfit } = req.body;
    
    // Check if trade exists
    const existingTrade = await db.select({ id: trades.id }).from(trades).where(eq(trades.id, id));
    
    if (existingTrade.length === 0) {
      return res.status(404).json({ error: "Trade not found" });
    }
    
    // Update trade
    const updateData: any = {
      updatedAt: new Date()
    };
    
    if (status) updateData.status = status;
    if (exitPrice !== undefined) updateData.exitPrice = exitPrice;
    if (profitLoss !== undefined) updateData.profitLoss = profitLoss;
    if (stopLoss !== undefined) updateData.stopLoss = stopLoss;
    if (takeProfit !== undefined) updateData.takeProfit = takeProfit;
    
    // If closing the trade, add closed timestamp
    if (status === 'closed' && !updateData.closedAt) {
      updateData.closedAt = new Date();
    }
    
    await db.update(trades).set(updateData).where(eq(trades.id, id));
    
    res.json({ message: "Trade updated successfully" });
  } catch (error) {
    console.error("Error updating trade:", error);
    res.status(500).json({ error: "Failed to update trade" });
  }
});

// Delete trade
router.delete('/trades/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if trade exists
    const existingTrade = await db.select({ id: trades.id }).from(trades).where(eq(trades.id, id));
    
    if (existingTrade.length === 0) {
      return res.status(404).json({ error: "Trade not found" });
    }
    
    // Delete trade
    await db.delete(trades).where(eq(trades.id, id));
    
    res.json({ message: "Trade deleted successfully" });
  } catch (error) {
    console.error("Error deleting trade:", error);
    res.status(500).json({ error: "Failed to delete trade" });
  }
});

// Get all transactions
router.get('/transactions', async (req, res) => {
  try {
    // Fix SQL syntax by using proper select statement
    const allTransactions = await db.select().from(transactions)
      .orderBy(transactions.transactionDate, { order: "desc" });
    res.json(allTransactions);
  } catch (error) {
    console.error("Error fetching transactions:", error);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});

// Get specific transaction
router.get('/transactions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const transaction = await db.select().from(transactions).where(eq(transactions.id, id));
    
    if (transaction.length === 0) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    
    res.json(transaction[0]);
  } catch (error) {
    console.error("Error fetching transaction:", error);
    res.status(500).json({ error: "Failed to fetch transaction" });
  }
});

// Update transaction status
router.patch('/transactions/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!['pending', 'completed', 'failed'].includes(status)) {
      return res.status(400).json({ error: "Invalid transaction status" });
    }
    
    // Check if transaction exists
    const existingTransaction = await db.select({ id: transactions.id }).from(transactions).where(eq(transactions.id, id));
    
    if (existingTransaction.length === 0) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    
    // Update transaction status
    await db.update(transactions).set({
      status,
      updatedAt: new Date()
    }).where(eq(transactions.id, id));
    
    res.json({ message: "Transaction status updated successfully" });
  } catch (error) {
    console.error("Error updating transaction status:", error);
    res.status(500).json({ error: "Failed to update transaction status" });
  }
});

// Bulk action on transactions
router.post('/transactions/bulk-action', async (req, res) => {
  try {
    const { transactionIds, action } = req.body;
    
    if (!transactionIds || !Array.isArray(transactionIds) || transactionIds.length === 0) {
      return res.status(400).json({ error: "No transaction IDs provided" });
    }
    
    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({ error: "Invalid action" });
    }
    
    // Update transaction statuses using the correct SQL syntax
    const updateResult = await db.update(transactions)
      .set({
        status: action === 'approve' ? 'completed' : 'failed',
        updatedAt: new Date()
      })
      .where(transactions.id.in(transactionIds));
    
    const updatedCount = transactionIds.length;
    res.json({ 
      message: `Successfully ${action === 'approve' ? 'approved' : 'rejected'} ${updatedCount} transactions`,
      updatedCount 
    });
  } catch (error) {
    console.error("Error performing bulk action on transactions:", error);
    res.status(500).json({ error: "Failed to perform bulk action on transactions" });
  }
});

// Get platform settings
router.get('/settings', async (req, res) => {
  try {
    // For now, return default settings
    // In a real implementation, these would be fetched from the database
    const settings = {
      maintenanceMode: false,
      allowNewRegistrations: true,
      allowDeposits: true,
      allowWithdrawals: true,
      systemNotification: "Welcome to the trading platform! We're currently in beta testing.",
      minimumDeposit: 100,
      maximumWithdrawal: 10000,
      defaultLeverageOptions: [1, 2, 5, 10, 20, 50, 100],
      tradingFeePercentage: 0.1,
      withdrawalFeePercentage: 0.5,
      apiKeys: {
        polygonApiKey: '********', // Masked for security
      },
      emailSettings: {
        smtpHost: 'smtp.example.com',
        smtpPort: 587,
        smtpUser: 'notifications@example.com',
        smtpPassword: '********', // Masked for security
        fromEmail: 'noreply@example.com',
      }
    };
    
    res.json(settings);
  } catch (error) {
    console.error("Error fetching platform settings:", error);
    res.status(500).json({ error: "Failed to fetch platform settings" });
  }
});

// Update platform settings
router.put('/settings', async (req, res) => {
  try {
    const settings = req.body;
    
    // Validate required fields
    if (settings.minimumDeposit < 0 || settings.maximumWithdrawal < 0) {
      return res.status(400).json({ error: "Amount values must be positive" });
    }
    
    // In a real implementation, save these settings to the database
    // For now, just return success
    
    // Log admin action
    const adminUser = req.user;
    console.log(`Platform settings updated by admin: ${adminUser?.username}`);
    
    res.json({ 
      message: "Settings updated successfully",
      settings
    });
  } catch (error) {
    console.error("Error updating platform settings:", error);
    res.status(500).json({ error: "Failed to update platform settings" });
  }
});

// Test email settings
router.post('/settings/test-email', async (req, res) => {
  try {
    const emailSettings = req.body;
    
    // Validate required fields
    if (!emailSettings.smtpHost || !emailSettings.smtpUser || !emailSettings.fromEmail) {
      return res.status(400).json({ error: "Missing required email settings" });
    }
    
    // In a real implementation, you would test sending an email here
    // For now, just return success
    
    // Add a small delay to simulate email sending
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    res.json({ message: "Test email sent successfully" });
  } catch (error) {
    console.error("Error testing email settings:", error);
    res.status(500).json({ error: "Failed to test email settings" });
  }
});

// API endpoints for Activity Log

// Get activity logs
router.get('/activity-logs', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database
    // For demo purposes, we'll return mock data
    const activityLogs = [
      {
        id: "1",
        userId: "admin1",
        username: "AdminUser",
        action: "user.update",
        target: "users",
        targetId: "user123",
        details: "Updated user verification status to verified",
        ip: "192.168.1.1",
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        status: "success"
      },
      {
        id: "2",
        userId: "admin1",
        username: "AdminUser",
        action: "asset.create",
        target: "assets",
        targetId: "asset456",
        details: "Added new asset: Bitcoin (BTC)",
        ip: "192.168.1.1",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        status: "success"
      },
      // More activity logs...
    ];
    
    res.json(activityLogs);
  } catch (error) {
    console.error("Error fetching activity logs:", error);
    res.status(500).json({ error: "Failed to fetch activity logs" });
  }
});

// Create a new user
router.post('/users', async (req, res) => {
  try {
    const { username, email, password, userRole } = req.body;
    
    // Validate required fields
    if (!username || !email || !password) {
      return res.status(400).json({ error: "Username, email, and password are required" });
    }
    
    // Validate email format
    const emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: "Invalid email format" });
    }
    
    // Validate password length
    if (password.length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters" });
    }
    
    // Validate userRole
    if (userRole && !['user', 'admin'].includes(userRole)) {
      return res.status(400).json({ error: "Invalid user role" });
    }
    
    // Check if username already exists
    const existingUserByUsername = await db.select({id: users.id}).from(users).where(eq(users.username, username));
    if (existingUserByUsername.length > 0) {
      return res.status(409).json({ error: "Username already exists" });
    }
    
    // Check if email already exists
    const existingUserByEmail = await db.select({id: users.id}).from(users).where(eq(users.email, email));
    if (existingUserByEmail.length > 0) {
      return res.status(409).json({ error: "Email already exists" });
    }
    
    // Hash the password using scrypt (Node.js built-in)
    const salt = randomBytes(16).toString('hex');
    const hashedPassword = await new Promise<string>((resolve, reject) => {
      scrypt(password, salt, 64, (err, key) => {
        if (err) reject(err);
        resolve(`${key.toString('hex')}.${salt}`);
      });
    });
    
    // Insert the new user
    const [newUser] = await db.insert(users).values({
      username,
      email,
      passwordHash: hashedPassword,
      fullName: username, // Default to username for fullName
      isVerified: true, // Admin-created users are verified by default
      verificationStatus: 'verified',
      userRole: userRole || 'user',
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    
    // Hide sensitive information
    const { passwordHash, ...userWithoutPassword } = newUser;
    
    // Log admin action
    console.log(`New user created by admin: ${username} (${userRole || 'user'})`);
    
    res.status(201).json(userWithoutPassword);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Failed to create user" });
  }
});

// Create activity log entry
router.post('/activity-logs', async (req, res) => {
  try {
    const { action, target, targetId, details, status } = req.body;
    
    // Validate required fields
    if (!action || !target || !targetId) {
      return res.status(400).json({ error: "Action, target, and targetId are required" });
    }
    
    // In a real implementation, you would save to the database
    // Get admin user info
    const adminUser = req.user;
    
    // Log the new activity
    console.log(`New admin activity: ${adminUser?.username} performed ${action} on ${target}/${targetId}`);
    
    res.status(201).json({ 
      message: "Activity logged successfully", 
      logId: `log-${Date.now()}` 
    });
  } catch (error) {
    console.error("Error logging activity:", error);
    res.status(500).json({ error: "Failed to log activity" });
  }
});

// API endpoints for Backup & Restore

// Get all backups
router.get('/backups', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database or file system
    // For demo purposes, we'll return mock data
    const backups = [
      {
        id: "backup-1",
        name: "Full Automatic Backup",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        size: "42.8 MB",
        type: "full",
        status: "completed",
        createdBy: "System (Automatic)",
        tables: ["users", "assets", "trades", "transactions", "settings", "activity_logs"],
        records: {
          users: 1250,
          assets: 153,
          trades: 8742,
          transactions: 5621,
          settings: 38,
          activity_logs: 12583
        },
        location: "local"
      },
      // More backups...
    ];
    
    res.json(backups);
  } catch (error) {
    console.error("Error fetching backups:", error);
    res.status(500).json({ error: "Failed to fetch backups" });
  }
});

// Create new backup
router.post('/backups', async (req, res) => {
  try {
    const { type } = req.body;
    
    if (!type || !['full', 'partial'].includes(type)) {
      return res.status(400).json({ error: "Valid type (full or partial) is required" });
    }
    
    // In a real implementation, you would:
    // 1. Create a database backup (dump)
    // 2. Save it to the file system
    // 3. Log the backup in the database
    
    // Simulate a backup process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Get admin user info
    const adminUser = req.user;
    
    // Log the new backup
    console.log(`New backup created by ${adminUser?.username}: ${type} backup`);
    
    // Return a response
    res.status(201).json({
      id: `backup-${Date.now()}`,
      name: `${type === 'full' ? 'Full' : 'Partial'} Backup - Manual`,
      createdAt: new Date().toISOString(),
      size: type === 'full' ? '43.2 MB' : '12.5 MB',
      type: type,
      status: 'completed',
      createdBy: adminUser?.username || 'Unknown',
      tables: type === 'full' 
        ? ["users", "assets", "trades", "transactions", "settings", "activity_logs"]
        : ["users", "settings"],
      records: type === 'full'
        ? { users: 1250, assets: 153, trades: 8742, transactions: 5621, settings: 38, activity_logs: 12583 }
        : { users: 1250, settings: 38 },
      location: 'local'
    });
  } catch (error) {
    console.error("Error creating backup:", error);
    res.status(500).json({ error: "Failed to create backup" });
  }
});

// Delete backup
router.delete('/backups/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // In a real implementation, you would:
    // 1. Check if backup exists
    // 2. Delete the backup file
    // 3. Remove the backup record from the database
    
    // Simulate deletion
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Get admin user info
    const adminUser = req.user;
    
    // Log the deletion
    console.log(`Backup ${id} deleted by ${adminUser?.username}`);
    
    res.json({ message: "Backup deleted successfully" });
  } catch (error) {
    console.error("Error deleting backup:", error);
    res.status(500).json({ error: "Failed to delete backup" });
  }
});

// Restore from backup
router.post('/backups/:id/restore', async (req, res) => {
  try {
    const { id } = req.params;
    
    // In a real implementation, you would:
    // 1. Check if backup exists
    // 2. Validate the backup file
    // 3. Restore the database from the backup
    
    // Simulate restoration process
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Get admin user info
    const adminUser = req.user;
    
    // Log the restoration
    console.log(`Database restored from backup ${id} by ${adminUser?.username}`);
    
    // Return a response
    res.json({ message: "Database restored successfully from backup" });
  } catch (error) {
    console.error("Error restoring from backup:", error);
    res.status(500).json({ error: "Failed to restore from backup" });
  }
});

// Get backup settings
router.get('/backup-settings', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database
    // For demo purposes, we'll return default settings
    const settings = {
      enabled: true,
      frequency: "daily",
      time: "02:00",
      keepLocal: true,
      keepCloud: true,
      retention: 30,
    };
    
    res.json(settings);
  } catch (error) {
    console.error("Error fetching backup settings:", error);
    res.status(500).json({ error: "Failed to fetch backup settings" });
  }
});

// Update backup settings
router.put('/backup-settings', async (req, res) => {
  try {
    const settings = req.body;
    
    // In a real implementation, you would validate and save to the database
    
    // Get admin user info
    const adminUser = req.user;
    
    // Log the settings update
    console.log(`Backup settings updated by ${adminUser?.username}`);
    
    res.json({ 
      message: "Backup settings updated successfully",
      settings
    });
  } catch (error) {
    console.error("Error updating backup settings:", error);
    res.status(500).json({ error: "Failed to update backup settings" });
  }
});

// API endpoints for Security

// Get security logs
router.get('/security/logs', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database
    // For demo purposes, we'll return mock data
    const securityLogs = [
      {
        id: "1",
        eventType: "login_failure",
        username: "user123",
        ipAddress: "192.168.1.100",
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        details: "Failed login attempt - incorrect password",
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        severity: "medium"
      },
      {
        id: "2",
        eventType: "login_success",
        username: "admin",
        ipAddress: "192.168.1.101",
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        details: "Successful admin login",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        severity: "low"
      },
      // More security logs...
    ];
    
    res.json(securityLogs);
  } catch (error) {
    console.error("Error fetching security logs:", error);
    res.status(500).json({ error: "Failed to fetch security logs" });
  }
});

// Get blocked IPs
router.get('/security/blocked-ips', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database
    // For demo purposes, we'll return mock data
    const blockedIPs = [
      {
        id: "1",
        ipAddress: "45.123.45.123",
        reason: "Multiple failed login attempts",
        blockedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        location: "Unknown",
        blockedBy: "system"
      },
      {
        id: "2",
        ipAddress: "198.51.100.76",
        reason: "Attempted API breach",
        blockedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        location: "Unknown",
        blockedBy: "admin"
      },
      // More blocked IPs...
    ];
    
    res.json(blockedIPs);
  } catch (error) {
    console.error("Error fetching blocked IPs:", error);
    res.status(500).json({ error: "Failed to fetch blocked IPs" });
  }
});

// Block an IP address
router.post('/security/block-ip', async (req, res) => {
  try {
    const { ipAddress, reason, duration } = req.body;
    
    if (!ipAddress) {
      return res.status(400).json({ error: "IP address is required" });
    }
    
    // In a real implementation, you would:
    // 1. Check if IP is already blocked
    // 2. Calculate expiration date based on duration
    // 3. Add IP to blocked list in database
    
    // Get admin user info for logging
    const adminUser = req.user;
    
    // Log the blocking
    console.log(`IP ${ipAddress} blocked by ${adminUser?.username} for reason: ${reason}`);
    
    // Return success
    res.status(201).json({
      message: "IP address blocked successfully",
      ipAddress,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // Default 7 days
    });
  } catch (error) {
    console.error("Error blocking IP:", error);
    res.status(500).json({ error: "Failed to block IP address" });
  }
});

// Unblock an IP address
router.delete('/security/blocked-ips/:ipAddress', async (req, res) => {
  try {
    const { ipAddress } = req.params;
    
    // In a real implementation, you would:
    // 1. Check if IP exists in blocked list
    // 2. Remove it from the database
    
    // Get admin user info for logging
    const adminUser = req.user;
    
    // Log the unblocking
    console.log(`IP ${ipAddress} unblocked by ${adminUser?.username}`);
    
    res.json({ message: "IP address unblocked successfully" });
  } catch (error) {
    console.error("Error unblocking IP:", error);
    res.status(500).json({ error: "Failed to unblock IP address" });
  }
});

// Get security settings
router.get('/security/settings', async (req, res) => {
  try {
    // In a real implementation, you would fetch from the database
    // For demo purposes, we'll return default settings
    const securitySettings = {
      twoFactorRequired: true,
      rateLimit: {
        enabled: true,
        requestsPerMinute: 60
      },
      loginAttempts: {
        maxAttempts: 5,
        lockoutDuration: 30 // minutes
      },
      sessionTimeout: 30, // minutes
      passwordPolicy: {
        minLength: 8,
        requireUppercase: true,
        requireLowercase: true,
        requireNumbers: true,
        requireSpecialChars: true,
        expiryDays: 90
      }
    };
    
    res.json(securitySettings);
  } catch (error) {
    console.error("Error fetching security settings:", error);
    res.status(500).json({ error: "Failed to fetch security settings" });
  }
});

// Update security settings
router.put('/security/settings', async (req, res) => {
  try {
    const settings = req.body;
    
    // In a real implementation, you would validate and save to the database
    
    // Get admin user info for logging
    const adminUser = req.user;
    
    // Log the settings update
    console.log(`Security settings updated by ${adminUser?.username}`);
    
    res.json({ 
      message: "Security settings updated successfully",
      settings
    });
  } catch (error) {
    console.error("Error updating security settings:", error);
    res.status(500).json({ error: "Failed to update security settings" });
  }
});

// Get all KYC requests
router.get('/kyc-requests', async (req, res) => {
  try {
    // Get all users with pending verification
    const pendingKycUsers = await db.select().from(users)
      .where(eq(users.verificationStatus, 'pending'))
      .orderBy(users.createdAt, { order: "desc" });
    
    // Return formatted KYC request data
    const kycRequests = pendingKycUsers.map(user => ({
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      phoneNumber: user.phoneNumber,
      submittedAt: user.createdAt,
      status: user.verificationStatus
    }));
    
    res.json(kycRequests);
  } catch (error) {
    console.error("Error fetching KYC requests:", error);
    res.status(500).json({ error: "Failed to fetch KYC requests" });
  }
});

// Get specific KYC request
router.get('/kyc-requests/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get the user with the given ID
    const user = await db.select().from(users).where(eq(users.id, id));
    
    if (user.length === 0) {
      return res.status(404).json({ error: "KYC request not found" });
    }
    
    // Return detailed KYC request data
    const kycRequest = {
      id: user[0].id,
      username: user[0].username,
      email: user[0].email,
      fullName: user[0].fullName,
      phoneNumber: user[0].phoneNumber,
      submittedAt: user[0].createdAt,
      status: user[0].verificationStatus,
      country: user[0].country,
      city: user[0].city,
      address: user[0].address,
      // Include additional KYC data that might be in the user record
      documentType: user[0].documentType || 'Passport', // Example, replace with actual field
      documentNumber: user[0].documentNumber || 'XX-XXXXXX', // Example, replace with actual field
      documentIssueDate: user[0].documentIssueDate || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000), // Example, replace with actual field
      documentExpiryDate: user[0].documentExpiryDate || new Date(Date.now() + 5 * 365 * 24 * 60 * 60 * 1000), // Example, replace with actual field
      // In a real implementation, you might have document URLs stored somewhere
      documentFrontUrl: user[0].documentFrontUrl || null,
      documentBackUrl: user[0].documentBackUrl || null,
      selfieUrl: user[0].selfieUrl || null,
      // Additional verification data
      verificationNotes: user[0].verificationNotes || null
    };
    
    res.json(kycRequest);
  } catch (error) {
    console.error("Error fetching KYC request:", error);
    res.status(500).json({ error: "Failed to fetch KYC request" });
  }
});

// Approve KYC request
router.post('/kyc-requests/:id/approve', async (req, res) => {
  try {
    const { id } = req.params;
    const { notes } = req.body;
    
    // Check if user exists
    const existingUser = await db.select({ id: users.id }).from(users).where(eq(users.id, id));
    
    if (existingUser.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Update user verification status
    await db.update(users).set({
      verificationStatus: 'verified',
      isVerified: true,
      verificationNotes: notes || null,
      updatedAt: new Date()
    }).where(eq(users.id, id));
    
    res.json({ message: "KYC request approved successfully" });
  } catch (error) {
    console.error("Error approving KYC request:", error);
    res.status(500).json({ error: "Failed to approve KYC request" });
  }
});

// Reject KYC request
router.post('/kyc-requests/:id/reject', async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    
    // Check if user exists
    const existingUser = await db.select({ id: users.id }).from(users).where(eq(users.id, id));
    
    if (existingUser.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Update user verification status
    await db.update(users).set({
      verificationStatus: 'rejected',
      isVerified: false,
      verificationNotes: reason || null,
      updatedAt: new Date()
    }).where(eq(users.id, id));
    
    res.json({ message: "KYC request rejected successfully" });
  } catch (error) {
    console.error("Error rejecting KYC request:", error);
    res.status(500).json({ error: "Failed to reject KYC request" });
  }
});

// Get user's portfolio details
router.get('/users/:id/portfolio', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if user exists
    const user = await db.select({ id: users.id, username: users.username }).from(users).where(eq(users.id, id));
    
    if (user.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Query using the db object directly to avoid parameter binding issues
    const portfolio = await db.select().from('portfolios')
      .where('user_id', '=', id)
      .limit(1);
    
    if (portfolio.length === 0) {
      // If no portfolio exists, create a default empty one
      return res.json({
        userId: id,
        username: user[0].username,
        totalValue: 0,
        availableBalance: 0,
        investedAmount: 0,
        unrealizedPL: 0,
        plPercentage: 0,
        transactions: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
    
    // Get recent transactions for this user
    const userTransactions = await db.select().from('transactions')
      .where('user_id', '=', id)
      .orderBy('created_at', 'desc')
      .limit(5);
    
    // Return the portfolio with actual values from database
    const portfolioData = {
      userId: id,
      username: user[0].username,
      totalValue: parseFloat(portfolio[0].total_balance) || 0,
      availableBalance: parseFloat(portfolio[0].available_balance) || 0,
      investedAmount: parseFloat(portfolio[0].total_invested_amount) || 0,
      unrealizedPL: (parseFloat(portfolio[0].total_profit || 0) - parseFloat(portfolio[0].total_loss || 0)) || 0,
      plPercentage: parseFloat(portfolio[0].total_invested_amount) > 0 
        ? ((parseFloat(portfolio[0].total_profit || 0) - parseFloat(portfolio[0].total_loss || 0)) / parseFloat(portfolio[0].total_invested_amount)) * 100 
        : 0,
      transactions: userTransactions,
      createdAt: portfolio[0].created_at ? new Date(portfolio[0].created_at).toISOString() : new Date().toISOString(),
      updatedAt: portfolio[0].updated_at ? new Date(portfolio[0].updated_at).toISOString() : new Date().toISOString()
    };
    
    res.json(portfolioData);
  } catch (error) {
    console.error("Error fetching user portfolio:", error);
    res.status(500).json({ error: "Failed to fetch user portfolio" });
  }
});

// Adjust user balance
router.post('/users/:id/adjust-balance', async (req, res) => {
  try {
    const { id } = req.params;
    const { amount, type, currency, notes } = req.body;
    
    // Validate input
    if (!amount || !type || !currency) {
      return res.status(400).json({ error: "Amount, type, and currency are required" });
    }
    
    if (!['deposit', 'withdrawal', 'adjustment'].includes(type)) {
      return res.status(400).json({ error: "Type must be deposit, withdrawal, or adjustment" });
    }
    
    if (typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ error: "Amount must be a positive number" });
    }
    
    // Check if user exists
    const user = await db.select({ id: users.id, username: users.username }).from(users).where(eq(users.id, id));
    
    if (user.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Get current portfolio data using db object directly
    const portfolio = await db.select().from('portfolios')
      .where('user_id', '=', id)
      .limit(1);
    
    if (portfolio.length === 0) {
      return res.status(404).json({ error: "User portfolio not found" });
    }
    
    // Check if user has sufficient balance for withdrawals
    if (type === 'withdrawal' && parseFloat(portfolio[0].available_balance) < amount) {
      return res.status(400).json({ 
        error: "Insufficient balance", 
        availableBalance: parseFloat(portfolio[0].available_balance)
      });
    }
    
    // Calculate new balance values based on transaction type
    let newAvailableBalance = parseFloat(portfolio[0].available_balance);
    
    if (type === 'deposit' || type === 'adjustment') {
      newAvailableBalance += amount;
    } else if (type === 'withdrawal') {
      newAvailableBalance -= amount;
    }
    
    // Update portfolio balance using db object directly
    await db.update('portfolios').set({
      available_balance: newAvailableBalance,
      total_balance: newAvailableBalance + parseFloat(portfolio[0].total_invested_amount),
      updated_at: new Date()
    }).where('user_id', '=', id);
    
    // Create transaction record
    const transactionId = `tx-${Date.now()}`;
    await db.insert('transactions').values({
      id: transactionId,
      user_id: id,
      type: type,
      amount: amount,
      currency: currency,
      status: 'completed',
      description: notes || `Admin ${type} transaction`,
      created_at: new Date(),
      updated_at: new Date()
    });
    
    // Prepare response with transaction info
    const transaction = {
      id: transactionId,
      userId: id,
      username: user[0].username,
      type,
      amount,
      currency,
      status: 'completed',
      notes: notes || `Admin ${type} transaction`,
      createdAt: new Date().toISOString(),
      processedBy: req.user?.username || 'admin'
    };
    
    // Log the transaction
    console.log(`Admin adjusted user balance: ${user[0].username}, ${type} of ${amount} ${currency}`);
    
    res.status(201).json({
      message: `Successfully processed ${type} of ${amount} ${currency} for user ${user[0].username}`,
      transaction
    });
  } catch (error) {
    console.error("Error adjusting user balance:", error);
    res.status(500).json({ error: "Failed to adjust user balance" });
  }
});

// Get economic events
router.get('/api/admin/economic-events', async (req, res) => {
  try {
    const { month } = req.query;
    
    if (!month || typeof month !== 'string') {
      return res.status(400).json({ error: 'Month parameter is required (format: YYYY-MM)' });
    }
    
    const events = await economicEventsService.getEconomicEventsByMonth(month);
    res.json(events);
  } catch (error) {
    console.error('Error fetching economic events:', error);
    res.status(500).json({ error: 'Failed to fetch economic events' });
  }
});

// Delete economic event
router.delete('/api/admin/economic-events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const deleted = await db.economic_events.delete({
      where: { id }
    });
    
    res.json({ success: true, deleted });
  } catch (error) {
    console.error('Error deleting economic event:', error);
    res.status(500).json({ error: 'Failed to delete economic event' });
  }
});

// Add economic event
router.post('/api/admin/economic-events', async (req, res) => {
  try {
    const data = req.body;
    
    if (!data.event_name || !data.event_date) {
      return res.status(400).json({ 
        error: 'Missing required fields', 
        required: ['event_name', 'event_date']
      });
    }
    
    const event = await db.economic_events.create({
      data: {
        event_name: data.event_name,
        event_date: new Date(data.event_date),
        event_time: data.event_time || null,
        country: data.country || null,
        importance_level: data.importance_level || 'medium',
        description: data.description || null,
        asset_impact: data.asset_impact || null,
        source: 'manual',
        created_at: new Date(),
        updated_at: new Date()
      }
    });
    
    res.status(201).json(event);
  } catch (error) {
    console.error('Error adding economic event:', error);
    res.status(500).json({ error: 'Failed to add economic event' });
  }
});

// Trigger notifications endpoint
router.post('/trigger-notifications', async (req, res) => {
  try {
    const startTime = Date.now();
    const { types = ['all'], userId } = req.body;
    const results = { triggered: [], errors: [], timing: {} };
    
    // Check which notification types to trigger
    const triggerAll = types.includes('all');
    const triggerEconomicEvents = triggerAll || types.includes('economic_events');
    const triggerCorrelations = triggerAll || types.includes('correlations');
    const triggerVolatility = triggerAll || types.includes('volatility');
    
    // Get user ID from request if provided (default to admin user 1)
    const targetUserId = userId || 1;
    
    // Run the notification checks based on requested types
    if (triggerEconomicEvents) {
      try {
        const start = Date.now();
        await checkForEconomicEventNotifications();
        const duration = Date.now() - start;
        results.triggered.push('economic_events');
        results.timing['economic_events'] = `${duration}ms`;
      } catch (error) {
        console.error("Error triggering economic event notifications:", error);
        results.errors.push({
          type: 'economic_events',
          message: error.message || 'Unknown error'
        });
      }
    }
    
    if (triggerCorrelations) {
      try {
        const start = Date.now();
        await checkEconomicEventCorrelations();
        const duration = Date.now() - start;
        results.triggered.push('correlations');
        results.timing['correlations'] = `${duration}ms`;
      } catch (error) {
        console.error("Error triggering correlation notifications:", error);
        results.errors.push({
          type: 'correlations',
          message: error.message || 'Unknown error'
        });
      }
    }
    
    if (triggerVolatility) {
      try {
        const start = Date.now();
        await checkUpcomingVolatilityEvents();
        const duration = Date.now() - start;
        results.triggered.push('volatility');
        results.timing['volatility'] = `${duration}ms`;
      } catch (error) {
        console.error("Error triggering volatility notifications:", error);
        results.errors.push({
          type: 'volatility',
          message: error.message || 'Unknown error'
        });
      }
    }
    
    // Calculate total execution time
    const totalDuration = Date.now() - startTime;
    
    // Return results
    res.json({
      success: results.errors.length === 0,
      userId: targetUserId,
      triggered: results.triggered,
      errors: results.errors,
      timing: {
        ...results.timing,
        total: `${totalDuration}ms`
      }
    });
  } catch (error) {
    console.error("Error in trigger-notifications endpoint:", error);
    res.status(500).json({
      success: false,
      error: "Failed to trigger notifications",
      details: error.message || 'Unknown error'
    });
  }
});

// Get notifications endpoint
router.get('/notifications', async (req, res) => {
  try {
    const { userId } = req.query;
    
    // Default to admin user if no userId provided
    const targetUserId = parseInt(userId as string) || 1;
    
    // Import notification service functions
    const { getUnseenNotifications, getNotificationHistory } = await import('../../services/notificationService.js');
    
    // Get both unseen and history
    const unseen = getUnseenNotifications(targetUserId);
    const history = getNotificationHistory(targetUserId, 50);
    
    res.json({
      userId: targetUserId,
      unseen,
      history,
      counts: {
        unseen: unseen.length,
        total: history.length
      }
    });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch notifications",
      details: error.message || 'Unknown error'
    });
  }
});

// Manually trigger notifications check (admin only)
router.post('/trigger-notifications', async (req, res) => {
  try {
    console.log('Admin manually triggered notifications check');
    
    // Run all notification checks
    const results = await runAllNotificationChecks();
    
    res.json({
      success: true,
      message: 'Notification checks triggered successfully',
      results
    });
  } catch (error) {
    console.error("Error triggering notification checks:", error);
    res.status(500).json({
      success: false,
      error: "Failed to trigger notification checks",
      details: error.message || 'Unknown error'
    });
  }
});

export default router; 