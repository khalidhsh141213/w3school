import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bitcoin, ChevronRight } from 'lucide-react';

export default function CryptoPromotionCard() {
  return (
    <Card className="shadow-md overflow-hidden">
      <div className="bg-gradient-to-br from-amber-500 to-amber-600 p-4 text-white">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Explore Crypto</h3>
          <div className="bg-white/20 p-2 rounded-full">
            <Bitcoin className="h-5 w-5" />
          </div>
        </div>
        <p className="mt-2 text-sm">Invest in cryptocurrency with as little as $10</p>
      </div>
      
      <CardContent className="p-4">
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-amber-50 rounded-md p-3 text-center">
            <div className="font-semibold text-amber-800">$10</div>
            <div className="text-xs text-amber-600 mt-1">Minimum</div>
          </div>
          <div className="bg-amber-50 rounded-md p-3 text-center">
            <div className="font-semibold text-amber-800">0.5%</div>
            <div className="text-xs text-amber-600 mt-1">Trading Fee</div>
          </div>
        </div>
        
        <Button className="w-full" variant="outline">
          Start Trading <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      </CardContent>
    </Card>
  );
}