import { useQuery } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';

export type PortfolioSummary = {
  id: number;
  userId: number;
  totalBalance: string;
  totalEquity: string;
  totalProfit: string;
  totalLoss: string;
  openPositions: number;
  totalInvestment: string;
  availableBalance: string;
  totalReturn: string;
  marginAuthorized: string;
  marginUsed: string;
  unauthorizedPnl: string;
  createdAt: string;
  lastUpdate: string;
};

/**
 * Hook to fetch detailed portfolio summary data
 */
export function usePortfolioSummary() {
  return useQuery({
    queryKey: ['/api/portfolio-summary'],
    refetchInterval: 60000, // Refetch every minute
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    staleTime: 30000, // Consider data stale after 30 seconds
  });
}

/**
 * Manually invalidate portfolio summary cache
 */
export function invalidatePortfolioSummary() {
  queryClient.invalidateQueries({ queryKey: ['/api/portfolio-summary'] });
}

/**
 * Format a monetary value with proper currency symbol
 * @param value The value to format
 * @param currency The currency code (default: USD)
 * @returns Formatted string
 */
export function formatCurrency(value: string | number | undefined | null, currency = 'USD') {
  if (value === undefined || value === null) return '$0.00';
  
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  // Handle NaN
  if (isNaN(numValue)) return '$0.00';
  
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(numValue);
}

/**
 * Format a percentage value
 * @param value The value to format
 * @returns Formatted string with % sign
 */
export function formatPercentage(value: string | number | undefined | null) {
  if (value === undefined || value === null) return '0.00%';
  
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  // Handle NaN
  if (isNaN(numValue)) return '0.00%';
  
  return `${numValue.toFixed(2)}%`;
}