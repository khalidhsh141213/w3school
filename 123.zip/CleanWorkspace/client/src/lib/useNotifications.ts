import { useState, useEffect, useCallback, useRef } from 'react';
import { ConnectionStatus } from '@/services/WebSocketManager';

// Notification types from the server
export enum NotificationType {
  ECONOMIC_EVENT = 'economic_event',
  PRICE_ALERT = 'price_alert',
  TRADE_EXECUTION = 'trade_execution',
  SYSTEM = 'system'
}

export enum NotificationImportance {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

export interface Notification {
  id: string;
  userId: number;
  type: NotificationType;
  title: string;
  message: string;
  importance: NotificationImportance;
  relatedData?: any;
  timestamp: number;
  seen: boolean;
}

interface NotificationOptions {
  autoMarkSeen?: boolean; // Automatically mark notifications as seen when received
  fetchOnConnect?: boolean; // Fetch notifications when WebSocket connects
  debug?: boolean; // Enable debug logging
}

const DEFAULT_OPTIONS: NotificationOptions = {
  autoMarkSeen: false,
  fetchOnConnect: true,
  debug: false
};

// Hook return type
interface NotificationHook {
  notifications: Notification[];
  hasUnseenNotifications: boolean;
  unseenCount: number;
  markAsRead: (notificationIds: string[]) => void;
  markAllAsRead: () => void;
  refresh: () => void;
  connectionStatus: ConnectionStatus;
  error: string | null;
}

export const useNotifications = (
  userId: number | null,
  wsUrl?: string,
  options: NotificationOptions = {}
): NotificationHook => {
  // Merge default options with provided options
  const notificationOptions = {
    ...DEFAULT_OPTIONS,
    ...options
  };

  // State
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [error, setError] = useState<string | null>(null);
  
  // Refs
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const debugLoggingRef = useRef<boolean>(notificationOptions.debug || false);
  
  // Debug logging helper
  const logDebug = useCallback((message: string, ...args: any[]) => {
    if (debugLoggingRef.current) {
      console.log(`[NotificationSocket] ${message}`, ...args);
    }
  }, []);
  
  // Initialize WebSocket connection
  const initSocket = useCallback(() => {
    if (!userId) {
      logDebug('No user ID provided, not connecting');
      return;
    }
    
    try {
      // Use the provided URL or default to window location
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const socketUrl = wsUrl || `${protocol}//${window.location.host}/ws`;
      
      logDebug(`Connecting to ${socketUrl}`);
      
      // Create WebSocket connection
      const socket = new WebSocket(socketUrl);
      socketRef.current = socket;
      
      socket.onopen = () => {
        logDebug('WebSocket connected');
        setConnectionStatus(ConnectionStatus.CONNECTED);
        setError(null);
        
        // Register for notifications
        socket.send(JSON.stringify({
          type: 'notifications_register',
          userId
        }));
        
        // Fetch existing notifications
        if (notificationOptions.fetchOnConnect) {
          socket.send(JSON.stringify({
            type: 'notifications_get',
            userId
          }));
        }
      };
      
      socket.onclose = () => {
        logDebug('WebSocket disconnected');
        setConnectionStatus(ConnectionStatus.DISCONNECTED);
        
        // Try to reconnect after a delay
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
        }
        
        reconnectTimeoutRef.current = setTimeout(() => {
          logDebug('Attempting to reconnect...');
          initSocket();
        }, 3000);
      };
      
      socket.onerror = (event) => {
        console.error('WebSocket error:', event);
        setError('Notification connection error occurred');
      };
      
      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          logDebug('Received message:', message.type);
          
          // Handle different message types
          switch (message.type) {
            case 'notifications':
              // Handle notifications data
              if (message.data && Array.isArray(message.data)) {
                logDebug(`Received ${message.data.length} notifications`);
                setNotifications(message.data);
                
                // Auto-mark as seen if enabled
                if (notificationOptions.autoMarkSeen && message.data.length > 0) {
                  const unseenIds = message.data
                    .filter((notification: Notification) => !notification.seen)
                    .map((notification: Notification) => notification.id);
                  
                  if (unseenIds.length > 0) {
                    socket.send(JSON.stringify({
                      type: 'notifications_mark_seen',
                      userId,
                      notificationIds: unseenIds
                    }));
                  }
                }
              }
              break;
              
            case 'notification':
              // Handle single new notification
              if (message.data) {
                logDebug('Received new notification');
                setNotifications(prev => [message.data, ...prev]);
              }
              break;
              
            case 'notifications_marked_seen':
              // Confirmation that notifications were marked as seen
              logDebug(`Marked ${message.count} notifications as seen`);
              break;
              
            case 'notification_registered':
              // Confirmation of registration
              logDebug('Successfully registered for notifications');
              break;
              
            case 'error':
              // Handle error from server
              console.error(`Notification error: ${message.code} - ${message.message}`);
              setError(message.message || 'Notification server error');
              break;
          }
        } catch (err) {
          console.error('Error parsing notification message:', err);
        }
      };
    } catch (err) {
      console.error('Failed to establish notification connection:', err);
      setError('Failed to connect to notification service');
      setConnectionStatus(ConnectionStatus.ERROR);
      
      // Try to reconnect after a delay
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      reconnectTimeoutRef.current = setTimeout(() => {
        logDebug('Attempting to reconnect after error...');
        initSocket();
      }, 5000);
    }
  }, [userId, wsUrl, logDebug, notificationOptions.fetchOnConnect, notificationOptions.autoMarkSeen]);
  
  // Mark specific notifications as read
  const markAsRead = useCallback((notificationIds: string[]) => {
    if (!userId || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      return;
    }
    
    // Send request to mark notifications as seen
    socketRef.current.send(JSON.stringify({
      type: 'notifications_mark_seen',
      userId,
      notificationIds
    }));
    
    // Update local state immediately for better UX
    setNotifications(prev => 
      prev.map(notification => 
        notificationIds.includes(notification.id) 
          ? { ...notification, seen: true } 
          : notification
      )
    );
  }, [userId]);
  
  // Mark all notifications as read
  const markAllAsRead = useCallback(() => {
    const unseenIds = notifications
      .filter(notification => !notification.seen)
      .map(notification => notification.id);
    
    if (unseenIds.length > 0) {
      markAsRead(unseenIds);
    }
  }, [notifications, markAsRead]);
  
  // Refresh notifications by requesting them from the server
  const refresh = useCallback(() => {
    if (!userId || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      return;
    }
    
    socketRef.current.send(JSON.stringify({
      type: 'notifications_get',
      userId
    }));
  }, [userId]);
  
  // Count unseen notifications
  const unseenCount = notifications.filter(notification => !notification.seen).length;
  const hasUnseenNotifications = unseenCount > 0;
  
  // Connect on component mount and when userId changes
  useEffect(() => {
    if (userId) {
      initSocket();
    }
    
    // Clean up on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [userId, initSocket]);
  
  return {
    notifications,
    hasUnseenNotifications,
    unseenCount,
    markAsRead,
    markAllAsRead,
    refresh,
    connectionStatus,
    error
  };
};