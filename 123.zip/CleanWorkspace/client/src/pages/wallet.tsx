import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  CreditCard, 
  BarChart, 
  Clock, 
  Filter,
  Search,
  AlertTriangle
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { format } from 'date-fns';
import { useAuth } from '@/lib/authContext';
import { defaultPortfolioData, usePortfolioData } from '@/hooks/use-portfolio-data';
import WebSocketManagerSingleton, { ConnectionStatus } from '@/services/WebSocketManagerSingleton';

import AccountSummaryCard from '@/components/wallet/AccountSummaryCard';
import PortfolioValueCard from '@/components/wallet/PortfolioValueCard';
import CryptoPromotionCard from '@/components/wallet/CryptoPromotionCard';
import ReferralInviteCard from '@/components/wallet/ReferralInviteCard';

// Transaction history component
const TransactionHistory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [transactionType, setTransactionType] = useState('all');
  
  // Mock transaction data
  const transactions = [
    {
      id: 1,
      type: 'deposit',
      amount: 10000,
      date: new Date(2023, 2, 15),
      status: 'completed',
      description: 'Bank Transfer Deposit'
    },
    {
      id: 2,
      type: 'withdrawal',
      amount: 5000,
      date: new Date(2023, 2, 10),
      status: 'completed',
      description: 'Bank Transfer Withdrawal'
    },
    {
      id: 3,
      type: 'purchase',
      amount: 2500,
      date: new Date(2023, 2, 5),
      status: 'completed',
      description: 'AAPL Stock Purchase'
    },
    {
      id: 4,
      type: 'sale',
      amount: 3700,
      date: new Date(2023, 1, 28),
      status: 'completed',
      description: 'MSFT Stock Sale'
    },
    {
      id: 5,
      type: 'dividend',
      amount: 150,
      date: new Date(2023, 1, 20),
      status: 'completed',
      description: 'AAPL Dividend Payment'
    }
  ];
  
  // Filter transactions based on search term and type
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = searchTerm === '' || 
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = transactionType === 'all' || transaction.type === transactionType;
    
    return matchesSearch && matchesType;
  });
  
  // Helper function to get icon and style based on transaction type
  const getTransactionMeta = (type: string) => {
    switch (type) {
      case 'deposit':
        return {
          icon: <ArrowDownRight className="h-4 w-4 text-primary" />,
          textColor: 'text-primary',
          bgColor: 'bg-primary-50'
        };
      case 'withdrawal':
        return {
          icon: <ArrowUpRight className="h-4 w-4 text-alertRed" />,
          textColor: 'text-alertRed',
          bgColor: 'bg-red-50'
        };
      case 'purchase':
        return {
          icon: <CreditCard className="h-4 w-4 text-amber-600" />,
          textColor: 'text-amber-600',
          bgColor: 'bg-amber-50'
        };
      case 'sale':
        return {
          icon: <BarChart className="h-4 w-4 text-green-600" />,
          textColor: 'text-green-600',
          bgColor: 'bg-green-50'
        };
      case 'dividend':
        return {
          icon: <Clock className="h-4 w-4 text-indigo-600" />,
          textColor: 'text-indigo-600',
          bgColor: 'bg-indigo-50'
        };
      default:
        return {
          icon: <Clock className="h-4 w-4 text-gray-500" />,
          textColor: 'text-gray-500',
          bgColor: 'bg-gray-50'
        };
    }
  };
  
  return (
    <div className="space-y-4">
      {/* Search and filter */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="w-full md:w-auto relative">
          <Search className="absolute top-2.5 left-2.5 h-4 w-4 text-gray-400" />
          <Input 
            className="pl-9 w-full" 
            placeholder="Search transactions" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <Filter className="h-4 w-4 text-gray-500" />
          <Select value={transactionType} onValueChange={setTransactionType}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Transactions</SelectItem>
              <SelectItem value="deposit">Deposits</SelectItem>
              <SelectItem value="withdrawal">Withdrawals</SelectItem>
              <SelectItem value="purchase">Purchases</SelectItem>
              <SelectItem value="sale">Sales</SelectItem>
              <SelectItem value="dividend">Dividends</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Transactions list */}
      <div className="bg-white rounded-md shadow-sm divide-y divide-gray-100">
        {filteredTransactions.length === 0 ? (
          <div className="py-6 text-center text-gray-500">
            No transactions found
          </div>
        ) : (
          filteredTransactions.map(transaction => {
            const meta = getTransactionMeta(transaction.type);
            
            return (
              <div key={transaction.id} className="p-4 flex items-center">
                <div className={`p-2 rounded-md ${meta.bgColor} mr-3`}>
                  {meta.icon}
                </div>
                
                <div className="flex-1">
                  <div className="font-medium">{transaction.description}</div>
                  <div className="text-sm text-gray-500">
                    {format(transaction.date, 'MMM d, yyyy')} • {transaction.status}
                  </div>
                </div>
                
                <div className={`font-medium ${meta.textColor}`}>
                  {transaction.type === 'deposit' || transaction.type === 'sale' || transaction.type === 'dividend'
                    ? '+'
                    : '-'}
                  ${transaction.amount.toLocaleString()}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default function WalletPage() {
  const [activeTab, setActiveTab] = useState('overview');
  const [currency, setCurrency] = useState('USD');
  const { user } = useAuth();
  const [wsStatus, setWsStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [wsError, setWsError] = useState<string | null>(null);
  
  // Use the shared portfolio data hook
  const { 
    portfolio, 
    isLoading: loadingPortfolio, 
    refetch: refetchPortfolio 
  } = usePortfolioData(user?.id);
  
  // Connect to WebSocket for real-time updates
  useEffect(() => {
    // Don't setup WebSocket if no user is provided
    if (!user?.id) return;
    
    // Use dynamic WebSocket URL based on current window location
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws`;
    
    console.log('[WalletPage] Setting up WebSocket connection to:', wsUrl);
    
    try {
      // Use the WebSocketManagerSingleton
      const manager = WebSocketManagerSingleton.getInstance();
      
      // Handle WebSocket messages for portfolio and transaction updates
      const handlePortfolioUpdate = (data: any) => {
        if (data.type === 'portfolioUpdate' && data.userId === user?.id) {
          console.log('[WalletPage] Received portfolio update, refetching data');
          refetchPortfolio();
        }
      };
      
      const handleTransactionUpdate = (data: any) => {
        if (data.type === 'transactionUpdate' && data.userId === user?.id) {
          console.log('[WalletPage] Received transaction update, refetching data');
          refetchPortfolio();
        }
      };
      
      // Subscribe to portfolio and transaction updates
      manager.subscribe(wsUrl, handlePortfolioUpdate);
      manager.subscribe(wsUrl, handleTransactionUpdate);
      
      // Update connection status
      const statusHandler = (status: ConnectionStatus) => {
        setWsStatus(status);
        if (status === ConnectionStatus.ERROR) {
          setWsError('Failed to connect to server. Please try refreshing the page.');
        } else {
          setWsError(null);
        }
      };
      
      // Subscribe to status updates
      manager.onStatusChange(statusHandler);
      
      // Connect if not already connected
      if (!manager.isConnected()) {
        manager.connect(wsUrl);
      }
      
      // Cleanup on unmount
      return () => {
        manager.unsubscribe(wsUrl, handlePortfolioUpdate);
        manager.unsubscribe(wsUrl, handleTransactionUpdate);
        manager.offStatusChange(statusHandler);
      };
    } catch (error) {
      console.error('[WalletPage] WebSocket setup error:', error);
      setWsError('Error setting up real-time updates. Some features may be limited.');
    }
  }, [user?.id, refetchPortfolio]);
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-textDark mb-6">Wallet</h1>
      
      {/* WebSocket error message */}
      {wsError && (
        <div className="rounded-md bg-red-50 p-4 mb-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
            <h3 className="text-sm font-medium text-red-800">{wsError}</h3>
          </div>
        </div>
      )}
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="payment-methods">Payment Methods</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          {/* Overview Content */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              {/* Account Summary Card */}
              {loadingPortfolio ? (
                <Card className="animate-pulse h-40" />
              ) : (
                <AccountSummaryCard 
                  availableBalance={portfolio?.availableBalance || 0} 
                  totalValue={portfolio?.totalValue || 0}
                  lastUpdated={new Date()}
                />
              )}
              
              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-4">
                <Button className="w-full py-6 flex flex-col items-center space-y-2">
                  <ArrowDownRight className="h-6 w-6 mb-1" />
                  <span>Deposit</span>
                </Button>
                <Button variant="outline" className="w-full py-6 flex flex-col items-center space-y-2">
                  <ArrowUpRight className="h-6 w-6 mb-1" />
                  <span>Withdraw</span>
                </Button>
              </div>
              
              {/* Portfolio Value Card */}
              {loadingPortfolio ? (
                <Card className="animate-pulse h-40" />
              ) : (
                <PortfolioValueCard 
                  portfolioValue={portfolio?.totalValue || 0}
                  currency={currency}
                  onCurrencyChange={setCurrency}
                />
              )}
            </div>
            
            {/* Right Sidebar */}
            <div className="space-y-6">
              <CryptoPromotionCard />
              <ReferralInviteCard />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="transactions">
          {/* Transactions Content */}
          <TransactionHistory />
        </TabsContent>
        
        <TabsContent value="payment-methods">
          {/* Payment Methods Content */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Payment Methods</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-6">
                <div className="bg-gray-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <CreditCard className="h-8 w-8 text-gray-500" />
                </div>
                <h3 className="font-medium mb-2">No payment methods yet</h3>
                <p className="text-gray-500 mb-4">Add a payment method to deposit funds into your account</p>
                <Button>
                  Add Payment Method
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}