import { useState, useEffect, useContext } from 'react';
import { useTranslation } from '../lib/useTranslation';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { AppContext } from '../context/AppContext';
import { useToast } from '@/hooks/use-toast';

interface TradingProps {
  symbol: string;
  marketData: any;
}

const TradingComponent = ({ symbol, marketData }: TradingProps) => {
  const { t } = useTranslation();
  const { appState, updateBalance } = useContext(AppContext);
  const { toast } = useToast();
  
  const [quantity, setQuantity] = useState(10);
  const [price, setPrice] = useState('0.00');
  const [orderType, setOrderType] = useState('Market Order');
  const [commission] = useState(4.99);
  
  // Update price when market data changes
  useEffect(() => {
    if (marketData && marketData.price) {
      setPrice(marketData.price);
    }
  }, [marketData]);

  // Calculate estimated cost
  const calculateCost = () => {
    return parseFloat(price) * quantity;
  };

  // Calculate total with commission
  const calculateTotal = () => {
    return calculateCost() + commission;
  };

  // Trade mutation
  const tradeMutation = useMutation({
    mutationFn: async ({ type }: { type: 'buy' | 'sell' }) => {
      if (!appState.userId) {
        throw new Error('You must be logged in to trade');
      }
      
      const tradeData = {
        userId: appState.userId,
        symbol,
        type,
        shares: quantity.toString(),
        price,
        total: calculateCost().toFixed(2),
        commission: commission.toFixed(2)
      };
      
      const response = await apiRequest('POST', '/api/trades', tradeData);
      return response.json();
    },
    onSuccess: (data) => {
      // Update user balance
      if (data && data.userId === appState.userId) {
        // Fetch new user data to get updated balance
        fetch(`/api/user/${appState.userId}`)
          .then(res => res.json())
          .then(userData => {
            updateBalance(userData.balance);
          })
          .catch(err => console.error('Failed to update balance:', err));
      }
      
      // Show success message
      toast({
        title: 'Trade successful',
        description: `${symbol} ${data.type === 'buy' ? 'purchased' : 'sold'} successfully`,
      });
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio', appState.userId] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades', appState.userId] });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Trade failed',
        description: error.message,
      });
    }
  });

  // Handle buy and sell buttons
  const handleTrade = (type: 'buy' | 'sell') => {
    if (!appState.isLoggedIn) {
      toast({
        variant: 'destructive',
        title: 'Login required',
        description: 'You must be logged in to trade',
      });
      return;
    }
    
    tradeMutation.mutate({ type });
  };

  // Handle quantity change
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  return (
    <div className="bg-white dark:bg-neutral-dark rounded-lg shadow p-4 card">
      <h2 className="text-lg font-condensed font-bold mb-3">
        {t('trade')}
      </h2>
      <div className="mb-4">
        <div className="mb-2 flex justify-between">
          <label className="text-sm font-medium">
            {t('symbol')}
          </label>
          <span className="text-xs text-neutral">
            {t('balance')}{' '}
            <span className="font-semibold">
              ${appState.balance || '0.00'}
            </span>
          </span>
        </div>
        <input 
          type="text" 
          value={symbol} 
          readOnly
          className="w-full px-3 py-2 border rounded text-sm bg-white dark:bg-neutral-dark dark:border-gray-700" 
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-sm font-medium mb-2">
            {t('quantity')}
          </label>
          <input 
            type="number" 
            value={quantity} 
            onChange={handleQuantityChange}
            min="1"
            className="w-full px-3 py-2 border rounded text-sm bg-white dark:bg-neutral-dark dark:border-gray-700" 
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">
            {t('price')}
          </label>
          <input 
            type="text" 
            value={`$${parseFloat(price).toFixed(2)}`} 
            readOnly
            className="w-full px-3 py-2 border rounded text-sm bg-white dark:bg-neutral-dark dark:border-gray-700" 
          />
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">
          {t('orderType')}
        </label>
        <select 
          className="w-full px-3 py-2 border rounded text-sm bg-white dark:bg-neutral-dark dark:border-gray-700"
          value={orderType}
          onChange={(e) => setOrderType(e.target.value)}
        >
          <option>Market Order</option>
          <option>Limit Order</option>
          <option>Stop Order</option>
          <option>Stop-Limit Order</option>
        </select>
      </div>
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        <button 
          className="w-full py-2 bg-secondary text-white font-semibold rounded-lg hover:bg-secondary-dark"
          onClick={() => handleTrade('buy')}
          disabled={tradeMutation.isPending}
        >
          {t('buy')}
        </button>
        <button 
          className="w-full py-2 bg-accent text-white font-semibold rounded-lg hover:bg-accent-dark"
          onClick={() => handleTrade('sell')}
          disabled={tradeMutation.isPending}
        >
          {t('sell')}
        </button>
      </div>
      
      <div className="text-sm text-neutral border-t pt-3">
        <div className="flex justify-between py-1">
          <span>
            {t('estimatedCost')}
          </span>
          <span className="font-semibold">${calculateCost().toFixed(2)}</span>
        </div>
        <div className="flex justify-between py-1">
          <span>
            {t('commission')}
          </span>
          <span className="font-semibold">${commission.toFixed(2)}</span>
        </div>
        <div className="flex justify-between py-1 border-t mt-1 pt-2 font-semibold">
          <span>
            {t('total')}
          </span>
          <span>${calculateTotal().toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};

export default TradingComponent;
