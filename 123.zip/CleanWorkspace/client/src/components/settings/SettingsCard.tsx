import React, { ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight } from 'lucide-react';

interface SettingsCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  iconBgColor: string;
  onClick: () => void;
  tag?: {
    text: string;
    bgColor: string;
    textColor: string;
  };
}

export default function SettingsCard({
  title,
  description,
  icon,
  iconBgColor,
  onClick,
  tag
}: SettingsCardProps) {
  return (
    <Card 
      className="shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer" 
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start">
          <div className={`${iconBgColor} p-2 rounded-md mr-3`}>
            {icon}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-textDark truncate pr-2">{title}</h3>
              
              {tag && (
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${tag.bgColor} ${tag.textColor}`}>
                  {tag.text}
                </span>
              )}
            </div>
            
            <p className="text-sm text-gray-500 mt-1 truncate">{description}</p>
          </div>
          
          <ChevronRight className="h-5 w-5 text-gray-400 ml-2 flex-shrink-0" />
        </div>
      </CardContent>
    </Card>
  );
}