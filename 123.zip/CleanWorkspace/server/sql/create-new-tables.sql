-- سكريبت SQL لإنشاء جداول نظام المكافآت والإحالات وتتبع الأنشطة
-- هذا الملف يستخدم من خلال البرنامج server/create-bonus-system.ts
-- يمكن أيضاً تنفيذه مباشرة على قاعدة البيانات من خلال أداة psql أو أي أداة إدارة PostgreSQL

-- إنشاء جدول المكافآت (bonuses)
CREATE TABLE IF NOT EXISTS bonuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id INTEGER NOT NULL REFERENCES users(id),
  amount NUMERIC(10, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  type TEXT NOT NULL, -- welcome, deposit, referral, promotion
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active', -- active, used, expired
  conditions JSONB DEFAULT '{}',
  start_date TIMESTAMP NOT NULL DEFAULT now(),
  expiry_date TIMESTAMP,
  used_amount NUMERIC(10, 2) DEFAULT 0.00,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- إنشاء جدول الأنشطة (activities)
CREATE TABLE IF NOT EXISTS activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL, -- login, trade, deposit, withdrawal, bonus_received, bonus_used, password_change, settings_update
  description TEXT NOT NULL,
  metadata JSONB DEFAULT '{}',
  ip TEXT,
  user_agent TEXT,
  timestamp TIMESTAMP NOT NULL DEFAULT now(),
  related_entity_type TEXT,
  related_entity_id TEXT
);

-- إنشاء جدول الإحالات (referrals)
CREATE TABLE IF NOT EXISTS referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id INTEGER NOT NULL REFERENCES users(id),
  referred_id INTEGER NOT NULL REFERENCES users(id),
  referral_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, completed, rewarded
  reward_id UUID REFERENCES bonuses(id),
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  completed_at TIMESTAMP
);

-- إضافة حقول جديدة إلى جدول المستخدمين (users)
ALTER TABLE users ADD COLUMN IF NOT EXISTS bonus_balance NUMERIC(10, 2) DEFAULT 0.00;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_code TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by INTEGER REFERENCES users(id);

-- إنشاء جدول المعاملات (transactions) إذا لم يكن موجودًا
CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL,
  amount NUMERIC(15, 5) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL DEFAULT 'pending',
  transaction_date TIMESTAMP NOT NULL DEFAULT NOW(),
  processed_by_admin BOOLEAN DEFAULT FALSE,
  notes TEXT,
  related_trade_id TEXT,
  bonus_amount NUMERIC(10, 2) DEFAULT '0.00',
  bonus_id UUID REFERENCES bonuses(id),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- إضافة فهارس لجدول المعاملات
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_transactions_transaction_date ON transactions(transaction_date);

-- إضافة حقول المكافآت إلى جدول الصفقات (trades)
ALTER TABLE trades ADD COLUMN IF NOT EXISTS used_bonus BOOLEAN DEFAULT FALSE;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS bonus_amount NUMERIC(10, 2) DEFAULT 0.00;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS bonus_id UUID REFERENCES bonuses(id);

-- إنشاء فهارس للتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_bonuses_user_id ON bonuses(user_id);
CREATE INDEX IF NOT EXISTS idx_bonuses_type ON bonuses(type);
CREATE INDEX IF NOT EXISTS idx_bonuses_status ON bonuses(status);
CREATE INDEX IF NOT EXISTS idx_activities_user_id ON activities(user_id);
CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(type);
CREATE INDEX IF NOT EXISTS idx_activities_timestamp ON activities(timestamp);
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_id ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred_id ON referrals(referred_id);
CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status);
CREATE INDEX IF NOT EXISTS idx_trades_bonus_id ON trades(bonus_id);
CREATE INDEX IF NOT EXISTS idx_transactions_bonus_id ON transactions(bonus_id);
CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);
CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by);

-- تعليق للمطورين
COMMENT ON TABLE bonuses IS 'جدول المكافآت والعروض الترويجية للمستخدمين';
COMMENT ON TABLE activities IS 'جدول تتبع أنشطة المستخدمين على المنصة';
COMMENT ON TABLE referrals IS 'جدول إحالات المستخدمين';
COMMENT ON COLUMN users.bonus_balance IS 'رصيد المكافآت المتاح للمستخدم';
COMMENT ON COLUMN users.referral_code IS 'رمز الإحالة الفريد للمستخدم';
COMMENT ON COLUMN users.referred_by IS 'معرف المستخدم الذي قام بإحالة هذا المستخدم';
COMMENT ON COLUMN transactions.bonus_amount IS 'مقدار المكافأة المستخدمة في المعاملة';
COMMENT ON COLUMN transactions.bonus_id IS 'معرف المكافأة المستخدمة في المعاملة';
COMMENT ON COLUMN trades.used_bonus IS 'ما إذا تم استخدام مكافأة في هذه الصفقة';
COMMENT ON COLUMN trades.bonus_amount IS 'مقدار المكافأة المستخدمة في الصفقة';
COMMENT ON COLUMN trades.bonus_id IS 'معرف المكافأة المستخدمة في الصفقة';