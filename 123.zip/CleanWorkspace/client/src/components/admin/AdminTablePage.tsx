import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useToast } from '@/hooks/use-toast';
import { useAdmin } from '../../hooks/useAdmin';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import {
  Search,
  Filter,
  MoreHorizontal,
  Download,
  Loader2,
  PlusCircle,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { format } from 'date-fns';
import KycDetailView from './KycDetailView';

type TableType = 'assets' | 'trades' | 'finances' | 'kyc';

interface AdminTablePageProps {
  tableType: TableType;
  title: string;
}

const AdminTablePage: React.FC<AdminTablePageProps> = ({ tableType, title }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { fetchData, deleteItem, exportData, loading, error } = useAdmin();

  const [data, setData] = useState<any[]>([]);
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [selectedKycId, setSelectedKycId] = useState<number | null>(null);
  const [isKycDialogOpen, setIsKycDialogOpen] = useState<boolean>(false);

  const itemsPerPage = 10;

  // Load data on component mount and when tableType changes
  useEffect(() => {
    loadData();
  }, [tableType]);

  // Filter data when search term changes
  useEffect(() => {
    filterData();
  }, [searchTerm, data]);

  const loadData = async () => {
    try {
      const result = await fetchData(tableType);
      setData(result);
      setFilteredData(result);
      setCurrentPage(1);
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.loadFailed'),
      });
    }
  };

  const filterData = () => {
    if (!searchTerm.trim()) {
      setFilteredData(data);
      return;
    }

    const term = searchTerm.toLowerCase();

    const filtered = data.filter((item) => {
      // Generic search across all fields
      return Object.values(item).some(
        (value) => 
          value !== null && 
          value !== undefined && 
          value.toString().toLowerCase().includes(term)
      );
    });

    setFilteredData(filtered);
    setCurrentPage(1);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleDelete = async (id: number | string) => {
    if (!window.confirm(t('admin.confirmDelete'))) {
      return;
    }

    try {
      await deleteItem(tableType, id);
      toast({
        title: t('admin.deleteSuccess'),
        description: t('admin.deleteSuccessDesc'),
      });
      loadData();
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.deleteFailed'),
      });
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportData(tableType);
      toast({
        title: t('admin.exportSuccess'),
        description: t('admin.exportSuccessDesc'),
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.exportFailed'),
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleKycDetailOpen = (id: number) => {
    setSelectedKycId(id);
    setIsKycDialogOpen(true);
  };

  const handleKycStatusChange = () => {
    loadData();
  };

  // Pagination
  const pageCount = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedData = filteredData.slice(startIndex, startIndex + itemsPerPage);

  const renderPagination = () => {
    if (pageCount <= 1) return null;

    return (
      <Pagination className="mt-4">
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious 
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            />
          </PaginationItem>

          {Array.from({ length: Math.min(5, pageCount) }, (_, i) => {
            let pageNum = i + 1;

            // Adjust page numbers for middle pages
            if (pageCount > 5 && currentPage > 3) {
              pageNum = Math.min(currentPage - 2 + i, pageCount);
            }

            return (
              <PaginationItem key={i}>
                {i === 0 && currentPage > 3 && pageCount > 5 ? (
                  <>
                    <PaginationLink onClick={() => setCurrentPage(1)}>1</PaginationLink>
                    <PaginationEllipsis />
                  </>
                ) : i === 4 && currentPage < pageCount - 2 && pageCount > 5 ? (
                  <>
                    <PaginationEllipsis />
                    <PaginationLink onClick={() => setCurrentPage(pageCount)}>{pageCount}</PaginationLink>
                  </>
                ) : (
                  <PaginationLink 
                    isActive={currentPage === pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                  >
                    {pageNum}
                  </PaginationLink>
                )}
              </PaginationItem>
            );
          })}

          <PaginationItem>
            <PaginationNext 
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, pageCount))}
              disabled={currentPage === pageCount}
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    );
  };

  // Render table columns based on table type
  const renderTableHeader = () => {
    switch (tableType) {
      case 'assets':
        return (
          <TableRow>
            <TableHead className="w-[100px]">{t('admin.columns.symbol')}</TableHead>
            <TableHead>{t('admin.columns.name')}</TableHead>
            <TableHead>{t('admin.columns.type')}</TableHead>
            <TableHead>{t('admin.columns.sector')}</TableHead>
            <TableHead className="text-center">{t('admin.columns.status')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.actions')}</TableHead>
          </TableRow>
        );
      case 'trades':
        return (
          <TableRow>
            <TableHead className="w-[100px]">{t('admin.columns.id')}</TableHead>
            <TableHead>{t('admin.columns.user')}</TableHead>
            <TableHead>{t('admin.columns.symbol')}</TableHead>
            <TableHead>{t('admin.columns.type')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.amount')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.price')}</TableHead>
            <TableHead>{t('admin.columns.date')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.actions')}</TableHead>
          </TableRow>
        );
      case 'finances':
        return (
          <TableRow>
            <TableHead className="w-[100px]">{t('admin.columns.id')}</TableHead>
            <TableHead>{t('admin.columns.user')}</TableHead>
            <TableHead>{t('admin.columns.type')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.amount')}</TableHead>
            <TableHead>{t('admin.columns.status')}</TableHead>
            <TableHead>{t('admin.columns.date')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.actions')}</TableHead>
          </TableRow>
        );
      case 'kyc':
        return (
          <TableRow>
            <TableHead className="w-[100px]">{t('admin.columns.id')}</TableHead>
            <TableHead>{t('admin.columns.user')}</TableHead>
            <TableHead>{t('admin.columns.email')}</TableHead>
            <TableHead>{t('admin.columns.fullName')}</TableHead>
            <TableHead>{t('admin.columns.status')}</TableHead>
            <TableHead>{t('admin.columns.submittedAt')}</TableHead>
            <TableHead className="text-right">{t('admin.columns.actions')}</TableHead>
          </TableRow>
        );
      default:
        return null;
    }
  };

  // Render table rows based on table type
  const renderTableRows = () => {
    if (loading) {
      return (
        <TableRow>
          <TableCell colSpan={8} className="text-center py-10">
            <div className="flex flex-col items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
              <p>{t('admin.loading')}</p>
            </div>
          </TableCell>
        </TableRow>
      );
    }

    if (paginatedData.length === 0) {
      return (
        <TableRow>
          <TableCell colSpan={8} className="text-center py-10">
            <p className="text-muted-foreground">{t('admin.noDataFound')}</p>
          </TableCell>
        </TableRow>
      );
    }

    switch (tableType) {
      case 'assets':
        return Array.isArray(paginatedData) ? paginatedData.map((asset) => (
          <TableRow key={asset.id}>
            <TableCell className="font-medium">{asset.symbol}</TableCell>
            <TableCell>{asset.name}</TableCell>
            <TableCell>{asset.type}</TableCell>
            <TableCell>{asset.sector || '-'}</TableCell>
            <TableCell className="text-center">
              {asset.isActive ? (
                <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-200">
                  {t('admin.active')}
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-200">
                  {t('admin.inactive')}
                </Badge>
              )}
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">{t('admin.openMenu')}</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>{t('admin.actions')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Edit className="h-4 w-4 mr-2" />
                    {t('admin.edit')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(asset.id)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    {t('admin.delete')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        )) : <tr><td colSpan={6}>No data available</td></tr>;
      case 'trades':
        return Array.isArray(paginatedData) ? paginatedData.map((trade) => (
          <TableRow key={trade.id}>
            <TableCell className="font-medium">#{trade.id}</TableCell>
            <TableCell>{trade.username || trade.userId}</TableCell>
            <TableCell>{trade.symbol}</TableCell>
            <TableCell>
              <Badge variant={trade.type === 'buy' ? 'default' : 'destructive'}>
                {trade.type.toUpperCase()}
              </Badge>
            </TableCell>
            <TableCell className="text-right">{trade.shares}</TableCell>
            <TableCell className="text-right">${trade.price}</TableCell>
            <TableCell>
              {trade.tradeDate ? format(new Date(trade.tradeDate), 'PPp') : '-'}
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">{t('admin.openMenu')}</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>{t('admin.actions')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Edit className="h-4 w-4 mr-2" />
                    {t('admin.details')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(trade.id)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    {t('admin.delete')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        )) : <tr><td colSpan={8}>No data available</td></tr>;
      case 'finances':
        return Array.isArray(paginatedData) ? paginatedData.map((transaction) => (
          <TableRow key={transaction.id}>
            <TableCell className="font-medium">#{transaction.id}</TableCell>
            <TableCell>{transaction.username || transaction.userId}</TableCell>
            <TableCell>
              <Badge variant={
                transaction.type === 'deposit' 
                ? 'default' 
                : transaction.type === 'withdrawal' 
                ? 'destructive' 
                : 'outline'
              }>
                {transaction.type}
              </Badge>
            </TableCell>
            <TableCell className="text-right">
              ${transaction.amount}
            </TableCell>
            <TableCell>
              {transaction.status === 'completed' ? (
                <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-200">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  {t('admin.completed')}
                </Badge>
              ) : transaction.status === 'pending' ? (
                <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  {t('admin.pending')}
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  {t('admin.failed')}
                </Badge>
              )}
            </TableCell>
            <TableCell>
              {transaction.transactionDate ? format(new Date(transaction.transactionDate), 'PPp') : '-'}
            </TableCell>
            <TableCell className="text-right">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">{t('admin.openMenu')}</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>{t('admin.actions')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Edit className="h-4 w-4 mr-2" />
                    {t('admin.details')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(transaction.id)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    {t('admin.delete')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        )) : <tr><td colSpan={7}>No data available</td></tr>;
      case 'kyc':
        return Array.isArray(paginatedData) ? paginatedData.map((request) => (
          <TableRow key={request.id}>
            <TableCell className="font-medium">#{request.id}</TableCell>
            <TableCell>{request.username}</TableCell>
            <TableCell>{request.email}</TableCell>
            <TableCell>{request.fullName}</TableCell>
            <TableCell>
              {request.status === 'verified' ? (
                <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-200">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  {t('admin.verified')}
                </Badge>
              ) : request.status === 'rejected' ? (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  {t('admin.rejected')}
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  {t('admin.pending')}
                </Badge>
              )}
            </TableCell>
            <TableCell>
              {request.submittedAt ? format(new Date(request.submittedAt), 'PP') : '-'}
            </TableCell>
            <TableCell className="text-right">
              <Dialog open={isKycDialogOpen && selectedKycId === request.id} onOpenChange={setIsKycDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" onClick={() => handleKycDetailOpen(request.id)}>
                    <FileText className="h-4 w-4 mr-2" />
                    {t('admin.view')}
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <KycDetailView 
                    requestId={request.id} 
                    onClose={() => setIsKycDialogOpen(false)}
                    onStatusChange={handleKycStatusChange}
                  />
                </DialogContent>
              </Dialog>
            </TableCell>
          </TableRow>
        )) : <tr><td colSpan={7}>No data available</td></tr>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{title}</h2>
          <p className="text-muted-foreground">
            {t('admin.manageDesc', { type: tableType })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={handleExport} disabled={isExporting || loading}>
            {isExporting ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            {t('admin.export')}
          </Button>
          {tableType !== 'kyc' && (
            <Button>
              <PlusCircle className="h-4 w-4 mr-2" />
              {t('admin.addNew')}
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>{title}</CardTitle>
            <div className="flex w-full max-w-sm items-center space-x-2">
              <Input
                placeholder={t('admin.search')}
                value={searchTerm}
                onChange={handleSearch}
                className="max-w-[250px]"
              />
              <Button size="sm" variant="outline">
                <Search className="h-4 w-4 mr-2" />
                {t('admin.search')}
              </Button>
              <Button size="sm" variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                {t('admin.filter')}
              </Button>
            </div>
          </div>
          <CardDescription>
            {t('admin.totalItems', { count: filteredData.length })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              {renderTableHeader()}
            </TableHeader>
            <TableBody>
              {renderTableRows()}
            </TableBody>
          </Table>
          {renderPagination()}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminTablePage;