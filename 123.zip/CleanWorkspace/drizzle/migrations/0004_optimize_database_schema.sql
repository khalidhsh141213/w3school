/*
 * Database Schema Optimization Migration
 * Improves database performance and data integrity:
 * - Adds strategic indexes for common query patterns
 * - Enforces data integrity constraints
 * - Implements denormalization for performance
 * - Adds triggers for data synchronization
 * 
 * Dependencies:
 * - All previous migrations (0000-0003)
 * - Requires careful testing of triggers
 */

-- Database Schema Optimization Migration

-- 1. Add missing indexes for frequently queried columns
-- Add index for trades filtered by user and status (common query pattern)
CREATE INDEX IF NOT EXISTS trades_userid_status_idx ON trades(user_id, status);

-- Add index for asset type filtering
CREATE INDEX IF NOT EXISTS assets_assettype_idx ON assets(asset_type);

-- Add index for transactions by user and status
CREATE INDEX IF NOT EXISTS transactions_userid_status_idx ON transactions(user_id, status);

-- 2. Enforce one-to-one relationship between users and settings
-- Add unique constraint for user settings if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'unique_user_settings'
    ) THEN
        ALTER TABLE user_settings ADD CONSTRAINT unique_user_settings UNIQUE (user_id);
    END IF;
END $$;

-- 3. Denormalize for performance - add asset info to trades table
-- Add columns to trades table for frequently joined fields
ALTER TABLE trades ADD COLUMN IF NOT EXISTS asset_symbol TEXT;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS asset_type asset_type;

-- Update existing data with asset information
UPDATE trades t
SET 
  asset_symbol = a.symbol,
  asset_type = a.asset_type
FROM assets a
WHERE t.asset_id = a.id;

-- 4. Create a trigger to keep denormalized data in sync
CREATE OR REPLACE FUNCTION update_trade_asset_data()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    SELECT symbol, asset_type INTO NEW.asset_symbol, NEW.asset_type
    FROM assets
    WHERE id = NEW.asset_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for keeping asset data in sync on trades table
DROP TRIGGER IF EXISTS trades_asset_data_trigger ON trades;
CREATE TRIGGER trades_asset_data_trigger
BEFORE INSERT OR UPDATE ON trades
FOR EACH ROW
EXECUTE FUNCTION update_trade_asset_data();

-- 5. Create a trigger to update asset data in trades when asset changes
CREATE OR REPLACE FUNCTION sync_trades_on_asset_update()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF NEW.symbol != OLD.symbol OR NEW.asset_type != OLD.asset_type THEN
      UPDATE trades
      SET asset_symbol = NEW.symbol, asset_type = NEW.asset_type
      WHERE asset_id = NEW.id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating trades when asset changes
DROP TRIGGER IF EXISTS sync_trades_on_asset_update_trigger ON assets;
CREATE TRIGGER sync_trades_on_asset_update_trigger
AFTER UPDATE ON assets
FOR EACH ROW
EXECUTE FUNCTION sync_trades_on_asset_update(); 