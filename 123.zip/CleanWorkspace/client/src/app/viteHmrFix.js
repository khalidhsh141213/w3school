/**
 * Vite HMR Fix for Replit Environment
 * 
 * This script patches Vite's HMR WebSocket connection to work properly in the Replit environment.
 * It fixes the "Failed to construct 'WebSocket': The URL 'wss://localhost:undefined/?token=...' is invalid." error.
 */

// Run this immediately when the script is imported
(function fixViteHmrWebSocket() {
  // Only run in development mode
  if (import.meta.env.PROD) return;

  console.log('[ViteHMR] Applying WebSocket fix for Replit environment');

  // Store the original WebSocket constructor
  const OriginalWebSocket = window.WebSocket;

  // Create a proxy to intercept WebSocket construction
  window.WebSocket = function(url, protocols) {
    // Check if it's a Vite HMR WebSocket connection (contains 'localhost:undefined')
    if (url && typeof url === 'string' && url.includes('localhost:undefined')) {
      // Extract the token from the original URL
      const token = new URL(url).searchParams.get('token');
      
      // Construct a valid WebSocket URL using the current origin but with WebSocket protocol
      const newUrl = new URL(window.location.href);
      newUrl.protocol = newUrl.protocol === 'https:' ? 'wss:' : 'ws:';
      newUrl.pathname = '/';
      if (token) {
        newUrl.searchParams.set('token', token);
      }
      
      console.log(`[ViteHMR] Fixing WebSocket URL: ${url} → ${newUrl.toString()}`);
      
      // Use the fixed URL instead
      return new OriginalWebSocket(newUrl.toString(), protocols);
    }
    
    // For non-Vite WebSockets, use the original constructor
    return new OriginalWebSocket(url, protocols);
  };

  // Ensure all prototype properties and methods are properly inherited
  window.WebSocket.prototype = OriginalWebSocket.prototype;
  window.WebSocket.CONNECTING = OriginalWebSocket.CONNECTING;
  window.WebSocket.OPEN = OriginalWebSocket.OPEN;
  window.WebSocket.CLOSING = OriginalWebSocket.CLOSING;
  window.WebSocket.CLOSED = OriginalWebSocket.CLOSED;
})();

export default {};