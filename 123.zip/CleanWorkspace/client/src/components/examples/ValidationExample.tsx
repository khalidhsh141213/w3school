import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { 
  validateApiResponse, 
  object, 
  string, 
  number, 
  array, 
  optional,
  ValidationError,
  marketDataValidator
} from '../../lib/validation';
import { MarketData } from '../../types';

interface ValidationExampleProps {
  symbol: string;
}

const ValidationExample: React.FC<ValidationExampleProps> = ({ symbol }) => {
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [validationPath, setValidationPath] = useState<string | null>(null);

  useEffect(() => {
    const fetchMarketData = async () => {
      setIsLoading(true);
      setError(null);
      setValidationPath(null);
      
      try {
        // Example of how to use validateApiResponse with the API client
        const response = await api.market.getLatestPrice(symbol);
        
        // Using validation utilities to validate the response
        const validatedData = validateApiResponse(
          response,
          marketDataValidator,
          (validationError: ValidationError) => {
            console.error('Validation error:', validationError);
            setValidationPath(validationError.path);
            setError(`Data validation failed at: ${validationError.path}. Expected ${validationError.expected}, got ${JSON.stringify(validationError.received)}`);
          }
        );
        
        if (validatedData) {
          setMarketData(validatedData);
        }
      } catch (err) {
        if (err instanceof Error) {
          setError(`Failed to fetch market data: ${err.message}`);
        } else {
          setError('An unknown error occurred');
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchMarketData();
    
    // Refresh data every 30 seconds
    const intervalId = setInterval(fetchMarketData, 30000);
    
    return () => {
      clearInterval(intervalId);
    };
  }, [symbol]);

  // Example of manually validating data (for demonstration purposes)
  const validateManualData = () => {
    try {
      // Creating a custom validator
      const customValidator = object({
        name: string,
        price: number,
        tags: array(string),
        description: optional(string)
      });

      // Valid data example
      const validData = {
        name: 'Bitcoin',
        price: 50000,
        tags: ['crypto', 'digital asset'],
        description: 'Digital currency'
      };

      const result1 = customValidator(validData);
      console.log('Valid data passed validation:', result1);

      // Invalid data example
      const invalidData = {
        name: 'Ethereum',
        price: '45000', // Invalid - should be number
        tags: ['crypto', 123], // Invalid - should be string[]
        description: true // Invalid - should be string or undefined
      };

      try {
        const result2 = customValidator(invalidData);
        console.log('This should not be reached', result2);
      } catch (validationError) {
        if (validationError instanceof ValidationError) {
          setValidationPath(validationError.path);
          setError(`Manual validation failed at: ${validationError.path}. Expected ${validationError.expected}, got ${JSON.stringify(validationError.received)}`);
        }
      }
    } catch (err) {
      if (err instanceof Error) {
        setError(`Validation example error: ${err.message}`);
      }
    }
  };

  const resetDemo = () => {
    setError(null);
    setValidationPath(null);
  };

  return (
    <div className="validation-example p-4 border rounded shadow-sm">
      <h2 className="text-xl font-bold mb-4">Validation Example: {symbol}</h2>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      ) : error ? (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
          <p>{error}</p>
          {validationPath && (
            <p className="mt-2 text-sm">
              <strong>Validation failed at path:</strong> {validationPath}
            </p>
          )}
          <button 
            onClick={resetDemo} 
            className="mt-2 bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded text-sm"
          >
            Reset Demo
          </button>
        </div>
      ) : marketData ? (
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-100 p-2 rounded">Symbol:</div>
            <div>{marketData.symbol}</div>
            
            <div className="bg-gray-100 p-2 rounded">Price:</div>
            <div>${marketData.price.toLocaleString()}</div>
            
            <div className="bg-gray-100 p-2 rounded">Change:</div>
            <div className={marketData.changePercent >= 0 ? 'text-green-600' : 'text-red-600'}>
              {marketData.changePercent >= 0 ? '+' : ''}{marketData.changePercent.toFixed(2)}%
            </div>
            
            <div className="bg-gray-100 p-2 rounded">Volume:</div>
            <div>{marketData.volume.toLocaleString()}</div>
            
            <div className="bg-gray-100 p-2 rounded">Time:</div>
            <div>{new Date(marketData.timestamp).toLocaleString()}</div>
          </div>
          
          <div className="mt-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4">
            <p>✅ API response successfully validated</p>
          </div>
        </div>
      ) : (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
          <p>No data available</p>
        </div>
      )}
      
      <div className="mt-6 space-y-4">
        <h3 className="font-semibold">Demonstration Tools</h3>
        <div className="flex space-x-2">
          <button
            onClick={validateManualData}
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
          >
            Run Manual Validation Demo
          </button>
          <button
            onClick={resetDemo}
            className="bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded"
          >
            Reset Demo
          </button>
        </div>
        <div className="bg-gray-100 p-4 rounded text-sm">
          <p className="font-medium">About this component:</p>
          <ul className="list-disc pl-5 mt-1 space-y-1">
            <li>Demonstrates real API data validation using our validation utilities</li>
            <li>Includes examples of handling validation errors</li>
            <li>Shows how to create custom validators for different data structures</li>
            <li>Click "Run Manual Validation Demo" to see validation of an intentionally invalid object</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ValidationExample; 