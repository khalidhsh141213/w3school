import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
interface QueryFnOptions {
  on401: UnauthorizedBehavior;
  urlTransform?: (url: string) => string;
}

export const getQueryFn: <T>(options: QueryFnOptions) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior, urlTransform }) =>
  async ({ queryKey }) => {
    // Use the base URL from queryKey[0]
    let url = queryKey[0] as string;
    
    // If there are additional query parameters in the queryKey, add them to the URL
    // Typically, the first element is the base URL, and subsequent elements are parameters
    if (queryKey.length > 1 && typeof queryKey[1] === 'string' || typeof queryKey[1] === 'number') {
      // Check if URL already has query parameters
      const hasParams = url.includes('?');
      
      // Assume the second item in queryKey is the userId
      // This is a common pattern in our app for endpoints that need userId
      url = `${url}${hasParams ? '&' : '?'}userId=${queryKey[1]}`;
    }
    
    // Apply URL transformation if provided (for more complex transformations)
    if (urlTransform && typeof urlTransform === 'function') {
      url = urlTransform(url);
    }
    
    const res = await fetch(url, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
