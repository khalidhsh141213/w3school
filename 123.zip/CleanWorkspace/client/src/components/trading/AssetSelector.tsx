"use client";

import { useState, useEffect } from "react";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  ArrowUp, 
  ArrowDown, 
  Search,
  DollarSign, 
  Percent,
  TrendingUp
} from "lucide-react";
import { Asset } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { assetTypeEnum } from "@shared/schema";

type AssetSelectorProps = {
  assets: Asset[];
  selectedAsset: Asset | null;
  onAssetChange: (asset: Asset) => void;
  marketData: Record<string, any>;
};

export default function AssetSelector({ 
  assets, 
  selectedAsset, 
  onAssetChange,
  marketData
}: AssetSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredAssets, setFilteredAssets] = useState<Asset[]>(assets);
  const [filter, setFilter] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(false);

  // Filter assets when search or filter changes
  useEffect(() => {
    setIsLoading(true);
    
    let result = assets;

    // Filter by type if not "all"
    if (filter !== "all") {
      result = result.filter(asset => asset.assetType === filter);
    }

    // Filter by search query
    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      result = result.filter(asset => 
        asset.symbol.toLowerCase().includes(lowerQuery) || 
        asset.name.toLowerCase().includes(lowerQuery)
      );
    }

    setFilteredAssets(result);
    setIsLoading(false);
  }, [assets, searchQuery, filter]);

  // Get the current price data for the selected asset
  const getAssetPriceData = (symbol: string) => {
    // If there's market data for this symbol
    if (marketData && marketData[symbol]) {
      return marketData[symbol];
    }
    
    // Default values if we don't have data yet
    return null;
  };
  
  // Use an effect to update the UI when market data changes
  useEffect(() => {
    // Force a re-render when new market data arrives
    if (marketData && Object.keys(marketData).length > 0) {
      // Just updating the state will trigger a re-render
      setFilteredAssets(prev => [...prev]);
    }
  }, [marketData]);

  // Get badge color based on asset type
  const getAssetTypeBadgeColor = (type: string) => {
    switch (type) {
      case "crypto":
        return "bg-[#FFB347]/10 text-[#FF9800] border-[#FFB347]/30";
      case "forex":
        return "bg-[#2A5CFF]/10 text-[#2A5CFF] border-[#2A5CFF]/30";
      case "stock":
        return "bg-[#00C06D]/10 text-[#00C06D] border-[#00C06D]/30";
      case "commodity":
        return "bg-[#FFC107]/10 text-[#FFC107] border-[#FFC107]/30";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  // Get asset icon based on asset type
  const getAssetTypeIcon = (type: string) => {
    switch (type) {
      case "crypto":
        return <div className="w-7 h-7 rounded-md bg-[#FF9800]/10 text-[#FF9800] flex items-center justify-center">
          <span className="text-xs font-bold">₿</span>
        </div>;
      case "forex":
        return <div className="w-7 h-7 rounded-md bg-[#2A5CFF]/10 text-[#2A5CFF] flex items-center justify-center">
          <DollarSign className="h-3.5 w-3.5" />
        </div>;
      case "stock":
        return <div className="w-7 h-7 rounded-md bg-[#00C06D]/10 text-[#00C06D] flex items-center justify-center">
          <TrendingUp className="h-3.5 w-3.5" />
        </div>;
      case "commodity":
        return <div className="w-7 h-7 rounded-md bg-[#FFC107]/10 text-[#FFC107] flex items-center justify-center">
          <span className="text-xs font-bold">Au</span>
        </div>;
      default:
        return <div className="w-7 h-7 rounded-md bg-gray-100 text-gray-800 flex items-center justify-center">
          <span className="text-xs font-bold">?</span>
        </div>;
    }
  };

  return (
    <div className="w-full">
      <div className="mb-4 space-y-3">
        <div className="flex gap-2">
          <Select 
            value={filter} 
            onValueChange={setFilter}
          >
            <SelectTrigger className="w-full md:w-[140px] border-[#1E2128]/50 bg-[#1E2128]/10">
              <SelectValue placeholder="Asset Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectLabel>Asset Types</SelectLabel>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="forex">Forex</SelectItem>
                <SelectItem value="crypto">Crypto</SelectItem>
                <SelectItem value="stock">Stocks</SelectItem>
                <SelectItem value="commodity">Commodities</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
        
        <div className="relative w-full">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search assets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 w-full border-[#1E2128]/50 bg-[#1E2128]/10"
          />
        </div>
      </div>

      <div className="bg-gradient-to-r from-[#1E2128]/40 to-[#2A2E39]/20 rounded-lg border border-[#1E2128]/30 shadow-md overflow-hidden">
        <div className="p-2.5 bg-[#1E2128]/40 border-b border-[#1E2128]/50 flex justify-between items-center text-sm font-medium text-muted-foreground">
          <span className="text-gray-400 text-xs uppercase tracking-wider">Asset</span>
          <span className="text-gray-400 text-xs uppercase tracking-wider">Price</span>
        </div>
        
        {isLoading ? (
          <div className="p-6 flex justify-center items-center">
            <div className="animate-spin w-5 h-5 border-2 border-[#00C06D] border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className="max-h-[320px] overflow-y-auto custom-scrollbar">
            {filteredAssets.length > 0 ? (
              <div className="divide-y divide-[#1E2128]/30">
                {filteredAssets.map((asset) => {
                  const priceData = getAssetPriceData(asset.symbol);
                  const isSelected = selectedAsset?.id === asset.id;
                  
                  return (
                    <button
                      key={asset.id}
                      className={`w-full p-3 flex justify-between items-center transition-all duration-200 ${
                        isSelected 
                          ? "bg-gradient-to-r from-[#00C06D]/5 to-[#2A5CFF]/5 border-l-[3px] border-l-[#00C06D]" 
                          : "hover:bg-[#1E2128]/20 border-l-[3px] border-transparent"
                      }`}
                      onClick={() => onAssetChange(asset)}
                    >
                      <div className="flex items-center">
                        {getAssetTypeIcon(asset.assetType)}
                        <div className="ml-3 text-left">
                          <div className="flex items-center gap-2">
                            <span className={`font-medium ${isSelected ? 'text-[#00C06D]' : ''}`}>
                              {asset.symbol}
                            </span>
                            <Badge 
                              className={`text-[10px] px-1.5 py-0 h-4 ${getAssetTypeBadgeColor(asset.assetType)}`}
                              variant="outline"
                            >
                              {asset.assetType}
                            </Badge>
                          </div>
                          <span className="text-xs text-gray-400 mt-0.5 block truncate max-w-[120px]">
                            {asset.name}
                          </span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        {priceData ? (
                          <>
                            <div className="font-mono font-medium">
                              ${Number(priceData.price).toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                              })}
                            </div>
                            <div className={`text-xs flex items-center justify-end mt-1 ${
                              priceData.change >= 0 
                                ? "text-[#00C06D]" 
                                : "text-red-500"
                            }`}>
                              {priceData.change >= 0 ? (
                                <ArrowUp className="h-3 w-3 mr-1" />
                              ) : (
                                <ArrowDown className="h-3 w-3 mr-1" />
                              )}
                              <span>{Math.abs(priceData.changePercent).toFixed(2)}%</span>
                            </div>
                          </>
                        ) : (
                          <div className="flex flex-col items-end">
                            <div className="h-4 w-16 bg-[#1E2128]/50 animate-pulse rounded" />
                            <div className="h-3 w-12 bg-[#1E2128]/40 animate-pulse rounded mt-1" />
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center">
                <div className="text-muted-foreground mb-2">No assets found</div>
                <p className="text-xs text-muted-foreground">
                  Try adjusting your filters or search criteria
                </p>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Selected Asset Info */}
      {selectedAsset && (
        <div className="mt-4 p-3 bg-gradient-to-r from-[#1E2128]/40 to-[#2A2E39]/20 rounded-lg border border-[#1E2128]/30 shadow-sm">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              {getAssetTypeIcon(selectedAsset.assetType)}
              <div className="ml-3">
                <div className="font-medium">{selectedAsset.name}</div>
                <div className="text-xs text-gray-400">{selectedAsset.symbol}</div>
              </div>
            </div>
            <Badge className={`${getAssetTypeBadgeColor(selectedAsset.assetType)} shadow-sm`}>
              {selectedAsset.assetType}
            </Badge>
          </div>
        </div>
      )}
      
      {/* Custom scrollbar styles */}
      <style dangerouslySetInnerHTML={{
        __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: rgba(155, 155, 155, 0.5);
          border-radius: 20px;
        }
        `
      }} />
    </div>
  );
}