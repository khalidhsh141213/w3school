import React, { useEffect, useState } from 'react';
import { ConnectionStatus, useWebSocket } from '../../services/WebSocketManager';
import { formatDateTime } from '../../utils/formatters';

interface Message {
  id: string;
  type: string;
  data: any;
  timestamp: Date;
  priority?: 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';
}

/**
 * WebSocket Example Component
 * 
 * Demonstrates the features of our WebSocketManager
 */
const WebSocketExample: React.FC = () => {
  // State
  const [symbol, setSymbol] = useState<string>('AAPL');
  const [messages, setMessages] = useState<Message[]>([]);
  const [priority, setPriority] = useState<'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW'>('NORMAL');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [isFilterActive, setIsFilterActive] = useState<boolean>(false);
  const [filterType, setFilterType] = useState<string>('');
  
  // Setup WebSocket connection using our hook
  const { 
    connectionStatus, 
    circuitBreakerStatus,
    subscribe, 
    unsubscribe, 
    sendMessage,
    reconnect
  } = useWebSocket({
    url: getWebSocketUrl(),
    onMessage: handleWebSocketMessage,
    reconnectOptions: {
      autoReconnect: true,
      maxReconnectAttempts: 5,
      reconnectInterval: 1000
    },
    heartbeatOptions: {
      enabled: true,
      interval: 30000,
      message: { type: 'ping' }
    }
  });
  
  // Construct WebSocket URL based on the environment
  function getWebSocketUrl(): string {
    const host = window.location.host;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${host}/ws`;
  }
  
  // Handle incoming WebSocket messages
  function handleWebSocketMessage(event: MessageEvent) {
    try {
      const data = JSON.parse(event.data);
      const message: Message = {
        id: Math.random().toString(36).substring(2, 9),
        type: data.type || 'unknown',
        data: data,
        timestamp: new Date()
      };
      
      setMessages(prev => [message, ...prev].slice(0, 50));  // Keep last 50 messages
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  }
  
  // Subscribe to ticker when symbol changes
  useEffect(() => {
    if (connectionStatus === ConnectionStatus.OPEN) {
      // First unsubscribe from any existing subscription
      unsubscribe({ type: 'unsubscribe', symbols: [symbol] });
      
      // Then subscribe to the new symbol
      subscribe(
        { type: 'subscribe', symbols: [symbol] },
        { priority: 'HIGH' }  // Set priority for subscription messages
      );
    }
  }, [symbol, connectionStatus, subscribe, unsubscribe]);
  
  // Handle symbol change
  const handleSymbolChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSymbol(event.target.value);
  };
  
  // Handle sending a custom message
  const handleSendMessage = () => {
    if (!customMessage.trim()) return;
    
    try {
      const messageObj = JSON.parse(customMessage);
      sendMessage(messageObj, { priority: priority });
      setCustomMessage('');
    } catch (error) {
      alert('Invalid JSON message. Please check the format.');
    }
  };
  
  // Handle message filtering
  const handleFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFilterType(event.target.value);
    setIsFilterActive(!!event.target.value);
  };
  
  // Filter messages based on type
  const filteredMessages = isFilterActive
    ? messages.filter(msg => msg.type.includes(filterType))
    : messages;
  
  // Determine connection status text and color
  const getConnectionStatusInfo = () => {
    switch (connectionStatus) {
      case ConnectionStatus.CONNECTING:
        return { text: 'Connecting...', color: '#f0ad4e' };
      case ConnectionStatus.OPEN:
        return { text: 'Connected', color: '#5cb85c' };
      case ConnectionStatus.CLOSING:
        return { text: 'Closing...', color: '#f0ad4e' };
      case ConnectionStatus.CLOSED:
        return { text: 'Disconnected', color: '#d9534f' };
      case ConnectionStatus.CIRCUIT_OPEN:
        return { text: 'Circuit Open', color: '#d9534f' };
      default:
        return { text: 'Unknown', color: '#6c757d' };
    }
  };
  
  const connectionStatusInfo = getConnectionStatusInfo();
  
  return (
    <div className="websocket-example">
      <div className="example-header">
        <h2>WebSocket Example</h2>
        <p className="description">
          This example demonstrates our WebSocketManager's features
          including connection management, circuit breaker, and message prioritization.
        </p>
      </div>
      
      <div className="ws-status-section">
        <div className="status-header">
          <h3>Connection Status</h3>
          <div 
            className="connection-indicator" 
            style={{ backgroundColor: connectionStatusInfo.color }}
          >
            {connectionStatusInfo.text}
          </div>
        </div>
        
        <div className="circuit-status">
          <span className="label">Circuit Breaker:</span>
          <span className={`value ${circuitBreakerStatus.toLowerCase()}`}>
            {circuitBreakerStatus}
          </span>
          {circuitBreakerStatus !== 'CLOSED' && (
            <button className="reset-button" onClick={reconnect}>
              Reset Circuit
            </button>
          )}
        </div>
        
        <div className="connection-actions">
          <button 
            className="reconnect-button"
            onClick={reconnect}
            disabled={connectionStatus === ConnectionStatus.OPEN}
          >
            Reconnect
          </button>
        </div>
      </div>
      
      <div className="subscription-section">
        <h3>Subscribe to Symbol</h3>
        <div className="subscription-controls">
          <label htmlFor="symbol-select">Symbol:</label>
          <select 
            id="symbol-select" 
            value={symbol} 
            onChange={handleSymbolChange}
            disabled={connectionStatus !== ConnectionStatus.OPEN}
          >
            <option value="AAPL">Apple (AAPL)</option>
            <option value="MSFT">Microsoft (MSFT)</option>
            <option value="GOOGL">Google (GOOGL)</option>
            <option value="AMZN">Amazon (AMZN)</option>
            <option value="TSLA">Tesla (TSLA)</option>
          </select>
        </div>
      </div>
      
      <div className="custom-message-section">
        <h3>Send Custom Message</h3>
        <div className="message-form">
          <div className="message-textarea-container">
            <textarea
              placeholder="Enter JSON message..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              disabled={connectionStatus !== ConnectionStatus.OPEN}
            />
          </div>
          
          <div className="message-controls">
            <div className="priority-control">
              <label htmlFor="priority-select">Priority:</label>
              <select 
                id="priority-select" 
                value={priority} 
                onChange={(e) => setPriority(e.target.value as any)}
                disabled={connectionStatus !== ConnectionStatus.OPEN}
              >
                <option value="CRITICAL">Critical</option>
                <option value="HIGH">High</option>
                <option value="NORMAL">Normal</option>
                <option value="LOW">Low</option>
              </select>
            </div>
            
            <button 
              className="send-button"
              onClick={handleSendMessage}
              disabled={connectionStatus !== ConnectionStatus.OPEN || !customMessage.trim()}
            >
              Send Message
            </button>
          </div>
        </div>
        
        <div className="example-messages">
          <h4>Example Messages:</h4>
          <div className="example-buttons">
            <button 
              onClick={() => setCustomMessage(JSON.stringify({ 
                type: 'subscribe', 
                symbols: [symbol] 
              }, null, 2))}
              disabled={connectionStatus !== ConnectionStatus.OPEN}
            >
              Subscribe
            </button>
            <button 
              onClick={() => setCustomMessage(JSON.stringify({ 
                type: 'unsubscribe', 
                symbols: [symbol] 
              }, null, 2))}
              disabled={connectionStatus !== ConnectionStatus.OPEN}
            >
              Unsubscribe
            </button>
            <button 
              onClick={() => setCustomMessage(JSON.stringify({ 
                type: 'ping'
              }, null, 2))}
              disabled={connectionStatus !== ConnectionStatus.OPEN}
            >
              Ping
            </button>
          </div>
        </div>
      </div>
      
      <div className="messages-section">
        <div className="messages-header">
          <h3>Received Messages</h3>
          <div className="message-filter">
            <label htmlFor="filter-input">Filter by type:</label>
            <input 
              id="filter-input"
              type="text" 
              placeholder="Filter messages..."
              value={filterType}
              onChange={handleFilterChange}
            />
          </div>
        </div>
        
        <div className="messages-list">
          {filteredMessages.length === 0 ? (
            <div className="empty-state">No messages received yet</div>
          ) : (
            filteredMessages.map(message => (
              <div key={message.id} className={`message-item ${message.type}`}>
                <div className="message-header">
                  <span className="message-type">{message.type}</span>
                  <span className="message-time">{formatDateTime(message.timestamp)}</span>
                </div>
                <pre className="message-content">
                  {JSON.stringify(message.data, null, 2)}
                </pre>
              </div>
            ))
          )}
        </div>
      </div>
      
      <div className="example-features">
        <h3>Implementation Features</h3>
        <ul>
          <li>
            <strong>Connection Management:</strong> Automatic connection handling with 
            reconnection logic and connection status tracking.
          </li>
          <li>
            <strong>Circuit Breaker Pattern:</strong> Prevents repeated reconnection attempts
            when the connection is failing persistently.
          </li>
          <li>
            <strong>Message Prioritization:</strong> Important messages like subscriptions
            are processed first during rate limiting.
          </li>
          <li>
            <strong>Message Queue:</strong> Ensures messages are properly queued and
            processed efficiently even during high traffic.
          </li>
          <li>
            <strong>Heartbeat Mechanism:</strong> Automatically sends ping messages to
            keep the connection alive.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default WebSocketExample; 