import { db } from '../db.js';
import { WebSocket } from 'ws';
import { marketDataCache } from '../cache.js';
import { errorHandler, ErrorType, ErrorSeverity } from './errorHandlingService.js';
import { log } from '../vite.js';
import { 
  getUpcomingEvents, 
  getEventsForPortfolio, 
  findMarketMovementAroundEvent,
  findSignificantEventsForAsset 
} from './economicEventService.js';
import { economicEvents, portfolio } from '../../shared/schema.js';
import { eq, desc, sql } from 'drizzle-orm';

// Cache key for notification data
const NOTIFICATION_CACHE_KEY = 'notifications';

// Cache duration (1 hour)
const NOTIFICATION_CACHE_TTL = 60 * 60 * 1000;

// Declare notification intervals

// Configuration for notification deduplication
const DEDUPLICATION_TTL = 12 * 60 * 60 * 1000; // 12 hours - how long to prevent duplicates

// Configuration for economic event notifications
const CONFIG = {
  // How many days in advance to notify users of upcoming events
  advanceNotificationDays: 3,
  // Minimum percent change to consider significant for historical correlation
  significantPercentChange: 1.5,
  // How often to check for market movement correlations (in ms)
  correlationCheckInterval: 12 * 60 * 60 * 1000, // 12 hours
  // Threshold for volatility to consider noteworthy (standard deviation)
  volatilityThreshold: 1.8
};

// Store notification state
interface NotificationState {
  unseenNotifications: Map<number, UserNotification[]>;
  notificationHistory: Map<number, UserNotification[]>;
  lastCheck: number;
  // Add fingerprints for deduplication
  notificationFingerprints: Map<string, number>; // fingerprint -> timestamp
}

// Track notification counts for reporting
const notificationCounts = {
  economicEvents: 0,
  correlations: 0,
  volatility: 0
};

// Using DEDUPLICATION_TTL defined at the top of the file (12 hours)

// Notification types
export enum NotificationType {
  ECONOMIC_EVENT = 'economic_event',
  PRICE_ALERT = 'price_alert',
  TRADE_EXECUTION = 'trade_execution',
  SYSTEM = 'system'
}

// Notification importance
export enum NotificationImportance {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

// Notification data structure
export interface UserNotification {
  id: string;
  userId: number;
  type: NotificationType;
  title: string;
  message: string;
  importance: NotificationImportance;
  relatedData?: any;
  timestamp: number;
  seen: boolean;
}

// Initialize notification state
const notificationState: NotificationState = {
  unseenNotifications: new Map(),
  notificationHistory: new Map(),
  lastCheck: Date.now(),
  notificationFingerprints: new Map()
};

// Connected clients for real-time notifications
const connectedClients: Map<number, Set<WebSocket>> = new Map();

/**
 * Register a client for notifications
 * @param userId User ID
 * @param ws WebSocket connection
 */
export function registerNotificationClient(userId: number, ws: WebSocket): void {
  if (!connectedClients.has(userId)) {
    connectedClients.set(userId, new Set());
  }
  
  connectedClients.get(userId)?.add(ws);
  log(`Registered notification client for user ${userId}`, 'notifications');
  
  // Send all unseen notifications to the client
  sendUnseenNotifications(userId, ws);
}

/**
 * Unregister a client from notifications
 * @param userId User ID
 * @param ws WebSocket connection
 */
export function unregisterNotificationClient(userId: number, ws: WebSocket): void {
  const clients = connectedClients.get(userId);
  if (clients) {
    clients.delete(ws);
    if (clients.size === 0) {
      connectedClients.delete(userId);
    }
    log(`Unregistered notification client for user ${userId}`, 'notifications');
  }
}

/**
 * Generate a fingerprint for a notification to prevent duplicates
 * @param notification The notification data
 * @returns A unique fingerprint string for deduplication
 */
function generateNotificationFingerprint(notification: Omit<UserNotification, 'id' | 'timestamp' | 'seen'>): string {
  // Create a fingerprint based on notification type and content
  let fingerprintParts: string[] = [
    notification.userId.toString(),
    notification.type,
    notification.title
  ];
  
  // Add specific parts based on notification type
  if (notification.type === NotificationType.ECONOMIC_EVENT) {
    // For economic events, use the event ID if available
    if (notification.relatedData?.eventId) {
      fingerprintParts.push(`event-${notification.relatedData.eventId}`);
    }
    
    // For correlations, include the symbol
    if (notification.relatedData?.correlationType === 'economic_event' && notification.relatedData?.symbol) {
      fingerprintParts.push(`symbol-${notification.relatedData.symbol}`);
    }
    
    // For volatility events, include the symbol and upcoming event ID
    if (notification.relatedData?.upcomingEventId && notification.relatedData?.symbol) {
      fingerprintParts.push(`vol-${notification.relatedData.symbol}-${notification.relatedData.upcomingEventId}`);
    }
  } else if (notification.type === NotificationType.PRICE_ALERT) {
    // For price alerts, use the symbol and alert type
    if (notification.relatedData?.symbol && notification.relatedData?.alertType) {
      fingerprintParts.push(`${notification.relatedData.symbol}-${notification.relatedData.alertType}`);
    }
  } else if (notification.type === NotificationType.TRADE_EXECUTION) {
    // For trade executions, use the trade ID
    if (notification.relatedData?.tradeId) {
      fingerprintParts.push(`trade-${notification.relatedData.tradeId}`);
    }
  }
  
  // Join parts with a separator and create a hash-like string
  return fingerprintParts.join('|');
}

/**
 * Check if a similar notification has been sent recently
 * @param fingerprint The notification fingerprint
 * @returns True if a similar notification exists within the deduplication window
 */
function isDuplicateNotification(fingerprint: string): boolean {
  const existingTimestamp = notificationState.notificationFingerprints.get(fingerprint);
  
  if (!existingTimestamp) {
    return false;
  }
  
  // Check if the existing notification is still within the deduplication window
  return (Date.now() - existingTimestamp) < DEDUPLICATION_TTL;
}

/**
 * Add a notification for a user
 * @param notification Notification data
 */
export function addNotification(notification: Omit<UserNotification, 'id' | 'timestamp' | 'seen'>): string {
  // Generate fingerprint for deduplication
  const fingerprint = generateNotificationFingerprint(notification);
  
  // Check if this is a duplicate notification (sent too recently)
  if (isDuplicateNotification(fingerprint)) {
    log(`Skipping duplicate notification: ${notification.title}`, 'notifications');
    return ''; // Return empty string for duplicate notifications
  }
  
  // Store fingerprint with current timestamp
  notificationState.notificationFingerprints.set(fingerprint, Date.now());
  
  // Clean up old fingerprints
  const now = Date.now();
  notificationState.notificationFingerprints.forEach((timestamp, key) => {
    if (now - timestamp > DEDUPLICATION_TTL) {
      notificationState.notificationFingerprints.delete(key);
    }
  });
  
  const notificationId = generateNotificationId();
  const timestamp = Date.now();
  
  const fullNotification: UserNotification = {
    ...notification,
    id: notificationId,
    timestamp,
    seen: false
  };
  
  // Add to unseen notifications
  if (!notificationState.unseenNotifications.has(notification.userId)) {
    notificationState.unseenNotifications.set(notification.userId, []);
  }
  notificationState.unseenNotifications.get(notification.userId)?.push(fullNotification);
  
  // Add to notification history
  if (!notificationState.notificationHistory.has(notification.userId)) {
    notificationState.notificationHistory.set(notification.userId, []);
  }
  notificationState.notificationHistory.get(notification.userId)?.push(fullNotification);
  
  // Limit history size
  const history = notificationState.notificationHistory.get(notification.userId);
  if (history && history.length > 100) {
    notificationState.notificationHistory.set(
      notification.userId,
      history.slice(history.length - 100)
    );
  }
  
  // Send notification to connected clients
  sendNotificationToUser(notification.userId, fullNotification);
  
  return notificationId;
}

/**
 * Mark notifications as seen
 * @param userId User ID
 * @param notificationIds IDs of notifications to mark as seen
 */
export function markNotificationsAsSeen(userId: number, notificationIds: string[]): void {
  const unseen = notificationState.unseenNotifications.get(userId) || [];
  const history = notificationState.notificationHistory.get(userId) || [];
  
  // Mark as seen in the unseen list
  for (const id of notificationIds) {
    const notification = unseen.find(n => n.id === id);
    if (notification) {
      notification.seen = true;
    }
  }
  
  // Mark as seen in history
  for (const id of notificationIds) {
    const notification = history.find(n => n.id === id);
    if (notification) {
      notification.seen = true;
    }
  }
  
  // Remove seen notifications from unseen list
  notificationState.unseenNotifications.set(
    userId,
    unseen.filter(n => !n.seen)
  );
}

/**
 * Get unseen notifications for a user
 * @param userId User ID
 */
export function getUnseenNotifications(userId: number): UserNotification[] {
  return notificationState.unseenNotifications.get(userId) || [];
}

/**
 * Get notification history for a user
 * @param userId User ID
 * @param limit Maximum number of notifications to return
 */
export function getNotificationHistory(userId: number, limit: number = 50): UserNotification[] {
  const history = notificationState.notificationHistory.get(userId) || [];
  return history.slice(-limit).reverse(); // Return most recent first
}

/**
 * Check for new economic events and create notifications
 */
export async function checkForEconomicEventNotifications(): Promise<void> {
  try {
    // Reset notification counter for this check
    notificationCounts.economicEvents = 0;
    
    // Only check once per hour
    const now = Date.now();
    if (now - notificationState.lastCheck < 60 * 60 * 1000) {
      return;
    }
    
    notificationState.lastCheck = now;
    
    // Get high-impact events for the next 3 days
    const highImpactEvents = await getUpcomingEvents(3, 'High');
    
    // Get active users
    const activeUserIds = await getActiveUserIds();
    
    for (const userId of activeUserIds) {
      // Get user's portfolio events
      const portfolioEvents = await getEventsForPortfolio(userId, 3);
      
      // Create notifications for portfolio-specific events
      for (const event of portfolioEvents) {
        // Skip if we've already notified about this (check in history)
        const eventIdExists = checkIfEventNotificationExists(userId, event.id);
        if (eventIdExists) continue;
        
        const importance = event.impact === 'High' 
          ? NotificationImportance.HIGH 
          : event.impact === 'Medium' 
            ? NotificationImportance.MEDIUM 
            : NotificationImportance.LOW;
        
        // Create notification
        addNotification({
          userId,
          type: NotificationType.ECONOMIC_EVENT,
          title: `Upcoming Economic Event: ${event.eventName}`,
          message: `${event.eventName} for ${event.country} on ${formatDate(event.eventDate)} may impact your portfolio assets: ${event.affectedSymbols.join(', ')}`,
          importance,
          relatedData: {
            eventId: event.id,
            eventDate: event.eventDate,
            country: event.country,
            impact: event.impact,
            affectedSymbols: event.affectedSymbols
          }
        });
        
        // Increment the notification counter
        notificationCounts.economicEvents++;
      }
      
      // Also notify about high-impact global events even if not in portfolio
      for (const event of highImpactEvents) {
        // Skip if country-specific and not in user's portfolio countries
        if (event.country !== 'US' && event.country !== 'EU' && event.country !== 'Global') {
          // Skip if we've already notified about it via portfolio events
          if (portfolioEvents.some(pe => pe.id === event.id)) {
            continue;
          }
        }
        
        // Skip if we've already notified about this
        const eventIdExists = checkIfEventNotificationExists(userId, event.id);
        if (eventIdExists) continue;
        
        // Create notification
        addNotification({
          userId,
          type: NotificationType.ECONOMIC_EVENT,
          title: `Major Economic Event: ${event.eventName}`,
          message: `High impact ${event.eventName} for ${event.country} on ${formatDate(event.eventDate)} may cause market volatility.`,
          importance: NotificationImportance.HIGH,
          relatedData: {
            eventId: event.id,
            eventDate: event.eventDate,
            country: event.country,
            impact: event.impact
          }
        });
        
        // Increment the notification counter
        notificationCounts.economicEvents++;
      }
    }
    
    log(`Created ${notificationCounts.economicEvents} economic event notifications`, 'notifications');
    
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.UNKNOWN,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'checkForEconomicEventNotifications'
      }
    );
  }
}

// Helper to send unseen notifications to a client
function sendUnseenNotifications(userId: number, ws: WebSocket): void {
  const unseen = getUnseenNotifications(userId);
  
  if (unseen.length > 0 && ws.readyState === WebSocket.OPEN) {
    try {
      ws.send(JSON.stringify({
        type: 'notifications',
        data: unseen
      }));
    } catch (error) {
      errorHandler.logError(
        error,
        ErrorType.NETWORK,
        ErrorSeverity.WARNING,
        { 
          component: 'notificationService',
          operation: 'sendUnseenNotifications',
          userId
        }
      );
    }
  }
}

// Helper to send a notification to all of a user's connected clients
function sendNotificationToUser(userId: number, notification: UserNotification): void {
  const clients = connectedClients.get(userId);
  
  if (clients && clients.size > 0) {
    for (const client of clients) {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.send(JSON.stringify({
            type: 'notification',
            data: notification
          }));
        } catch (error) {
          errorHandler.logError(
            error,
            ErrorType.NETWORK,
            ErrorSeverity.WARNING,
            { 
              component: 'notificationService',
              operation: 'sendNotificationToUser',
              userId
            }
          );
        }
      }
    }
  }
}

// Helper to generate a unique notification ID
function generateNotificationId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
}

// Helper to get active user IDs
async function getActiveUserIds(): Promise<number[]> {
  try {
    // Get user IDs from cache if available
    const cached = marketDataCache.get<number[]>('active_user_ids');
    if (cached) {
      return cached;
    }
    
    // Hardcoded for now since we don't track user activity yet
    // In a real implementation, we would check recent login activity
    const activeIds = [1, 2, 3]; // Default to admin + test users
    
    // Cache for 1 hour
    marketDataCache.set('active_user_ids', activeIds, 60 * 60 * 1000);
    
    return activeIds;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'getActiveUserIds'
      }
    );
    
    return [1]; // Default to admin user only on error
  }
}

// Helper to check if we've already notified a user about an event
function checkIfEventNotificationExists(userId: number, eventId: number): boolean {
  // Use the fingerprinting system first
  const fingerprint = `${userId}|${NotificationType.ECONOMIC_EVENT}|event-${eventId}`;
  if (isDuplicateNotification(fingerprint)) {
    return true;
  }
  
  // Fallback to old method for backward compatibility
  const history = notificationState.notificationHistory.get(userId) || [];
  
  return history.some(notification => 
    notification.type === NotificationType.ECONOMIC_EVENT && 
    notification.relatedData?.eventId === eventId
  );
}

// Helper to format a date for display
function formatDate(dateStr: string | Date): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Check for historical price movements related to economic events
 * and notify users about potential correlations
 */
export async function checkEconomicEventCorrelations(): Promise<void> {
  try {
    // Reset notification counter for this check
    notificationCounts.correlations = 0;
    
    // Get active users
    const activeUserIds = await getActiveUserIds();
    
    for (const userId of activeUserIds) {
      // Get user's portfolio
      const userAssets = await getUserAssetsFromPortfolio(userId);
      
      if (!userAssets.length) continue;
      
      // For each asset, check for significant economic event correlations
      for (const { symbol } of userAssets) {
        // Find significant events for this asset
        const significantEvents = await findSignificantEventsForAsset(
          symbol,
          CONFIG.significantPercentChange,
          5 // Limit to top 5 most significant events
        );
        
        if (!significantEvents.length) continue;
        
        // Only notify if we have at least one significant event with notable impact
        const notableEvents = significantEvents.filter(
          event => Math.abs(event.percentChange) >= CONFIG.significantPercentChange * 1.5
        );
        
        if (notableEvents.length === 0) continue;
        
        // Check if we've already notified about this correlation
        const correlationExists = checkIfCorrelationNotificationExists(userId, symbol);
        if (correlationExists) continue;
        
        // Create a notification for this correlation
        const topEvent = notableEvents[0];
        const direction = topEvent.percentChange > 0 ? 'positive' : 'negative';
        const eventType = topEvent.eventName.length > 30 
          ? topEvent.eventName.substring(0, 30) + '...' 
          : topEvent.eventName;
        
        addNotification({
          userId,
          type: NotificationType.ECONOMIC_EVENT,
          title: `Economic Event Correlation for ${symbol}`,
          message: `${symbol} historically has a ${direction} reaction (${topEvent.percentChange.toFixed(2)}%) to "${eventType}" events. Next such event: ${getNextSimilarEventDate(topEvent) || 'Unknown'}`,
          importance: Math.abs(topEvent.percentChange) >= 5 
            ? NotificationImportance.HIGH 
            : Math.abs(topEvent.percentChange) >= 2 
              ? NotificationImportance.MEDIUM 
              : NotificationImportance.LOW,
          relatedData: {
            symbol,
            correlationType: 'economic_event',
            eventName: topEvent.eventName,
            eventId: topEvent.id,
            percentChange: topEvent.percentChange,
            significance: notableEvents.length,
            otherEvents: notableEvents.slice(1).map(e => ({
              id: e.id,
              name: e.eventName,
              change: e.percentChange
            }))
          }
        });
        
        // Increment the notification counter
        notificationCounts.correlations++;
        
        log(`Created correlation notification for user ${userId} about ${symbol} and ${topEvent.eventName}`, 'notifications');
      }
    }
    
    log(`Created ${notificationCounts.correlations} economic event correlation notifications`, 'notifications');
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.UNKNOWN,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'checkEconomicEventCorrelations'
      }
    );
  }
}

/**
 * Check for upcoming economic events that historically caused high volatility
 * and notify users about potential volatility
 */
export async function checkUpcomingVolatilityEvents(): Promise<void> {
  try {
    // Reset notification counter for this check
    notificationCounts.volatility = 0;
    
    // Get active users
    const activeUserIds = await getActiveUserIds();
    
    // Get events for next 7 days
    const upcomingEvents = await getUpcomingEvents(7, 'Low'); // Get all events
    
    if (!upcomingEvents.length) return;
    
    for (const userId of activeUserIds) {
      // Get user's portfolio
      const userAssets = await getUserAssetsFromPortfolio(userId);
      
      if (!userAssets.length) continue;
      
      // For each asset, check upcoming events that may cause volatility
      for (const { symbol } of userAssets) {
        // For each upcoming event, check historical volatility impact
        for (const event of upcomingEvents) {
          // Skip if already notified about this event for this user
          const eventVolatilityExists = checkIfEventVolatilityNotificationExists(userId, symbol, event.id);
          if (eventVolatilityExists) continue;
          
          // Find similar past events
          const similarEvents = await findSimilarPastEvents(event.eventName);
          
          if (!similarEvents.length) continue;
          
          // Check historical volatility for similar events
          let highestVolatility = 0;
          let highestVolatilityEvent = null;
          
          for (const pastEvent of similarEvents) {
            const movement = await findMarketMovementAroundEvent(
              symbol, 
              new Date(pastEvent.eventDate),
              3 // Look at 3 days around the event
            );
            
            if (movement.volatility > highestVolatility) {
              highestVolatility = movement.volatility;
              highestVolatilityEvent = pastEvent;
            }
          }
          
          // If we found significant historical volatility, notify the user
          if (highestVolatility >= CONFIG.volatilityThreshold && highestVolatilityEvent) {
            addNotification({
              userId,
              type: NotificationType.ECONOMIC_EVENT,
              title: `Potential Volatility Alert for ${symbol}`,
              message: `Upcoming event "${event.eventName}" on ${formatDate(event.eventDate)} may cause high volatility for ${symbol} based on historical patterns (${highestVolatility.toFixed(1)}% volatility)`,
              importance: highestVolatility >= 5 
                ? NotificationImportance.HIGH 
                : highestVolatility >= 3 
                  ? NotificationImportance.MEDIUM 
                  : NotificationImportance.LOW,
              relatedData: {
                symbol,
                upcomingEventId: event.id,
                upcomingEventDate: event.eventDate,
                upcomingEventName: event.eventName,
                historicalEventId: highestVolatilityEvent.id,
                historicalEventDate: highestVolatilityEvent.eventDate,
                volatility: highestVolatility
              }
            });
            
            // Increment the notification counter
            notificationCounts.volatility++;
            
            log(`Created volatility notification for user ${userId} about ${symbol} and ${event.eventName}`, 'notifications');
            
            // Only create one notification per asset to avoid spam
            break;
          }
        }
      }
    }
    
    log(`Created ${notificationCounts.volatility} volatility notifications`, 'notifications');
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.UNKNOWN,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'checkUpcomingVolatilityEvents'
      }
    );
  }
}

// Helper to find similar past events
async function findSimilarPastEvents(eventName: string, limit: number = 3): Promise<any[]> {
  try {
    const cacheKey = `similar_events_${eventName.replace(/\s+/g, '_').substring(0, 30)}`;
    
    // Try to get from cache first
    const cached = marketDataCache.get<any[]>(cacheKey);
    if (cached && Array.isArray(cached)) {
      return cached;
    }
    
    // Get past events with similar names - format date as ISO string
    const now = new Date();
    const nowISOString = now.toISOString();
    
    const events = await db.select()
      .from(economicEvents)
      .where(sql`LOWER(${economicEvents.eventName}) LIKE LOWER('%${sql.raw(eventName.replace(/[%_]/g, '\\$&'))}%')
        AND ${economicEvents.eventDate} < ${nowISOString}`)
      .orderBy(desc(economicEvents.eventDate))
      .limit(limit);
    
    // Cache results for 6 hours
    marketDataCache.set(cacheKey, events, 6 * 60 * 60 * 1000);
    
    return events;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'findSimilarPastEvents',
        eventName
      }
    );
    
    return [];
  }
}

// Helper to get user's assets from portfolio
async function getUserAssetsFromPortfolio(userId: number): Promise<{ symbol: string }[]> {
  try {
    const cacheKey = `user_${userId}_portfolio_assets`;
    
    // Try to get from cache first
    const cached = marketDataCache.get<{ symbol: string }[]>(cacheKey);
    if (cached && Array.isArray(cached)) {
      return cached;
    }
    
    // Get user's portfolio assets
    const portfolioAssets = await db.select({ symbol: portfolio.symbol })
      .from(portfolio)
      .where(eq(portfolio.userId, userId));
    
    // Cache for 30 minutes
    marketDataCache.set(cacheKey, portfolioAssets, 30 * 60 * 1000);
    
    return portfolioAssets;
  } catch (error) {
    errorHandler.logError(
      error,
      ErrorType.DATABASE,
      ErrorSeverity.WARNING,
      { 
        component: 'notificationService',
        operation: 'getUserAssetsFromPortfolio',
        userId
      }
    );
    
    return [];
  }
}

// Helper to check if we've already notified about a correlation
function checkIfCorrelationNotificationExists(userId: number, symbol: string): boolean {
  // Use the fingerprinting system first
  const fingerprint = `${userId}|${NotificationType.ECONOMIC_EVENT}|symbol-${symbol}|correlation`;
  if (isDuplicateNotification(fingerprint)) {
    return true;
  }
  
  // Fallback to time-based check for backward compatibility
  const history = notificationState.notificationHistory.get(userId) || [];
  
  // Check if we've notified about this correlation in the last 7 days
  const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
  
  return history.some(notification => 
    notification.type === NotificationType.ECONOMIC_EVENT && 
    notification.relatedData?.correlationType === 'economic_event' &&
    notification.relatedData?.symbol === symbol &&
    notification.timestamp > sevenDaysAgo
  );
}

// Helper to check if we've already notified about event volatility
function checkIfEventVolatilityNotificationExists(userId: number, symbol: string, eventId: number): boolean {
  // Use the fingerprinting system first
  const fingerprint = `${userId}|${NotificationType.ECONOMIC_EVENT}|vol-${symbol}-${eventId}`;
  if (isDuplicateNotification(fingerprint)) {
    return true;
  }
  
  // Fallback to direct check for backward compatibility
  const history = notificationState.notificationHistory.get(userId) || [];
  
  return history.some(notification => 
    notification.type === NotificationType.ECONOMIC_EVENT && 
    notification.relatedData?.upcomingEventId === eventId &&
    notification.relatedData?.symbol === symbol
  );
}

// Helper to get the date of the next similar event
function getNextSimilarEventDate(event: any): string | null {
  try {
    // In a real implementation, we would query upcoming events with similar name/type
    // For now, return a placeholder date
    const today = new Date();
    const nextMonth = new Date();
    nextMonth.setMonth(today.getMonth() + 1);
    return formatDate(nextMonth);
  } catch (error) {
    return null;
  }
}

// Multiple notification check intervals
let notificationCheckInterval: NodeJS.Timeout | null = null;
let correlationCheckInterval: NodeJS.Timeout | null = null;
let volatilityCheckInterval: NodeJS.Timeout | null = null;

export function startNotificationService(): void {
  // Clear any existing intervals
  stopNotificationService();
  
  // Check for upcoming economic event notifications every 15 minutes
  notificationCheckInterval = setInterval(
    checkForEconomicEventNotifications,
    15 * 60 * 1000
  );
  
  // Check for economic event correlations every 12 hours
  correlationCheckInterval = setInterval(
    checkEconomicEventCorrelations,
    CONFIG.correlationCheckInterval
  );
  
  // Check for upcoming volatility events once a day
  volatilityCheckInterval = setInterval(
    checkUpcomingVolatilityEvents,
    24 * 60 * 60 * 1000
  );
  
  // Initial checks
  checkForEconomicEventNotifications();
  
  // Stagger other checks to avoid overloading the database
  setTimeout(() => checkEconomicEventCorrelations(), 5 * 60 * 1000); // 5 minutes after start
  setTimeout(() => checkUpcomingVolatilityEvents(), 10 * 60 * 1000); // 10 minutes after start
  
  log('Notification service started with enhanced economic event monitoring', 'notifications');
}

/**
 * Run all notification checks at once - used for manual triggering through admin panel
 * @returns Object with results of each notification check
 */
export async function runAllNotificationChecks(): Promise<{
  economicEvents: { success: boolean; count: number };
  correlations: { success: boolean; count: number };
  volatility: { success: boolean; count: number };
}> {
  log('Running all notification checks manually', 'notifications');
  
  const results = {
    economicEvents: { success: false, count: 0 },
    correlations: { success: false, count: 0 },
    volatility: { success: false, count: 0 }
  };
  
  try {
    // Run economic event notifications check
    await checkForEconomicEventNotifications();
    results.economicEvents = { success: true, count: notificationCounts.economicEvents || 0 };
  } catch (error) {
    errorHandler.logError(
      error, 
      ErrorType.UNKNOWN, 
      ErrorSeverity.ERROR, 
      { function: 'runAllNotificationChecks', check: 'economicEvents' }
    );
    log(`Error running economic event notifications check: ${error instanceof Error ? error.message : String(error)}`, 'notifications');
  }
  
  try {
    // Run correlations check
    await checkEconomicEventCorrelations();
    results.correlations = { success: true, count: notificationCounts.correlations || 0 };
  } catch (error) {
    errorHandler.logError(
      error, 
      ErrorType.UNKNOWN, 
      ErrorSeverity.ERROR, 
      { function: 'runAllNotificationChecks', check: 'correlations' }
    );
    log(`Error running correlations check: ${error instanceof Error ? error.message : String(error)}`, 'notifications');
  }
  
  try {
    // Run volatility check
    await checkUpcomingVolatilityEvents();
    results.volatility = { success: true, count: notificationCounts.volatility || 0 };
  } catch (error) {
    errorHandler.logError(
      error, 
      ErrorType.UNKNOWN, 
      ErrorSeverity.ERROR, 
      { function: 'runAllNotificationChecks', check: 'volatility' }
    );
    log(`Error running volatility check: ${error instanceof Error ? error.message : String(error)}`, 'notifications');
  }
  
  log(`Manual notification checks completed: ${JSON.stringify(results)}`, 'notifications');
  return results;
}

export function stopNotificationService(): void {
  if (notificationCheckInterval) {
    clearInterval(notificationCheckInterval);
    notificationCheckInterval = null;
  }
  
  if (correlationCheckInterval) {
    clearInterval(correlationCheckInterval);
    correlationCheckInterval = null;
  }
  
  if (volatilityCheckInterval) {
    clearInterval(volatilityCheckInterval);
    volatilityCheckInterval = null;
  }
  
  log('Notification service stopped', 'notifications');
}