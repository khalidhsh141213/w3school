# تنفيذ WebSocket: دليل المطور

## نظرة عامة على البنية التحتية

تم تطوير نظام تحديث الأسعار في الوقت الفعلي في منصتنا باستخدام بنية WebSocket متعددة الطبقات:

1. **طبقة العميل (Client Layer)**: 
   - استخدام `WebSocketManager` كواجهة موحدة للتعامل مع اتصالات WebSocket
   - مكون `useWebSocket` كـ React Hook للتكامل مع مكونات React

2. **طبقة الخادم (Server Layer)**:
   - خدمة `MarketDataService` لإدارة اتصالات WebSocket وتوزيع التحديثات
   - آلية تحديث الأسعار المختلفة بناءً على نوع الأصل

3. **طبقة مصدر البيانات (Data Source Layer)**:
   - تحديثات مباشرة للعملات الرقمية والفوركس (WebSocket)
   - تحديثات أقل تكرارًا للأسهم والمؤشرات (REST API)

## الفصل بين أنواع الأصول

تم تقسيم الأصول المالية حسب نمط التحديث المناسب لها:

| نوع الأصل | طريقة التحديث | الفاصل الزمني | ملاحظات |
|-----------|---------------|---------------|---------|
| العملات الرقمية (crypto) | WebSocket (مباشر) | 5 ثواني | متاحة دائمًا (24/7) |
| الفوركس (forex) | WebSocket (مباشر) | 5 ثواني | مغلقة يوم الأحد |
| الأسهم (stock) | REST API | 5 دقائق | مغلقة في عطلات نهاية الأسبوع |
| المؤشرات (index) | REST API | 5 دقائق | مغلقة في عطلات نهاية الأسبوع |

## تنفيذ الخادم (Server)

### 1. MarketDataService

`MarketDataService` هو المكون الرئيسي المسؤول عن إدارة البيانات في الوقت الفعلي:

```typescript
// من server/services/marketData.ts
export class MarketDataService {
  private wss: WebSocketServer | null = null;
  private clients: Map<CustomWebSocket, Set<string>> = new Map();
  private lastPrices: Map<string, { price: number, change: number, changePercent: number }> = new Map();
  
  // ...

  async initialize(server: HttpServer) {
    // إنشاء خادم WebSocket على مسار محدد
    this.wss = new WebSocketServer({ 
      server,
      path: '/api/market-data'
    });

    this.wss.on('connection', (ws: CustomWebSocket) => {
      // التعامل مع اتصال العميل
      // ...
    });

    // تحديث الأسعار دوريًا
    this.startPriceUpdates();
  }
}
```

### 2. نظام تحديث الأسعار

تم تنفيذ نظام تحديث الأسعار باستخدام نموذج العمل التالي:

```javascript
// من scripts/market-update.js
// تحديث الأصول في الوقت الفعلي (العملات الرقمية والفوركس)
async function updateRealtimeAssets() {
  // تحديث أصول العملات الرقمية (نشطة دائمًا)
  for (const asset of assetsByType.crypto) {
    // الحصول على بيانات الأسعار المحدثة
    const { price, change, changePercent, volume } = simulatePriceChange(
      currentPrices[asset.symbol] || asset.basePrice, 
      asset.volatility || 1
    );
    
    // محاولة استخدام WebSocket أولاً، والعودة إلى REST إذا فشل
    const wsSuccess = updateViaWebSocket(asset.symbol, { price, change, changePercent, volume });
    if (!wsSuccess) {
      await updateViaREST(asset.symbol, { price, change, changePercent, volume });
    }
  }
  
  // تحديث أصول الفوركس (التحقق مما إذا كانت السوق مفتوحة)
  if (areMarketsOpen('forex')) {
    // تحديث الفوركس...
  } else {
    console.log('Forex markets are closed (Sunday). Skipping updates.');
  }
}
```

### 3. التحقق من حالة السوق

يتم التحقق من حالة السوق قبل تحديث الأسعار:

```javascript
// من scripts/market-update.js
function areMarketsOpen(assetType) {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 هو الأحد، 6 هو السبت
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
  
  // العملات الرقمية مفتوحة دائمًا
  if (assetType === 'crypto') {
    return true;
  }
  
  // الفوركس له تداول محدود في عطلة نهاية الأسبوع
  if (assetType === 'forex') {
    if (dayOfWeek === 0) { // الأحد
      return false; // مغلق عمومًا يوم الأحد
    }
    return true; // يمكن أن يكون نشطًا خلال الأيام الأخرى
  }
  
  // أسواق الأسهم مغلقة في عطلات نهاية الأسبوع
  if (assetType === 'stock' || assetType === 'index') {
    return !isWeekend;
  }
  
  // الافتراضي هو مغلق يوم الأحد، مفتوح في الأيام الأخرى
  return dayOfWeek !== 0;
}
```

## تنفيذ العميل (Client)

### 1. WebSocketManager

`WebSocketManager` هو مكون مركزي للتعامل مع اتصالات WebSocket على جانب العميل:

```typescript
// من client/src/services/WebSocketManager.ts
class WebSocketManager {
  private static instance: WebSocketManager;
  private connections: Map<string, WebSocket> = new Map();
  private statuses: Map<string, ConnectionStatus> = new Map();
  private subscriptions: Map<string, Set<SubscriptionCallback>> = new Map();
  // ...
  
  public static getInstance(): WebSocketManager {
    if (!WebSocketManager.instance) {
      WebSocketManager.instance = new WebSocketManager();
    }
    return WebSocketManager.instance;
  }
  
  public connect(url: string, options: WebSocketOptions = {}): Promise<WebSocket> {
    // إنشاء اتصال WebSocket...
  }
  
  public send(url: string, message: WebSocketMessage): boolean {
    // إرسال رسالة عبر WebSocket...
  }
  
  public subscribe(url: string, callback: SubscriptionCallback): void {
    // الاشتراك في تحديثات WebSocket...
  }
  
  // ...
}
```

### 2. React Hook (useWebSocket)

تم توفير React Hook لتسهيل استخدام WebSocket في مكونات React:

```typescript
// من client/src/services/WebSocketManager.ts
export function useWebSocket(
  url: string,
  options: WebSocketOptions = {},
  dependencies: any[] = []
) {
  const manager = WebSocketManager.getInstance();
  const wsRef = useRef<WebSocket | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>(
    manager.getStatus(url) || ConnectionStatus.DISCONNECTED
  );
  
  // الاتصال بـ WebSocket عند تحميل المكون
  useEffect(() => {
    if (!url) return;
    
    manager.connect(url, options)
      .then(ws => {
        wsRef.current = ws;
      })
      .catch(error => {
        console.error(`Error connecting to WebSocket at ${url}:`, error);
      });
    
    // تحديث الحالة عند تغيرها
    const statusListener = (newStatus: ConnectionStatus) => {
      setStatus(newStatus);
    };
    
    manager.onStatusChange(url, statusListener);
    
    // تنظيف الاتصال عند إزالة المكون
    return () => {
      manager.offStatusChange(url, statusListener);
    };
  }, [url, ...dependencies]);
  
  // إرجاع واجهة متناسقة للاستخدام في المكونات
  return {
    status,
    send: (message: any) => manager.send(url, message),
    subscribe: (callback: (data: any) => void) => manager.subscribe(url, callback),
    unsubscribe: (callback: (data: any) => void) => manager.unsubscribe(url, callback)
  };
}
```

## القضايا المعروفة والحلول

### 1. فقدان الاتصال

للتعامل مع فقدان الاتصال، تم تنفيذ آليات متعددة:

- **إعادة الاتصال التلقائي**: محاولات إعادة الاتصال المتكررة مع زيادة فترات التأخير.
- **Circuit Breaker**: منع محاولات إعادة الاتصال المفرطة عند وجود مشاكل مستمرة.
- **Fallback لـ REST API**: استخدام REST API كآلية احتياطية عند عدم توفر WebSocket.

### 2. تصميم الاختبار

لاختبار وظيفة WebSocket، يمكن استخدام الأدوات التالية:

- `test-websocket.js`: أداة لاختبار اتصالات WebSocket.
- `test-notification-ws.js`: اختبار نظام الإشعارات عبر WebSocket.

## مثال كامل لاستخدام WebSocket

### في مكون React:

```tsx
import React, { useEffect, useState } from 'react';
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';

const CryptoMarketTicker: React.FC = () => {
  const [cryptoPrices, setCryptoPrices] = useState<Record<string, number>>({});
  const cryptoSymbols = ['BTC/USD', 'ETH/USD', 'SOL/USD', 'ADA/USD'];
  
  // استخدام WebSocket لتحديثات الأسعار في الوقت الفعلي
  const { status, send, subscribe } = useWebSocket('/api/market-data', {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });
  
  // الاشتراك في تحديثات الأسعار
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      // إرسال طلب اشتراك للعملات الرقمية
      send({
        type: 'subscribe',
        symbols: cryptoSymbols
      });
      
      // معالجة تحديثات الأسعار الواردة
      const handlePriceUpdate = (message: any) => {
        if (message.type === 'priceUpdate' && message.data) {
          const { symbol, price } = message.data;
          
          // تحديث الأسعار
          if (cryptoSymbols.includes(symbol)) {
            setCryptoPrices(prev => ({
              ...prev,
              [symbol]: parseFloat(price)
            }));
          }
        }
      };
      
      // الاشتراك في رسائل WebSocket
      subscribe(handlePriceUpdate);
      
      // تنظيف عند إزالة المكون
      return () => {
        // إلغاء الاشتراك من الرموز
        send({
          type: 'unsubscribe',
          symbols: cryptoSymbols
        });
      };
    }
  }, [status, send, subscribe]);
  
  // عرض حالة الاتصال والأسعار
  return (
    <div className="crypto-ticker">
      <div className="connection-status">
        اتصال WebSocket: {status}
      </div>
      <div className="price-grid">
        {cryptoSymbols.map(symbol => (
          <div key={symbol} className="price-card">
            <div className="symbol">{symbol}</div>
            <div className="price">
              {cryptoPrices[symbol] 
                ? `$${cryptoPrices[symbol]?.toLocaleString()}`
                : 'جاري التحميل...'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CryptoMarketTicker;
```

## خريطة الطريق المستقبلية

1. **دعم المزيد من الأصول**: توسيع دعم WebSocket ليشمل المزيد من أزواج العملات والأصول.
2. **تحسينات الأداء**: تحسين استهلاك الموارد من خلال تحسين إدارة الاشتراكات.
3. **التوافق مع أوقات السوق**: تحسين التعامل مع عطلات نهاية الأسبوع والعطلات الرسمية.
4. **ضغط البيانات**: تنفيذ آليات لضغط بيانات WebSocket لتحسين الأداء.