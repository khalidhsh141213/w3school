import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../../hooks/useSettings';

type SettingsType = 'notifications' | 'privacy' | 'regional';

interface SettingsFormProps {
  settingsType: SettingsType;
  onSuccess?: () => void;
}

export const SettingsForm: React.FC<SettingsFormProps> = ({ settingsType, onSuccess }) => {
  const { t } = useTranslation();
  const { getSettings, updateSettings } = useSettings();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const [formData, setFormData] = useState({
    // Notification Settings
    emailNotifications: false,
    pushNotifications: false,
    tradeAlerts: false,
    marketUpdates: false,
    
    // Privacy Settings
    profileVisibility: 'public',
    showPortfolio: false,
    shareTradeHistory: false,
    
    // Regional Settings
    language: 'en',
    timezone: 'UTC',
    currency: 'USD',
    dateFormat: 'MM/DD/YYYY'
  });

  useEffect(() => {
    loadSettings();
  }, [settingsType]);

  const loadSettings = async () => {
    try {
      const settings = await getSettings(settingsType);
      setFormData(prev => ({ ...prev, ...settings }));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setFormData({
      ...formData,
      [e.target.name]: value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const settingsToUpdate = getRelevantSettings();
      await updateSettings(settingsType, settingsToUpdate);
      onSuccess?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getRelevantSettings = () => {
    switch (settingsType) {
      case 'notifications':
        return {
          emailNotifications: formData.emailNotifications,
          pushNotifications: formData.pushNotifications,
          tradeAlerts: formData.tradeAlerts,
          marketUpdates: formData.marketUpdates
        };
      case 'privacy':
        return {
          profileVisibility: formData.profileVisibility,
          showPortfolio: formData.showPortfolio,
          shareTradeHistory: formData.shareTradeHistory
        };
      case 'regional':
        return {
          language: formData.language,
          timezone: formData.timezone,
          currency: formData.currency,
          dateFormat: formData.dateFormat
        };
      default:
        return {};
    }
  };

  const renderNotificationSettings = () => (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label htmlFor="emailNotifications" className="text-sm font-medium">
            {t('settings.emailNotifications')}
          </label>
          <input
            type="checkbox"
            id="emailNotifications"
            name="emailNotifications"
            checked={formData.emailNotifications}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
        <div className="flex items-center justify-between">
          <label htmlFor="pushNotifications" className="text-sm font-medium">
            {t('settings.pushNotifications')}
          </label>
          <input
            type="checkbox"
            id="pushNotifications"
            name="pushNotifications"
            checked={formData.pushNotifications}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
        <div className="flex items-center justify-between">
          <label htmlFor="tradeAlerts" className="text-sm font-medium">
            {t('settings.tradeAlerts')}
          </label>
          <input
            type="checkbox"
            id="tradeAlerts"
            name="tradeAlerts"
            checked={formData.tradeAlerts}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
        <div className="flex items-center justify-between">
          <label htmlFor="marketUpdates" className="text-sm font-medium">
            {t('settings.marketUpdates')}
          </label>
          <input
            type="checkbox"
            id="marketUpdates"
            name="marketUpdates"
            checked={formData.marketUpdates}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
      </div>
    </>
  );

  const renderPrivacySettings = () => (
    <>
      <div className="space-y-4">
        <div>
          <label htmlFor="profileVisibility" className="block text-sm font-medium">
            {t('settings.profileVisibility')}
          </label>
          <select
            id="profileVisibility"
            name="profileVisibility"
            value={formData.profileVisibility}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          >
            <option value="public">{t('settings.public')}</option>
            <option value="private">{t('settings.private')}</option>
            <option value="friends">{t('settings.friendsOnly')}</option>
          </select>
        </div>
        <div className="flex items-center justify-between">
          <label htmlFor="showPortfolio" className="text-sm font-medium">
            {t('settings.showPortfolio')}
          </label>
          <input
            type="checkbox"
            id="showPortfolio"
            name="showPortfolio"
            checked={formData.showPortfolio}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
        <div className="flex items-center justify-between">
          <label htmlFor="shareTradeHistory" className="text-sm font-medium">
            {t('settings.shareTradeHistory')}
          </label>
          <input
            type="checkbox"
            id="shareTradeHistory"
            name="shareTradeHistory"
            checked={formData.shareTradeHistory}
            onChange={handleChange}
            className="toggle toggle-primary"
          />
        </div>
      </div>
    </>
  );

  const renderRegionalSettings = () => (
    <>
      <div className="space-y-4">
        <div>
          <label htmlFor="language" className="block text-sm font-medium">
            {t('settings.language')}
          </label>
          <select
            id="language"
            name="language"
            value={formData.language}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          >
            <option value="en">English</option>
            <option value="ar">العربية</option>
            <option value="fr">Français</option>
          </select>
        </div>
        <div>
          <label htmlFor="timezone" className="block text-sm font-medium">
            {t('settings.timezone')}
          </label>
          <select
            id="timezone"
            name="timezone"
            value={formData.timezone}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          >
            <option value="UTC">UTC</option>
            <option value="America/New_York">EST</option>
            <option value="Europe/London">GMT</option>
            <option value="Asia/Dubai">GST</option>
          </select>
        </div>
        <div>
          <label htmlFor="currency" className="block text-sm font-medium">
            {t('settings.currency')}
          </label>
          <select
            id="currency"
            name="currency"
            value={formData.currency}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          >
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="AED">AED</option>
          </select>
        </div>
        <div>
          <label htmlFor="dateFormat" className="block text-sm font-medium">
            {t('settings.dateFormat')}
          </label>
          <select
            id="dateFormat"
            name="dateFormat"
            value={formData.dateFormat}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          >
            <option value="MM/DD/YYYY">MM/DD/YYYY</option>
            <option value="DD/MM/YYYY">DD/MM/YYYY</option>
            <option value="YYYY-MM-DD">YYYY-MM-DD</option>
          </select>
        </div>
      </div>
    </>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded">
          {error}
        </div>
      )}

      {settingsType === 'notifications' && renderNotificationSettings()}
      {settingsType === 'privacy' && renderPrivacySettings()}
      {settingsType === 'regional' && renderRegionalSettings()}

      <button
        type="submit"
        disabled={loading}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
      >
        {loading ? (
          <span className="loading loading-spinner" />
        ) : (
          t('settings.saveChanges')
        )}
      </button>
    </form>
  );
}; 