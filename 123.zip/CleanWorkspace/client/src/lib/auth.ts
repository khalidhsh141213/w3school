import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware'
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { queryClient } from './queryClient';

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string | null;
  balance: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  register: (username: string, email: string, password: string, fullName?: string) => Promise<void>;
  updateToken: (token: string) => void;
  updateUser: (user: User) => void;
  clearError: () => void;
}

// Create auth store with zustand
export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      
      login: async (username, password) => {
        set({ isLoading: true, error: null });
        try {
          // Validate inputs before sending
          if (!username || !password) {
            throw new Error('Username and password are required');
          }
          
          const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
            credentials: 'include', // This is important for session cookies
          });
          
          // Safe handling of the response content
          let data;
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            data = await response.json();
          } else {
            // Handle non-JSON responses
            const text = await response.text();
            console.error("Non-JSON response:", text);
            
            // Provide better error message based on status code
            if (response.status === 401) {
              throw new Error("Invalid username or password");
            } else if (response.status === 403) {
              throw new Error("Account is locked or requires additional verification");
            } else if (response.status >= 500) {
              throw new Error("Server error. Please try again later");
            } else {
              throw new Error("Invalid response from server");
            }
          }
          
          if (!response.ok) {
            // Handle specific error messages from server
            const errorMessage = data.message || 'Login failed';
            console.error('Login failed with message:', errorMessage);
            throw new Error(errorMessage);
          }
          
          // In a session-based auth system, the server doesn't return a token
          // The user data is returned directly
          set({ 
            user: data, 
            token: null, // No token in session-based auth
            isAuthenticated: true, 
            isLoading: false 
          });
          
          // Refresh all user-related data
          queryClient.invalidateQueries({ queryKey: ['/api/user'] });
          queryClient.invalidateQueries({ queryKey: ['/api/user/portfolio'] });
          queryClient.invalidateQueries({ queryKey: ['/api/user/watchlist'] });
          queryClient.invalidateQueries({ queryKey: ['/api/portfolio-summary'] });
          console.log('Login successful:', data);
        } catch (error) {
          console.error('Login error:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'An unknown error occurred'
          });
        }
      },
      
      register: async (username, email, password, fullName) => {
        set({ isLoading: true, error: null });
        try {
          // Form validation
          if (!username || username.length < 3) {
            throw new Error('Username must be at least 3 characters');
          }
          
          if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            throw new Error('Please enter a valid email address');
          }
          
          if (!password || password.length < 8) {
            throw new Error('Password must be at least 8 characters');
          }
          
          const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              username, 
              email, 
              password, 
              fullName: fullName || '' // Ensure fullName is never undefined
            }),
            credentials: 'include', // Important for session cookies
          });
          
          // Safe handling of the response content
          let data;
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            data = await response.json();
          } else {
            // Handle non-JSON responses
            const text = await response.text();
            console.error("Non-JSON response:", text);
            
            // Provide better error message based on status code
            if (response.status === 409) {
              throw new Error("Username or email already exists");
            } else if (response.status === 400) {
              throw new Error("Invalid registration data");
            } else if (response.status >= 500) {
              throw new Error("Server error. Please try again later");
            } else {
              throw new Error("Invalid response from server");
            }
          }
          
          if (!response.ok) {
            throw new Error(data.message || 'Registration failed');
          }
          
          // In a session-based auth, the user data is returned directly
          set({ 
            user: data, 
            token: null, // No token in session-based auth
            isAuthenticated: true, 
            isLoading: false 
          });
          
          // Clear cache and refresh user data
          queryClient.invalidateQueries({ queryKey: ['/api/user'] });
          
          console.log('Registration successful:', data);
        } catch (error) {
          console.error('Registration error:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'An unknown error occurred'
          });
        }
      },
      
      logout: async () => {
        try {
          // First clear local state to ensure UI updates immediately
          set({ user: null, token: null, isAuthenticated: false });
          
          // Clear user-specific cache
          queryClient.invalidateQueries();
          
          // Then try to terminate the session on the server
          const response = await fetch('/api/auth/logout', { 
            method: 'POST',
            credentials: 'include', // Important for session cookies
            // Add a timeout to prevent hanging if server is slow
            signal: AbortSignal.timeout(5000) // 5 second timeout
          });
          
          if (response.ok) {
            console.log('Logout successful on server');
          } else {
            console.warn('Server logout returned status:', response.status);
            // Even if server logout fails, we still want to clear local state
          }
        } catch (error) {
          // Log but don't rethrow errors during logout
          console.error('Error during logout:', error);
          // Even if server logout fails, we still want to clear local state
        }
      },
      
      updateToken: (token) => set({ token }),
      
      updateUser: (user) => set({ user }),
      
      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);

// React hook for auth
export function useAuth() {
  const {
    user,
    token,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    register,
    updateToken,
    updateUser,
    clearError,
  } = useAuthStore();
  
  // Fetch current user session data
  const { isLoading: isFetchingUser } = useQuery({
    queryKey: ['/api/user'],
    queryFn: async () => {
      try {
        // Use direct user endpoint for session validation
        const response = await fetch('/api/user', {
          credentials: 'include'
        });
        
        if (!response.ok) {
          // If not authenticated, clear any existing auth state
          if (response.status === 401) {
            useAuthStore.getState().logout();
            console.log('Session expired or not authenticated');
          }
          return null;
        }
        
        // Update user data from session
        const userData = await response.json();
        updateUser(userData);
        if (!isAuthenticated) {
          // Update auth state directly
          const authStore = useAuthStore.getState();
          useAuthStore.setState({ ...authStore, isAuthenticated: true });
        }
        return userData;
      } catch (error) {
        console.error('Error fetching user session:', error);
        // Clear authentication on session error
        useAuthStore.getState().logout();
        return null;
      }
    },
    // Enable automatic retry for session validation (3 retries with backoff)
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
    // Always refresh session on page load, with broader conditions
    enabled: true,
    // Refresh session data periodically to prevent timeouts
    refetchInterval: 5 * 60 * 1000, // Check session every 5 minutes
    refetchOnWindowFocus: true,     // Also refresh when tab regains focus
  });
  
  // أضف وظيفة تحديث بيانات المستخدم
  const updateUserProfile = async (userData: Partial<User>) => {
    if (!user) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`/api/user/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || 'Failed to update user';
        } catch {
          errorMessage = errorText || 'Failed to update user';
        }
        throw new Error(errorMessage);
      }
      
      const updatedUser = await response.json();
      updateUser(updatedUser);
      return updatedUser;
    } catch (error) {
      console.error('Update user error:', error);
      throw error;
    }
  };

  return {
    user,
    token,
    isAuthenticated,
    isLoading: isLoading || isFetchingUser,
    error,
    login,
    logout,
    register,
    clearError,
    updateUserProfile, // إضافة الوظيفة للعائد
  };
}