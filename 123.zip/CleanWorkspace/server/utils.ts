/**
 * Utility functions for the trading platform
 */

/**
 * Log a message to the console with category and level
 * @param message The message to log
 * @param category The category of the log (e.g. 'server', 'auth', 'db')
 * @param level The log level (e.g. 'info', 'warn', 'error')
 */
export function log(message: string, category = 'server', level = 'info'): void {
  const timestamp = new Date().toLocaleTimeString();
  const prefix = `${timestamp} [${category}]`;
  
  switch (level) {
    case 'warn':
      console.warn(`${prefix} Warning: ${message}`);
      break;
    case 'error':
      console.error(`${prefix} Error: ${message}`);
      break;
    case 'info':
    default:
      console.log(`${prefix} ${message}`);
      break;
  }
}