import { useState, useEffect, useCallback } from 'react';
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from "@/components/ui/carousel";
import { Quote } from 'lucide-react';

export default function TestimonialsCarousel() {
  const testimonials = [
    {
      text: "This platform has completely transformed how I approach trading. The real-time analytics and portfolio management tools are exceptional.",
      author: "Alex Morgan",
      position: "Day Trader",
      location: "New York"
    },
    {
      text: "I've tried many trading platforms, but this one stands out with its intuitive interface and powerful market analysis tools. Highly recommended!",
      author: "Sarah Chen",
      position: "Investment Analyst",
      location: "Singapore"
    },
    {
      text: "The multi-asset trading capabilities have allowed me to diversify my portfolio efficiently. The seamless experience across markets is impressive.",
      author: "Michael Rodriguez",
      position: "Portfolio Manager",
      location: "London"
    },
    {
      text: "As a beginner, I found the platform educational and easy to use. The responsive customer support helped me get started with confidence.",
      author: "Emma Williams",
      position: "Retail Investor",
      location: "Toronto"
    }
  ];

  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  const scrollToIndex = useCallback((index: number) => {
    api?.scrollTo(index);
  }, [api]);

  // Setup the carousel API
  const onSelect = useCallback(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap());
  }, [api]);

  useEffect(() => {
    if (!api) return;
    
    onSelect();
    api.on("select", onSelect);
    
    return () => {
      api.off("select", onSelect);
    };
  }, [api, onSelect]);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      const nextIndex = (current + 1) % testimonials.length;
      scrollToIndex(nextIndex);
    }, 5000);

    return () => clearInterval(interval);
  }, [current, testimonials.length, scrollToIndex]);

  return (
    <section className="py-20 px-4 bg-[#1E2128]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            What Our Traders Say
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join thousands of satisfied traders worldwide
          </p>
        </div>

        <div className="relative">
          <Carousel
            setApi={setApi}
            className="max-w-4xl mx-auto"
          >
            <CarouselContent>
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index}>
                  <div className="bg-[#2A2E39] p-8 md:p-12 rounded-xl text-center">
                    <Quote className="h-12 w-12 text-[#00C06D] mx-auto mb-6" />
                    <p className="text-lg md:text-xl text-white mb-8 italic">
                      "{testimonial.text}"
                    </p>
                    <div>
                      <h4 className="text-[#00C06D] font-semibold text-lg">
                        {testimonial.author}
                      </h4>
                      <p className="text-gray-400">
                        {testimonial.position}, {testimonial.location}
                      </p>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="absolute -left-4 top-1/2 -translate-y-1/2">
              <CarouselPrevious className="bg-[#2A5CFF] text-white border-none hover:bg-[#2145CF]" />
            </div>
            <div className="absolute -right-4 top-1/2 -translate-y-1/2">
              <CarouselNext className="bg-[#2A5CFF] text-white border-none hover:bg-[#2145CF]" />
            </div>
          </Carousel>
        </div>

        <div className="flex justify-center mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => scrollToIndex(index)}
              className={`h-3 w-3 mx-1 rounded-full ${
                current === index ? 'bg-[#00C06D]' : 'bg-gray-600'
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}