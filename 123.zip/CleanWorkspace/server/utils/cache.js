/**
 * In-Memory Cache Utility
 * 
 * Provides a simple in-memory cache with optional expiration for data items
 * to reduce database load and improve performance for frequently accessed data.
 */

/**
 * Simple in-memory cache with expiration
 */
class Cache {
  /**
   * Create a new cache instance
   * @param {string} name - Name of the cache for logging
   * @param {number} maxItems - Maximum number of items to store (defaults to 100)
   * @param {number} defaultTTL - Default time to live in milliseconds (defaults to 30 minutes)
   */
  constructor(name, maxItems = 100, defaultTTL = 30 * 60 * 1000) {
    this.name = name;
    this.maxItems = maxItems;
    this.defaultTTL = defaultTTL;
    this.cache = new Map();
    this.accessOrder = new Map(); // Track access order for LRU
    
    // Setup cleanup interval (every 5 minutes)
    this.cleanupInterval = setInterval(() => this.cleanup(), 5 * 60 * 1000);
    
    console.log(`${new Date().toISOString()} [cache] Cache '${name}' initialized with max ${maxItems} entries and ${defaultTTL / 1000}s TTL`);
  }
  
  /**
   * Get an item from the cache
   * @param {string} key - The cache key
   * @returns {any} The cached value or undefined if not found or expired
   */
  get(key) {
    if (!this.cache.has(key)) {
      return undefined;
    }
    
    const item = this.cache.get(key);
    
    // Check expiration
    if (item.expires < Date.now()) {
      this.delete(key);
      return undefined;
    }
    
    // Update access time for LRU
    this.accessOrder.set(key, Date.now());
    
    return item.value;
  }
  
  /**
   * Set an item in the cache
   * @param {string} key - The cache key
   * @param {any} value - Value to store
   * @param {number} [ttl] - Time to live in milliseconds (optional, uses default if not specified)
   */
  set(key, value, ttl) {
    // Evict oldest item if at capacity
    if (!this.cache.has(key) && this.cache.size >= this.maxItems) {
      this.evictOldest();
    }
    
    const expires = Date.now() + (ttl || this.defaultTTL);
    
    this.cache.set(key, { value, expires });
    this.accessOrder.set(key, Date.now());
    
    return this;
  }
  
  /**
   * Check if the cache contains a key
   * @param {string} key - The cache key
   * @returns {boolean} True if the key exists and is not expired
   */
  has(key) {
    if (!this.cache.has(key)) {
      return false;
    }
    
    const item = this.cache.get(key);
    
    // Check expiration
    if (item.expires < Date.now()) {
      this.delete(key);
      return false;
    }
    
    return true;
  }
  
  /**
   * Delete an item from the cache
   * @param {string} key - The cache key
   */
  delete(key) {
    this.cache.delete(key);
    this.accessOrder.delete(key);
    return this;
  }
  
  /**
   * Clear the entire cache
   */
  clear() {
    this.cache.clear();
    this.accessOrder.clear();
    return this;
  }
  
  /**
   * Get the number of items in the cache
   * @returns {number} The number of cached items
   */
  size() {
    return this.cache.size;
  }
  
  /**
   * Evict the least recently accessed item
   * @private
   */
  evictOldest() {
    if (this.cache.size === 0) return;
    
    let oldestKey = null;
    let oldestTime = Date.now();
    
    for (const [key, time] of this.accessOrder.entries()) {
      if (time < oldestTime) {
        oldestTime = time;
        oldestKey = key;
      }
    }
    
    if (oldestKey) {
      this.delete(oldestKey);
    }
  }
  
  /**
   * Remove expired items from the cache
   * @private
   */
  cleanup() {
    const now = Date.now();
    let removed = 0;
    
    for (const [key, item] of this.cache.entries()) {
      if (item.expires < now) {
        this.delete(key);
        removed++;
      }
    }
    
    if (removed > 0) {
      console.log(`${new Date().toISOString()} [cache] Cache '${this.name}' cleanup: removed ${removed} expired entries`);
    }
  }
  
  /**
   * Dispose of the cache and clear cleanup interval
   */
  dispose() {
    clearInterval(this.cleanupInterval);
    this.clear();
  }
}

export { Cache };