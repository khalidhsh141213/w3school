import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronRight, Zap, Loader2 } from 'lucide-react';
import FeaturedCard from '@/components/dashboard/FeaturedCard';
import { Link } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function MarketOverview() {
  // Fetch all assets
  const { data: assets, isLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const res = await fetch('/api/assets');
      if (!res.ok) throw new Error('Failed to fetch assets');
      return res.json();
    }
  });
  
  // Fetch trending assets specifically
  const { data: trendingAssets, isLoading: isTrendingLoading } = useQuery({
    queryKey: ['/api/assets/trending'],
    queryFn: async () => {
      const res = await fetch('/api/assets/trending');
      if (!res.ok) throw new Error('Failed to fetch trending assets');
      return res.json();
    }
  });
  
  // Safely extract and prepare asset data with null handling
  const prepareAssetData = (asset: any) => {
    if (!asset) return null;
    
    try {
      return {
        id: asset.id,
        name: asset.name || 'Unknown',
        symbol: asset.symbol || '',
        price: typeof asset.price === 'number' ? asset.price : 0,
        priceChange24h: typeof asset.priceChange24h === 'number' ? asset.priceChange24h : 0,
        priceChangePercent: typeof asset.priceChangePercent === 'number' ? asset.priceChangePercent : 0,
        highPrice: asset.highPrice || null,
        lowPrice: asset.lowPrice || null,
        closePrice: asset.closePrice || null,
        volume: asset.volume || null,
        marketCap: asset.marketCap || null,
        volume24h: asset.volume24h || null,
        high24h: asset.high24h || null,
        low24h: asset.low24h || null,
        lastUpdated: asset.lastUpdated || null,
        assetType: asset.assetType || 'unknown'
      };
    } catch (e) {
      console.error("Error preparing asset data:", e);
      return null;
    }
  };
  
  // Helper to get appropriate asset icon based on asset type
  const getAssetIcon = (assetType: string, symbol: string) => {
    // Default path for logo placeholder
    let logoPath = `https://picsum.photos/seed/${symbol}/100/100`;
    
    // Try to use a more specific icon based on asset type and symbol
    if (assetType === 'crypto') {
      logoPath = `https://cryptologos.cc/logos/${symbol.toLowerCase()}-logo.svg?v=025` || logoPath;
    } else if (assetType === 'stock') {
      // You could integrate a stock logo API here
      logoPath = `https://logo.clearbit.com/${symbol.toLowerCase()}.com` || logoPath;
    }
    
    return logoPath;
  };
  
  // Separate assets by type with null handling
  const stocks = assets?.filter((asset: any) => asset?.assetType === 'stock')
    .map(prepareAssetData)
    .filter(Boolean) || [];
    
  const cryptos = assets?.filter((asset: any) => asset?.assetType === 'crypto')
    .map(prepareAssetData)
    .filter(Boolean) || [];
    
  const forex = assets?.filter((asset: any) => asset?.assetType === 'forex')
    .map(prepareAssetData)
    .filter(Boolean) || [];
    
  // Prepare trending assets
  const trending = trendingAssets?.map(prepareAssetData).filter(Boolean) || [];
  
  // Show more assets in each category
  const displayCount = 6; // Increased from 3
  
  return (
    <Card className="shadow-md">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-bold text-textDark">Explore Global Markets</CardTitle>
        <Link href="/discover">
          <Button variant="ghost" size="sm" className="text-accent">
            View All
            <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="trending">
          <TabsList className="mb-4">
            <TabsTrigger value="trending" className="flex items-center">
              <Zap className="h-3.5 w-3.5 mr-1.5" />Trending
            </TabsTrigger>
            <TabsTrigger value="stocks">Stocks</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
            <TabsTrigger value="forex">Forex</TabsTrigger>
          </TabsList>
          
          {/* Trending Assets tab */}
          <TabsContent value="trending" className="mt-0">
            {isTrendingLoading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : trending.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {trending.slice(0, displayCount).map((asset: any) => (
                  <FeaturedCard
                    key={asset.id}
                    title={asset.name}
                    subtitle={asset.symbol}
                    value={asset.price}
                    change={asset.priceChange24h}
                    changePercent={asset.priceChangePercent}
                    imageUrl={getAssetIcon(asset.assetType, asset.symbol)}
                    highPrice={asset.highPrice}
                    lowPrice={asset.lowPrice}
                    closePrice={asset.closePrice}
                    volume={asset.volume}
                    marketCap={asset.marketCap}
                    volume24h={asset.volume24h}
                    high24h={asset.high24h}
                    low24h={asset.low24h}
                    lastUpdated={asset.lastUpdated}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No trending assets available at the moment
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="stocks" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : stocks.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {stocks.slice(0, displayCount).map((asset: any) => (
                  <FeaturedCard
                    key={asset.id}
                    title={asset.name}
                    subtitle={asset.symbol}
                    value={asset.price}
                    change={asset.priceChange24h}
                    changePercent={asset.priceChangePercent}
                    imageUrl={getAssetIcon('stock', asset.symbol)}
                    highPrice={asset.highPrice}
                    lowPrice={asset.lowPrice}
                    closePrice={asset.closePrice}
                    volume={asset.volume}
                    marketCap={asset.marketCap}
                    volume24h={asset.volume24h}
                    high24h={asset.high24h}
                    low24h={asset.low24h}
                    lastUpdated={asset.lastUpdated}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No stock data available
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="crypto" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : cryptos.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cryptos.slice(0, displayCount).map((asset: any) => (
                  <FeaturedCard
                    key={asset.id}
                    title={asset.name}
                    subtitle={asset.symbol}
                    value={asset.price}
                    change={asset.priceChange24h}
                    changePercent={asset.priceChangePercent}
                    imageUrl={getAssetIcon('crypto', asset.symbol)}
                    highPrice={asset.highPrice}
                    lowPrice={asset.lowPrice}
                    closePrice={asset.closePrice}
                    volume={asset.volume}
                    marketCap={asset.marketCap}
                    volume24h={asset.volume24h}
                    high24h={asset.high24h}
                    low24h={asset.low24h}
                    lastUpdated={asset.lastUpdated}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No crypto data available
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="forex" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : forex.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {forex.slice(0, displayCount).map((asset: any) => (
                  <FeaturedCard
                    key={asset.id}
                    title={asset.name}
                    subtitle={asset.symbol}
                    value={asset.price}
                    change={asset.priceChange24h}
                    changePercent={asset.priceChangePercent}
                    imageUrl={getAssetIcon('forex', asset.symbol)}
                    highPrice={asset.highPrice}
                    lowPrice={asset.lowPrice}
                    closePrice={asset.closePrice}
                    volume={asset.volume}
                    marketCap={asset.marketCap}
                    volume24h={asset.volume24h}
                    high24h={asset.high24h}
                    low24h={asset.low24h}
                    lastUpdated={asset.lastUpdated}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No forex data available
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
