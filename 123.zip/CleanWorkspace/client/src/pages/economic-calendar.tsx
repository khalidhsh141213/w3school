import { addDays, addWeeks, endOfMonth, endOfWeek, format, startOfMonth, startOfWeek } from 'date-fns';
import React, { useState } from 'react';
import EventMarketCorrelation from '../components/economic/EventMarketCorrelation';
import EventNotificationSettings from '../components/economic/EventNotificationSettings';
import { MainLayout } from '../components/layout/MainLayout';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { DatePicker } from '../components/ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import useEconomicEvents, { EconomicEvent, EventCategory } from '../hooks/useEconomicEvents';
import { ConnectionStatus } from '../services/WebSocketService';

const CATEGORIES: { label: string; value: EventCategory }[] = [
  { label: 'All Events', value: 'all' },
  { label: 'High Impact', value: 'high_impact' },
  { label: 'Interest Rates', value: 'interest_rate' },
  { label: 'GDP', value: 'gdp' },
  { label: 'Employment', value: 'employment' },
  { label: 'Inflation', value: 'inflation' },
  { label: 'Trade', value: 'trade' },
  { label: 'Consumer', value: 'consumer' },
  { label: 'Housing', value: 'housing' },
  { label: 'Central Bank', value: 'central_bank' },
  { label: 'Earnings', value: 'earnings' },
];

const COUNTRIES = [
  { label: 'All Countries', value: 'all' },
  { label: 'United States', value: 'US' },
  { label: 'Eurozone', value: 'EU' },
  { label: 'United Kingdom', value: 'UK' },
  { label: 'Japan', value: 'JP' },
  { label: 'Canada', value: 'CA' },
  { label: 'Australia', value: 'AU' },
  { label: 'China', value: 'CN' },
];

// Impact level badge component
const ImpactBadge = ({ impact }: { impact: 'low' | 'medium' | 'high' }) => {
  const colors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800'
  };
  
  return (
    <Badge className={colors[impact]}>
      {impact.charAt(0).toUpperCase() + impact.slice(1)}
    </Badge>
  );
};

// Economic event card component
const EventCard = ({ event }: { event: EconomicEvent }) => {
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-md">{event.title}</CardTitle>
          <ImpactBadge impact={event.impact} />
        </div>
        <CardDescription>
          {event.country} | {format(new Date(event.date), 'PPP')}
          {event.time && ` at ${event.time}`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {event.description && <p className="text-sm mb-2">{event.description}</p>}
        <div className="grid grid-cols-3 gap-2 mt-2">
          <div>
            <div className="text-xs text-muted-foreground">Previous</div>
            <div>{event.previous || 'N/A'}{event.unit ? ` ${event.unit}` : ''}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Forecast</div>
            <div>{event.forecast || 'N/A'}{event.unit ? ` ${event.unit}` : ''}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Actual</div>
            <div className="font-medium">
              {event.actual || 'Pending'}{event.unit ? ` ${event.unit}` : ''}
            </div>
          </div>
        </div>
      </CardContent>
      {event.source && (
        <div className="px-6 pb-4 text-xs text-muted-foreground">
          Source: {event.source}
        </div>
      )}
    </Card>
  );
};

// Connection status indicator
const ConnectionStatusIndicator = ({ status }: { status: ConnectionStatus }) => {
  const statusConfig = {
    [ConnectionStatus.CONNECTED]: { 
      color: 'bg-green-500', 
      text: 'Connected'
    },
    [ConnectionStatus.CONNECTING]: { 
      color: 'bg-yellow-500', 
      text: 'Connecting...'
    },
    [ConnectionStatus.DISCONNECTED]: { 
      color: 'bg-red-500', 
      text: 'Disconnected'
    },
    [ConnectionStatus.ERROR]: { 
      color: 'bg-red-500', 
      text: 'Error'
    },
    [ConnectionStatus.RECONNECTING]: { 
      color: 'bg-yellow-500', 
      text: 'Reconnecting...'
    },
  };
  
  const config = statusConfig[status];
  
  return (
    <div className="flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${config.color}`}></div>
      <span className="text-sm">{config.text}</span>
    </div>
  );
};

// Date range preset options
const DATE_RANGE_PRESETS = [
  { label: 'Today', value: 'today', 
    getRange: () => {
      const today = new Date();
      return { start: today, end: today };
    }
  },
  { label: 'This Week', value: 'this-week',
    getRange: () => {
      const today = new Date();
      return {
        start: startOfWeek(today, { weekStartsOn: 1 }),
        end: endOfWeek(today, { weekStartsOn: 1 })
      };
    }
  },
  { label: 'Next Week', value: 'next-week',
    getRange: () => {
      const nextWeek = addWeeks(new Date(), 1);
      return {
        start: startOfWeek(nextWeek, { weekStartsOn: 1 }),
        end: endOfWeek(nextWeek, { weekStartsOn: 1 })
      };
    }
  },
  { label: 'This Month', value: 'this-month',
    getRange: () => {
      const today = new Date();
      return {
        start: startOfMonth(today),
        end: endOfMonth(today)
      };
    }
  },
  { label: 'Next 7 Days', value: 'next-7-days',
    getRange: () => {
      const today = new Date();
      return {
        start: today,
        end: addDays(today, 7)
      };
    }
  },
  { label: 'Next 30 Days', value: 'next-30-days',
    getRange: () => {
      const today = new Date();
      return {
        start: today,
        end: addDays(today, 30)
      };
    }
  },
];

const EconomicCalendarPage: React.FC = () => {
  // State for filters
  const [category, setCategory] = useState<EventCategory>('all');
  const [country, setCountry] = useState('all');
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [view, setView] = useState('calendar');
  
  // Set a date range from preset
  const setDateRangePreset = (presetValue: string) => {
    const preset = DATE_RANGE_PRESETS.find(p => p.value === presetValue);
    if (preset) {
      const { start, end } = preset.getRange();
      setStartDate(start);
      setEndDate(end);
    }
  };
  
  // Use the economic events hook
  const {
    events,
    isLoading,
    error,
    isConnected,
    connectionStatus,
    lastUpdateTime,
    filterByCategory,
    filterByCountry,
    getUpcomingEvents,
    getHighImpactEvents,
    refresh
  } = useEconomicEvents({
    categories: [category],
    pollingInterval: 60000, // 1 minute
    throttleUpdates: 1000,
    cache: {
      enabled: true,
      maxAge: 300000 // 5 minutes
    },
    dateRange: {
      start: startDate,
      end: endDate
    },
    limit: 100
  });
  
  // Apply filters
  let filteredEvents = events;
  
  // If country filter is applied
  if (country !== 'all') {
    filteredEvents = filterByCountry(country);
  }
  
  // Handle errors and loading state
  if (error) {
    return (
      <MainLayout>
        <div className="container mx-auto py-8">
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Economic Calendar</CardTitle>
              <CardDescription>Error loading economic events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 text-center">
                <div className="text-red-500 mb-4">Failed to load economic events: {error.message}</div>
                <Button onClick={() => refresh()}>
                  Retry
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <div className="container mx-auto py-8">
        <Card className="w-full mb-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Economic Calendar</CardTitle>
                <CardDescription>Track economic events and indicators that impact markets</CardDescription>
              </div>
              <ConnectionStatusIndicator status={connectionStatus} />
            </div>
          </CardHeader>
          
          <CardContent>
            {/* Filters */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-3">Filters</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Category</label>
                  <Select value={category} onValueChange={(value) => setCategory(value as EventCategory)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Country</label>
                  <Select value={country} onValueChange={setCountry}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      {COUNTRIES.map((c) => (
                        <SelectItem key={c.value} value={c.value}>
                          {c.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Date Range</label>
                  <Select onValueChange={setDateRangePreset}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select date range" />
                    </SelectTrigger>
                    <SelectContent>
                      {DATE_RANGE_PRESETS.map((preset) => (
                        <SelectItem key={preset.value} value={preset.value}>
                          {preset.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">View</label>
                  <Select value={view} onValueChange={setView}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select view" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="calendar">Calendar</SelectItem>
                      <SelectItem value="list">List</SelectItem>
                      <SelectItem value="upcoming">Upcoming</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Start Date</label>
                  <DatePicker
                    selected={startDate}
                    onSelect={setStartDate}
                    mode="single"
                    disabled={(date) => endDate ? date > endDate : false}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">End Date</label>
                  <DatePicker
                    selected={endDate}
                    onSelect={setEndDate}
                    mode="single"
                    disabled={(date) => startDate ? date < startDate : false}
                  />
                </div>
              </div>
              
              <div className="flex justify-between items-center mt-4">
                <div>
                  {startDate && endDate && (
                    <span className="text-sm text-muted-foreground">
                      Showing events from {format(startDate, 'PP')} to {format(endDate, 'PP')}
                    </span>
                  )}
                </div>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setCategory('all');
                    setCountry('all');
                    setStartDate(undefined);
                    setEndDate(undefined);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            </div>
            
            {/* Last updated text */}
            {lastUpdateTime > 0 && (
              <div className="text-xs text-muted-foreground mb-4">
                Last updated: {format(new Date(lastUpdateTime), 'PPpp')}
                <Button 
                  variant="link"
                  className="ml-2 p-0 h-auto text-xs"
                  onClick={() => refresh()}
                >
                  Refresh
                </Button>
              </div>
            )}
            
            {/* Content based on view selection */}
            {isLoading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : view === 'calendar' ? (
              <div className="space-y-6">
                {/* Group events by date */}
                {Object.entries(
                  filteredEvents.reduce((acc, event) => {
                    const date = format(new Date(event.date), 'yyyy-MM-dd');
                    if (!acc[date]) acc[date] = [];
                    acc[date].push(event);
                    return acc;
                  }, {} as Record<string, EconomicEvent[]>)
                )
                  .sort(([dateA], [dateB]) => new Date(dateA).getTime() - new Date(dateB).getTime())
                  .map(([date, dateEvents]) => (
                    <div key={date}>
                      <h3 className="text-lg font-bold mb-3">
                        {format(new Date(date), 'EEEE, MMMM d, yyyy')}
                      </h3>
                      <div className="space-y-4">
                        {dateEvents.map((event) => (
                          <EventCard key={event.id} event={event} />
                        ))}
                      </div>
                    </div>
                  ))}
                
                {filteredEvents.length === 0 && (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No economic events found matching your filters
                  </div>
                )}
              </div>
            ) : view === 'list' ? (
              <div className="space-y-4">
                {filteredEvents.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
                
                {filteredEvents.length === 0 && (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No economic events found matching your filters
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {getUpcomingEvents(10).map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
                
                {getUpcomingEvents(10).length === 0 && (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No upcoming economic events found
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Market Correlation Analysis */}
        <div className="mt-8">
          <Tabs defaultValue="correlation">
            <TabsList className="mb-6">
              <TabsTrigger value="correlation">Market Impact Analysis</TabsTrigger>
              <TabsTrigger value="notifications">Event Notifications</TabsTrigger>
              <TabsTrigger value="trading">Trading Opportunities</TabsTrigger>
              <TabsTrigger value="insights">Event Insights</TabsTrigger>
            </TabsList>
            
            <TabsContent value="correlation">
              <EventMarketCorrelation 
                initialCategory={category !== 'all' ? category : 'interest_rate'} 
                initialTimeFrame="1d"
              />
            </TabsContent>
            
            <TabsContent value="notifications">
              <EventNotificationSettings />
            </TabsContent>
            
            <TabsContent value="trading">
              <Card>
                <CardHeader>
                  <CardTitle>Trading Opportunities</CardTitle>
                  <CardDescription>
                    Potential trading strategies based on economic events
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10">
                    <p className="text-muted-foreground mb-4">
                      Trading opportunities analysis is coming soon
                    </p>
                    <Button variant="outline">
                      Get Notified When Available
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="insights">
              <Card>
                <CardHeader>
                  <CardTitle>Event Insights</CardTitle>
                  <CardDescription>
                    Expert analysis and historical context for economic events
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10">
                    <p className="text-muted-foreground mb-4">
                      Event insights and analysis is coming soon
                    </p>
                    <Button variant="outline">
                      Get Notified When Available
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

export default EconomicCalendarPage;
