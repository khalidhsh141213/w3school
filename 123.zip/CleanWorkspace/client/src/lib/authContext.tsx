import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// Define types for user and authentication context
interface User {
  id: number;
  username: string;
  email: string;
  verificationLevel: number;
  firstName?: string | null;
  lastName?: string | null;
  profileImage?: string | null;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<User>;
  register: (username: string, email: string, password: string) => Promise<User>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => Promise<User>;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  // التحقق مما إذا كان المستخدم مسجل الدخول بالفعل
  useEffect(() => {
    async function loadUser() {
      try {
        setIsLoading(true);
        
        // استخدام مسار api/user مباشرة للتحقق من حالة المصادقة
        const response = await fetch('/api/user', {
          credentials: 'include'
        });
        
        if (response.ok) {
          // تم المصادقة، قم بتحليل بيانات المستخدم
          const userData = await response.json();
          setUser(userData);
        } else {
          // غير مصادق
          setUser(null);
        }
      } catch (error) {
        // في حالة حدوث خطأ، المستخدم غير مصادق
        console.error('Error loading user:', error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }

    loadUser();
  }, []);

  // Login function
  const login = async (username: string, password: string): Promise<User> => {
    setIsLoading(true);
    try {
      // أولاً، قم باستدعاء نقطة النهاية login
      const loginResponse = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
        credentials: 'include'
      });

      // التحقق من الاستجابة
      if (!loginResponse.ok) {
        const errorText = await loginResponse.text();
        let errorMessage;
        try {
          // محاولة تحليل النص كـ JSON
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || 'Login failed';
        } catch {
          // إذا فشل التحليل، استخدم النص الكامل
          errorMessage = errorText || 'Login failed';
        }
        throw new Error(errorMessage);
      }
      
      // استرداد بيانات المستخدم من الاستجابة
      const userData = await loginResponse.json();
      setUser(userData);
      return userData;
    } catch (error) {
      console.error('Login error:', error);
      const message = error instanceof Error ? error.message : 'Login failed';
      toast({
        title: 'Authentication Error',
        description: message,
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (username: string, email: string, password: string): Promise<User> => {
    setIsLoading(true);
    try {
      // استدعاء نقطة نهاية التسجيل
      const registerResponse = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          username, 
          email, 
          password,
          fullName: username // استخدام اسم المستخدم كاسم أولي
        }),
        credentials: 'include'
      });

      // التحقق من الاستجابة
      if (!registerResponse.ok) {
        const errorText = await registerResponse.text();
        let errorMessage;
        try {
          // محاولة تحليل النص كـ JSON
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || 'Registration failed';
        } catch {
          // إذا فشل التحليل، استخدم النص الكامل
          errorMessage = errorText || 'Registration failed';
        }
        throw new Error(errorMessage);
      }
      
      // استرداد بيانات المستخدم من الاستجابة
      const userData = await registerResponse.json();
      setUser(userData);
      return userData;
    } catch (error) {
      console.error('Registration error:', error);
      const message = error instanceof Error ? error.message : 'Registration failed';
      toast({
        title: 'Registration Error',
        description: message,
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // وظيفة تسجيل الخروج
  const logout = async () => {
    try {
      // استدعاء نقطة نهاية تسجيل الخروج
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      // حتى في حالة الفشل، قم بتنظيف البيانات وإعادة التوجيه
      setUser(null);
      navigate('/');
      
      // رسالة نجاح
      toast({
        title: 'تم تسجيل الخروج',
        description: 'تم تسجيل خروجك بنجاح من المنصة',
      });
    } catch (error) {
      // حتى في حالة حدوث خطأ، قم بتنظيف البيانات وإعادة التوجيه
      console.error('Logout error:', error);
      setUser(null);
      navigate('/');
      
      toast({
        title: 'تم تسجيل الخروج',
        description: 'تم تسجيل خروجك من المنصة',
      });
    }
  };

  // وظيفة تحديث بيانات المستخدم
  const updateUser = async (userData: Partial<User>): Promise<User> => {
    if (!user) throw new Error('لم يتم تسجيل الدخول');
    
    try {
      // استدعاء نقطة نهاية تحديث المستخدم
      const response = await fetch(`/api/user/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
        credentials: 'include'
      });

      // التحقق من الاستجابة
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage;
        try {
          // محاولة تحليل النص كـ JSON
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || 'فشل تحديث بيانات المستخدم';
        } catch {
          // إذا فشل التحليل، استخدم النص الكامل
          errorMessage = errorText || 'فشل تحديث بيانات المستخدم';
        }
        throw new Error(errorMessage);
      }
      
      // استرداد بيانات المستخدم المحدثة
      const updatedUser = await response.json();
      setUser({ ...user, ...updatedUser });
      return updatedUser;
    } catch (error) {
      console.error('Update user error:', error);
      const message = error instanceof Error ? error.message : 'فشل تحديث بيانات المستخدم';
      toast({
        title: 'خطأ في التحديث',
        description: message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  // Create value object
  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    updateUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Custom hook to use auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}