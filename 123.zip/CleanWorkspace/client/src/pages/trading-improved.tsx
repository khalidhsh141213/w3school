import AccountSummary from "@/components/trading/AccountSummary";
import AssetSelector from "@/components/trading/AssetSelector";
import OrderPlacement from "@/components/trading/OrderPlacement";
import PositionsSummary from "@/components/trading/PositionsSummary";
import RealTimeChart from "@/components/trading/RealTimeChart";
import TradeHistory from "@/components/trading/TradeHistory";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { getQueryFn } from "@/lib/queryClient";
import { Asset } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Loader2, RotateCw } from "lucide-react";
import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useWebSocketManager } from "@/hooks/useWebSocketManager";
import { ConnectionStatus, WebSocketMessage } from "@/services/WebSocketManager";

export default function TradingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [marketData, setMarketData] = useState<Record<string, any>>({});
  
  // Determine WebSocket URL
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host || window.location.hostname || '0.0.0.0:5000';
  const wsUrl = `${protocol}//${host}/ws`;
  
  // Use the WebSocket manager hook for standardized connection management
  const { 
    status, 
    connected,
    send,
    subscribe
  } = useWebSocketManager(wsUrl);

  // Fetch available assets
  const { data: assets, isLoading: isLoadingAssets } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Set up WebSocket message processing
  const [lastReceivedMessage, setLastReceivedMessage] = useState<any>(null);
  
  // Subscribe to WebSocket messages
  useEffect(() => {
    // The subscribe function returns an unsubscribe function
    const unsubscribe = subscribe((data) => {
      setLastReceivedMessage(data);
    });
    
    // Clean up subscription when component unmounts
    return unsubscribe;
  }, [subscribe]);
  
  // Process incoming WebSocket messages
  useEffect(() => {
    if (!lastReceivedMessage) return;
    
    try {
      // Messages already come as parsed JSON from the WebSocketManager
      const message = lastReceivedMessage;
      
      if (message.type === "assetList") {
        // Assets received, select first one by default if none selected
        if (!selectedAsset && message.data.length > 0) {
          setSelectedAsset(message.data[0]);
          // Subscribe to price updates for this asset
          send({
            action: "subscribe",
            symbols: [message.data[0].symbol]
          });
        }
      } else if (message.type === "priceUpdate") {
        // Update market data for the symbol
        setMarketData(prevData => ({
          ...prevData,
          [message.data.symbol]: message.data
        }));
      }
    } catch (error) {
      console.error("Error processing WebSocket message:", error);
    }
  }, [lastReceivedMessage, selectedAsset, send]);

  // Request initial assets once connected
  useEffect(() => {
    if (connected) {
      // Get initial asset list once connected
      send({ action: "getAssets" });
    }
  }, [connected, send]);

  // Handle asset selection change
  useEffect(() => {
    if (!connected || !selectedAsset) return;

    // Only unsubscribe if we have any marketData
    if (Object.keys(marketData).length > 0) {
      send({
        action: "unsubscribe",
        symbols: Object.keys(marketData)
      });
    }

    // Subscribe to the new symbol
    send({
      action: "subscribe",
      symbols: [selectedAsset.symbol]
    });
    
    // Clear previous market data to avoid showing stale data
    setMarketData(prevData => {
      const newData = { ...prevData };
      // Keep only the selected asset data if it exists
      if (newData[selectedAsset.symbol]) {
        return { [selectedAsset.symbol]: newData[selectedAsset.symbol] };
      }
      return {};
    });
    
  }, [selectedAsset, connected, send, marketData]);

  // Handle user change
  useEffect(() => {
    if (!user) return;
    
    // Could load user-specific data here like positions, trade history, etc.
  }, [user]);

  if (isLoadingAssets) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>TradePro | Advanced Trading Platform</title>
        <meta name="description" content="Execute trades with real-time charts, advanced order types, and position management for forex and cryptocurrency markets." />
        <meta name="keywords" content="trading, forex, crypto, real-time charts, market data" />
      </Helmet>
      
      <div className="flex flex-col h-full bg-background">
        {/* Full-width Account Summary Bar - Horizontal at the top */}
        <div className="border-b bg-card/60 backdrop-blur-sm sticky top-0 z-20 shadow-sm">
          <div className="container mx-auto">
            <AccountSummary user={user} />
          </div>
        </div>
        
        {/* Connection status - small badge in corner */}
        <div className="fixed top-4 right-4 h-12 flex items-center z-30">
          {connected && (
            <div className="flex items-center text-xs font-medium text-green-600 bg-green-50 border border-green-200 px-2.5 py-1.5 rounded-md shadow-sm transition-all duration-300">
              <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-1.5 animate-pulse" aria-hidden="true"></span>
              Connected
            </div>
          )}
          {status === ConnectionStatus.CONNECTING && (
            <div className="flex items-center text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 px-2.5 py-1.5 rounded-md shadow-sm transition-all duration-300">
              <span className="inline-block w-2 h-2 bg-amber-500 rounded-full mr-1.5 animate-pulse" aria-hidden="true"></span>
              Connecting...
            </div>
          )}
          {(status === ConnectionStatus.DISCONNECTED || status === ConnectionStatus.ERROR) && (
            <div className="flex items-center gap-2">
              <div className="flex items-center text-xs font-medium text-red-600 bg-red-50 border border-red-200 px-2.5 py-1.5 rounded-md shadow-sm transition-all duration-300">
                <span className="inline-block w-2 h-2 bg-red-500 rounded-full mr-1.5" aria-hidden="true"></span>
                {status === ConnectionStatus.ERROR ? "Error" : "Disconnected"}
              </div>
              {/* No manual reconnect button needed - WebSocketManager handles reconnection */}
            </div>
          )}
          {status === ConnectionStatus.CIRCUIT_OPEN && (
            <div className="flex items-center text-xs font-medium text-orange-600 bg-orange-50 border border-orange-200 px-2.5 py-1.5 rounded-md shadow-sm transition-all duration-300">
              <span className="inline-block w-2 h-2 bg-orange-500 rounded-full mr-1.5" aria-hidden="true"></span>
              Circuit Open
            </div>
          )}
          {status === ConnectionStatus.RATE_LIMITED && (
            <div className="flex items-center text-xs font-medium text-yellow-600 bg-yellow-50 border border-yellow-200 px-2.5 py-1.5 rounded-md shadow-sm transition-all duration-300">
              <span className="inline-block w-2 h-2 bg-yellow-500 rounded-full mr-1.5" aria-hidden="true"></span>
              Rate Limited
            </div>
          )}
        </div>

        {/* Main content with improved responsive layout */}
        <div className="container mx-auto px-3 sm:px-4 pb-6 pt-4 flex-1">
          <div className="flex flex-col h-full gap-6">
            {/* Main trading area with chart and sidebar */}
            <div className="flex flex-col lg:flex-row gap-6 h-full">
              {/* Left column with chart - Made wider */}
              <div className="flex-grow order-2 lg:order-1 w-full lg:w-3/4">
                <div className="bg-card rounded-xl shadow-md border overflow-hidden h-[500px] md:h-[600px] lg:h-[550px] transition-all duration-300">
                  <div className="bg-muted/30 border-b p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div className="flex items-center">
                      <h2 className="font-semibold flex items-center">
                        <span className="text-lg mr-2">{selectedAsset?.symbol}</span>
                        <span className="text-muted-foreground text-sm hidden sm:inline">{selectedAsset?.name}</span>
                      </h2>
                    </div>
                    
                    {selectedAsset && marketData[selectedAsset?.symbol] && (
                      <div className="flex items-center">
                        <span className="text-lg font-mono font-medium mr-3">
                          ${marketData[selectedAsset.symbol]?.price?.toLocaleString() || (selectedAsset.price && selectedAsset.price.toLocaleString())}
                        </span>
                        
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                          marketData[selectedAsset.symbol]?.changePercent >= 0 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {(marketData[selectedAsset.symbol]?.changePercent || 0) >= 0 ? '+' : ''}
                          {(marketData[selectedAsset.symbol]?.changePercent || 0).toFixed(2)}%
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <RealTimeChart 
                    selectedAsset={selectedAsset}
                    marketData={selectedAsset && marketData[selectedAsset.symbol] ? marketData[selectedAsset.symbol] : {}}
                  />
                </div>
                
                {/* Add interactive controls */}
                <div className="flex items-center justify-end gap-2 mt-3 mb-2">
                  <button className="text-xs px-3 py-1.5 rounded-md bg-muted hover:bg-muted/80 flex items-center gap-1.5 transition-all duration-200">
                    <span className="inline-block w-1.5 h-1.5 bg-green-500 rounded-full" aria-hidden="true"></span>
                    Live
                  </button>
                  <button className="text-xs px-3 py-1.5 rounded-md border hover:bg-muted/10 flex items-center gap-1.5 transition-all duration-200">
                    1H
                  </button>
                  <button className="text-xs px-3 py-1.5 rounded-md border hover:bg-muted/10 flex items-center gap-1.5 transition-all duration-200">
                    1D
                  </button>
                  <button className="text-xs px-3 py-1.5 rounded-md border hover:bg-muted/10 flex items-center gap-1.5 transition-all duration-200">
                    1W
                  </button>
                  <button className="text-xs px-3 py-1.5 rounded-md border hover:bg-muted/10 flex items-center gap-1.5 transition-all duration-200">
                    1M
                  </button>
                </div>

                {/* Horizontal sections for Open Positions and Trade History */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* Open Positions section - left side on larger screens */}
                  <div className="bg-card rounded-xl shadow-md border p-4 md:h-[350px] overflow-hidden flex flex-col">
                    <h2 className="text-sm font-semibold mb-3 flex items-center justify-between border-b pb-2">
                      <div className="flex items-center">
                        <span className="inline-block w-2 h-2 bg-blue-500 rounded-full mr-2.5" aria-hidden="true"></span>
                        Open Positions
                      </div>
                      <button className="text-xs px-3 py-1.5 rounded-md bg-muted hover:bg-muted/80 flex items-center gap-1.5 transition-all duration-200">
                        <span className="inline-block w-1.5 h-1.5 bg-green-500 rounded-full" aria-hidden="true"></span>
                        Refresh
                      </button>
                    </h2>
                    <div className="overflow-y-auto flex-grow custom-scrollbar">
                      <PositionsSummary 
                        userId={user?.id} 
                        marketData={marketData}
                      />
                    </div>
                  </div>
                  
                  {/* Trade History section - right side on larger screens */}
                  <div className="bg-card rounded-xl shadow-md border p-4 md:h-[350px] overflow-hidden flex flex-col">
                    <h2 className="text-sm font-semibold mb-3 flex items-center justify-between border-b pb-2">
                      <div className="flex items-center">
                        <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mr-2.5" aria-hidden="true"></span>
                        Trade History
                      </div>
                      <button className="text-xs px-3 py-1.5 rounded-md bg-muted hover:bg-muted/80 flex items-center gap-1.5 transition-all duration-200">
                        <span className="inline-block w-1.5 h-1.5 bg-green-500 rounded-full" aria-hidden="true"></span>
                        Refresh
                      </button>
                    </h2>
                    <div className="overflow-y-auto flex-grow custom-scrollbar">
                      <TradeHistory userId={user?.id} />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Right sidebar for asset selection and order placement - Made more compact */}
              <div className="lg:w-1/4 order-1 lg:order-2 flex flex-col gap-6">
                {/* Asset selector - more visual design */}
                <div className="bg-card rounded-xl shadow-md border overflow-hidden">
                  <div className="bg-muted/30 border-b p-3">
                    <h2 className="text-sm font-semibold flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2.5" aria-hidden="true"></span>
                        Select Asset
                      </div>
                      {selectedAsset && (
                        <div className="text-xs font-medium text-muted-foreground px-2 py-0.5 rounded-full bg-muted/50">
                          {selectedAsset.assetType}
                        </div>
                      )}
                    </h2>
                  </div>
                  <div className="p-3">
                    <AssetSelector 
                      assets={assets || []} 
                      selectedAsset={selectedAsset}
                      onAssetChange={setSelectedAsset}
                      marketData={marketData}
                    />
                  </div>
                </div>
              
                {/* Order placement section - more elegant design */}
                <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl shadow-lg border border-gray-700 overflow-hidden">
                  <div className="p-3 border-b border-gray-700">
                    <h2 className="text-sm font-semibold flex items-center justify-between text-white">
                      <div className="flex items-center">
                        <span className="inline-block w-2 h-2 bg-primary rounded-full mr-2.5" aria-hidden="true"></span>
                        Place Order
                      </div>
                      
                      {/* Buy/Sell quick action buttons */}
                      <div className="flex space-x-1.5">
                        <button className="bg-green-500 hover:bg-green-600 text-white text-xs font-medium py-1.5 px-4 rounded-md transition-all duration-200">
                          BUY
                        </button>
                        <button className="bg-red-500 hover:bg-red-600 text-white text-xs font-medium py-1.5 px-4 rounded-md transition-all duration-200">
                          SELL
                        </button>
                      </div>
                    </h2>
                  </div>
                  
                  <div className="p-3">
                    <OrderPlacement 
                      selectedAsset={selectedAsset}
                      marketData={marketData}
                      userId={user?.id}
                    />
                  </div>
                </div>

                {/* Quick Info Card */}
                <div className="bg-card rounded-xl shadow-md border overflow-hidden hidden lg:block">
                  <div className="bg-muted/30 border-b p-3">
                    <h2 className="text-sm font-semibold flex items-center">
                      <span className="inline-block w-2 h-2 bg-blue-500 rounded-full mr-2.5" aria-hidden="true"></span>
                      Market Stats
                    </h2>
                  </div>
                  <div className="p-4">
                    {selectedAsset && (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">24h Volume</span>
                          <span className="font-medium">$23.5M</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">24h High</span>
                          <span className="font-medium text-green-600">$84,250.00</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">24h Low</span>
                          <span className="font-medium text-red-600">$83,450.00</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Market Cap</span>
                          <span className="font-medium">$1.64T</span>
                        </div>
                        <div className="pt-2 border-t">
                          <button className="w-full text-xs text-center text-muted-foreground hover:text-foreground py-1.5 transition-colors">
                            View More Stats
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Custom scrollbar styles */}
        <style dangerouslySetInnerHTML={{
          __html: `
          .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: rgba(155, 155, 155, 0.5);
            border-radius: 20px;
          }
          `
        }} />
      </div>
    </>
  );
}