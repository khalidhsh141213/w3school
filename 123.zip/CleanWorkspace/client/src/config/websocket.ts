/**
 * WebSocket Configuration
 * 
 * Configuration for WebSocket connections including URL construction and options.
 */

// WebSocket URL Configuration
export const getWebSocketUrl = (): string => {
  // Check for environment variable first (highest priority)
  const envWsUrl = import.meta.env.VITE_WS_URL;
  if (envWsUrl) {
    console.log(`[WebSocketConfig] Using WS_URL from environment: ${envWsUrl}`);
    return envWsUrl;
  }
  
  // Fallback to dynamic construction for Replit environment
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  
  // For Replit, we should use the host directly without manually adding the port
  // as the host already includes the domain mapping
  
  // Construct URL
  const wsUrl = `${protocol}//${host}/ws`;
  console.log(`[WebSocketConfig] Dynamically constructed WebSocket URL: ${wsUrl}`);
  
  // Special handling for Replit environment
  if (host.includes('replit.dev') || host.includes('replit.app')) {
    // For Replit environments, use a simplified WebSocket URL structure
    // This helps avoid potential routing issues in the Replit environment
    console.log(`[WebSocketConfig] Using Replit-specific WebSocket URL: ${wsUrl}`);
  }
  
  return wsUrl;
};

// Default WebSocket Options 
export const DEFAULT_WS_OPTIONS = {
  reconnectAttempts: 5,
  reconnectInterval: 3000, // 3 seconds
  heartbeatInterval: 30000, // 30 seconds
  heartbeatTimeout: 60000, // 1 minute
  
  // Circuit breaker options
  circuitBreaker: {
    enabled: true,
    failureThreshold: 3,
    resetTimeout: 30000 // 30 seconds
  },
  
  // Rate limiter options
  rateLimiter: {
    enabled: true,
    maxOperations: 20, // 20 messages
    windowMs: 1000, // per second
    queueExceeded: true,
    maxQueueSize: 100,
    priorityBasedQueue: true
  }
};

/**
 * Get WebSocket URL for a specific endpoint
 * @param endpoint Optional endpoint to append to the base URL
 * @returns Full WebSocket URL
 */
export const getWebSocketEndpointUrl = (endpoint?: string): string => {
  const baseUrl = getWebSocketUrl();
  
  if (!endpoint) {
    return baseUrl;
  }
  
  // Handle various endpoint formats
  if (endpoint.startsWith('/')) {
    // Endpoint starts with a slash, so append it directly
    return `${baseUrl}${endpoint}`;
  } else if (baseUrl.endsWith('/')) {
    // Base URL already has a trailing slash
    return `${baseUrl}${endpoint}`;
  } else {
    // Need to add a separator
    return `${baseUrl}/${endpoint}`;
  }
};