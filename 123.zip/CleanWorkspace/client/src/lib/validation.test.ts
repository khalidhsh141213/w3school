import { describe, expect, it } from 'vitest';
import {
    array,
    boolean,
    date,
    enumValue,
    literal,
    marketDataValidator,
    number,
    object,
    oneOf,
    optional,
    string,
    userValidator,
    validateApiResponse,
    ValidationError
} from './validation';

describe('Validation Utilities', () => {
  describe('Basic Validators', () => {
    it('string validator should validate strings', () => {
      expect(string('test')).toBe('test');
      expect(() => string(123)).toThrow(ValidationError);
      expect(() => string(null)).toThrow(ValidationError);
      expect(() => string(undefined)).toThrow(ValidationError);
    });

    it('number validator should validate numbers', () => {
      expect(number(123)).toBe(123);
      expect(number(0)).toBe(0);
      expect(number(-1.5)).toBe(-1.5);
      expect(() => number('123')).toThrow(ValidationError);
      expect(() => number(NaN)).toThrow(ValidationError);
      expect(() => number(null)).toThrow(ValidationError);
    });

    it('boolean validator should validate booleans', () => {
      expect(boolean(true)).toBe(true);
      expect(boolean(false)).toBe(false);
      expect(() => boolean('true')).toThrow(ValidationError);
      expect(() => boolean(1)).toThrow(ValidationError);
      expect(() => boolean(null)).toThrow(ValidationError);
    });

    it('date validator should validate dates', () => {
      const now = new Date();
      expect(date(now)).toBe(now);
      expect(date('2023-01-01T00:00:00Z').getTime()).toBe(new Date('2023-01-01T00:00:00Z').getTime());
      expect(() => date('invalid date')).toThrow(ValidationError);
      expect(() => date(123)).toThrow(ValidationError);
      expect(() => date(null)).toThrow(ValidationError);
    });
  });

  describe('Object Validator', () => {
    it('should validate objects with the specified shape', () => {
      const personValidator = object({
        name: string,
        age: number,
        isActive: boolean
      });

      const validPerson = { name: 'John', age: 30, isActive: true };
      expect(personValidator(validPerson)).toEqual(validPerson);

      expect(() => personValidator({ name: 'John', age: '30', isActive: true })).toThrow(ValidationError);
      expect(() => personValidator({ name: 'John', isActive: true })).toThrow(ValidationError);
      expect(() => personValidator(null)).toThrow(ValidationError);
      expect(() => personValidator('not an object')).toThrow(ValidationError);
    });

    it('should include the path in the error message', () => {
      const personValidator = object({
        name: string,
        address: object({
          city: string,
          zipCode: number
        })
      });

      try {
        personValidator({ name: 'John', address: { city: 'New York', zipCode: 'invalid' } });
        // Should not reach here
        expect(true).toBe(false);
      } catch (error) {
        expect(error).toBeInstanceOf(ValidationError);
        expect(error.path).toBe('address.zipCode');
      }
    });
  });

  describe('Array Validator', () => {
    it('should validate arrays of the specified type', () => {
      const numberArrayValidator = array(number);

      expect(numberArrayValidator([1, 2, 3])).toEqual([1, 2, 3]);
      expect(() => numberArrayValidator(['1', 2, 3])).toThrow(ValidationError);
      expect(() => numberArrayValidator(null)).toThrow(ValidationError);
      expect(() => numberArrayValidator(123)).toThrow(ValidationError);
    });

    it('should validate arrays of objects', () => {
      const userArrayValidator = array(
        object({
          id: string,
          name: string
        })
      );

      const validUsers = [
        { id: '1', name: 'John' },
        { id: '2', name: 'Jane' }
      ];

      expect(userArrayValidator(validUsers)).toEqual(validUsers);
      expect(() => userArrayValidator([{ id: 1, name: 'John' }])).toThrow(ValidationError);
    });
  });

  describe('Optional Validator', () => {
    it('should allow undefined and null values', () => {
      const optionalStringValidator = optional(string);

      expect(optionalStringValidator('test')).toBe('test');
      expect(optionalStringValidator(undefined)).toBe(undefined);
      expect(optionalStringValidator(null)).toBe(undefined);
      expect(() => optionalStringValidator(123)).toThrow(ValidationError);
    });

    it('should work with complex validators', () => {
      const userValidator = object({
        id: string,
        name: string,
        email: optional(string)
      });

      expect(userValidator({ id: '1', name: 'John' })).toEqual({ id: '1', name: 'John', email: undefined });
      expect(userValidator({ id: '1', name: 'John', email: 'john@example.com' })).toEqual({
        id: '1',
        name: 'John',
        email: 'john@example.com'
      });
      expect(() => userValidator({ id: '1', name: 'John', email: 123 })).toThrow(ValidationError);
    });
  });

  describe('Union Validator', () => {
    it('should validate values of different types', () => {
      const stringOrNumber = oneOf([string, number]);

      expect(stringOrNumber('test')).toBe('test');
      expect(stringOrNumber(123)).toBe(123);
      expect(() => stringOrNumber(true)).toThrow(ValidationError);
      expect(() => stringOrNumber(null)).toThrow(ValidationError);
    });

    it('should work with complex validators', () => {
      const userOrId = oneOf([
        string,
        object({
          id: string,
          name: string
        })
      ]);

      expect(userOrId('user-123')).toBe('user-123');
      expect(userOrId({ id: 'user-123', name: 'John' })).toEqual({ id: 'user-123', name: 'John' });
      expect(() => userOrId(123)).toThrow(ValidationError);
    });
  });

  describe('Literal Validator', () => {
    it('should validate exact values', () => {
      const statusOk = literal('OK');
      const statusCode200 = literal(200);
      const isEnabled = literal(true);

      expect(statusOk('OK')).toBe('OK');
      expect(statusCode200(200)).toBe(200);
      expect(isEnabled(true)).toBe(true);

      expect(() => statusOk('NOT_OK')).toThrow(ValidationError);
      expect(() => statusCode200(404)).toThrow(ValidationError);
      expect(() => isEnabled(false)).toThrow(ValidationError);
    });
  });

  describe('Enum Validator', () => {
    it('should validate values from a set of options', () => {
      const statusValidator = enumValue(['pending', 'approved', 'rejected'] as const);

      expect(statusValidator('pending')).toBe('pending');
      expect(statusValidator('approved')).toBe('approved');
      expect(statusValidator('rejected')).toBe('rejected');
      expect(() => statusValidator('unknown')).toThrow(ValidationError);
      expect(() => statusValidator(123)).toThrow(ValidationError);
    });

    it('should work with enums', () => {
      enum Status {
        Pending = 'pending',
        Approved = 'approved',
        Rejected = 'rejected'
      }

      const statusValidator = enumValue(Status);

      expect(statusValidator('pending')).toBe('pending');
      expect(statusValidator('approved')).toBe('approved');
      expect(() => statusValidator('unknown')).toThrow(ValidationError);
    });
  });

  describe('validateApiResponse', () => {
    it('should return the validated response if valid', () => {
      const validator = object({
        id: string,
        name: string
      });

      const response = { id: '123', name: 'John' };
      expect(validateApiResponse(response, validator)).toEqual(response);
    });

    it('should return null if validation fails', () => {
      const validator = object({
        id: string,
        name: string
      });

      const response = { id: 123, name: 'John' };
      expect(validateApiResponse(response, validator)).toBeNull();
    });

    it('should call the error handler if validation fails', () => {
      const validator = object({
        id: string,
        name: string
      });

      const response = { id: 123, name: 'John' };
      let errorHandled = false;
      
      const result = validateApiResponse(response, validator, (error) => {
        errorHandled = true;
        expect(error).toBeInstanceOf(ValidationError);
        expect(error.path).toBe('id');
      });
      
      expect(result).toBeNull();
      expect(errorHandled).toBe(true);
    });
  });

  describe('Example Validators', () => {
    it('should validate market data', () => {
      const validMarketData = {
        symbol: 'BTC-USD',
        price: 50000,
        volume: 1000,
        high: 51000,
        low: 49000,
        open: 49500,
        close: 50000,
        changePercent: 1.01,
        timestamp: '2023-01-01T12:00:00Z'
      };

      expect(marketDataValidator(validMarketData)).toEqual(validMarketData);
      
      const invalidMarketData = {
        symbol: 'BTC-USD',
        price: '50000', // Invalid type
        volume: 1000,
        high: 51000,
        low: 49000,
        open: 49500,
        close: 50000,
        changePercent: 1.01,
        timestamp: '2023-01-01T12:00:00Z'
      };

      expect(() => marketDataValidator(invalidMarketData)).toThrow(ValidationError);
    });

    it('should validate user data', () => {
      const validUser = {
        id: 'user-123',
        username: 'johndoe',
        email: 'john@example.com',
        fullName: 'John Doe',
        role: 'user',
        createdAt: '2023-01-01T00:00:00Z',
        updatedAt: '2023-01-02T00:00:00Z',
        preferences: {
          theme: 'dark',
          language: 'en',
          notifications: {
            email: true,
            push: false,
            sms: true
          },
          defaultLeverage: 2,
          riskLevel: 'medium'
        }
      };

      expect(userValidator(validUser)).toEqual(validUser);

      // Test with minimal required fields
      const minimalUser = {
        id: 'user-123',
        username: 'johndoe',
        email: 'john@example.com',
        role: 'user',
        createdAt: '2023-01-01T00:00:00Z',
        updatedAt: '2023-01-02T00:00:00Z'
      };

      expect(userValidator(minimalUser)).toEqual(minimalUser);

      // Test with invalid role
      const userWithInvalidRole = {
        ...validUser,
        role: 'superadmin' // Invalid role
      };

      expect(() => userValidator(userWithInvalidRole)).toThrow(ValidationError);
    });
  });
}); 