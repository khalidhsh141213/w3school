import React, { useState } from 'react';
import ApiClientExample from './ApiClientExample';
import WebSocketExample from './WebSocketExample';
import EconomicEventsExample from './EconomicEventsExample';

// Import CSS
import '../../styles/ApiClientExample.css';
import '../../styles/Examples.css';
import '../../styles/WebSocketExample.css';

/**
 * Example types
 */
type ExampleType = 'api-client' | 'websocket' | 'economic-events';

/**
 * Examples component
 * 
 * A component that showcases various examples of our implementation
 */
const Examples: React.FC = () => {
  const [activeExample, setActiveExample] = useState<ExampleType>('api-client');
  
  // Handle tab click
  const handleTabClick = (example: ExampleType) => {
    setActiveExample(example);
  };
  
  return (
    <div className="examples-container">
      <div className="examples-header">
        <h1>Trading App Examples</h1>
        <p>
          This page showcases examples of our implementation components and services.
          Select a tab below to view different examples.
        </p>
      </div>
      
      <div className="examples-tabs">
        <button 
          className={`tab ${activeExample === 'api-client' ? 'active' : ''}`}
          onClick={() => handleTabClick('api-client')}
        >
          API Client
        </button>
        <button 
          className={`tab ${activeExample === 'websocket' ? 'active' : ''}`}
          onClick={() => handleTabClick('websocket')}
        >
          WebSocket
        </button>
        <button 
          className={`tab ${activeExample === 'economic-events' ? 'active' : ''}`}
          onClick={() => handleTabClick('economic-events')}
        >
          Economic Events
        </button>
      </div>
      
      <div className="examples-content">
        {activeExample === 'api-client' && <ApiClientExample />}
        {activeExample === 'websocket' && <WebSocketExample />}
        {activeExample === 'economic-events' && <EconomicEventsExample />}
      </div>
    </div>
  );
};

export default Examples; 