# خريطة بنية التطبيق

تقدم هذه الوثيقة خريطة تفصيلية وهندسة شاملة لتطبيق إدارة الأحداث الاقتصادية. توضح الخريطة:
- مسارات التطبيق (Client)
- الخادم (Server) ونقاط النهاية الخاصة به (API Endpoints)
- قاعدة البيانات والعلاقات بين الجداول
- المكتبات والأدوات المستخدمة

---

## 1. البنية العامة للتطبيق

```mermaid
flowchart TD
    subgraph Frontend [واجهة المستخدم (Client)]
        A1[React + TypeScript]
        A2[مكونات UI (Shadcn UI, Tailwind CSS)]
        A3[هوكس (Hooks) ومكتبات (Lib)]
        A4[Routes & Pages]
    end

    subgraph Backend [الخادم (Server)]
        B1[Express.js & Node.js]
        B2[API Endpoints]
        B3[Middleware & Authentication]
        B4[خدمات (Services)]
        B5[WebSocket Communication]
    end

    subgraph Database [قاعدة البيانات]
        C1[economic_events]
        C2[market_correlations]
        C3[جداول إضافية (مثل users, notifications)]
    end

    subgraph External [مصادر خارجية]
        D1[APIs خارجية (بيانات اقتصادية، Polygon API)]
    end

    %% Frontend to Backend
    A4 -->|استدعاء API| B2
    A3 --> A4
    A1 --> A2
    A2 --> A3

    %% Backend to Database
    B2 -->|عمليات CRUD| C1
    B2 -->|عمليات التحليل| C2
    B4 -->|معالجة البيانات| C1
    B4 -->|تنبيهات ومراسلات| C2

    %% Backend to External
    B4 -->|جلب البيانات| D1

    %% WebSocket
    B5 -- تبادل بيانات --> A4

    %% ملحقات أخرى
    D1 --> B4
```

---

## 2. تفصيل المكونات

### 2.1 واجهة المستخدم (Client)
- **التقنيات**: تستخدم React مع TypeScript.
- **المكونات**:
  - **الصفحات (Pages)**: مثل صفحات الأحدث الاقتصادية وDashboard وPortfolio وغيرها.
  - **المكونات (Components)**: عبارة عن وحدات UI منظمة في مجلدات مثل:
    - **admin**: واجهة الإدارة (تمت إزالتها إذا كانت غير مستخدمة).
    - **auth**: نماذج تسجيل الدخول والتسجيل.
    - **dashboard, economic, trading, landing, wallet، ...**
  - **الهوكس (Hooks)**: تلتقط بيانات مثل الاستخدام من API والتواصل عبر WebSocket مثل: useEconomicEvents, useWebSocketManager وغيرها.
  - **المكتبات (Lib)**: تحتوي على وظائف المساعدة مثل: auth, i18n, queryClient, validation.

### 2.2 الخادم (Server)
- **التقنيات**: Node.js مع Express.js و TypeScript.
- **نقاط النهاية (API Endpoints)**:
  - **الأحداث الاقتصادية**: على سبيل المثال، `/api/economic-events` لتقديم بيانات الأحداث الاقتصادية.
  - **التداول (Trade)**: مثل `/api/trade` لتقديم أو معالجة بيانات التداول.
  - **الذكاء الاصطناعي**: نقاط نهاية خاصة بعمليات الذكاء الاصطناعي (إذا وجدت) مثل DeepSeek أو API الخاصة بتحليل السوق.
  - **التحقق وإدارة المستخدم**: من خلال Middleware مثل الـ auth وجلسات المستخدم.
- **الخدمات (Services)**:
  - **خدمة الأحداث الاقتصادية**: تتعامل مع البيانات وتحديثها.
  - **خدمة السوق (Market Data Service)**: مسؤولة عن جلب وتحليل بيانات السوق.
  - **خدمات WebSocket**: تدير الاتصالات الفورية بين الخادم والعميل.
- **التعامل مع البيانات**:
  - تُستخدم Drizzle لإجراء عمليات قاعدة البيانات (CRUD) على جداول اقتصادية مثل `economic_events` و `market_correlations`.

### 2.3 قاعدة البيانات
- **الجداول الأساسية**:
  - **economic_events**: يخزن بيانات الأحداث الاقتصادية مثل:
    - **العناصر**: id، title، description، date، time، country، category، impact، previous، forecast، actual، unit، source، created_at، updated_at.
  - **market_correlations**: لتخزين نتائج التحليل والارتباط بين الأحداث والأصول، مع حقول مثل correlation_score، average_impact، significance_level، sample_size، direction، time_frame.
- **العلاقات**:
  - علاقة 1 إلى متعدد بين **economic_events** و **market_correlations**.
- **عمليات الكتابة**:
  - تُنفذ عمليات (INSERT، UPDATE، DELETE) من خلال خدمات الخادم باستخدام Drizzle ORM.
  - يتضمن التحقق من صحة البيانات (Validation) قبل الكتابة.

---

## 3. تدفق البيانات ونقاط النهاية

1. **تدفق البيانات في الواجهة الأمامية (Client)**
   - يقوم المستخدم بالتفاعل مع الصفحات والمكونات.
   - الهوكس تتصل بنقاط النهاية لجلب البيانات (باستخدام fetch أو axios).
   - يتم استقبال التحديثات في الوقت الحقيقي عبر WebSocket.

2. **تدفق البيانات في الخادم (Backend)**
   - نقاط النهاية (API) تتلقى الطلبات من الواجهة الأمامية.
   - يتم معالجة الطلب عن طريق Middleware للتحقق والأمان.
   - تستدعي خدمات الخادم البيانات من مصادر خارجية (APIs) وتقوم بالكتابة إلى قاعدة البيانات.
   - تُرسل تغييرات فورية عبر WebSocket عند تحديث البيانات.

3. **التعامل مع قاعدة البيانات**
   - يتم تنفيذ الاستعلامات والعمليات باستخدام Drizzle ORM.
   - تُقيم عمليات التحقق والتحديث لضمان اتساق البيانات.
   - العلاقات بين الجداول تساعد في الربط بين الأحداث الاقتصادية ونتائج التحليل.

---

## 4. المكتبات والأدوات المستخدمة

- **Frontend**:
  - React, TypeScript
  - Tailwind CSS, Shadcn UI
  - هوكس خاصة لإدارة الحالة والتواصل عبر WebSocket مثل useEconomicEvents و useWebSocketManager
- **Backend**:
  - Node.js, Express.js, TypeScript
  - Drizzle ORM لإدارة قاعدة البيانات
  - WebSocket Communication لتحديثات البيانات الفورية
- **قاعدة البيانات**:
  - PostgreSQL

---

## 5. نقاط النهاية الرئيسية

- **GET /api/economic-events**: إسترجاع بيانات الأحداث الاقتصادية.
- **POST /api/economic-events**: إضافة حدث اقتصادي جديد.
- **PUT /api/economic-events/:id**: تحديث بيانات حدث اقتصادي معين.
- **DELETE /api/economic-events/:id**: حذف حدث اقتصادي.
- بالإضافة إلى نقاط نهاية للتداول، والتحليلات، وعمليات WebSocket لتحديثات الوقت الحقيقي.

---

هذه الخريطة الشاملة تُقدم نظرة واضحة على كافة جوانب التطبيق من الواجهة الأمامية إلى الخادم وقاعدة البيانات، مما يسهل على أي مطور فهم النظام بالكامل والبدء في الصيانة أو التطوير دون لبس.
