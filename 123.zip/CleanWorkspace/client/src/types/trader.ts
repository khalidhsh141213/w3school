// Define TypeScript interfaces for trader data
export interface PortfolioItem {
  symbol: string;
  name: string;
  percentage: number;
  change: number;
  currentPrice?: number;
}

export interface Trader {
  id: number;
  name: string;
  description: string;
  avatarUrl: string;
  verified: boolean;
  featured: boolean;
  performance: number;
  lastMonthPerformance: number;
  lastWeekPerformance: number;
  followers: number;
  risk: string;
  portfolio: PortfolioItem[];
}

export interface WebSocketMessage {
  type: string;
  symbol?: string;
  price?: number;
  changePercent?: number;
  data?: any;
}

export interface TraderCardProps {
  trader: Trader;
  updatedPrices?: Record<string, number>;
}