import AdminLayout from "@/components/admin/AdminLayout";
import AuditLogViewer from "@/components/admin/AuditLogViewer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import {
    AlertTriangle,
    DollarSign,
    Eye,
    FileText,
    ShieldAlert,
    UserX
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

export default function AdminActivityLogPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [selectedTab, setSelectedTab] = useState("audit");
  const [isLoading, setIsLoading] = useState(false);

  // Check if user is admin, if not redirect to dashboard
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access the admin panel.",
        variant: "destructive"
      });
      location("/dashboard");
    }
  }, [user, location, toast]);

  if (!user || isLoading) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-6 max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-[600px] w-full" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <Helmet>
        <title>Activity Log | Admin Portal</title>
      </Helmet>

      <div className="container mx-auto p-4 space-y-6 max-w-6xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Activity Log</h1>
            <p className="text-muted-foreground">Track and review all actions taken on the platform</p>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsLoading(true)}
            >
              <FileText className="h-4 w-4 mr-2" />
              Download Report
            </Button>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
          <TabsList className="grid grid-cols-1 md:grid-cols-3 h-auto">
            <TabsTrigger value="audit" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <FileText className="h-4 w-4 mr-2" />
              Admin Logs
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <ShieldAlert className="h-4 w-4 mr-2" />
              Security Logs
            </TabsTrigger>
            <TabsTrigger value="notifications" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Important Events
            </TabsTrigger>
          </TabsList>

          {/* Main Admin Audit Log Tab */}
          <TabsContent value="audit">
            <AuditLogViewer />
          </TabsContent>

          {/* Security Events Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Security Event Log</CardTitle>
                <CardDescription>All login attempts and suspicious activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12">
                  <ShieldAlert className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Loading security logs</h3>
                  <p className="text-sm text-muted-foreground text-center max-w-md">
                    Security logs will be available soon. This includes failed login attempts, 
                    two-factor authentication issues, and unauthorized access attempts.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Important Events Tab */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Important Events</CardTitle>
                <CardDescription>Alerts and notifications that require your attention</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border rounded-md p-4 flex items-start space-x-4 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-900">
                  <UserX className="h-6 w-6 text-yellow-600 dark:text-yellow-400 flex-shrink-0" />
                  <div className="flex-1">
                    <h4 className="font-medium">Alert: Multiple failed login attempts</h4>
                    <p className="text-sm text-muted-foreground">There are 5 failed login attempts for admin account "admin" from IP address 185.22.154.87</p>
                    <div className="text-xs text-muted-foreground mt-1">35 minutes ago</div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </div>
                
                <div className="border rounded-md p-4 flex items-start space-x-4 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900">
                  <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400 flex-shrink-0" />
                  <div className="flex-1">
                    <h4 className="font-medium">Alert: Unusual activity detected</h4>
                    <p className="text-sm text-muted-foreground">Multiple attempts to access restricted API endpoints from unknown IP address detected</p>
                    <div className="text-xs text-muted-foreground mt-1">2 hours ago</div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </div>
                
                <div className="border rounded-md p-4 flex items-start space-x-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-900">
                  <DollarSign className="h-6 w-6 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <div className="flex-1">
                    <h4 className="font-medium">Alert: Large withdrawal requires approval</h4>
                    <p className="text-sm text-muted-foreground">A withdrawal request exceeding $10,000 is awaiting admin approval</p>
                    <div className="text-xs text-muted-foreground mt-1">5 hours ago</div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
} 