"use client";

import AdminLayout from "@/components/admin/AdminLayout";
import SystemStatus from "@/components/admin/SystemStatus";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/authContext";
import { getQueryFn } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import {
    Activity,
    AlertTriangle,
    Database,
    DollarSign,
    LineChart,
    List,
    Settings,
    ShieldCheck,
    Users
} from "lucide-react";
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [showSystemStatus, setShowSystemStatus] = useState(false);
  
  // Check if user is admin, if not redirect to home
  useEffect(() => {
    if (user && user.userRole !== "admin") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access this page.",
        variant: "destructive"
      });
      location("/");
    }
  }, [user, location, toast]);

  // Fetch dashboard metrics
  const { data: metrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ["/api/admin/metrics"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user && user.userRole === "admin",
  });

  // Sample data while API is built
  const dashboardData = metrics || {
    totalUsers: 1254,
    activeUsers: 876,
    totalTrades: 8765,
    openTrades: 423,
    totalAssets: 87,
    pendingKyc: 15,
    pendingDeposits: 8,
    pendingWithdrawals: 12,
    tradeVolume: {
      today: 854621,
      weekly: 4235689,
      monthly: 12568943
    },
    userGrowth: {
      data: [23, 34, 56, 78, 45, 67, 89],
      labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    }
  };

  // Navigation cards for quick access to admin sections
  const adminSections = [
    { 
      title: "User Management", 
      description: "View and manage user accounts", 
      icon: <Users className="h-5 w-5" />, 
      path: "/admin/users",
      count: dashboardData.totalUsers,
      color: "from-blue-600 to-indigo-600" 
    },
    { 
      title: "Asset Management", 
      description: "Manage tradable assets and symbols", 
      icon: <Database className="h-5 w-5" />, 
      path: "/admin/assets",
      count: dashboardData.totalAssets,
      color: "from-emerald-600 to-teal-600"
    },
    { 
      title: "Trade Management", 
      description: "Monitor and manage active trades", 
      icon: <Activity className="h-5 w-5" />, 
      path: "/admin/trades",
      count: dashboardData.totalTrades,
      color: "from-violet-600 to-purple-600"
    },
    { 
      title: "Financial Control", 
      description: "Manage deposits and withdrawals", 
      icon: <DollarSign className="h-5 w-5" />, 
      path: "/admin/finances",
      count: dashboardData.pendingDeposits + dashboardData.pendingWithdrawals,
      color: "from-orange-600 to-amber-600" 
    },
    { 
      title: "KYC Verification", 
      description: "Review and approve user verifications", 
      icon: <ShieldCheck className="h-5 w-5" />, 
      path: "/admin/kyc",
      count: dashboardData.pendingKyc,
      color: "from-sky-600 to-cyan-600"
    },
    { 
      title: "Platform Settings", 
      description: "Configure system settings and parameters", 
      icon: <Settings className="h-5 w-5" />, 
      path: "/admin/settings",
      color: "from-gray-600 to-gray-700"
    },
  ];

  // Main metrics for the dashboard
  const keyMetrics = [
    { 
      title: "Total Users", 
      value: dashboardData.totalUsers, 
      description: `${dashboardData.activeUsers} active users`,
      icon: <Users className="h-4 w-4 text-blue-500" />,
      change: "+12.5%",
      changeType: "positive"
    },
    { 
      title: "Open Trades", 
      value: dashboardData.openTrades, 
      description: `${dashboardData.totalTrades} total trades`,
      icon: <LineChart className="h-4 w-4 text-purple-500" />,
      change: "+5.2%",
      changeType: "positive"
    },
    { 
      title: "Pending Deposits", 
      value: dashboardData.pendingDeposits, 
      description: `$${(dashboardData.tradeVolume.today / 1000).toFixed(1)}k daily volume`,
      icon: <DollarSign className="h-4 w-4 text-green-500" />,
      change: "-2.1%",
      changeType: "negative"
    },
    { 
      title: "Pending KYC", 
      value: dashboardData.pendingKyc, 
      description: "Verification requests",
      icon: <ShieldCheck className="h-4 w-4 text-orange-500" />,
      change: "+8.3%",
      changeType: "positive"
    },
  ];

  if (!user || isLoadingMetrics) {
    return (
      <AdminLayout>
        <div className="container mx-auto p-4 space-y-6 max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            {Array(4).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            {Array(6).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </AdminLayout>
    );
  }

  // If user is not admin, don't render the page
  if (user.userRole !== "admin") {
    return null;
  }

  return (
    <AdminLayout>
      <Helmet>
        <title>Admin Dashboard | TradePro</title>
      </Helmet>

      <div className="container mx-auto p-4 space-y-6 max-w-6xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage and monitor your trading platform</p>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant={showSystemStatus ? "default" : "outline"} 
              size="sm"
              onClick={() => setShowSystemStatus(!showSystemStatus)}
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              System Status
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => location("/admin/activity-log")}
            >
              <List className="h-4 w-4 mr-2" />
              Activity Log
            </Button>
          </div>
        </div>

        {/* System Status Panel */}
        {showSystemStatus && (
          <div className="mb-6">
            <SystemStatus />
          </div>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {keyMetrics.map((metric, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground flex items-center">
                      {metric.icon}
                      <span className="ml-1.5">{metric.title}</span>
                    </p>
                    <h3 className="text-2xl font-bold mt-2">{metric.value.toLocaleString()}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{metric.description}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    metric.changeType === "positive" 
                      ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" 
                      : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                  }`}>
                    {metric.change}
                  </span>
                </div>
                <div className="mt-4">
                  <Progress value={75} className="h-1.5" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Access Navigation Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
          {adminSections.map((section, index) => (
            <a 
              key={index} 
              href={section.path}
              className="group block"
            >
              <div className="border border-border rounded-lg overflow-hidden transition-all duration-200 hover:shadow-md hover:border-primary/50 h-full">
                <div className={`bg-gradient-to-r ${section.color} h-2`}></div>
                <div className="p-5">
                  <div className="flex justify-between items-start">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      {section.icon}
                    </div>
                    {section.count !== undefined && (
                      <span className="bg-primary/10 text-primary text-xs rounded-full px-2 py-1 font-medium">
                        {section.count.toLocaleString()}
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold mt-4 group-hover:text-primary transition-colors">
                    {section.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {section.description}
                  </p>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
} 