"use client";

import EmptyStateView from "@/components/portfolio/EmptyStateView";
import { DetailedPortfolioSummary } from "@/components/portfolio/DetailedPortfolioSummary";
import OpenPositionsTable from "@/components/portfolio/OpenPositionsTable";
import OrdersTabs from "@/components/portfolio/OrdersTabs";
import PortfolioSummaryBar from "@/components/portfolio/PortfolioSummaryBar";
import PortfolioSummaryWidget from "@/components/portfolio/PortfolioSummaryWidget";
import { Button } from '@/components/ui/button';
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolioData } from "@/hooks/use-portfolio-data";
import { useAuth } from "@/lib/authContext";
import { formatCurrency, formatNumber, formatPercentage } from '@/lib/utils';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, Loader2, TrendingDown, TrendingUp } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from 'wouter';
import WebSocketManagerSingleton, { ConnectionStatus } from '@/services/WebSocketManagerSingleton';

// Define interfaces for TypeScript
interface AssetHolding {
  id: string;
  assetId: string;
  symbol: string;
  name: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  type: 'stock' | 'crypto' | 'forex';
  value: number;
  priceChange: number;
  priceChangePercent: number;
  totalReturn: number;
  totalReturnPercent: number;
  icon?: string;
}

interface PortfolioSummary {
  totalValue: number;
  todayChange: number;
  todayChangePercent: number;
  totalReturn: number;
  totalReturnPercent: number;
  cashBalance: number;
}

interface PositionAllocation {
  symbol: string;
  percentage: number;
}

interface Trade {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  quantity: number;
  price: number;
  timestamp: string;
  value: number;
}

interface WebSocketMessage {
  type: string;
  symbol: string;
  price: number;
  changePercent: number;
  volume?: number;
  timestamp?: number;
}

export default function PortfolioPage() {
  const { user } = useAuth();
  // Ensure we pass a string ID to usePortfolioData
  const userId = user?.id ? String(user.id) : undefined;
  
  // For debugging - log the user object to see what we're getting
  useEffect(() => {
    if (user) {
      console.log("Current user:", user);
      console.log("User ID for portfolio:", userId);
    }
  }, [user, userId]);
  
  // Fetch portfolio data using our custom hook
  const { 
    portfolio, 
    orders, 
    trades, 
    isLoading,
    errors,
    refetch 
  } = usePortfolioData(userId);

  // Handle any potential errors
  useEffect(() => {
    if (errors.portfolio || errors.orders || errors.trades) {
      console.error("Error fetching portfolio data:", errors);
    }
  }, [errors]);

  // Add marketData state 
  const [marketData, setMarketData] = useState<Record<string, any>>({});

  // Add effect to fetch market data
  useEffect(() => {
    // Function to fetch market data for open orders
    const fetchMarketData = async () => {
      if (!orders || orders.length === 0) return;
      
      try {
        // Extract unique asset IDs from orders
        const assetIds = [...new Set(orders.map(order => order.assetId))];
        
        // Fetch data for each asset
        const marketDataTemp: Record<string, any> = {};
        
        for (const assetId of assetIds) {
          const response = await fetch(`/api/assets/${assetId}`);
          if (response.ok) {
            const asset = await response.json();
            marketDataTemp[assetId] = asset;
          }
        }
        
        setMarketData(marketDataTemp);
      } catch (error) {
        console.error('Error fetching market data:', error);
      }
    };
    
    fetchMarketData();
    
    // Set up interval to refresh market data
    const intervalId = setInterval(fetchMarketData, 15000);
    
    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, [orders]);

  const [activeTab, setActiveTab] = useState('overview');
  const [wsStatus, setWsStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [priceMap, setPriceMap] = useState<Record<string, number>>({});
  const maxConnectionAttempts = 5;
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [_, navigate] = useLocation();
  const queryClient = useQueryClient();
  
  // Fetch recent trades
  const { 
    data: recentTrades, 
    isLoading: isLoadingTrades 
  } = useQuery<Trade[]>({
    queryKey: ['trades', 'recent'],
    queryFn: async () => {
      const res = await fetch('/api/trades/recent');
      if (!res.ok) {
        throw new Error('Failed to fetch recent trades');
      }
      return res.json();
    },
  });
  
  // Create portfolio summary from portfolio data
  const portfolioSummary: PortfolioSummary = {
    totalValue: portfolio?.totalValue || 0,
    todayChange: 0, // Not available in current API response
    todayChangePercent: 0, // Not available in current API response
    totalReturn: portfolio?.unrealizedPL || 0,
    totalReturnPercent: portfolio?.plPercentage || 0,
    cashBalance: portfolio?.availableBalance || 0,
  };
  
  // Extract holdings (will come from trades/positions once implemented)
  const holdings: AssetHolding[] = [];
  
  // Create a lookup map of all asset symbols in the portfolio
  const getPortfolioSymbols = useCallback(() => {
    if (!holdings || holdings.length === 0) return [];
    return holdings.map(holding => holding.symbol);
  }, [holdings]);
  
  // Connect to WebSocket for real-time price updates
  useEffect(() => {
    const symbols = getPortfolioSymbols();
    if (symbols.length === 0) return;
    
    const connectWebSocket = () => {
      setWsStatus('connecting');
      
      // Use dynamic WebSocket URL based on current window location
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      // Use the correct /ws endpoint that server actually has configured
      const wsUrl = process.env.REACT_APP_WS_URL || `${protocol}//${host}/ws`;
      
      console.log('Creating WebSocket connection to:', wsUrl);
      
      try {
        // Use the WebSocketManagerSingleton instead of direct WebSocket
        const manager = WebSocketManagerSingleton.getInstance();
        wsRef.current = manager; // Store reference to manager for cleanup
        
        // Set connection status when it changes
        const connectionStatusInterval = setInterval(() => {
          const status = manager.getStatus(wsUrl);
          if (status === ConnectionStatus.CONNECTED) {
            setWsStatus('connected');
            setConnectionAttempts(0);
            
            // Subscribe to price updates for all symbols in portfolio
            manager.send(wsUrl, JSON.stringify({
              action: 'subscribe',
              symbols: symbols
            }));
            console.log(`Subscribed to ${symbols.length} portfolio symbols`);
          } else if (status === ConnectionStatus.CONNECTING) {
            setWsStatus('connecting');
          } else {
            setWsStatus('disconnected');
          }
        }, 1000);
        
        // Set up a subscription to receive WebSocket messages using the manager
        const messageHandler = (message: any) => {
          try {
            let data = message;
            
            // Handle both string messages and object messages
            if (typeof message === 'string') {
              data = JSON.parse(message);
            }
            
            console.log('WebSocket message received in portfolio:', data);
            
            // Handle different message types
            if (data.type === 'price' || data.type === 'priceUpdate') {
              if (data.symbol && symbols.includes(data.symbol)) {
                // Update our price map with the latest price
                setPriceMap(prev => ({
                  ...prev,
                  [data.symbol]: data.price
                }));
                
                // Update real-time portfolio values
                updateHoldingValues(data.symbol, data.price);
                setLastUpdated(new Date());
              }
            } else if (data.type === 'assetList' && Array.isArray(data.data)) {
              // Handle asset list updates
              console.log('Received asset list update with', data.data.length, 'assets');
              
              // Process each asset in the list
              data.data.forEach((asset: any) => {
                if (asset.symbol && symbols.includes(asset.symbol)) {
                  setPriceMap(prev => ({
                    ...prev,
                    [asset.symbol]: asset.price || asset.currentPrice
                  }));
                  
                  // Update holding values with new price
                  updateHoldingValues(asset.symbol, asset.price || asset.currentPrice);
                }
              });
              
              setLastUpdated(new Date());
            }
          } catch (e) {
            console.error('Error handling WebSocket message in portfolio:', e);
          }
        };
        
        // Subscribe to WebSocket messages
        manager.subscribe(wsUrl, messageHandler);
        
        // Store the message handler for cleanup
        const cleanupRef = { wsUrl, messageHandler, interval: connectionStatusInterval };
        wsRef.current = cleanupRef;
      } catch (error) {
        console.error('Error setting up WebSocket in portfolio:', error);
        setWsStatus('error');
        handleReconnect();
      }
    };
    
    // Function to update holding values with real-time prices
    const updateHoldingValues = (symbol: string, price: number) => {
      // Ensure we have holdings data
      if (!portfolio?.holdings) return;
      
      // Create a copy of the holdings to update
      const updatedHoldings = [...portfolio.holdings].map(holding => {
        if (holding.symbol === symbol) {
          // Calculate new values based on updated price
          const value = holding.quantity * price;
          const totalReturn = value - (holding.quantity * holding.averagePrice);
          const totalReturnPercent = holding.averagePrice > 0 
            ? (totalReturn / (holding.quantity * holding.averagePrice)) * 100 
            : 0;
          
          return {
            ...holding,
            currentPrice: price,
            value,
            totalReturn,
            totalReturnPercent
          };
        }
        return holding;
      });
      
      // Update portfolio with new holding values
      if (portfolio) {
        const newPortfolio = {
          ...portfolio,
          holdings: updatedHoldings
        };
        
        // Recalculate portfolio summary
        const totalValue = updatedHoldings.reduce((sum, holding) => sum + holding.value, 0) + 
          (portfolio.summary?.cashBalance || 0);
        const todayChange = updatedHoldings.reduce((sum, holding) => {
          const prevPrice = holding.currentPrice / (1 + (holding.priceChangePercent / 100));
          return sum + (holding.quantity * (holding.currentPrice - prevPrice));
        }, 0);
        const todayChangePercent = portfolio.summary?.totalValue > 0 
          ? (todayChange / portfolio.summary.totalValue) * 100 
          : 0;
        
        // Update portfolio summary
        newPortfolio.summary = {
          ...portfolio.summary,
          totalValue,
          todayChange,
          todayChangePercent
        };
        
        // Update state with new portfolio data
        // Using a callback to ensure we're working with the latest state
        setPortfolio(newPortfolio);
      }
    };
    
    // Handle reconnection with exponential backoff
    const handleReconnect = () => {
      if (connectionAttempts < maxConnectionAttempts) {
        // Exponential backoff for reconnection attempts
        const backoffTime = Math.min(1000 * Math.pow(2, connectionAttempts), 30000);
        
        console.log(`Attempting to reconnect (${connectionAttempts + 1}/${maxConnectionAttempts}) in ${backoffTime}ms`);
        
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
        }
        
        reconnectTimeoutRef.current = setTimeout(() => {
          setConnectionAttempts(prev => prev + 1);
          connectWebSocket();
        }, backoffTime);
      } else {
        console.error('Maximum WebSocket reconnection attempts reached');
      }
    };
    
    connectWebSocket();
    
    // Cleanup function
    return () => {
      // Properly unsubscribe from the WebSocketManager
      if (wsRef.current) {
        const { wsUrl, messageHandler, interval } = wsRef.current as any;
        // Get the manager singleton
        const manager = WebSocketManagerSingleton.getInstance();
        // Unsubscribe from WebSocket messages
        manager.unsubscribe(wsUrl, messageHandler);
        // Clear the interval
        if (interval) {
          clearInterval(interval);
        }
      }
      
      // Clear any pending reconnect timeouts
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [getPortfolioSymbols, connectionAttempts, portfolio]);
  
  // Calculate allocation percentages
  const calculateAllocations = (): PositionAllocation[] => {
    if (!holdings || holdings.length === 0 || !portfolioSummary) return [];
    
    const totalPortfolioValue = portfolioSummary.totalValue;
    if (totalPortfolioValue <= 0) return [];
    
    return holdings.map(holding => ({
      symbol: holding.symbol,
      percentage: (holding.value / totalPortfolioValue) * 100
    }))
    .sort((a, b) => b.percentage - a.percentage);
  };
  
  // Get data for allocation chart
  const allocationData = calculateAllocations();
  
  // Format price change for display
  const formatPriceChange = (change: number, changePercent: number) => {
    const isPositive = change >= 0;
    
    return {
      value: formatCurrency(change),
      percent: formatPercentage(changePercent),
      color: isPositive ? 'text-green-600' : 'text-red-600',
      icon: isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />,
    };
  };
  
  // Format holding data for the assets data table
  const formatHoldingsForTable = () => {
    if (!holdings) return [];
    
    return holdings.map(holding => {
      // Use real-time price from WebSocket if available
      const currentPrice = priceMap[holding.symbol] || holding.currentPrice;
      const value = holding.quantity * currentPrice;
      const priceChange = currentPrice - holding.averagePrice;
      const priceChangePercent = (priceChange / holding.averagePrice) * 100;
      
      return {
        id: holding.id,
        symbol: holding.symbol,
        name: holding.name,
        quantity: holding.quantity,
        averagePrice: formatCurrency(holding.averagePrice),
        currentPrice: formatCurrency(currentPrice),
        value: formatCurrency(value),
        change: formatPriceChange(priceChange, priceChangePercent),
        type: holding.type,
        icon: holding.icon,
        action: (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate(`/trade/${holding.symbol}`)}
          >
            Trade <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        )
      };
    });
  };
  
  // Format trade data for the recent trades table
  const formatTradesForTable = () => {
    if (!recentTrades) return [];
    
    return recentTrades.map(trade => ({
      id: trade.id,
      symbol: trade.symbol,
      type: trade.type === 'buy' ? 
        <span className="text-green-600 font-medium">Buy</span> : 
        <span className="text-red-600 font-medium">Sell</span>,
      quantity: formatNumber(trade.quantity),
      price: formatCurrency(trade.price),
      value: formatCurrency(trade.value),
      date: new Date(trade.timestamp).toLocaleDateString(),
      time: new Date(trade.timestamp).toLocaleTimeString(),
      action: (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(`/trade/${trade.symbol}`)}
        >
          Trade <ArrowRight className="h-3 w-3 ml-1" />
        </Button>
      )
    }));
  };
  
  // Define columns for the assets data table
  const assetColumns = [
    {
      accessorKey: 'symbol',
      header: 'Symbol',
      cell: ({ row }: any) => (
        <div className="flex items-center gap-2">
          <div className="font-medium">{row.original.symbol}</div>
        </div>
      ),
    },
    {
      accessorKey: 'name',
      header: 'Name',
    },
    {
      accessorKey: 'quantity',
      header: 'Quantity',
      cell: ({ row }: any) => formatNumber(row.original.quantity),
    },
    {
      accessorKey: 'averagePrice',
      header: 'Avg. Price',
    },
    {
      accessorKey: 'currentPrice',
      header: 'Current Price',
    },
    {
      accessorKey: 'value',
      header: 'Value',
    },
    {
      accessorKey: 'change',
      header: 'Return',
      cell: ({ row }: any) => {
        const change = row.original.change;
        return (
          <div className={`flex items-center gap-1 ${change.color}`}>
            {change.icon}
            <span>{change.value}</span>
            <span className="text-xs">({change.percent})</span>
          </div>
        );
      },
    },
    {
      accessorKey: 'action',
      header: '',
    },
  ];
  
  // Define columns for the recent trades data table
  const tradeColumns = [
    {
      accessorKey: 'symbol',
      header: 'Symbol',
    },
    {
      accessorKey: 'type',
      header: 'Type',
    },
    {
      accessorKey: 'quantity',
      header: 'Quantity',
    },
    {
      accessorKey: 'price',
      header: 'Price',
    },
    {
      accessorKey: 'value',
      header: 'Value',
    },
    {
      accessorKey: 'date',
      header: 'Date',
    },
    {
      accessorKey: 'time',
      header: 'Time',
    },
    {
      accessorKey: 'action',
      header: '',
    },
  ];
  
  // Format portfolio summary values for display
  const todayChangeDisplay = formatPriceChange(
    portfolioSummary?.todayChange || 0, 
    portfolioSummary?.todayChangePercent || 0
  );
  
  const totalReturnDisplay = formatPriceChange(
    portfolioSummary?.totalReturn || 0, 
    portfolioSummary?.totalReturnPercent || 0
  );

  // Loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Skeleton className="h-8 w-64" />
        </div>
        
        <div className="relative min-h-[calc(100vh-14rem)]">
          <div className="flex justify-center items-center h-96">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </div>
        
        <div className="h-20 mt-auto">
          {/* Empty space for the fixed summary bar */}
        </div>
      </div>
    );
  }

  // Render Orders Tab Content
  const renderOrdersContent = () => {
    if (!orders || orders.length === 0) {
      return (
        <EmptyStateView 
          title="There are no open positions" 
          backText="Start trading now"
          backUrl="/trading"
        />
      );
    }

    return (
      <OpenPositionsTable 
        positions={orders}
        marketData={marketData || {}}
        onRefresh={() => refetch()}
      />
    );
  };

  // Render Trades Tab Content
  const renderTradesContent = () => {
    if (!trades || trades.length === 0) {
      return (
        <EmptyStateView 
          title="No manual trades found" 
          backText="Start trading now"
          backUrl="/trading"
        />
      );
    }

    return (
      <div className="space-y-4">
        {trades.map(trade => (
          <div key={trade.id} className="p-4 border rounded-lg shadow-sm">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">{trade.assetSymbol || trade.assetId}</h3>
                <p className="text-sm text-muted-foreground">
                  {trade.orderSide} {trade.quantity} @ ${trade.price}
                </p>
              </div>
              <div className="text-right">
                <span className={`px-2 py-1 text-xs rounded-full ${
                  trade.orderStatus === 'completed' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {trade.orderStatus}
                </span>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(trade.orderDate).toLocaleDateString()}
                </p>
              </div>
            </div>
            
            {trade.pnl !== undefined && (
              <div className="mt-2 flex justify-end">
                <span className={`text-sm ${trade.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  P/L: ${trade.pnl.toFixed(2)} ({trade.pnlPercentage?.toFixed(2)}%)
                </span>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <>
      <Helmet>
        <title>Portfolio | Trading Platform</title>
        <meta name="description" content="View your portfolio, pending orders, and manual trades" />
      </Helmet>
      
      {/* Add detailed portfolio summary component */}
      <DetailedPortfolioSummary />
      
      <div className="container mx-auto px-4 pb-8">
        {/* Enhanced Financial Information Display (similar to trading page) */}
        <div className="mt-2">
          <h1 className="text-2xl font-bold mb-2">Portfolio</h1>
          
          <div className="mb-8">
            <PortfolioSummaryWidget userId={userId} />
          </div>
          
          <div className="relative min-h-[calc(100vh-14rem)]">
            {/* Main Content with Tabs */}
            <OrdersTabs 
              ordersContent={renderOrdersContent()}
              tradesContent={renderTradesContent()}
            />
          </div>
          
          {/* Spacer for fixed summary bar (keeping for mobile) */}
          <div className="h-20 mt-auto lg:hidden">
            {/* Empty space for the fixed summary bar on mobile */}
          </div>
        </div>
      </div>
      
      {/* Fixed Portfolio Summary Bar (only visible on mobile) */}
      <div className="lg:hidden">
        <PortfolioSummaryBar 
          userId={userId}
          initialData={portfolio ? {
            totalValue: portfolio.totalValue,
            availableBalance: portfolio.availableBalance,
            investedAmount: portfolio.investedAmount,
            unrealizedPL: portfolio.unrealizedPL,
            plPercentage: portfolio.plPercentage
          } : undefined}
        />
      </div>
    </>
  );
}