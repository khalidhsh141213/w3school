import { useEffect, useState, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  ChevronRight, 
  ArrowRight, 
  CheckCircle, 
  ChevronDown, 
  Github, 
  BarChart, 
  LineChart, 
  Shield, 
  TrendingUp,
  Users, 
  Clock,
  Zap,
  MousePointer,
  LucideIcon,
  Sparkles,
  Plus,
  Minus,
  Wallet
} from 'lucide-react';
import Hero3D from '../components/landing/Hero3D';
import FeaturesHighlight from '../components/landing/FeaturesHighlight';
import TestimonialsCarousel from '../components/landing/TestimonialsCarousel';
import LandingFooter from '../components/landing/LandingFooter';
import { useAuth } from '@/lib/authContext';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from '@/lib/utils';

interface StatBlockProps {
  value: string;
  label: string;
  icon?: React.ReactNode;
}

function StatBlock({ value, label, icon }: StatBlockProps) {
  return (
    <div className="flex flex-col items-center p-6 bg-card dark:bg-gray-800 rounded-xl border border-border dark:border-gray-700 shadow-sm hover:shadow-md transition-all">
      {icon && <div className="mb-3 text-primary">{icon}</div>}
      <div className="text-3xl md:text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500">
        {value}
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400 text-center">
        {label}
      </div>
    </div>
  );
}

interface ProcessStepProps {
  step: number;
  title: string;
  description: string;
  icon: LucideIcon;
}

function ProcessStep({ step, title, description, icon: Icon }: ProcessStepProps) {
  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mt-1">
        <Icon className="h-6 w-6 text-primary" />
      </div>
      <div className="flex-1">
        <div className="text-xs text-primary font-semibold tracking-wider uppercase mb-1">
          Step {step}
        </div>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-300">
          {description}
        </p>
      </div>
    </div>
  );
}

export default function LandingPage() {
  const [_, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);
  const processRef = useRef<HTMLDivElement>(null);

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  // Handle scroll for navbar transparency
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <Helmet>
        <title>TradePro - Advanced Trading Platform | Stocks, Crypto & Forex</title>
        <meta name="description" content="Professional trading platform offering real-time market data, advanced analytics, and seamless portfolio management for stocks, forex, and cryptocurrencies." />
        <meta name="keywords" content="trading platform, stock trading, cryptocurrency, forex, investment, portfolio management" />
      </Helmet>

      {/* Fixed navbar */}
      <header className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled 
          ? "bg-background/90 dark:bg-gray-900/90 backdrop-blur-lg shadow-sm border-b border-border" 
          : "bg-transparent border-transparent"
      )}>
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className={cn(
                "h-9 w-9 rounded-xl flex items-center justify-center text-white shadow-md transition-all",
                isScrolled
                  ? "bg-gradient-to-br from-primary to-primary/80"
                  : "bg-white/20 backdrop-blur-md"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                  <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                  <polyline points="16 7 22 7 22 13"></polyline>
                </svg>
              </div>
              <div className={cn(
                "ml-3 font-bold text-xl transition-all",
                isScrolled
                  ? "bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent"
                  : "text-white"
              )}>TradePro</div>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <a href="#features" className={cn(
                "text-sm font-medium transition-colors",
                isScrolled ? "text-gray-600 hover:text-gray-900" : "text-white/80 hover:text-white"
              )}>Features</a>
              <a href="#how-it-works" className={cn(
                "text-sm font-medium transition-colors",
                isScrolled ? "text-gray-600 hover:text-gray-900" : "text-white/80 hover:text-white"
              )}>How It Works</a>
              <a href="#testimonials" className={cn(
                "text-sm font-medium transition-colors",
                isScrolled ? "text-gray-600 hover:text-gray-900" : "text-white/80 hover:text-white"
              )}>Testimonials</a>
              <a href="#faq" className={cn(
                "text-sm font-medium transition-colors",
                isScrolled ? "text-gray-600 hover:text-gray-900" : "text-white/80 hover:text-white"
              )}>FAQ</a>
              <Button
                variant={isScrolled ? "ghost" : "outline"}
                size="sm"
                onClick={() => navigate('/auth?tab=signin')}
                className={isScrolled 
                  ? "text-primary hover:text-primary/90" 
                  : "text-white border-white hover:bg-black/10 backdrop-blur-sm shadow-sm"
                }
              >
                Sign In
              </Button>
              <Button
                onClick={() => navigate('/auth?tab=signup')}
                size="sm"
                className={isScrolled 
                  ? "bg-primary hover:bg-primary/90" 
                  : "bg-white text-primary hover:bg-white/90 shadow-md"
                }
              >
                Start Trading
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </nav>

            <div className="md:hidden">
              <Button
                variant={isScrolled ? "ghost" : "outline"}
                size="sm"
                onClick={() => navigate('/auth?tab=signin')}
                className={isScrolled 
                  ? "text-primary hover:text-primary/90" 
                  : "text-white border-white hover:bg-black/10 backdrop-blur-sm shadow-sm bg-black/10"
                }
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-col min-h-screen">
        {/* Hero Section */}
        <section className="relative w-full min-h-screen bg-gradient-to-b from-primary to-primary/80 dark:from-gray-900 dark:to-gray-800 pt-16 overflow-hidden">
          {/* Background pattern */}
          <div className="absolute inset-0 z-0 opacity-20">
            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>
          
          <div className="absolute inset-0 z-0 overflow-hidden opacity-40">
            <Hero3D />
          </div>
          
          <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 h-full pt-20 pb-24 flex flex-col items-center justify-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-6 bg-white/20 text-white px-4 py-1.5 rounded-full text-sm font-medium backdrop-blur-sm"
            >
              Professional Trading for Everyone
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-7xl font-bold text-center tracking-tight mb-6 max-w-5xl text-white"
            >
              Trade Smarter with Real-Time Market Intelligence
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl text-center mb-10 max-w-3xl text-white/90 leading-relaxed"
            >
              A powerful platform that seamlessly combines real-time data, advanced analytics, and intuitive portfolio management
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 mb-16"
            >
              <Button 
                size="lg" 
                className="bg-white hover:bg-white/90 text-primary hover:text-primary/90 px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => navigate('/auth?tab=signup')}
              >
                Start Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/20 px-8 py-6 text-lg rounded-xl shadow-md backdrop-blur-sm bg-black/10"
                onClick={() => navigate('/auth?tab=signin')}
              >
                Sign In to Dashboard
              </Button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl"
            >
              <div className="flex items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 shadow-sm">
                <CheckCircle className="h-5 w-5 text-white mr-3 flex-shrink-0" />
                <p className="text-sm text-white">Real-time market data with live updates</p>
              </div>
              <div className="flex items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 shadow-sm">
                <CheckCircle className="h-5 w-5 text-white mr-3 flex-shrink-0" />
                <p className="text-sm text-white">Advanced analytics and visual charts</p>
              </div>
              <div className="flex items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 shadow-sm">
                <CheckCircle className="h-5 w-5 text-white mr-3 flex-shrink-0" />
                <p className="text-sm text-white">Secure trading with risk management</p>
              </div>
            </motion.div>
          </div>
          
          <div className="absolute bottom-10 left-0 right-0 flex justify-center">
            <a 
              href="#stats"
              className="group flex flex-col items-center gap-2 text-sm text-white/70 hover:text-white transition-colors"
            >
              <span>Discover more</span>
              <div className="animate-bounce bg-white/10 backdrop-blur-md p-2 rounded-full shadow-md group-hover:bg-white/20 transition-all">
                <ChevronDown className="h-4 w-4 text-white" />
              </div>
            </a>
          </div>
        </section>

        {/* Stats Section */}
        <section id="stats" ref={statsRef} className="py-24 bg-background dark:bg-gray-900">
          <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">The Numbers Speak for Themselves</h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Join thousands of professional traders who are using our platform to trade smarter
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <StatBlock 
                value="2.5M+"
                label="Monthly Trades"
                icon={<BarChart className="h-8 w-8" />}
              />
              <StatBlock 
                value="150K+"
                label="Active Users"
                icon={<Users className="h-8 w-8" />}
              />
              <StatBlock 
                value="99.9%"
                label="Monthly Uptime"
                icon={<Clock className="h-8 w-8" />}
              />
              <StatBlock 
                value="50ms"
                label="Average Execution Time"
                icon={<Zap className="h-8 w-8" />}
              />
            </div>
            
            {/* Logos Section */}
            <div className="mt-24">
              <p className="text-center text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider font-medium mb-8">
                We integrate with the best data providers in the industry
              </p>
              <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
                <div className="h-8 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/1/1b/Coinbase_logo_%282018%29.svg" alt="Coinbase" className="h-full" />
                </div>
                <div className="h-8 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
                  <img src="https://cryptologos.cc/logos/polygon-matic-logo.svg" alt="Polygon" className="h-full" />
                </div>
                <div className="h-8 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
                  <img src="https://cryptologos.cc/logos/binance-usd-busd-logo.svg" alt="Binance" className="h-full" />
                </div>
                <div className="h-8 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
                  <img src="https://cryptologos.cc/logos/tradingview-tv-logo.svg" alt="TradingView" className="h-full" />
                </div>
                <div className="h-8 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
                  <img src="https://cryptologos.cc/logos/kraken-krak-logo.svg" alt="Kraken" className="h-full" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How it Works Section */}
        <section id="how-it-works" ref={processRef} className="py-24 bg-white dark:bg-gray-800">
          <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">How the Platform Works</h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Getting started with trading is easier than you think. Follow these simple steps:
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
              <div className="space-y-12">
                <ProcessStep 
                  step={1}
                  title="Create Your Account"
                  description="Register in less than a minute and verify your account with just a few clicks."
                  icon={Users}
                />
                <ProcessStep 
                  step={3}
                  title="Explore and Analyze"
                  description="Use our advanced technical analysis tools and explore market opportunities."
                  icon={LineChart}
                />
              </div>
              <div className="space-y-12">
                <ProcessStep 
                  step={2}
                  title="Deposit Funds"
                  description="Easily add funds through multiple secure payment options."
                  icon={Wallet}
                />
                <ProcessStep 
                  step={4}
                  title="Start Trading"
                  description="Execute trades quickly and easily with guaranteed best prices."
                  icon={MousePointer}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-24 bg-background dark:bg-gray-900">
          <FeaturesHighlight />
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-24 bg-white dark:bg-gray-800">
          <TestimonialsCarousel />
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-24 bg-gray-50 dark:bg-gray-900">
          <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Here are answers to some of the most common questions
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left font-medium">
                    What products can I trade on the platform?
                  </AccordionTrigger>
                  <AccordionContent>
                    Our platform allows trading a wide range of financial assets including stocks, cryptocurrencies, forex, and commodities. We offer more than 10,000 trading instruments from various global markets.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left font-medium">
                    How do you ensure the safety of my funds?
                  </AccordionTrigger>
                  <AccordionContent>
                    We use advanced encryption technologies and strict security protocols to protect your funds. Client funds are held in segregated accounts, and we provide two-factor authentication and hack protection for all accounts.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left font-medium">
                    What fees do you charge?
                  </AccordionTrigger>
                  <AccordionContent>
                    We pride ourselves on offering a transparent and competitive fee structure. Fees vary depending on the asset type and selected package, but we always ensure the best rates with no hidden charges. You can view the complete fee schedule on our pricing page.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left font-medium">
                    Can I trade from my mobile device?
                  </AccordionTrigger>
                  <AccordionContent>
                    Yes, our platform offers dedicated apps for iOS and Android devices, allowing you to trade, access your account, and monitor markets from anywhere and at any time.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left font-medium">
                    How can I withdraw my funds?
                  </AccordionTrigger>
                  <AccordionContent>
                    You can easily withdraw your funds through the wallet section in your account. We support a variety of withdrawal methods including bank transfers, e-wallets, and credit/debit cards. Most withdrawals are processed within 24 hours.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        {/* Pre-footer CTA */}
        <section className="py-24 bg-gradient-to-r from-primary to-primary/80 text-white dark:from-gray-800 dark:to-gray-900">
          <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight">
              Ready to Upgrade Your Trading Experience?
            </h2>
            <p className="text-xl text-white/90 mb-10 max-w-3xl mx-auto">
              Join thousands of professional traders who have already transformed their trading strategy
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-white text-primary hover:bg-white/90 hover:text-primary/90 transition-all duration-300"
                onClick={() => navigate('/auth?tab=signup')}
              >
                Create Free Account
                <Sparkles className="ml-2 h-4 w-4" />
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-white/40 text-white hover:bg-white/10"
                onClick={() => window.open('https://github.com/yourusername/tradepro', '_blank')}
              >
                <Github className="mr-2 h-4 w-4" />
                Star on GitHub
              </Button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <LandingFooter />
      </div>
    </>
  );
}