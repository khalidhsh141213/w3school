# WebSocket Implementation: Developer's Guide

## Infrastructure Overview

Real-time price update system in our platform is developed using a multi-layered WebSocket architecture:

1. **Client Layer**: 
   - `WebSocketManager` as a unified interface for handling WebSocket connections
   - `useWebSocket` component as a React Hook for integration with React components

2. **Server Layer**:
   - `MarketDataService` for managing WebSocket connections and distributing updates
   - Different price update mechanisms based on asset type

3. **Data Source Layer**:
   - Real-time updates for cryptocurrency and forex (WebSocket)
   - Less frequent updates for stocks and indices (REST API)

## Asset Type Separation

Financial assets are categorized according to their appropriate update pattern:

| Asset Type | Update Method | Interval | Notes |
|------------|---------------|----------|-------|
| Cryptocurrency (crypto) | WebSocket (real-time) | 5 seconds | Always available (24/7) |
| Forex (forex) | WebSocket (real-time) | 5 seconds | Closed on Sunday |
| Stocks (stock) | REST API | 5 minutes | Closed on weekends |
| Indices (index) | REST API | 5 minutes | Closed on weekends |

## Server Implementation

### 1. MarketDataService

`MarketDataService` is the primary component responsible for managing real-time data:

```typescript
// From server/services/marketData.ts
export class MarketDataService {
  private wss: WebSocketServer | null = null;
  private clients: Map<CustomWebSocket, Set<string>> = new Map();
  private lastPrices: Map<string, { price: number, change: number, changePercent: number }> = new Map();
  
  // ...

  async initialize(server: HttpServer) {
    // Create WebSocket server on specific path
    this.wss = new WebSocketServer({ 
      server,
      path: '/api/market-data'
    });

    this.wss.on('connection', (ws: CustomWebSocket) => {
      // Handle client connection
      // ...
    });

    // Update prices periodically
    this.startPriceUpdates();
  }
}
```

### 2. Price Update System

The price update system is implemented using the following workflow:

```javascript
// From scripts/market-update.js
// Update real-time assets (crypto and forex)
async function updateRealtimeAssets() {
  // Update cryptocurrency assets (always active)
  for (const asset of assetsByType.crypto) {
    // Get updated price data
    const { price, change, changePercent, volume } = simulatePriceChange(
      currentPrices[asset.symbol] || asset.basePrice, 
      asset.volatility || 1
    );
    
    // Try WebSocket first, fall back to REST
    const wsSuccess = updateViaWebSocket(asset.symbol, { price, change, changePercent, volume });
    if (!wsSuccess) {
      await updateViaREST(asset.symbol, { price, change, changePercent, volume });
    }
  }
  
  // Update forex assets (check if market is open)
  if (areMarketsOpen('forex')) {
    // Update forex...
  } else {
    console.log('Forex markets are closed (Sunday). Skipping updates.');
  }
}
```

### 3. Market Status Checking

Market status is verified before updating prices:

```javascript
// From scripts/market-update.js
function areMarketsOpen(assetType) {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 is Sunday, 6 is Saturday
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
  
  // Crypto markets always open
  if (assetType === 'crypto') {
    return true;
  }
  
  // Forex has limited weekend trading
  if (assetType === 'forex') {
    if (dayOfWeek === 0) { // Sunday
      return false; // Generally closed on Sunday
    }
    return true; // Can be active on other days
  }
  
  // Stock markets closed on weekends
  if (assetType === 'stock' || assetType === 'index') {
    return !isWeekend;
  }
  
  // Default to closed on Sunday, open other days
  return dayOfWeek !== 0;
}
```

## Client Implementation

### 1. WebSocketManager

`WebSocketManager` is a central component for handling WebSocket connections on the client side:

```typescript
// From client/src/services/WebSocketManager.ts
class WebSocketManager {
  private static instance: WebSocketManager;
  private connections: Map<string, WebSocket> = new Map();
  private statuses: Map<string, ConnectionStatus> = new Map();
  private subscriptions: Map<string, Set<SubscriptionCallback>> = new Map();
  // ...
  
  public static getInstance(): WebSocketManager {
    if (!WebSocketManager.instance) {
      WebSocketManager.instance = new WebSocketManager();
    }
    return WebSocketManager.instance;
  }
  
  public connect(url: string, options: WebSocketOptions = {}): Promise<WebSocket> {
    // Create WebSocket connection...
  }
  
  public send(url: string, message: WebSocketMessage): boolean {
    // Send message via WebSocket...
  }
  
  public subscribe(url: string, callback: SubscriptionCallback): void {
    // Subscribe to WebSocket updates...
  }
  
  // ...
}
```

### 2. React Hook (useWebSocket)

A React Hook is provided to facilitate WebSocket usage in React components:

```typescript
// From client/src/services/WebSocketManager.ts
export function useWebSocket(
  url: string,
  options: WebSocketOptions = {},
  dependencies: any[] = []
) {
  const manager = WebSocketManager.getInstance();
  const wsRef = useRef<WebSocket | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>(
    manager.getStatus(url) || ConnectionStatus.DISCONNECTED
  );
  
  // Connect to WebSocket when component loads
  useEffect(() => {
    if (!url) return;
    
    manager.connect(url, options)
      .then(ws => {
        wsRef.current = ws;
      })
      .catch(error => {
        console.error(`Error connecting to WebSocket at ${url}:`, error);
      });
    
    // Update status when it changes
    const statusListener = (newStatus: ConnectionStatus) => {
      setStatus(newStatus);
    };
    
    manager.onStatusChange(url, statusListener);
    
    // Clean up connection when component is unmounted
    return () => {
      manager.offStatusChange(url, statusListener);
    };
  }, [url, ...dependencies]);
  
  // Return a consistent interface for use in components
  return {
    status,
    send: (message: any) => manager.send(url, message),
    subscribe: (callback: (data: any) => void) => manager.subscribe(url, callback),
    unsubscribe: (callback: (data: any) => void) => manager.unsubscribe(url, callback)
  };
}
```

## Known Issues and Solutions

### 1. Connection Loss

To handle connection loss, multiple mechanisms are implemented:

- **Automatic Reconnection**: Repeated reconnection attempts with increasing delay intervals.
- **Circuit Breaker**: Preventing excessive reconnection attempts when persistent issues exist.
- **REST API Fallback**: Using REST API as a backup mechanism when WebSocket is unavailable.

### 2. Testing Design

To test WebSocket functionality, the following tools can be used:

- `test-websocket.js`: Tool for testing WebSocket connections.
- `test-notification-ws.js`: Test notification system via WebSocket.

## Complete WebSocket Usage Example

### In a React Component:

```tsx
import React, { useEffect, useState } from 'react';
import { useWebSocket, ConnectionStatus } from '@/services/WebSocketManager';

const CryptoMarketTicker: React.FC = () => {
  const [cryptoPrices, setCryptoPrices] = useState<Record<string, number>>({});
  const cryptoSymbols = ['BTC/USD', 'ETH/USD', 'SOL/USD', 'ADA/USD'];
  
  // Use WebSocket for real-time price updates
  const { status, send, subscribe } = useWebSocket('/api/market-data', {
    reconnectAttempts: 5,
    reconnectInterval: 3000,
    heartbeatInterval: 30000,
  });
  
  // Subscribe to price updates
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      // Send subscription request for crypto currencies
      send({
        type: 'subscribe',
        symbols: cryptoSymbols
      });
      
      // Handle incoming price updates
      const handlePriceUpdate = (message: any) => {
        if (message.type === 'priceUpdate' && message.data) {
          const { symbol, price } = message.data;
          
          // Update prices
          if (cryptoSymbols.includes(symbol)) {
            setCryptoPrices(prev => ({
              ...prev,
              [symbol]: parseFloat(price)
            }));
          }
        }
      };
      
      // Subscribe to WebSocket messages
      subscribe(handlePriceUpdate);
      
      // Clean up when component is unmounted
      return () => {
        // Unsubscribe from symbols
        send({
          type: 'unsubscribe',
          symbols: cryptoSymbols
        });
      };
    }
  }, [status, send, subscribe]);
  
  // Display connection status and prices
  return (
    <div className="crypto-ticker">
      <div className="connection-status">
        WebSocket Connection: {status}
      </div>
      <div className="price-grid">
        {cryptoSymbols.map(symbol => (
          <div key={symbol} className="price-card">
            <div className="symbol">{symbol}</div>
            <div className="price">
              {cryptoPrices[symbol] 
                ? `$${cryptoPrices[symbol]?.toLocaleString()}`
                : 'Loading...'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CryptoMarketTicker;
```

## Future Roadmap

1. **Support More Assets**: Extend WebSocket support to include more currency pairs and assets.
2. **Performance Improvements**: Optimize resource consumption through improved subscription management.
3. **Market Hours Compatibility**: Enhance handling of weekends and official holidays.
4. **Data Compression**: Implement mechanisms to compress WebSocket data for improved performance.