/**
 * Message Queue
 * 
 * A simple queue implementation for WebSocket messages.
 * This helps decouple the receipt of messages from their processing,
 * which is critical for high-frequency data feeds like market data.
 */

/**
 * Message queue interface
 */
export interface MessageQueue<T> {
  /**
   * Add an item to the queue
   * @param item The item to add
   */
  enqueue(item: T): void;
  
  /**
   * Remove and return the next item from the queue
   * @returns The next item, or undefined if the queue is empty
   */
  dequeue(): T | undefined;
  
  /**
   * Get the number of items in the queue
   * @returns The number of items
   */
  size(): number;
  
  /**
   * Check if the queue is empty
   * @returns True if the queue is empty, false otherwise
   */
  isEmpty(): boolean;
  
  /**
   * Clear the queue
   */
  clear(): void;
}

/**
 * A simple bounded queue implementation
 */
export class BoundedMessageQueue<T> implements MessageQueue<T> {
  private items: T[] = [];
  private readonly maxSize: number;
  private dropStrategy: 'oldest' | 'newest';
  private droppedCount: number = 0;
  
  /**
   * Constructor
   * @param maxSize The maximum number of items in the queue
   * @param dropStrategy The strategy to use when the queue is full ('oldest' or 'newest')
   */
  constructor(maxSize = 10000, dropStrategy: 'oldest' | 'newest' = 'oldest') {
    this.maxSize = maxSize;
    this.dropStrategy = dropStrategy;
  }
  
  /**
   * Add an item to the queue
   * @param item The item to add
   */
  enqueue(item: T): void {
    if (this.items.length >= this.maxSize) {
      this.droppedCount++;
      if (this.dropStrategy === 'oldest') {
        // Remove the oldest item (FIFO)
        this.items.shift();
      } else {
        // Drop the new item
        return;
      }
    }
    this.items.push(item);
  }
  
  /**
   * Remove and return the next item from the queue
   * @returns The next item, or undefined if the queue is empty
   */
  dequeue(): T | undefined {
    return this.items.shift();
  }
  
  /**
   * Get the number of items in the queue
   * @returns The number of items
   */
  size(): number {
    return this.items.length;
  }
  
  /**
   * Check if the queue is empty
   * @returns True if the queue is empty, false otherwise
   */
  isEmpty(): boolean {
    return this.items.length === 0;
  }
  
  /**
   * Clear the queue
   */
  clear(): void {
    this.items = [];
  }
  
  /**
   * Get the number of dropped messages
   * @returns The number of dropped messages
   */
  getDroppedCount(): number {
    return this.droppedCount;
  }
  
  /**
   * Reset the dropped count
   */
  resetDroppedCount(): void {
    this.droppedCount = 0;
  }
  
  /**
   * Batch process multiple items at once
   * @param count The maximum number of items to process
   * @param processor The function to process each item
   * @returns The number of items processed
   */
  processBatch(count: number, processor: (item: T) => void): number {
    let processed = 0;
    
    while (!this.isEmpty() && processed < count) {
      const item = this.dequeue();
      if (item !== undefined) {
        processor(item);
        processed++;
      }
    }
    
    return processed;
  }
}

/**
 * Factory function to create a bounded message queue
 * @param maxSize The maximum number of items in the queue
 * @param dropStrategy The strategy to use when the queue is full
 * @returns A new bounded message queue
 */
export function createMessageQueue<T>(
  maxSize = 10000,
  dropStrategy: 'oldest' | 'newest' = 'oldest'
): MessageQueue<T> {
  return new BoundedMessageQueue<T>(maxSize, dropStrategy);
} 