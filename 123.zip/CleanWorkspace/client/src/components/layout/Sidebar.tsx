import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/authContext";
import { cn } from "@/lib/utils";
import {
    Calendar,
    ChevronRight,
    Compass,
    Eye,
    HelpCircle,
    LayoutDashboard,
    LineChart,
    LogOut,
    PieChart,
    Settings,
    TrendingUp,
    Users,
    Wallet
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { user, logout } = useAuth();
  
  // Reorganize the navigation items into logical groups
  const mainNavItems = [
    { name: t('navigation.dashboard'), path: '/dashboard', icon: <LayoutDashboard className="h-4 w-4 mr-3" /> },
  ];
  
  // Combine Portfolio and Trading into a single section
  const tradingNavItems = [
    { name: t('navigation.trading'), path: '/trading', icon: <LineChart className="h-4 w-4 mr-3" />, badge: 'Live' },
    { name: t('navigation.portfolio'), path: '/portfolio', icon: <PieChart className="h-4 w-4 mr-3" /> },
    { name: t('navigation.watchlist'), path: '/watchlist', icon: <Eye className="h-4 w-4 mr-3" /> },
  ];
  
  const financeNavItems = [
    { name: t('navigation.wallet'), path: '/wallet', icon: <Wallet className="h-4 w-4 mr-3" /> },
  ];
  
  const discoverNavItems = [
    { name: t('navigation.discover'), path: '/discover', icon: <Compass className="h-4 w-4 mr-3" /> },
    { name: t('navigation.copyTrading'), path: '/copy-trading', icon: <Users className="h-4 w-4 mr-3" />, badge: 'Beta' },
    { name: t('navigation.calendar'), path: '/calendar', icon: <Calendar className="h-4 w-4 mr-3" /> },
    { name: t('navigation.economicCalendar'), path: '/economic-calendar', icon: <Calendar className="h-4 w-4 mr-3" />, badge: 'New' },
  ];

  const accountItems = [
    { name: t('common.settings'), path: '/settings', icon: <Settings className="h-4 w-4 mr-3" /> },
  ];

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user || !user.username) return "UT";
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <div className="flex flex-col w-64 bg-background/95 backdrop-blur-lg h-full overflow-auto border-r border-border">
      {/* Logo and branding */}
      <div className="p-4 border-b border-border flex items-center">
        <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-primary-foreground shadow-sm">
          <TrendingUp className="h-5 w-5" />
        </div>
        <h1 className="text-lg font-bold ml-2.5 tracking-tight bg-clip-text text-foreground">TradePro</h1>
      </div>
      
      {/* User profile */}
      <div className="p-3 border-b border-border hover:bg-muted/30 transition-colors">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="h-9 w-9 ring-1 ring-primary/10 ring-offset-1 ring-offset-background">
              <AvatarImage src={user?.profileImage || ''} alt={user?.username || 'User'} />
              <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-0.5">
              <div className="text-sm font-medium">{user?.username || "Trader"}</div>
              <div className="text-xs text-muted-foreground flex items-center">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mr-1.5"></span>
                Active
              </div>
            </div>
          </div>
          <Link href="/settings">
            <Button variant="ghost" size="icon" className="h-7 w-7 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/50">
              <Settings className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Navigation - updated styles */}
      <nav className="flex-1 p-2 overflow-y-auto text-sm space-y-0.5">
        <div className="text-xs uppercase text-muted-foreground mt-2 mb-1 px-2 font-medium tracking-wider">
          Main
        </div>
        {mainNavItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex items-center px-2 py-1.5 rounded-md transition-all duration-200",
              location === item.path 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-foreground hover:bg-muted/50 hover:text-foreground'
            )}
          >
            {item.icon}
            {item.name}
          </Link>
        ))}
        
        <div className="text-xs uppercase text-muted-foreground mt-4 mb-1 px-2 font-medium tracking-wider">
          Trading & Portfolio
        </div>
        {tradingNavItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex items-center px-2 py-1.5 rounded-md transition-all duration-200",
              location === item.path 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-foreground hover:bg-muted/50 hover:text-foreground'
            )}
          >
            <div className="flex-1 flex items-center">
              {item.icon}
              {item.name}
            </div>
            {item.badge && (
              <Badge variant={item.badge === 'Live' ? "success" : "default"} className="ml-auto text-[10px] py-0 px-1.5 h-4.5">
                {item.badge}
              </Badge>
            )}
          </Link>
        ))}
        
        <div className="text-xs uppercase text-muted-foreground mt-4 mb-1 px-2 font-medium tracking-wider">
          Finances
        </div>
        {financeNavItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex items-center px-2 py-1.5 rounded-md transition-all duration-200",
              location === item.path 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-foreground hover:bg-muted/50 hover:text-foreground'
            )}
          >
            {item.icon}
            {item.name}
          </Link>
        ))}
        
        <div className="text-xs uppercase text-muted-foreground mt-4 mb-1 px-2 font-medium tracking-wider">
          Discover
        </div>
        {discoverNavItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex items-center px-2 py-1.5 rounded-md transition-all duration-200",
              location === item.path 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-foreground hover:bg-muted/50 hover:text-foreground'
            )}
          >
            <div className="flex-1 flex items-center">
              {item.icon}
              {item.name}
            </div>
            {item.badge && (
              <Badge variant="default" className="ml-auto text-[10px] bg-blue-500/10 text-blue-500 border-blue-500/20 py-0 px-1.5 h-4.5">
                {item.badge}
              </Badge>
            )}
          </Link>
        ))}
        
        <div className="text-xs uppercase text-muted-foreground mt-4 mb-1 px-2 font-medium tracking-wider">
          Account
        </div>
        {accountItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex items-center px-2 py-1.5 rounded-md transition-all duration-200",
              location === item.path 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-foreground hover:bg-muted/50 hover:text-foreground'
            )}
          >
            {item.icon}
            {item.name}
          </Link>
        ))}
        
        <button
          onClick={logout}
          className="flex items-center px-2 py-1.5 rounded-md transition-all duration-200 text-red-500 hover:bg-red-500/10 w-full mt-2"
        >
          <LogOut className="h-4 w-4 mr-3" />
          {t('common.logout')}
        </button>
      </nav>
      
      {/* Support banner */}
      <div className="p-3 mt-auto">
        <div className="bg-primary/5 rounded-md p-3 shadow-sm border border-primary/10">
          <div className="flex items-center mb-2">
            <HelpCircle className="h-4 w-4 text-primary mr-2" />
            <h3 className="text-sm font-medium">Need Help?</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-2">Contact our support team for assistance</p>
          <Link href="/support">
            <Button variant="outline" size="sm" className="w-full justify-between">
              {t('common.support')} <ChevronRight className="h-3 w-3 ml-1 opacity-70" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
