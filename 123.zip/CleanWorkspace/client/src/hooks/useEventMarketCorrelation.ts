/**
 * useEventMarketCorrelation Hook
 * 
 * A specialized hook for analyzing correlations between economic events and market movements.
 * This hook helps traders understand how specific economic indicators affect asset prices.
 * 
 * @example
 * ```tsx
 * function CorrelationAnalysis() {
 *   const { 
 *     correlations,
 *     topImpactedAssets,
 *     isLoading
 *   } = useEventMarketCorrelation('interest_rate');
 *   
 *   return (
 *     <div>
 *       <h2>Interest Rate Impact Analysis</h2>
 *       {topImpactedAssets.map(asset => (
 *         <div key={asset.symbol}>
 *           {asset.symbol}: {asset.correlationScore}
 *         </div>
 *       ))}
 *     </div>
 *   );
 * }
 * ```
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import useEconomicEvents, { EventCategory } from './useEconomicEvents';
import useWebSocketConnection from './useWebSocketConnection';
import { ConnectionStatus } from '../services/WebSocketService';
import api from '../lib/api';

// Types
export interface AssetCorrelation {
  symbol: string;
  name: string;
  correlationScore: number; // -1 to 1, where 1 is perfect positive correlation
  averageImpact: number; // Average % price change after event
  significanceLevel: 'low' | 'medium' | 'high'; // Statistical significance
  sampleSize: number; // Number of events analyzed
  direction: 'positive' | 'negative' | 'mixed'; // Price movement direction
  timeFrame: string; // e.g., "1h", "1d", "1w"
}

export interface EventImpact {
  eventId: string;
  eventTitle: string;
  date: string;
  category: EventCategory;
  impact: 'low' | 'medium' | 'high';
  priceChanges: {
    symbol: string;
    pre: number;
    post: number;
    change: number;
    percentChange: number;
  }[];
}

export interface CorrelationData {
  category: EventCategory;
  lastUpdated: number;
  correlations: AssetCorrelation[];
  historicalImpacts: EventImpact[];
}

export interface EventMarketCorrelationOptions {
  // Time frame for analyzing price changes after events
  timeFrame?: '1h' | '4h' | '1d' | '1w';
  // Minimum number of events to analyze for correlation
  minSampleSize?: number;
  // Whether to use cached correlation data
  useCache?: boolean;
  // Maximum age of cached data in milliseconds
  cacheMaxAge?: number;
  // Assets to include in analysis (leave empty for all tracked assets)
  assetSymbols?: string[];
}

const DEFAULT_OPTIONS: EventMarketCorrelationOptions = {
  timeFrame: '1d',
  minSampleSize: 3,
  useCache: true,
  cacheMaxAge: 3600000, // 1 hour
  assetSymbols: [],
};

// Local cache for correlation data
const correlationCache = new Map<string, {
  data: CorrelationData;
  timestamp: number;
}>();

// Helper to create cache key
function createCacheKey(category: EventCategory, options: EventMarketCorrelationOptions): string {
  return `${category}:${options.timeFrame}:${options.minSampleSize}:${options.assetSymbols?.sort().join(',') || 'all'}`;
}

/**
 * Hook for analyzing correlations between economic events and market movements
 * @param category The economic event category to analyze
 * @param options Additional options for correlation analysis
 * @returns Correlation data and utility functions
 */
export function useEventMarketCorrelation(
  category: EventCategory = 'all',
  options: Partial<EventMarketCorrelationOptions> = {}
) {
  // Merge with default options
  const mergedOptions: EventMarketCorrelationOptions = {
    ...DEFAULT_OPTIONS,
    ...options,
  };
  
  // Generate a cache key for the current settings
  const cacheKey = useMemo(() => createCacheKey(category, mergedOptions), [
    category,
    mergedOptions.timeFrame,
    mergedOptions.minSampleSize,
    mergedOptions.assetSymbols
  ]);
  
  // State
  const [correlationData, setCorrelationData] = useState<CorrelationData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  
  // Use our WebSocket connection for real-time correlation updates
  const {
    status: wsStatus,
    subscribe,
    isConnected
  } = useWebSocketConnection('/market-analysis');
  
  // Use economic events hook to get event data
  const {
    events,
    isLoading: eventsLoading,
  } = useEconomicEvents({
    categories: [category],
    cache: {
      enabled: true,
      maxAge: 600000 // 10 minutes
    }
  });
  
  // Fetch correlation data
  const fetchCorrelationData = useCallback(async () => {
    try {
      // Check cache first if enabled
      if (mergedOptions.useCache) {
        const cached = correlationCache.get(cacheKey);
        if (cached && (Date.now() - cached.timestamp) < (mergedOptions.cacheMaxAge || 3600000)) {
          setCorrelationData(cached.data);
          setIsLoading(false);
          return;
        }
      }
      
      // Build query parameters
      const params: Record<string, any> = {
        category,
        timeFrame: mergedOptions.timeFrame,
        minSampleSize: mergedOptions.minSampleSize,
      };
      
      // Add asset symbols if provided
      if (mergedOptions.assetSymbols && mergedOptions.assetSymbols.length > 0) {
        params.symbols = mergedOptions.assetSymbols.join(',');
      }
      
      // Fetch correlation data from API
      const response = await api.get('/api/analytics/event-correlations', params);
      
      if (response.data) {
        const correlationData: CorrelationData = {
          category,
          lastUpdated: Date.now(),
          correlations: response.data.correlations || [],
          historicalImpacts: response.data.historicalImpacts || []
        };
        
        // Update cache if enabled
        if (mergedOptions.useCache) {
          correlationCache.set(cacheKey, {
            data: correlationData,
            timestamp: Date.now()
          });
        }
        
        setCorrelationData(correlationData);
      } else {
        console.warn('[useEventMarketCorrelation] No correlation data returned from API');
        setCorrelationData({
          category,
          lastUpdated: Date.now(),
          correlations: [],
          historicalImpacts: []
        });
      }
    } catch (err) {
      console.error('[useEventMarketCorrelation] Error fetching correlation data:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setIsLoading(false);
    }
  }, [category, cacheKey, mergedOptions]);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    if (wsStatus === ConnectionStatus.CONNECTED) {
      // Subscribe to correlation updates
      const unsubscribe = subscribe('eventCorrelations', (data) => {
        if (data && data.category === category) {
          const newCorrelationData: CorrelationData = {
            category: data.category,
            lastUpdated: Date.now(),
            correlations: data.correlations || [],
            historicalImpacts: data.historicalImpacts || []
          };
          
          // Update cache if enabled
          if (mergedOptions.useCache) {
            correlationCache.set(cacheKey, {
              data: newCorrelationData,
              timestamp: Date.now()
            });
          }
          
          setCorrelationData(newCorrelationData);
        }
      });
      
      // Tell the server what we're interested in
      const subscriptionMessage = {
        type: 'subscribe',
        channel: 'eventCorrelations',
        data: {
          category,
          timeFrame: mergedOptions.timeFrame,
          assetSymbols: mergedOptions.assetSymbols
        }
      };
      
      // Send subscription via WebSocket
      const connection = useWebSocketConnection('/market-analysis');
      connection.send(subscriptionMessage);
      
      return unsubscribe;
    }
    
    // Fetch initial data if WebSocket is not connected
    fetchCorrelationData();
  }, [
    wsStatus,
    category,
    cacheKey, 
    subscribe,
    fetchCorrelationData,
    mergedOptions.timeFrame,
    mergedOptions.assetSymbols,
    mergedOptions.useCache
  ]);
  
  // Get top impacted assets (sorted by absolute correlation)
  const topImpactedAssets = useMemo(() => {
    if (!correlationData) return [];
    
    return [...correlationData.correlations]
      .sort((a, b) => Math.abs(b.correlationScore) - Math.abs(a.correlationScore))
      .slice(0, 10);
  }, [correlationData]);
  
  // Get positively correlated assets
  const positiveCorrelations = useMemo(() => {
    if (!correlationData) return [];
    
    return correlationData.correlations
      .filter(c => c.correlationScore > 0.3)
      .sort((a, b) => b.correlationScore - a.correlationScore);
  }, [correlationData]);
  
  // Get negatively correlated assets
  const negativeCorrelations = useMemo(() => {
    if (!correlationData) return [];
    
    return correlationData.correlations
      .filter(c => c.correlationScore < -0.3)
      .sort((a, b) => a.correlationScore - b.correlationScore);
  }, [correlationData]);
  
  // Get most recent impacts
  const recentImpacts = useMemo(() => {
    if (!correlationData) return [];
    
    return [...correlationData.historicalImpacts]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [correlationData]);
  
  // Calculate the average impact for a given symbol
  const getAverageImpact = useCallback((symbol: string): number | null => {
    if (!correlationData || !correlationData.historicalImpacts.length) return null;
    
    const impacts = correlationData.historicalImpacts
      .flatMap(impact => impact.priceChanges)
      .filter(change => change.symbol === symbol);
    
    if (impacts.length === 0) return null;
    
    const sum = impacts.reduce((acc, curr) => acc + curr.percentChange, 0);
    return sum / impacts.length;
  }, [correlationData]);
  
  // Return the hook API
  return {
    // Data
    correlations: correlationData?.correlations || [],
    historicalImpacts: correlationData?.historicalImpacts || [],
    
    // Calculated/derived data
    topImpactedAssets,
    positiveCorrelations,
    negativeCorrelations,
    recentImpacts,
    
    // State
    isLoading: isLoading || eventsLoading,
    error,
    isConnected,
    lastUpdated: correlationData?.lastUpdated,
    
    // Utility functions
    getAverageImpact,
    refresh: fetchCorrelationData
  };
}

export default useEventMarketCorrelation;