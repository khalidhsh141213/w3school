"use client";

import { useEffect, useRef, useState } from "react";
import { Loader2, Maximize, Minimize, RefreshCw, ArrowUp, ArrowDown, LineChart } from "lucide-react";
import { Asset } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

let tvScriptLoadingPromise: Promise<void>;

type RealTimeChartProps = {
  selectedAsset: Asset | null;
  marketData: any;
};

// This will map our internal asset to TradingView symbol format
const mapAssetToTradingViewSymbol = (asset: Asset): string => {
  if (!asset) return "";
  
  // Always use tradingviewSymbol field directly if it exists (tradingview_symbol in database)
  if (asset.tradingviewSymbol) {
    console.log(`Using tradingviewSymbol from database: ${asset.tradingviewSymbol} for ${asset.symbol}`);
    return asset.tradingviewSymbol;
  }
  
  console.log(`WARNING: No tradingviewSymbol found for ${asset.symbol}, using fallback formatting`);
  
  // Use a prefix that is compatible with TradingView based on asset type
  let prefix = "";
  
  switch (asset.assetType) {
    case "forex":
      prefix = "FX:";
      break;
    case "crypto":
      // Use different exchanges based on the asset
      if (asset.symbol.includes("BTC") || asset.symbol.includes("ETH")) {
        prefix = "BINANCE:";
      } else {
        prefix = "COINBASE:";
      }
      break;
    case "stock":
      prefix = "NASDAQ:";
      break;
    case "commodity":
      // For commodities, check specific symbols
      if (asset.symbol.includes("XAU") || asset.symbol.includes("GOLD")) {
        return `COMEX:GC1!`; // Gold futures
      } else if (asset.symbol.includes("XAG") || asset.symbol.includes("SILVER")) {
        return `COMEX:SI1!`; // Silver futures
      } else if (asset.symbol.includes("OIL") || asset.symbol.includes("CL")) {
        return `NYMEX:CL1!`; // Crude oil futures
      } else {
        prefix = "COMEX:";
      }
      break;
    default:
      prefix = "FX:";
      break;
  }
  
  // Try to use the polygonSymbol (without the prefix) if available, otherwise fallback to the display symbol
  const symbolWithoutPrefix = asset.polygonSymbol 
    ? asset.polygonSymbol.split(':').pop() || asset.symbol 
    : asset.symbol.replace("-", "");
    
  return `${prefix}${symbolWithoutPrefix}`;
};

export default function RealTimeChart({ selectedAsset, marketData }: RealTimeChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const scriptRef = useRef<HTMLScriptElement | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [timeframe, setTimeframe] = useState("1D");
  const [chartStyle, setChartStyle] = useState("candles");
  const [isLoading, setIsLoading] = useState(true);

  // Function to create the TradingView widget
  const createWidget = () => {
    if (!selectedAsset || !containerRef.current) return;
    
    // Clear previous widget
    containerRef.current.innerHTML = "";
    setIsLoading(true);
    
    const tradingViewSymbol = mapAssetToTradingViewSymbol(selectedAsset);
    
    // @ts-ignore - TradingView widget is loaded from external script
    new window.TradingView.widget({
      container_id: containerRef.current.id,
      autosize: true,
      symbol: tradingViewSymbol,
      interval: timeframe,
      timezone: "exchange",
      theme: "dark",
      style: chartStyle,
      locale: "en",
      toolbar_bg: "#1e293b",
      enable_publishing: false,
      hide_top_toolbar: false,
      withdateranges: true,
      hide_side_toolbar: false,
      allow_symbol_change: false,
      details: true,
      hotlist: true,
      calendar: true,
      studies: [
        "MASimple@tv-basicstudies",
        "RSI@tv-basicstudies",
        "Volume@tv-basicstudies"
      ],
      container: containerRef.current,
      // Add the ready callback directly in the constructor
      onReady: () => {
        setIsLoading(false);
      }
    });
  };

  // Load TradingView script
  useEffect(() => {
    const loadTradingViewScript = () => {
      if (!tvScriptLoadingPromise) {
        tvScriptLoadingPromise = new Promise((resolve) => {
          const script = document.createElement("script");
          script.id = "tradingview-widget-script";
          script.src = "https://s3.tradingview.com/tv.js";
          script.type = "text/javascript";
          script.onload = () => resolve();
          
          document.head.appendChild(script);
          scriptRef.current = script;
        });
      }
      return tvScriptLoadingPromise;
    };

    // Load the script and create widget
    loadTradingViewScript().then(() => {
      if (selectedAsset) {
        // Slight delay to ensure TradingView is fully loaded
        setTimeout(() => {
          createWidget();
        }, 300);
      }
    });
  }, []); // Only load script once

  // Update chart when selectedAsset, timeframe, or chartStyle changes
  useEffect(() => {
    if (selectedAsset) {
      // Only create widget if TradingView is available
      // @ts-ignore - TradingView widget is loaded from external script
      if (typeof window.TradingView !== 'undefined') {
        createWidget();
        
        // Force loading state to be false after 5 seconds as a fallback
        // This ensures we don't get stuck in loading state
        const loadingTimer = setTimeout(() => {
          setIsLoading(false);
        }, 5000);
        
        return () => clearTimeout(loadingTimer);
      }
    } else {
      // If no asset is selected, ensure we're not in loading state
      setIsLoading(false);
    }
  }, [selectedAsset, timeframe, chartStyle]);

  // Toggle fullscreen mode
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
    
    setIsFullscreen(!isFullscreen);
  };

  // Handle refresh
  const handleRefresh = () => {
    // @ts-ignore - TradingView widget is loaded from external script
    if (typeof window.TradingView !== 'undefined') {
      createWidget();
    }
  };

  // Get current price info from market data
  const getCurrentPrice = () => {
    if (!selectedAsset || !marketData) return null;
    
    // Check if we have price data
    const assetData = marketData[selectedAsset.symbol] || {};
    
    return {
      price: assetData.price || selectedAsset.price || 0,
      change: assetData.change || selectedAsset.priceChange24h || 0,
      changePercent: assetData.changePercent || selectedAsset.priceChangePercent || 0,
      open: assetData.open || selectedAsset.openPrice || 0,
      high: assetData.high || selectedAsset.highPrice || 0,
      low: assetData.low || selectedAsset.lowPrice || 0,
      volume: assetData.volume || selectedAsset.volume || 0,
    };
  };
  
  const priceInfo = getCurrentPrice();
  
  // Force a refresh of the chart if market data changes significantly
  useEffect(() => {
    if (priceInfo && selectedAsset) {
      // We have both an asset selected and price data - ensure chart is properly loaded
      setIsLoading(false);
    }
  }, [priceInfo, selectedAsset]);

  return (
    <div className="relative h-full flex flex-col">
      {/* Chart header with asset info and controls */}
      <div className="flex flex-col bg-card border-b p-3 z-10 dark:bg-gray-800/90 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-2">
          {/* Asset info */}
          <div className="flex items-center gap-2">
            {selectedAsset && (
              <>
                <div className="flex flex-col">
                  <div className="flex items-center">
                    <span className="font-bold text-lg">{selectedAsset.name}</span>
                    <span className="text-gray-500 text-sm ml-2">({selectedAsset.symbol})</span>
                  </div>
                  <div className="text-xs text-gray-500 capitalize">
                    {selectedAsset.assetType}
                  </div>
                </div>
              </>
            )}
          </div>
          
          {/* Controls */}
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleRefresh}
              className="h-8 w-8 p-0"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={toggleFullscreen}
              className="h-8 w-8 p-0"
            >
              {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        
        {/* Price indicators */}
        {priceInfo && (
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <span className="text-xl font-mono font-semibold mr-2">
                ${Number(priceInfo.price).toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}
              </span>
              <div className={`flex items-center text-sm ${
                priceInfo.change >= 0 
                  ? "text-green-500" 
                  : "text-red-500"
              }`}>
                {priceInfo.change >= 0 ? (
                  <ArrowUp className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDown className="h-3 w-3 mr-1" />
                )}
                <span>{Math.abs(priceInfo.changePercent).toFixed(2)}%</span>
              </div>
            </div>
            
            <div className="flex space-x-2 text-xs text-muted-foreground">
              <div>
                <span className="mr-1">O:</span>
                <span className="font-mono">${Number(priceInfo.open).toLocaleString(undefined, {maximumFractionDigits: 2})}</span>
              </div>
              <div>
                <span className="mr-1">H:</span>
                <span className="font-mono">${Number(priceInfo.high).toLocaleString(undefined, {maximumFractionDigits: 2})}</span>
              </div>
              <div>
                <span className="mr-1">L:</span>
                <span className="font-mono">${Number(priceInfo.low).toLocaleString(undefined, {maximumFractionDigits: 2})}</span>
              </div>
              <div className="hidden md:block">
                <span className="mr-1">Vol:</span>
                <span className="font-mono">{Number(priceInfo.volume).toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
        
        {/* Chart controls - timeframe and chart style */}
        <div className="flex justify-between mt-2">
          <Tabs 
            value={timeframe} 
            onValueChange={setTimeframe}
            className="h-7"
          >
            <TabsList className="h-7 p-0.5">
              <TabsTrigger value="1" className="text-xs h-6 px-2">1m</TabsTrigger>
              <TabsTrigger value="5" className="text-xs h-6 px-2">5m</TabsTrigger>
              <TabsTrigger value="15" className="text-xs h-6 px-2">15m</TabsTrigger>
              <TabsTrigger value="30" className="text-xs h-6 px-2">30m</TabsTrigger>
              <TabsTrigger value="60" className="text-xs h-6 px-2">1h</TabsTrigger>
              <TabsTrigger value="D" className="text-xs h-6 px-2">1d</TabsTrigger>
              <TabsTrigger value="W" className="text-xs h-6 px-2">1w</TabsTrigger>
            </TabsList>
          </Tabs>
          
          <Tabs 
            value={chartStyle} 
            onValueChange={setChartStyle}
            className="h-7"
          >
            <TabsList className="h-7 p-0.5">
              <TabsTrigger value="candles" className="text-xs h-6 px-2">Candles</TabsTrigger>
              <TabsTrigger value="line" className="text-xs h-6 px-2">Line</TabsTrigger>
              <TabsTrigger value="bars" className="text-xs h-6 px-2">Bars</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      
      {/* Chart container */}
      <div className="relative flex-1 min-h-[350px] md:min-h-[450px] lg:min-h-[500px]">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2 text-primary" />
              <p className="text-sm text-muted-foreground">Loading chart...</p>
            </div>
          </div>
        )}
        
        <div 
          id="tradingview_chart" 
          ref={containerRef} 
          className="w-full h-full"
        />
        
        {!selectedAsset && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center p-6">
              <LineChart className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
              <h3 className="text-lg font-medium mb-2">No asset selected</h3>
              <p className="text-sm text-muted-foreground">Select an asset to view the chart</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}