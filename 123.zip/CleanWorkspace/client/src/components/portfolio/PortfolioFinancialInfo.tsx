"use client";

import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { 
  DollarSign, 
  Wallet, 
  TrendingUp, 
  ArrowUpRight,
  Loader2,
  LineChart,
  PiggyBank
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";

interface PortfolioFinancialInfoProps {
  userId?: string;
  portfolio?: {
    totalValue: number;
    availableBalance: number;
    investedAmount: number;
    unrealizedPL: number;
    plPercentage: number;
  };
}

export default function PortfolioFinancialInfo({ userId, portfolio }: PortfolioFinancialInfoProps) {
  // Fetch portfolio data if not provided (and userId exists)
  const { data: portfolioData, isLoading } = useQuery({
    queryKey: [`/api/portfolio/${userId || ''}`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!userId && !portfolio,
  });
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0, // No decimal places for compact display
    }).format(value);
  };
  
  // Use portfolio prop or fetched data
  const data = portfolio || portfolioData || {
    totalValue: 0,
    availableBalance: 0,
    investedAmount: 0,
    unrealizedPL: 0,
    plPercentage: 0
  };
  
  if (isLoading) {
    return (
      <div className="flex h-18 w-full items-center justify-center bg-gradient-to-r from-gray-900/95 to-gray-800/95 backdrop-blur-sm border-b border-gray-700/50 px-6 py-4 shadow-md">
        <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
        <span className="text-sm">Loading financial data...</span>
      </div>
    );
  }
  
  return (
    <div className="flex h-18 w-full items-center justify-between bg-gradient-to-r from-gray-900/95 to-gray-800/95 backdrop-blur-sm border-b border-gray-700/50 px-6 py-4 shadow-md mb-6">
      <div className="flex items-center space-x-8">
        {/* Total Value */}
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-[#2A5CFF]/20 flex items-center justify-center text-[#2A5CFF] mr-3 shadow-sm">
            <DollarSign className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none">Total Value</div>
            <div className="font-bold text-base leading-tight">{formatCurrency(data.totalValue)}</div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-10" />
        
        {/* Available Balance */}
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-[#00C06D]/20 flex items-center justify-center text-[#00C06D] mr-3 shadow-sm">
            <Wallet className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none">Available Balance</div>
            <div className="font-bold text-base leading-tight">{formatCurrency(data.availableBalance)}</div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-10" />
        
        {/* Invested Amount */}
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-500 mr-3 shadow-sm">
            <PiggyBank className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none">Invested Amount</div>
            <div className="font-bold text-base leading-tight">{formatCurrency(data.investedAmount)}</div>
          </div>
        </div>
        
        <Separator orientation="vertical" className="h-10" />
        
        {/* P/L */}
        <div className="flex items-center">
          <div className={`w-8 h-8 rounded-full ${data.unrealizedPL >= 0 ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'} flex items-center justify-center mr-3 shadow-sm`}>
            <TrendingUp className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground leading-none">Unrealized P/L</div>
            <div className={`font-bold text-base leading-tight ${data.unrealizedPL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {formatCurrency(data.unrealizedPL)}
              <span className="text-xs ml-1">
                ({data.plPercentage >= 0 ? '+' : ''}{data.plPercentage.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Deposit button - positioned at the right */}
      <Button 
        size="default" 
        variant="outline"
        className="h-9 px-4 text-sm bg-gradient-to-r from-[#00C06D] to-[#2A5CFF] hover:from-[#00A055] hover:to-[#2240B0] text-white border-none shadow-sm" 
        asChild
      >
        <Link to="/wallet">
          Deposit
          <ArrowUpRight className="ml-1 h-4 w-4" />
        </Link>
      </Button>
    </div>
  );
}