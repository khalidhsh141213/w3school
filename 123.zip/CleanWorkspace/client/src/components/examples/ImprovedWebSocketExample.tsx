/**
 * ImprovedWebSocketExample
 * 
 * Example component demonstrating the improved WebSocket architecture
 * with real-time market data, connection management, and error handling.
 */

import { useEffect, useState } from 'react';
import { ConnectionStatus, Priority } from '../../services/WebSocketService';
import useWebSocketConnection from '../../hooks/useWebSocketConnection';
import useMarketData from '../../hooks/useMarketData';
import WebSocketStatusIndicator from '../WebSocketStatusIndicator';

const AVAILABLE_SYMBOLS = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 
  'BTC-USD', 'ETH-USD', 'EUR-USD', 'GBP-USD'
];

export default function ImprovedWebSocketExample() {
  const [selectedSymbol, setSelectedSymbol] = useState('AAPL');
  const [customMessage, setCustomMessage] = useState('');
  const [receivedMessages, setReceivedMessages] = useState<any[]>([]);
  
  // Use our WebSocket connection hook
  const { 
    status, 
    subscribe, 
    send,
    isConnected
  } = useWebSocketConnection('/market');
  
  // Use our specialized market data hook for the selected symbol
  const {
    data: marketData,
    isLoading,
    error,
    isStale,
    subscribeToSymbol,
    unsubscribeFromSymbol
  } = useMarketData(selectedSymbol, {
    // Set a short polling interval as fallback
    pollingInterval: 10000,
    // Use throttling to reduce UI updates
    throttleUpdates: 500
  });
  
  // Subscribe to all messages for the example log
  useEffect(() => {
    if (isConnected) {
      // This gets ALL messages
      const unsubscribe = subscribe('message', (data) => {
        setReceivedMessages(prev => [
          { data, timestamp: new Date().toISOString() },
          ...prev.slice(0, 9) // Keep last 10 messages
        ]);
      });
      
      return unsubscribe;
    }
  }, [isConnected, subscribe]);
  
  // Handle sending a custom message
  const handleSendMessage = () => {
    if (!customMessage.trim()) return;
    
    try {
      const messageObj = JSON.parse(customMessage);
      send('custom', messageObj, Priority.NORMAL);
      setCustomMessage('');
    } catch (error) {
      alert('Invalid JSON. Please check the format.');
    }
  };
  
  // Handle symbol change
  const handleSymbolChange = (newSymbol: string) => {
    setSelectedSymbol(newSymbol);
  };
  
  // Format price changes with colors
  const formatPriceChange = (change?: number, percent?: number) => {
    if (change === undefined || percent === undefined) return 'N/A';
    
    const color = change >= 0 ? 'text-green-600' : 'text-red-600';
    const sign = change >= 0 ? '+' : '';
    
    return (
      <span className={color}>
        {sign}{change.toFixed(2)} ({sign}{percent.toFixed(2)}%)
      </span>
    );
  };
  
  // Render the loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Market Data</h2>
          <WebSocketStatusIndicator />
        </div>
        
        <div className="p-8 flex justify-center items-center">
          <div className="animate-pulse flex space-x-4">
            <div className="rounded-full bg-gray-200 h-12 w-12"></div>
            <div className="flex-1 space-y-4 py-1">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header with WebSocket Status */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">
          WebSocket Example
          {isStale && (
            <span className="ml-2 text-xs text-amber-600 font-normal">
              (Data may be stale)
            </span>
          )}
        </h2>
        <WebSocketStatusIndicator />
      </div>
      
      {/* Error display */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
          Error: {error.message}
        </div>
      )}
      
      {/* Market data display and symbol selector */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="card bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Symbol
            </label>
            <div className="flex gap-2 flex-wrap">
              {AVAILABLE_SYMBOLS.map(symbol => (
                <button
                  key={symbol}
                  className={`px-3 py-1 text-sm rounded-full ${
                    selectedSymbol === symbol
                      ? 'bg-blue-100 text-blue-700 border-blue-300'
                      : 'bg-gray-100 text-gray-700 border-gray-200'
                  } border`}
                  onClick={() => handleSymbolChange(symbol)}
                >
                  {symbol}
                </button>
              ))}
            </div>
          </div>
          
          {marketData ? (
            <div className="space-y-4">
              <div className="flex justify-between items-baseline">
                <h3 className="text-lg font-semibold">{marketData.symbol}</h3>
                <span className="text-gray-500 text-sm">
                  Last Updated: {new Date(marketData.timestamp).toLocaleTimeString()}
                </span>
              </div>
              
              <div className="text-3xl font-bold">
                ${marketData.price.toFixed(2)}
              </div>
              
              <div className="text-lg">
                Change: {formatPriceChange(marketData.change, marketData.changePercent)}
              </div>
              
              {marketData.volume !== undefined && (
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-sm border-t border-gray-100 pt-2">
                  <div className="text-gray-500">Volume</div>
                  <div className="text-right font-medium">{marketData.volume.toLocaleString()}</div>
                  
                  {marketData.high !== undefined && (
                    <>
                      <div className="text-gray-500">High</div>
                      <div className="text-right font-medium">${marketData.high.toFixed(2)}</div>
                    </>
                  )}
                  
                  {marketData.low !== undefined && (
                    <>
                      <div className="text-gray-500">Low</div>
                      <div className="text-right font-medium">${marketData.low.toFixed(2)}</div>
                    </>
                  )}
                  
                  {marketData.open !== undefined && (
                    <>
                      <div className="text-gray-500">Open</div>
                      <div className="text-right font-medium">${marketData.open.toFixed(2)}</div>
                    </>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">
              No data available for {selectedSymbol}
            </div>
          )}
        </div>
        
        {/* WebSocket Messages and Controls */}
        <div className="card bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold mb-4">WebSocket Controls</h3>
          
          {/* Connection Status */}
          <div className="mb-4">
            <div className="text-sm font-medium text-gray-700 mb-1">
              Connection Status
            </div>
            <div className={`text-sm ${
              status === ConnectionStatus.CONNECTED 
                ? 'text-green-600' 
                : 'text-gray-500'
            }`}>
              {status}
            </div>
          </div>
          
          {/* Custom Message Sender */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Send Custom Message
            </label>
            <div className="flex gap-2">
              <textarea
                className="flex-1 min-h-[80px] p-2 border border-gray-300 rounded-md text-sm"
                placeholder='{"type": "example", "data": 123}'
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                disabled={!isConnected}
              />
              <button
                className="bg-blue-500 text-white px-3 py-2 rounded-md text-sm disabled:bg-gray-300"
                onClick={handleSendMessage}
                disabled={!isConnected || !customMessage.trim()}
              >
                Send
              </button>
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Enter valid JSON to send a custom message.
            </div>
          </div>
          
          {/* Recent Messages */}
          <div>
            <div className="text-sm font-medium text-gray-700 mb-1">
              Recent Messages ({receivedMessages.length})
            </div>
            <div className="border border-gray-200 rounded-md h-[200px] overflow-y-auto text-xs">
              {receivedMessages.length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  No messages received yet
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {receivedMessages.map((msg, i) => (
                    <div key={i} className="p-2 hover:bg-gray-50">
                      <div className="text-gray-400 mb-1">{msg.timestamp}</div>
                      <pre className="font-mono whitespace-pre-wrap break-all">
                        {JSON.stringify(msg.data, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Implementation Details Section */}
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mt-6">
        <h3 className="text-lg font-semibold mb-2">Implementation Features</h3>
        <ul className="list-disc pl-5 space-y-1 text-sm">
          <li>
            <strong>Singleton WebSocket Service</strong> with connection pooling to reduce resource usage
          </li>
          <li>
            <strong>Circuit Breaker Pattern</strong> to prevent overwhelming servers during outages
          </li>
          <li>
            <strong>Message Queueing</strong> with priority handling for critical messages
          </li>
          <li>
            <strong>Automatic Reconnection</strong> with exponential backoff
          </li>
          <li>
            <strong>Rate Limiting</strong> to control message flow and prevent server overload
          </li>
          <li>
            <strong>Specialized Hooks</strong> for different data types (market data, portfolio, etc.)
          </li>
          <li>
            <strong>Fallback Polling</strong> when WebSocket is unavailable
          </li>
          <li>
            <strong>Update Throttling</strong> to reduce unnecessary re-renders
          </li>
        </ul>
      </div>
    </div>
  );
}