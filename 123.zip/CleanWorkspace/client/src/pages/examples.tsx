import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import AssetSelectorExample from '../examples/AssetSelectorExample';
import MarketDataExample from '../examples/MarketDataExample';
import PriceDisplayExample from '../examples/PriceDisplayExample';
import WebSocketExample from '../examples/WebSocketExample';
import EconomicEventsExample from '../components/examples/EconomicEventsExample';

/**
 * Examples Page
 * 
 * This page showcases various components with example implementations.
 * The tabbed interface makes it easy to navigate between different examples.
 */
const ExamplesPage: React.FC = () => {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Example Components</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>About These Examples</CardTitle>
          <CardDescription>
            This page demonstrates reusable components that have been consolidated across the application.
            Each example shows how to use the component with different configurations.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600">
            These examples serve as living documentation for how to use the shared components
            in the Trading App. Browse through the tabs to see different components with 
            their various configurations and use cases.
          </p>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="websocket">
        <TabsList className="mb-6">
          <TabsTrigger value="websocket">WebSocket</TabsTrigger>
          <TabsTrigger value="assetSelector">Asset Selector</TabsTrigger>
          <TabsTrigger value="priceDisplay">Price Display</TabsTrigger>
          <TabsTrigger value="marketData">Market Data</TabsTrigger>
          <TabsTrigger value="economicEvents">Economic Events</TabsTrigger>
        </TabsList>
        
        <TabsContent value="websocket">
          <WebSocketExample />
        </TabsContent>
        
        <TabsContent value="assetSelector">
          <AssetSelectorExample />
        </TabsContent>
        
        <TabsContent value="priceDisplay">
          <PriceDisplayExample />
        </TabsContent>
        
        <TabsContent value="marketData">
          <MarketDataExample />
        </TabsContent>
        
        <TabsContent value="economicEvents">
          <EconomicEventsExample />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ExamplesPage; 