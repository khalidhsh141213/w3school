
import { PolygonWebSocketService } from './polygonWebSocket';
import { log } from '../utils/logger';

export class MarketDataUpdater {
  private polygonWS: PolygonWebSocketService;

  constructor(apiKey: string) {
    this.polygonWS = new PolygonWebSocketService(
      apiKey,
      this.handlePriceUpdate.bind(this)
    );
  }

  public start() {
    log('Starting market data updater...', 'market');
    this.polygonWS.connect();
  }

  public stop() {
    this.polygonWS.disconnect();
  }

  private handlePriceUpdate(data: any) {
    log(`Price update received for ${data.pair}`, 'market');
  }
}
