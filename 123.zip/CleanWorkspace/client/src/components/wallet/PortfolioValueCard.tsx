import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { ArrowUpDown } from 'lucide-react';

interface PortfolioValueCardProps {
  portfolioValue: number;
  currency: string;
  onCurrencyChange: (currency: string) => void;
}

export default function PortfolioValueCard({ 
  portfolioValue, 
  currency, 
  onCurrencyChange 
}: PortfolioValueCardProps) {
  // Simple conversion rates for demo purposes
  const conversionRates = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 148.52,
    CAD: 1.34
  };
  
  // Convert portfolio value to selected currency
  const convertedValue = portfolioValue * conversionRates[currency];
  
  // Format currency symbols
  const getCurrencySymbol = (currency: string) => {
    switch (currency) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'GBP': return '£';
      case 'JPY': return '¥';
      case 'CAD': return 'C$';
      default: return '$';
    }
  };
  
  return (
    <Card className="shadow-md">
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <CardTitle className="text-lg">Portfolio Value</CardTitle>
          
          <Select value={currency} onValueChange={onCurrencyChange}>
            <SelectTrigger className="w-[100px]">
              <SelectValue placeholder="Currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="JPY">JPY</SelectItem>
              <SelectItem value="CAD">CAD</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <div className="text-3xl font-bold mb-4">
          {getCurrencySymbol(currency)}{convertedValue.toLocaleString(undefined, {
            minimumFractionDigits: currency === 'JPY' ? 0 : 2,
            maximumFractionDigits: currency === 'JPY' ? 0 : 2
          })}
        </div>
        
        <div className="text-sm text-gray-500 flex items-center">
          <ArrowUpDown className="h-4 w-4 mr-1" />
          <span>1 USD = {getCurrencySymbol(currency)}{conversionRates[currency].toFixed(currency === 'JPY' ? 0 : 2)} {currency}</span>
        </div>
      </CardContent>
    </Card>
  );
}