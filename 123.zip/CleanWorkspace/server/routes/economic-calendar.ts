import { Router } from 'express';
import { syncPolygonEconomicEvents, getEconomicEventsByMonth } from '../services/economicEventsService';
import { verifyAuth, verifyAdmin } from '../middleware/auth';

const router = Router();

/**
 * GET /api/economic-events
 * Get economic events for a specific month
 * 
 * Query parameters:
 * - month: string (YYYY-MM format)
 */
router.get('/economic-events', async (req, res) => {
  try {
    let month = req.query.month as string;
    
    // Default to current month if none specified
    if (!month) {
      const now = new Date();
      month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    }
    
    console.log(`[economicCalendarRoute] Fetching events for month ${month}`);
    
    // Validate month format (YYYY-MM)
    if (!/^\d{4}-\d{2}$/.test(month)) {
      return res.status(400).json({ 
        error: 'Invalid month format. Expected format: YYYY-MM' 
      });
    }
    
    // Get events from database
    const events = await getEconomicEventsByMonth(month);
    
    res.json(events);
  } catch (error) {
    console.error('[economicCalendarRoute] Error fetching economic events:', error);
    res.status(500).json({ 
      error: 'Failed to fetch economic events',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * POST /api/sync-economic-calendar
 * Sync economic events from Polygon for a specific month
 * 
 * Body:
 * - month: string (YYYY-MM format, or 'all' for all months)
 */
router.post('/sync-economic-calendar', verifyAuth, async (req, res) => {
  try {
    const { month } = req.body;
    
    // Validate month parameter
    if (!month) {
      const now = new Date();
      req.body.month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    }
    
    console.log(`[economicCalendarRoute] Syncing events for month ${req.body.month}`);
    
    if (req.body.month !== 'all' && !/^\d{4}-\d{2}$/.test(req.body.month)) {
      return res.status(400).json({ 
        error: 'Invalid month format. Expected format: YYYY-MM or "all"' 
      });
    }
    
    // Sync events from Polygon
    const count = await syncPolygonEconomicEvents(req.body.month);
    
    res.json({ 
      message: `Successfully synced ${count} economic events for ${req.body.month}`,
      count
    });
  } catch (error) {
    console.error('[economicCalendarRoute] Error syncing economic events:', error);
    res.status(500).json({ 
      error: 'Failed to sync economic events',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * POST /api/admin/sync-economic-calendar-all
 * Admin endpoint to sync all economic events (from 2022 to current)
 * This is a long-running operation that might take several minutes
 */
router.post('/admin/sync-economic-calendar-all', verifyAdmin, async (req, res) => {
  try {
    console.log('[economicCalendarRoute] Admin requested sync of all economic events');
    
    // Start the sync process in the background
    const syncPromise = syncPolygonEconomicEvents('all');
    
    // Return immediately to prevent timeout
    res.json({ 
      message: 'Syncing all economic events in the background. This may take several minutes.',
      status: 'started'
    });
    
    // Log when the sync completes
    syncPromise.then(count => {
      console.log(`[economicCalendarRoute] Background sync completed with ${count} events`);
    }).catch(error => {
      console.error('[economicCalendarRoute] Background sync failed:', error);
    });
  } catch (error) {
    console.error('[economicCalendarRoute] Error starting background sync:', error);
    res.status(500).json({ 
      error: 'Failed to start background sync',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router;