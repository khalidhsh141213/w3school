import express, { Request, Response } from 'express';
import { aiService } from '../services/aiService';
import { z } from 'zod';

const router = express.Router();

// Schema for validating the AI request
const aiRequestSchema = z.object({
  prompt: z.string().min(1).max(2000),
  max_length: z.number().optional(),
  temperature: z.number().optional(),
  num_return_sequences: z.number().optional(),
});

/**
 * POST /api/ai/generate
 * Generate text using the Arabic LLM
 */
router.post('/generate', async (req: Request, res: Response) => {
  try {
    // Validate the request body
    const { prompt, max_length, temperature, num_return_sequences } = aiRequestSchema.parse(req.body);
    
    // Generate text
    const generatedText = await aiService.generateText(prompt, {
      max_length,
      temperature,
      num_return_sequences
    });
    
    // Return the response
    res.json({
      success: true,
      result: generatedText
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Invalid request data',
        errors: error.errors
      });
    }
    
    console.error('Error generating AI response:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate AI response',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * GET /api/ai/health
 * Check if the AI service is healthy
 */
router.get('/health', async (_req: Request, res: Response) => {
  try {
    const isHealthy = await aiService.checkHealth();
    
    if (isHealthy) {
      return res.json({
        success: true,
        status: 'healthy'
      });
    }
    
    res.status(503).json({
      success: false,
      status: 'unhealthy'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error checking AI service health',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router; 