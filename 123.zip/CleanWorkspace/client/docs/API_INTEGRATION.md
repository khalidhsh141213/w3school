
# API Integration Guide

## REST Endpoints
- `/api/user` - User management
- `/api/assets` - Asset data
- `/api/trades` - Trading operations
- `/api/market` - Market data

## WebSocket Events
- `marketUpdate` - Real-time market updates
- `tradeConfirmation` - Trade confirmation events
- `systemStatus` - System status updates

## Error Handling
Use the centralized error handling system from `@/utils/errors`.
