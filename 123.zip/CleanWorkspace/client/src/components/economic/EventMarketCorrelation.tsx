import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { BarChart, LineChart } from '@/components/charts';
import useEventMarketCorrelation, { AssetCorrelation, EventCategory, EventImpact } from '@/hooks/useEventMarketCorrelation';
import { format } from 'date-fns';
import { ArrowDownIcon, ArrowRightIcon, ArrowUpIcon, CalendarIcon, TrendingDownIcon, TrendingUpIcon } from 'lucide-react';

// Impact badge component
const ImpactBadge = ({ score }: { score: number }) => {
  // Determine color based on correlation strength (absolute value)
  const strength = Math.abs(score);
  
  let className = '';
  if (strength >= 0.7) {
    className = score > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  } else if (strength >= 0.4) {
    className = score > 0 ? 'bg-lime-100 text-lime-800' : 'bg-orange-100 text-orange-800';
  } else {
    className = 'bg-gray-100 text-gray-800';
  }
  
  return (
    <Badge className={className}>
      {score > 0 ? '+' : ''}{(score * 100).toFixed(0)}%
    </Badge>
  );
};

// Direction indicator component
const DirectionIndicator = ({ direction }: { direction: 'positive' | 'negative' | 'mixed' }) => {
  if (direction === 'positive') {
    return <TrendingUpIcon className="h-4 w-4 text-green-600" />;
  } else if (direction === 'negative') {
    return <TrendingDownIcon className="h-4 w-4 text-red-600" />;
  }
  return <ArrowRightIcon className="h-4 w-4 text-gray-600" />;
};

// Historical impact card component
const ImpactCard = ({ impact }: { impact: EventImpact }) => {
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-sm font-medium">{impact.eventTitle}</CardTitle>
          <Badge variant={impact.impact === 'high' ? 'destructive' : (impact.impact === 'medium' ? 'warning' : 'outline')}>
            {impact.impact}
          </Badge>
        </div>
        <CardDescription className="flex items-center">
          <CalendarIcon className="h-3 w-3 mr-1" />
          {format(new Date(impact.date), 'PPP')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-sm">Top impacts:</div>
        <div className="grid grid-cols-1 gap-2 mt-2">
          {impact.priceChanges
            .sort((a, b) => Math.abs(b.percentChange) - Math.abs(a.percentChange))
            .slice(0, 3)
            .map((change) => (
              <div key={change.symbol} className="flex justify-between items-center px-2 py-1 rounded-md bg-gray-50">
                <div className="font-medium">{change.symbol}</div>
                <div className={`flex items-center ${change.percentChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {change.percentChange >= 0 
                    ? <ArrowUpIcon className="h-3 w-3 mr-1" /> 
                    : <ArrowDownIcon className="h-3 w-3 mr-1" />
                  }
                  {change.percentChange.toFixed(2)}%
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Categories for selection
const EVENT_CATEGORIES: { label: string; value: EventCategory }[] = [
  { label: 'All Events', value: 'all' },
  { label: 'Interest Rates', value: 'interest_rate' },
  { label: 'GDP', value: 'gdp' },
  { label: 'Employment', value: 'employment' },
  { label: 'Inflation', value: 'inflation' },
  { label: 'Trade', value: 'trade' },
  { label: 'Consumer', value: 'consumer' },
  { label: 'Housing', value: 'housing' },
  { label: 'Central Bank', value: 'central_bank' },
  { label: 'High Impact Events', value: 'high_impact' },
];

// Time frames for selection
const TIME_FRAMES = [
  { label: '1 Hour', value: '1h' },
  { label: '4 Hours', value: '4h' },
  { label: '1 Day', value: '1d' },
  { label: '1 Week', value: '1w' },
];

interface EventMarketCorrelationProps {
  initialCategory?: EventCategory;
  initialTimeFrame?: '1h' | '4h' | '1d' | '1w';
  limit?: number;
}

export function EventMarketCorrelation({
  initialCategory = 'interest_rate',
  initialTimeFrame = '1d',
  limit = 10
}: EventMarketCorrelationProps) {
  // State for filters
  const [category, setCategory] = useState<EventCategory>(initialCategory);
  const [timeFrame, setTimeFrame] = useState<'1h' | '4h' | '1d' | '1w'>(initialTimeFrame);
  
  // Use the correlation hook
  const {
    topImpactedAssets,
    positiveCorrelations,
    negativeCorrelations,
    recentImpacts,
    isLoading,
    error,
    lastUpdated,
    refresh
  } = useEventMarketCorrelation(category, {
    timeFrame: timeFrame,
    minSampleSize: 3,
    useCache: true
  });
  
  // Prepare chart data
  const getCorrelationChartData = (correlations: AssetCorrelation[]) => {
    return correlations
      .slice(0, limit)
      .map(corr => ({
        name: corr.symbol,
        value: corr.correlationScore * 100  // Convert to percentage
      }))
      .sort((a, b) => b.value - a.value);
  };
  
  const positiveChartData = getCorrelationChartData(positiveCorrelations);
  const negativeChartData = getCorrelationChartData(negativeCorrelations)
    .map(item => ({ ...item, value: Math.abs(item.value) })); // Use absolute value for better visualization
  
  // Handle errors
  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Economic Event-Market Correlation</CardTitle>
          <CardDescription>Error loading correlation data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 text-center">
            <div className="text-red-500 mb-4">Failed to load correlation data: {error.message}</div>
            <Button onClick={() => refresh()}>
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <CardTitle>Economic Event-Market Correlation</CardTitle>
            <CardDescription>
              Analyze how economic events affect asset prices
            </CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Select value={category} onValueChange={(value) => setCategory(value as EventCategory)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Event category" />
              </SelectTrigger>
              <SelectContent>
                {EVENT_CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={timeFrame} onValueChange={(value) => setTimeFrame(value as '1h' | '4h' | '1d' | '1w')}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Time frame" />
              </SelectTrigger>
              <SelectContent>
                {TIME_FRAMES.map((tf) => (
                  <SelectItem key={tf.value} value={tf.value}>
                    {tf.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {lastUpdated && (
          <div className="text-xs text-muted-foreground mt-2">
            Last updated: {format(new Date(lastUpdated), 'PPpp')}
            <Button 
              variant="link"
              className="ml-2 p-0 h-auto text-xs"
              onClick={() => refresh()}
            >
              Refresh
            </Button>
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <Tabs defaultValue="overview">
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Impact Overview</TabsTrigger>
              <TabsTrigger value="positive">Positive Correlation</TabsTrigger>
              <TabsTrigger value="negative">Negative Correlation</TabsTrigger>
              <TabsTrigger value="historical">Historical Impact</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Top Assets by Impact</h3>
                    <div className="h-[300px]">
                      <BarChart
                        data={topImpactedAssets.map(asset => ({
                          name: asset.symbol,
                          value: asset.correlationScore * 100  // Convert to percentage
                        }))}
                        xKey="name"
                        yKey="value"
                        colors={
                          topImpactedAssets.map(asset => 
                            asset.correlationScore > 0 ? '#22c55e' : '#ef4444'
                          )
                        }
                      />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Top Impacted Assets</h3>
                    <div className="space-y-2">
                      {topImpactedAssets.slice(0, 5).map((asset) => (
                        <div 
                          key={asset.symbol}
                          className="p-3 rounded-lg border flex justify-between items-center"
                        >
                          <div>
                            <div className="font-medium flex items-center">
                              {asset.symbol}
                              <DirectionIndicator direction={asset.direction} />
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {asset.sampleSize} events analyzed
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <ImpactBadge score={asset.correlationScore} />
                            <div className="text-xs text-muted-foreground mt-1">
                              Avg: {asset.averageImpact.toFixed(2)}%
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                {topImpactedAssets.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-muted-foreground">
                    No significant correlations found for this category
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="positive">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-3">Assets That Rise After Events</h3>
                  <div className="h-[300px]">
                    <BarChart
                      data={positiveChartData}
                      xKey="name"
                      yKey="value"
                      colors={Array(positiveChartData.length).fill('#22c55e')}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {positiveCorrelations.slice(0, 6).map((asset) => (
                    <div 
                      key={asset.symbol}
                      className="p-3 rounded-lg border flex justify-between items-center bg-green-50"
                    >
                      <div>
                        <div className="font-medium">{asset.symbol}</div>
                        <div className="text-xs text-muted-foreground">
                          {asset.name}
                        </div>
                      </div>
                      <div>
                        <ImpactBadge score={asset.correlationScore} />
                      </div>
                    </div>
                  ))}
                </div>
                
                {positiveCorrelations.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-muted-foreground">
                    No significant positive correlations found
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="negative">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-3">Assets That Fall After Events</h3>
                  <div className="h-[300px]">
                    <BarChart
                      data={negativeChartData}
                      xKey="name"
                      yKey="value"
                      colors={Array(negativeChartData.length).fill('#ef4444')}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {negativeCorrelations.slice(0, 6).map((asset) => (
                    <div 
                      key={asset.symbol}
                      className="p-3 rounded-lg border flex justify-between items-center bg-red-50"
                    >
                      <div>
                        <div className="font-medium">{asset.symbol}</div>
                        <div className="text-xs text-muted-foreground">
                          {asset.name}
                        </div>
                      </div>
                      <div>
                        <ImpactBadge score={asset.correlationScore} />
                      </div>
                    </div>
                  ))}
                </div>
                
                {negativeCorrelations.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-muted-foreground">
                    No significant negative correlations found
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="historical">
              <div>
                <h3 className="text-lg font-medium mb-3">Recent Event Impacts</h3>
                <div className="space-y-4">
                  {recentImpacts.map((impact) => (
                    <ImpactCard key={impact.eventId} impact={impact} />
                  ))}
                  
                  {recentImpacts.length === 0 && (
                    <div className="h-32 flex items-center justify-center text-muted-foreground">
                      No historical impact data available
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}

export default EventMarketCorrelation;