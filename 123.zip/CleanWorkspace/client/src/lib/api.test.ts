import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest';
import api, { ApiError, fetchApi, buildUrl } from './api';
import { validateApiResponse, marketDataValidator } from './/validation';

// Mock fetch
global.fetch = vi.fn();

describe('API Client', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('buildUrl', () => {
    it('should build URL with no query params', () => {
      const url = buildUrl('/users');
      expect(url).toBe('/users');
    });

    it('should build URL with query params', () => {
      const url = buildUrl('/assets', { type: 'crypto', active: true });
      expect(url).toBe('/assets?type=crypto&active=true');
    });

    it('should handle undefined query params', () => {
      const url = buildUrl('/market/price', { symbol: 'BTC-USD', interval: undefined });
      expect(url).toBe('/market/price?symbol=BTC-USD');
    });
  });

  describe('fetchApi', () => {
    it('should handle successful JSON responses', async () => {
      const mockResponse = { 
        data: { id: '123', name: 'Test User' },
        success: true,
        timestamp: new Date().toISOString()
      };
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => mockResponse,
        headers: new Headers({ 'content-type': 'application/json' })
      });

      const result = await fetchApi('/users/123');
      expect(result).toEqual(mockResponse);
      expect(global.fetch).toHaveBeenCalledWith('/users/123', expect.any(Object));
    });

    it('should handle non-JSON responses', async () => {
      const mockTextResponse = 'Plain text response';
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        text: async () => mockTextResponse,
        headers: new Headers({ 'content-type': 'text/plain' })
      });

      const result = await fetchApi('/export/csv');
      expect(result).toBe(mockTextResponse);
    });

    it('should throw ApiError for error responses', async () => {
      const errorResponse = {
        code: 'VALIDATION_ERROR',
        message: 'Invalid input',
        details: { field: 'email', error: 'Invalid format' }
      };
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 400,
        json: async () => errorResponse,
        headers: new Headers({ 'content-type': 'application/json' })
      });

      await expect(fetchApi('/users', { method: 'POST' })).rejects.toThrow(ApiError);
      
      try {
        await fetchApi('/users', { method: 'POST' });
      } catch (error) {
        expect(error).toBeInstanceOf(ApiError);
        expect(error.code).toBe('VALIDATION_ERROR');
        expect(error.message).toBe('Invalid input');
        expect(error.details).toEqual({ field: 'email', error: 'Invalid format' });
        expect(error.status).toBe(400);
      }
    });

    it('should handle network errors', async () => {
      (global.fetch as jest.Mock).mockRejectedValueOnce(new Error('Network failure'));

      await expect(fetchApi('/assets')).rejects.toThrow('Network failure');
    });
  });

  describe('API endpoints', () => {
    it('should call auth.login with correct parameters', async () => {
      const mockResponse = { 
        data: { token: 'abc123', user: { id: '123' } },
        success: true,
        timestamp: new Date().toISOString()
      };
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => mockResponse,
        headers: new Headers({ 'content-type': 'application/json' })
      });
      
      const credentials = { email: 'test@example.com', password: 'password123' };
      await api.auth.login(credentials);
      
      expect(global.fetch).toHaveBeenCalledWith(
        '/auth/login',
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify(credentials)
        })
      );
    });

    it('should call orders.create with correct parameters', async () => {
      const mockResponse = { 
        data: { id: 'order123', status: 'pending' },
        success: true,
        timestamp: new Date().toISOString()
      };
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 201,
        json: async () => mockResponse,
        headers: new Headers({ 'content-type': 'application/json' })
      });
      
      const order = { 
        symbol: 'BTC-USD',
        assetId: 'asset123',
        type: 'market',
        direction: 'buy',
        quantity: 1,
        leverage: 2
      };
      
      await api.orders.create(order);
      
      expect(global.fetch).toHaveBeenCalledWith(
        '/orders',
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify(order)
        })
      );
    });

    it('should call market.getLatestPrice with correct parameters', async () => {
      const mockResponse = { 
        data: { symbol: 'BTC-USD', price: 50000 },
        success: true,
        timestamp: new Date().toISOString()
      };
      
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => mockResponse,
        headers: new Headers({ 'content-type': 'application/json' })
      });
      
      await api.market.getLatestPrice('BTC-USD');
      
      expect(global.fetch).toHaveBeenCalledWith(
        '/market/price?symbol=BTC-USD',
        expect.any(Object)
      );
    });
  });
}); 