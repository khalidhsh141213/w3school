interface Window {
  ENV?: {
    WS_URL?: string;
    [key: string]: any;
  };
}