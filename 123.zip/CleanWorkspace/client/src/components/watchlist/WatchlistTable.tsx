import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAuth } from '@/lib/authContext';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import useWebSocketManager from '@/hooks/useWebSocketManager';
import { ConnectionStatus } from '@/services/WebSocketManager';
import { useQuery } from '@tanstack/react-query';
import {
    AlertCircle,
    RotateCcw,
    Search,
    Star,
    StarOff,
    Trash2,
    TrendingDown,
    TrendingUp
} from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { WebSocketMessage as WSMessage } from '@/services/WebSocketManager';
import { useLocation } from 'wouter';

// Define TypeScript interfaces
interface WatchlistItem {
  id: string;
  assetId: string;
  symbol: string;
  name: string;
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  lastUpdated: string;
  type: 'stock' | 'crypto' | 'forex';
  isFavorite?: boolean;
}

interface WebSocketMessage {
  type: string;
  symbol: string;
  price: number;
  changePercent: number;
  timestamp?: number;
}

export default function WatchlistTable() {
  const [searchTerm, setSearchTerm] = useState('');
  const [favoriteFilter, setFavoriteFilter] = useState(false);
  const [watchlistSymbols, setWatchlistSymbols] = useState<string[]>([]);
  const [priceMap, setPriceMap] = useState<Record<string, number>>({});
  const [percentMap, setPercentMap] = useState<Record<string, number>>({});
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  
  // Construct WebSocket URL
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = import.meta.env.VITE_WS_URL || `${protocol}//${host}/ws`;
  
  // Use WebSocketManager hook
  const { status: wsStatus, send, subscribe } = useWebSocketManager();

  // Fetch watchlist
  const { 
    data: watchlist, 
    isLoading: isLoadingWatchlist, 
    error: watchlistError,
    refetch: refetchWatchlist
  } = useQuery({
    queryKey: ['watchlist', user?.id],
    queryFn: async () => {
      try {
        if (!user?.id) {
          throw new Error('User ID is required');
        }
        
        const res = await fetch(`/api/watchlist?userId=${user.id}`);
        if (!res.ok) throw new Error(`Failed to fetch watchlist: ${res.status} ${res.statusText}`);
        
        // Get the response text first to check if it's valid JSON
        const text = await res.text();
        
        try {
          // Try to parse the text as JSON
          return JSON.parse(text);
        } catch (parseError) {
          console.error('Invalid JSON in watchlist response:', parseError);
          console.error('Response content:', text.substring(0, 200) + '...'); // Log first 200 chars
          throw new Error('Invalid JSON response from watchlist API');
        }
      } catch (error) {
        console.error('Error fetching watchlist:', error);
        throw error;
      }
    },
    enabled: !!user,
    retry: 1, // Limit retries on failure
    retryDelay: 1000, // Wait 1 second between retries
  });

  // Extract all watchlist symbols for WebSocket subscription
  useEffect(() => {
    if (watchlist?.length) {
      const symbols = watchlist.map((item: WatchlistItem) => item.symbol);
      setWatchlistSymbols(symbols);
    }
  }, [watchlist]);

  // Set up WebSocket connection for real-time updates
  useEffect(() => {
    if (watchlistSymbols.length === 0 || wsStatus !== ConnectionStatus.CONNECTED) return;
    
    // Create a message handler function
    const handleMessage = (data: any) => {
      try {
        console.log('WebSocket message received:', data);
        
        // Handle different message types
        if (data.type === 'price' || data.type === 'priceUpdate' || data.type === 'marketUpdate') {
          if (data.symbol && watchlistSymbols.includes(data.symbol)) {
            // Update our price map with the latest price
            setPriceMap(prev => ({
              ...prev,
              [data.symbol]: data.price
            }));
            
            // Update percent change if provided
            if (typeof data.changePercent === 'number') {
              setPercentMap(prev => ({
                ...prev,
                [data.symbol]: data.changePercent
              }));
            }
            
            setLastUpdated(new Date());
          }
        } else if (data.type === 'assetList' || data.type === 'marketData' && Array.isArray(data.data)) {
          // Handle asset list updates
          console.log('Received asset list update with', data.data.length, 'assets');
          
          // Process each asset in the list
          data.data.forEach((asset: any) => {
            if (asset.symbol && watchlistSymbols.includes(asset.symbol)) {
              setPriceMap(prev => ({
                ...prev,
                [asset.symbol]: asset.price || asset.currentPrice
              }));
              
              if (typeof asset.changePercent === 'number') {
                setPercentMap(prev => ({
                  ...prev,
                  [asset.symbol]: asset.changePercent
                }));
              }
            }
          });
          
          setLastUpdated(new Date());
        }
      } catch (e) {
        console.error('Error handling WebSocket message:', e);
      }
    };
    
    // Subscribe to WebSocket updates
    const unsubscribe = subscribe('marketUpdate', handleMessage);
    
    // Send a subscription message for watchlist symbols
    send('subscribe', {
      channel: 'market',
      symbols: watchlistSymbols
    });
    
    console.log(`Subscribed to ${watchlistSymbols.length} symbols`);
    
    // Clean up subscription on unmount
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
      // Also unsubscribe from the market data for these symbols
      watchlistSymbols.forEach(symbol => {
        send('unsubscribe', {
          channel: 'market',
          symbol
        });
      });
    };
    
  }, [watchlistSymbols, wsStatus, subscribe, send]);

  // Get real-time price or fallback to API data
  const getLatestPrice = (item: WatchlistItem): number => {
    return priceMap[item.symbol] || item.currentPrice;
  };

  // Get real-time percent change or fallback to API data
  const getLatestPercentChange = (item: WatchlistItem): number => {
    return percentMap[item.symbol] !== undefined ? percentMap[item.symbol] : item.changePercent;
  };

  // Format price change display with icon
  const formatPriceChange = (price: number, prevPrice: number, changePercent: number) => {
    const isPositive = changePercent >= 0;
    return {
      icon: isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />,
      color: isPositive ? 'text-green-600' : 'text-red-600',
    };
  };

  // Function to toggle favorite status
  const toggleFavorite = async (itemId: string) => {
    try {
      const res = await fetch(`/api/watchlist/${itemId}/favorite`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!res.ok) throw new Error('Failed to update favorite status');
      
      // Refetch the watchlist to get updated data
      refetchWatchlist();
    } catch (error) {
      console.error('Error toggling favorite status:', error);
    }
  };

  // Function to remove item from watchlist
  const removeFromWatchlist = async (itemId: string) => {
    try {
      const res = await fetch(`/api/watchlist/${itemId}`, {
        method: 'DELETE',
      });
      
      if (!res.ok) throw new Error('Failed to remove from watchlist');
      
      // Refetch the watchlist to get updated data
      refetchWatchlist();
    } catch (error) {
      console.error('Error removing from watchlist:', error);
    }
  };

  // Filter watchlist items based on search term and favorites filter
  const filteredWatchlist = watchlist?.filter((item: WatchlistItem) => {
    const matchesSearch = searchTerm
      ? item.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.name.toLowerCase().includes(searchTerm.toLowerCase())
      : true;
    
    const matchesFavorite = favoriteFilter ? item.isFavorite : true;
    
    return matchesSearch && matchesFavorite;
  });

  if (isLoadingWatchlist) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Your Watchlist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (watchlistError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Your Watchlist</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Failed to load watchlist data. Please try again later.
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={() => refetchWatchlist()}
              >
                <RotateCcw className="h-4 w-4 mr-2" /> Retry
              </Button>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <CardTitle className="flex items-center">
            Your Watchlist
            {wsStatus === ConnectionStatus.CONNECTED && (
              <span className="ml-2 text-xs px-2 py-0.5 bg-green-100 text-green-700 rounded-full flex items-center">
                <span className="block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
                Live
              </span>
            )}
          </CardTitle>
          
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search assets"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 w-full sm:w-[200px]"
              />
            </div>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setFavoriteFilter(!favoriteFilter)}
              className={favoriteFilter ? "bg-amber-50 border-amber-200 text-amber-700" : ""}
            >
              {favoriteFilter ? (
                <>
                  <Star className="h-4 w-4 mr-1 text-amber-500" /> Favorites
                </>
              ) : (
                <>
                  <Star className="h-4 w-4 mr-1" /> All
                </>
              )}
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {wsStatus === ConnectionStatus.ERROR && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>Live data connection failed. Prices may be delayed.</span>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  send('reconnect', {});
                }}
              >
                <RotateCcw className="h-3 w-3 mr-1" /> Reconnect
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        {(!watchlist || watchlist.length === 0) ? (
          <div className="text-center py-8">
            <h3 className="font-medium mb-2">Your watchlist is empty</h3>
            <p className="text-gray-500 mb-4">Add assets to your watchlist to track them here</p>
            <Button onClick={() => navigate('/discover')}>
              Discover Assets
            </Button>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Symbol</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="text-right">Price</TableHead>
                    <TableHead className="text-right">24h Change</TableHead>
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWatchlist?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                        No matching assets found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredWatchlist?.map((item: WatchlistItem) => {
                      const currentPrice = getLatestPrice(item);
                      const changePercent = getLatestPercentChange(item);
                      const priceChange = formatPriceChange(
                        currentPrice,
                        item.previousPrice,
                        changePercent
                      );
                      
                      return (
                        <TableRow 
                          key={item.id}
                          className="cursor-pointer"
                          onClick={() => navigate(`/trade/${item.symbol}`)}
                        >
                          <TableCell className="font-medium">{item.symbol}</TableCell>
                          <TableCell>{item.name}</TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(currentPrice)}
                          </TableCell>
                          <TableCell className={`text-right ${priceChange.color}`}>
                            <div className="flex items-center justify-end">
                              {priceChange.icon}
                              <span className="ml-1">{formatPercentage(changePercent)}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center space-x-2" onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" size="icon" onClick={() => toggleFavorite(item.id)}>
                                {item.isFavorite ? (
                                  <Star className="h-4 w-4 text-amber-500" />
                                ) : (
                                  <StarOff className="h-4 w-4" />
                                )}
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => removeFromWatchlist(item.id)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
            
            {lastUpdated && (
              <div className="text-xs text-gray-500 mt-4 text-right">
                {wsStatus === ConnectionStatus.CONNECTED ? 'Live updates' : 'Last updated'}: {lastUpdated.toLocaleTimeString()}
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
