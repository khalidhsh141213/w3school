import api from '@/lib/api';
import { WebSocketManager } from '@/lib/websocket/WebSocketManager';
import { Asset, MarketData } from '@/types';
import React, { useEffect, useRef, useState } from 'react';
import { validateApiResponse, marketDataValidator, portfolioValidator } from '../../lib/validation';

interface AssetTrackerProps {
  symbol: string;
  initialLeverage?: number;
}

/**
 * AssetTracker - Example component demonstrating integrated use of:
 * 1. Typed API client for initial data fetching
 * 2. WebSocketManager for real-time updates
 * 3. Proper cleanup of WebSocket connections
 * 4. Error handling for both API and WebSocket
 */
const AssetTracker: React.FC<AssetTrackerProps> = ({ 
  symbol, 
  initialLeverage = 1 
}) => {
  // State management
  const [asset, setAsset] = useState<Asset | null>(null);
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [orderAmount, setOrderAmount] = useState<number>(0);
  const [leverage, setLeverage] = useState<number>(initialLeverage);
  
  // Refs
  const wsManager = useRef<WebSocketManager | null>(null);
  
  // Initial data fetch using API client
  useEffect(() => {
    async function fetchInitialData() {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch asset details using the typed API client
        const assetResponse = await api.assets.getBySymbol(symbol);
        setAsset(assetResponse.data);
        
        // Fetch initial market data
        const marketResponse = await api.market.getLatestPrice(symbol);
        // Validate the response
        const validatedMarketResponse = validateApiResponse(
          marketResponse,
          marketDataValidator,
          (error) => {
            console.error('Validation error:', error);
          }
        );

        setMarketData(marketResponse.data);
      } catch (error) {
        console.error('Failed to fetch initial data:', error);
        setError(error instanceof Error ? error.message : 'Failed to fetch initial data');
      } finally {
        setLoading(false);
      }
    }
    
    fetchInitialData();
  }, [symbol]);
  
  // WebSocket connection for real-time updates
  useEffect(() => {
    if (!asset) return;
    
    // Initialize WebSocket manager if not already done
    if (!wsManager.current) {
      wsManager.current = new WebSocketManager();
    }
    
    // Prepare WebSocket connection
    const manager = wsManager.current;
    
    // Define message handler for market data updates
    const handleMarketUpdate = (data: any) => {
      if (data && data.symbol === symbol) {
        setMarketData({
          symbol: data.symbol,
          price: data.price,
          volume: data.volume || 0,
          high: data.high || 0,
          low: data.low || 0,
          open: data.open || 0,
          close: data.close || data.price,
          changePercent: data.changePercent || 0,
          timestamp: new Date().toISOString()
        });
      }
    };
    
    // Connect to WebSocket and subscribe to market data
    try {
      // Connect to the appropriate endpoint based on asset type
      const endpoint = asset.type === 'crypto' ? 'crypto' : 'forex';
      manager.connect(endpoint);
      
      // Subscribe to market data for this symbol
      manager.subscribe(symbol, handleMarketUpdate);
      
      // Handle connection errors
      manager.onError((err) => {
        console.error('WebSocket error:', err);
        setError(`WebSocket error: ${err.message}`);
      });
    } catch (error) {
      console.error('WebSocket connection failed:', error);
      setError(`WebSocket connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    // Cleanup WebSocket connection on unmount
    return () => {
      if (wsManager.current) {
        wsManager.current.unsubscribe(symbol);
        
        // Close the connection if this is the only subscription
        if (wsManager.current.getSubscriptionCount() === 0) {
          wsManager.current.disconnect();
        }
      }
    };
  }, [asset, symbol]);
  
  // Handle order placement
  const handlePlaceOrder = async (direction: 'buy' | 'sell') => {
    if (!asset || !marketData || orderAmount <= 0) {
      setError('Invalid order parameters');
      return;
    }
    
    try {
      const response = await api.orders.create({
        symbol: asset.symbol,
        assetId: asset.id,
        type: 'market',
        direction,
        quantity: orderAmount,
        leverage
      });
      
      console.log('Order placed successfully:', response.data);
      
      // Reset form
      setOrderAmount(0);
      
      // Refresh portfolio data
      await api.portfolio.getSummary();
      
    } catch (error) {
      console.error('Failed to place order:', error);
      setError(error instanceof Error ? error.message : 'Failed to place order');
    }
  };
  
  if (loading) {
    return <div className="p-4">Loading asset data...</div>;
  }
  
  if (error) {
    return (
      <div className="p-4 border rounded bg-red-50 text-red-800">
        <h3 className="font-bold">Error</h3>
        <p>{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-2 px-4 py-2 bg-red-100 hover:bg-red-200 rounded"
        >
          Retry
        </button>
      </div>
    );
  }
  
  if (!asset || !marketData) {
    return <div className="p-4">No data available</div>;
  }
  
  return (
    <div className="p-4 border rounded">
      <div className="mb-4">
        <h2 className="text-xl font-bold">{asset.name} ({asset.symbol})</h2>
        <div className="flex justify-between mt-2">
          <div>
            <p className="text-2xl font-bold">${marketData.price.toFixed(2)}</p>
            <p className={marketData.changePercent >= 0 ? "text-green-600" : "text-red-600"}>
              {marketData.changePercent >= 0 ? "+" : ""}{marketData.changePercent.toFixed(2)}%
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm">Volume: {marketData.volume.toLocaleString()}</p>
            <p className="text-sm">High: ${marketData.high.toFixed(2)}</p>
            <p className="text-sm">Low: ${marketData.low.toFixed(2)}</p>
          </div>
        </div>
      </div>
      
      <div className="border-t pt-4 mt-4">
        <h3 className="font-bold mb-2">Place Order</h3>
        <div className="mb-4">
          <label className="block text-sm mb-1">Amount</label>
          <input
            type="number"
            value={orderAmount || ''}
            onChange={(e) => setOrderAmount(parseFloat(e.target.value) || 0)}
            className="w-full p-2 border rounded"
            placeholder="Enter amount"
            min="0"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm mb-1">Leverage (1-100x)</label>
          <input
            type="number"
            value={leverage}
            onChange={(e) => setLeverage(Math.min(100, Math.max(1, parseInt(e.target.value) || 1)))}
            className="w-full p-2 border rounded"
            placeholder="Leverage"
            min="1"
            max="100"
          />
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => handlePlaceOrder('buy')}
            disabled={orderAmount <= 0}
            className="flex-1 py-2 bg-green-600 hover:bg-green-700 text-white rounded disabled:opacity-50"
          >
            Buy
          </button>
          <button
            onClick={() => handlePlaceOrder('sell')}
            disabled={orderAmount <= 0}
            className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded disabled:opacity-50"
          >
            Sell
          </button>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-4">
        <p>Last updated: {new Date(marketData.timestamp).toLocaleString()}</p>
        <p className="mt-1">
          Using: WebSocket ({wsManager.current?.isConnected() ? 'Connected' : 'Disconnected'})
        </p>
      </div>
    </div>
  );
};

export default AssetTracker; 