import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useWebSocket } from '@/services/WebSocketManager';
import { Asset, ChartInterval, MarketData } from '@/types';
import { ArrowDown, ArrowUp, Percent } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState, useRef } from 'react';

interface MarketDataViewProps {
  symbol: string;
  interval?: ChartInterval;
  showDetails?: boolean;
  onDataUpdate?: (data: MarketData) => void;
  className?: string;
}

/**
 * MarketDataView Component
 * 
 * A real-time market data display component using the WebSocket Manager for
 * efficient connection handling and proper resource cleanup.
 */
export default function MarketDataView({
  symbol,
  interval = '1m',
  showDetails = true,
  onDataUpdate,
  className
}: MarketDataViewProps) {
  // State for market data
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [asset, setAsset] = useState<Asset | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Debounce for high-frequency updates
  const updateTimeRef = useRef<number>(Date.now());
  const updateIntervalMs = 500; // Only update UI every 500ms for better performance
  
  // Connect to WebSocket with proper configuration
  const { subscribe, send, status } = useWebSocket(
    `${process.env.NEXT_PUBLIC_WS_URL}/market-data`,
    {
      reconnectAttempts: 5,
      reconnectInterval: 2000,
      heartbeatInterval: 30000
    },
    [symbol, interval] // Dependencies - reconnect if these change
  );
  
  // Fetch initial asset data
  useEffect(() => {
    const fetchAssetData = async () => {
      try {
        const response = await fetch(`/api/assets/${symbol}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch asset data: ${response.status}`);
        }
        const data = await response.json();
        setAsset(data);
      } catch (err) {
        console.error('Error fetching asset data:', err);
        setError('Failed to load asset information');
      }
    };
    
    fetchAssetData();
  }, [symbol]);
  
  // Subscribe to market data updates when connection is established
  useEffect(() => {
    if (status === 'connected') {
      // Send subscription message for this symbol and interval
      send({
        type: 'subscribe',
        symbol,
        interval
      });
      
      console.log(`Subscribed to market data for ${symbol} @ ${interval}`);
    }
    
    return () => {
      if (status === 'connected') {
        // Unsubscribe when component unmounts or dependencies change
        send({
          type: 'unsubscribe',
          symbol,
          interval
        });
        
        console.log(`Unsubscribed from market data for ${symbol}`);
      }
    };
  }, [status, send, symbol, interval]);
  
  // Handle incoming WebSocket messages
  useEffect(() => {
    subscribe((data) => {
      try {
        if (data.type === 'market_update' && data.symbol === symbol) {
          const now = Date.now();
          
          // Throttle updates for better performance
          if (now - updateTimeRef.current >= updateIntervalMs) {
            updateTimeRef.current = now;
            setMarketData(data);
            
            // Call the onDataUpdate callback if provided
            if (onDataUpdate) {
              onDataUpdate(data);
            }
          }
        } else if (data.type === 'error') {
          setError(data.message || 'An error occurred');
        }
      } catch (error) {
        console.error('Error processing market data:', error);
      }
    });
  }, [subscribe, symbol, onDataUpdate]);
  
  // Format currency for display
  const formatCurrency = useCallback((value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }, []);
  
  // Format percentage for display
  const formatPercentage = useCallback((value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'percent',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value / 100);
  }, []);
  
  // Memoize price direction to prevent unnecessary re-renders
  const priceDirection = useMemo(() => {
    if (!marketData) return 'neutral';
    return marketData.change > 0 ? 'up' : marketData.change < 0 ? 'down' : 'neutral';
  }, [marketData]);
  
  // Calculate badge color based on price movement
  const badgeVariant = useMemo(() => {
    if (priceDirection === 'up') return 'success';
    if (priceDirection === 'down') return 'destructive';
    return 'secondary';
  }, [priceDirection]);
  
  // Loading state
  if (!marketData && status !== 'error' && !error) {
    return (
      <Card className={cn("market-data-view", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">
            {asset?.name || symbol}
            <Skeleton className="h-6 w-24 ml-2 inline-block" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            <Skeleton className="h-8 w-32" />
            <div className="flex items-center space-x-2">
              <Skeleton className="h-5 w-16" />
              <Skeleton className="h-5 w-20" />
            </div>
            {showDetails && (
              <div className="grid grid-cols-2 gap-2 mt-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Error state
  if (error || status === 'error') {
    return (
      <Card className={cn("market-data-view bg-red-50", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">{asset?.name || symbol}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-red-500">
            {error || 'Failed to connect to market data service'}
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Please try again later or contact support if the issue persists.
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className={cn("market-data-view", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium flex items-center justify-between">
          <div className="flex items-center">
            {asset?.logo && (
              <img 
                src={asset.logo} 
                alt={asset.name} 
                className="w-6 h-6 mr-2"
              />
            )}
            {asset?.name || symbol}
          </div>
          <Badge variant={badgeVariant} className="ml-2">
            {interval}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-2">
          {/* Price */}
          <div className="text-2xl font-bold flex items-center">
            {formatCurrency(marketData?.price || 0)}
            {priceDirection === 'up' && <ArrowUp className="text-green-500 ml-2 h-5 w-5" />}
            {priceDirection === 'down' && <ArrowDown className="text-red-500 ml-2 h-5 w-5" />}
          </div>
          
          {/* Change */}
          <div className="flex items-center space-x-2">
            <span className={cn(
              priceDirection === 'up' ? 'text-green-500' : 
              priceDirection === 'down' ? 'text-red-500' : 
              'text-gray-500'
            )}>
              {formatCurrency(marketData?.change || 0)}
            </span>
            <Badge variant={badgeVariant} className="flex items-center">
              <Percent className="h-3 w-3 mr-1" />
              {formatPercentage(marketData?.changePercent || 0)}
            </Badge>
          </div>
          
          {/* Additional details */}
          {showDetails && marketData && (
            <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">High</span>
                <span>{formatCurrency(marketData.high)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Low</span>
                <span>{formatCurrency(marketData.low)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Volume</span>
                <span>{marketData.volume.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Spread</span>
                <span>{formatCurrency(marketData.spread || 0)}</span>
              </div>
            </div>
          )}
          
          {/* Updated time */}
          <div className="text-xs text-muted-foreground mt-2">
            Updated {new Date(marketData?.timestamp || Date.now()).toLocaleTimeString()}
            <span className="ml-2">
              {status === 'connected' ? '●' : '○'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 