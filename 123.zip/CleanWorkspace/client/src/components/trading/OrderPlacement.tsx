"use client";

import { Button } from "@/components/ui/button";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
    Tabs,
    TabsList,
    TabsTrigger
} from "@/components/ui/tabs";
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import { usePortfolioData } from "@/hooks/use-portfolio-data";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Asset } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
    AlertTriangle,
    CreditCard,
    MinusCircle,
    PlusCircle,
    RefreshCw,
    TrendingDown,
    TrendingUp
} from "lucide-react";
import React, { useEffect, useState, useRef } from "react";
import { z } from "zod";
import WebSocketManagerSingleton, { ConnectionStatus } from '@/services/WebSocketManagerSingleton';

type OrderPlacementProps = {
  selectedAsset: Asset | null;
  marketData: Record<string, any>;
  userId: string | undefined;
};

// Order types
const ORDER_TYPES = ["market", "limit", "stop"] as const;
type OrderType = typeof ORDER_TYPES[number];

// Order sides
const ORDER_SIDES = ["buy", "sell"] as const;
type OrderSide = typeof ORDER_SIDES[number];

// Order schema for validation
const orderSchema = z.object({
  userId: z.string(),
  assetId: z.string(),
  tradeType: z.enum(["buy", "sell"]),
  quantity: z.number().positive(),
  entryPrice: z.number().positive(),
  exitPrice: z.number().positive().optional(),
  status: z.enum(["open", "closed", "cancelled"]).optional(),
  leverage: z.number().min(1).max(100),
  stopLoss: z.number().positive().optional(),
  takeProfit: z.number().positive().optional(),
  profitLoss: z.number().optional(),
  // openedAt is handled by the server with defaultNow()
});

type OrderData = z.infer<typeof orderSchema>;

// Format currency for display
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
};

export default function OrderPlacement({
  selectedAsset,
  marketData,
  userId
}: OrderPlacementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Use WebSocketManagerSingleton for real-time updates
  const wsRef = useRef<any>(null);
  const [wsStatus, setWsStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  
  // Subscribe to WebSocket updates
  useEffect(() => {
    // Don't set up WebSocket if no asset is selected
    if (!selectedAsset) return;
    
    // Use dynamic WebSocket URL based on current window location
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws`;
    
    console.log('[OrderPlacement] Setting up WebSocket connection to:', wsUrl);
    
    try {
      // Use the WebSocketManagerSingleton
      const manager = WebSocketManagerSingleton.getInstance();
      
      // Handle WebSocket messages for market data updates
      const handleMessage = (data: any) => {
        try {
          // Handle both string messages and object messages
          let message = data;
          if (typeof data === 'string') {
            message = JSON.parse(data);
          }
          
          if (message.type === 'marketUpdate' && selectedAsset && message.symbol === selectedAsset.symbol) {
            // Market data is updated automatically by the parent component
            // This is just to ensure we respond to any specific trade events
            console.log('[OrderPlacement] Received market update for:', message.symbol);
          }
        } catch (error) {
          console.error('[OrderPlacement] Error handling WebSocket message:', error);
        }
      };
      
      // Subscribe to WebSocket messages
      manager.subscribe(wsUrl, handleMessage);
      
      // Store references for cleanup
      wsRef.current = { wsUrl, messageHandler: handleMessage };
      
      // Set up connection status monitoring
      const checkConnectionStatus = setInterval(() => {
        const status = manager.getStatus(wsUrl);
        setWsStatus(status);
        
        if (status === ConnectionStatus.CONNECTED) {
          // Subscribe to the specific asset's market data
          manager.send(wsUrl, JSON.stringify({
            action: 'subscribe',
            symbols: [selectedAsset.symbol]
          }));
        }
      }, 1000);
      
      // Store interval for cleanup
      wsRef.current.interval = checkConnectionStatus;
      
      // Cleanup on unmount
      return () => {
        if (wsRef.current) {
          const { wsUrl, messageHandler, interval } = wsRef.current;
          // Get the manager singleton
          const manager = WebSocketManagerSingleton.getInstance();
          // Unsubscribe from WebSocket messages
          manager.unsubscribe(wsUrl, messageHandler);
          // Clear the interval
          if (interval) {
            clearInterval(interval);
          }
        }
      };
    } catch (error) {
      console.error('[OrderPlacement] Error setting up WebSocket:', error);
    }
  }, [selectedAsset]);
  
  // Use the shared portfolio data hook
  const { portfolio: portfolioData } = usePortfolioData(userId);
  
  // Order form state
  const [orderSide, setOrderSide] = useState<OrderSide>("buy");
  const [orderType, setOrderType] = useState<OrderType>("market");
  const [quantity, setQuantity] = useState<string>("0.1");
  const [price, setPrice] = useState<string>("");
  const [stopPrice, setStopPrice] = useState<string>("");
  const [leverage, setLeverage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [showAdvanced, setShowAdvanced] = useState<boolean>(true);
  const [takeProfit, setTakeProfit] = useState<string>("");
  const [stopLoss, setStopLoss] = useState<string>("");
  const [useTakeProfit, setUseTakeProfit] = useState<boolean>(true);
  const [useStopLoss, setUseStopLoss] = useState<boolean>(true);
  
  // Get current price of selected asset
  const getCurrentPrice = (): number => {
    if (!selectedAsset) return 0;
    
    const assetData = marketData[selectedAsset.symbol];
    return assetData?.price || selectedAsset.price || 0;
  };

  // Calculate total cost based on quantity and price
  useEffect(() => {
    if (!selectedAsset) return;
    
    const currentPrice = getCurrentPrice();
    const qtyNum = parseFloat(quantity) || 0;
    
    const priceToUse = orderType === "market" 
      ? currentPrice
      : parseFloat(price) || currentPrice;
    
    const calculatedTotal = qtyNum * priceToUse;
    setTotal(calculatedTotal);
  }, [selectedAsset, quantity, price, orderType, marketData]);

  // Set default take profit and stop loss based on order side
  useEffect(() => {
    if (selectedAsset) {
      const currentPrice = getCurrentPrice();
      
      // Set default take profit and stop loss values based on trade type
      if (orderSide === 'buy') {
        setTakeProfit((currentPrice * 1.05).toFixed(2)); // 5% above for buy
        setStopLoss((currentPrice * 0.95).toFixed(2));   // 5% below for buy
      } else {
        setTakeProfit((currentPrice * 0.95).toFixed(2)); // 5% below for sell
        setStopLoss((currentPrice * 1.05).toFixed(2));   // 5% above for sell
      }
    }
  }, [selectedAsset, orderSide, marketData]);

  // Order placement mutation
  const placeTradeMutation = useMutation({
    mutationFn: async (data: OrderData) => {
      try {
        const response = await apiRequest("POST", "/api/trades", data);
        
        if (!response.ok) {
          // Get error details from response
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to place order");
        }
        
        return response.json();
      } catch (error) {
        console.error("Error in trade placement:", error);
        throw error;
      }
    },
    onSuccess: () => {
      // Reset form
      setQuantity("0.1");
      setPrice("");
      setStopPrice("");
      setTakeProfit("");
      setStopLoss("");
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/trades/user", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio", userId] });
      
      toast({
        title: "Order placed successfully",
        description: `${orderSide.toUpperCase()} ${quantity} ${selectedAsset?.symbol} at ${orderType === "market" ? "market price" : price}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to place order",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  // Update price field when selected asset or order type changes
  useEffect(() => {
    if (orderType !== "market" && selectedAsset) {
      const currentPrice = getCurrentPrice();
      setPrice(currentPrice.toString());
    }
  }, [selectedAsset, orderType]);

  // Handle order submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedAsset || !userId) {
      toast({
        title: "Cannot place order",
        description: "Please select an asset and ensure you are logged in",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // Validate quantity
      const quantityNum = parseFloat(quantity);
      if (isNaN(quantityNum) || quantityNum <= 0) {
        toast({
          title: "Invalid quantity",
          description: "Please enter a valid positive quantity",
          variant: "destructive",
        });
        return;
      }
      
      // Enforce minimum order size
      const minOrderSize = 0.01;
      if (quantityNum < minOrderSize) {
        toast({
          title: "Order too small",
          description: `Minimum order size is ${minOrderSize}`,
          variant: "destructive",
        });
        return;
      }
      
      // Validate leverage
      if (leverage < 1 || leverage > 100) {
        toast({
          title: "Invalid leverage",
          description: "Leverage must be between 1 and 100",
          variant: "destructive",
        });
        return;
      }
      
      // Calculate required margin based on leverage
      const currentPrice = getCurrentPrice();
      const orderTotal = quantityNum * currentPrice;
      const requiredMargin = orderTotal / leverage;
      const availableBalance = portfolioData?.availableBalance || 0;
      
      // For buy orders, check if we have sufficient balance/margin
      if (orderSide === "buy") {
        if (requiredMargin > availableBalance) {
          toast({
            title: "Insufficient margin",
            description: `Required margin (${formatCurrency(requiredMargin)}) exceeds your available balance (${formatCurrency(availableBalance)})`,
            variant: "destructive",
          });
          return;
        }
      }
      
      // Create order data object
      const orderData: OrderData = {
        userId,
        assetId: selectedAsset.id,
        tradeType: orderSide,
        quantity: quantityNum,
        entryPrice: currentPrice,
        leverage,
        status: "open",
      };
      
      // Add stop loss and take profit if enabled
      if (useStopLoss && stopLoss && showAdvanced) {
        orderData.stopLoss = parseFloat(stopLoss);
      } else if (orderType !== "market") {
        // Default values if advanced options not shown
        const priceValue = parseFloat(price);
        if (orderSide === "buy") {
          orderData.stopLoss = priceValue * 0.95; // 5% below price
        } else {
          orderData.stopLoss = priceValue * 1.05; // 5% above price for sell orders
        }
      }
      
      if (useTakeProfit && takeProfit && showAdvanced) {
        orderData.takeProfit = parseFloat(takeProfit);
      } else if (orderType !== "market") {
        // Default values if advanced options not shown
        const priceValue = parseFloat(price);
        if (orderSide === "buy") {
          orderData.takeProfit = priceValue * 1.05; // 5% above price
        } else {
          orderData.takeProfit = priceValue * 0.95; // 5% below price for sell orders
        }
      }
      
      // Validate the order data
      orderSchema.parse(orderData);
      
      // Place the trade
      placeTradeMutation.mutate(orderData);
      
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Invalid order parameters",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error placing order",
          description: error.message || "An unexpected error occurred",
          variant: "destructive",
        });
      }
    }
  };
  
  // Quick quantity buttons
  const handleQuickQuantity = (value: number) => {
    setQuantity(value.toString());
  };
  
  // Price increment/decrement
  const handlePriceChange = (increment: boolean) => {
    const currentPrice = parseFloat(price || "0");
    if (isNaN(currentPrice)) return;
    
    const step = selectedAsset?.priceStep || 0.01;
    const newPrice = increment ? currentPrice + step : currentPrice - step;
    
    if (newPrice <= 0) return; // Prevent negative or zero prices
    setPrice(newPrice.toFixed(2));
  };
  
  // Calculate quick order amount based on available balance
  const getQuickOrderAmount = (percent: number): string => {
    if (!availableBalance) return "0.01";
    const maxAmount = (availableBalance * (percent / 100)) / getCurrentPrice();
    return maxAmount.toFixed(4);
  };
  
  // Calculate position size in USD
  const calculatePositionSize = (): number => {
    if (!selectedAsset) return 0;
    const qtyNum = parseFloat(quantity) || 0;
    return qtyNum * getCurrentPrice();
  };
  
  if (!selectedAsset) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Place Order</CardTitle>
          <CardDescription>Select an asset to start trading</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  const currentPrice = getCurrentPrice();
  const isBuying = orderSide === 'buy';
  const availableBalance = portfolioData?.availableBalance || 0;
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            Place Order
            <span className="text-sm font-normal text-muted-foreground">
              {selectedAsset.symbol}
            </span>
          </div>
          <div className="text-base font-medium">
            {formatCurrency(currentPrice)}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Order Type Tabs */}
          <Tabs defaultValue="market" value={orderType} onValueChange={(v) => setOrderType(v as OrderType)} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="market">Market</TabsTrigger>
              <TabsTrigger value="limit">Limit</TabsTrigger>
              <TabsTrigger value="stop">Stop</TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Buy/Sell Order Tabs */}
          <Tabs defaultValue="buy" value={orderSide} onValueChange={(v) => setOrderSide(v as OrderSide)} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buy" className="bg-green-50 data-[state=active]:bg-green-100">
                <TrendingUp className="h-4 w-4 mr-2 text-green-600" />
                Buy
              </TabsTrigger>
              <TabsTrigger value="sell" className="bg-red-50 data-[state=active]:bg-red-100">
                <TrendingDown className="h-4 w-4 mr-2 text-red-600" />
                Sell
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Price Input (for limit and stop orders) */}
          {orderType !== "market" && (
            <div className="space-y-2">
              <Label htmlFor="price" className="text-sm font-medium">
                {orderType === "limit" ? "Limit Price" : "Stop Price"}
              </Label>
              <div className="flex items-center">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-r-none"
                  onClick={() => handlePriceChange(false)}
                >
                  <MinusCircle className="h-4 w-4" />
                </Button>
                <Input
                  id="price"
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="rounded-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  step="0.01"
                  min="0"
                  required={orderType !== "market"}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-l-none"
                  onClick={() => handlePriceChange(true)}
                >
                  <PlusCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
          
          {/* Quantity Input */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="quantity" className="text-sm font-medium">
                Quantity
              </Label>
              
              <div className="flex gap-1">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="xs" 
                        onClick={() => handleQuickQuantity(parseFloat(getQuickOrderAmount(25)))}
                        className="h-5 px-1 text-xs"
                      >
                        25%
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>25% of available balance</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="xs" 
                        onClick={() => handleQuickQuantity(parseFloat(getQuickOrderAmount(50)))}
                        className="h-5 px-1 text-xs"
                      >
                        50%
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>50% of available balance</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="xs" 
                        onClick={() => handleQuickQuantity(parseFloat(getQuickOrderAmount(75)))}
                        className="h-5 px-1 text-xs"
                      >
                        75%
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>75% of available balance</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="xs" 
                        onClick={() => handleQuickQuantity(parseFloat(getQuickOrderAmount(100)))}
                        className="h-5 px-1 text-xs"
                      >
                        100%
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>100% of available balance</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>
            
            <div className="flex items-center">
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-8 w-8 rounded-r-none"
                onClick={() => {
                  const current = parseFloat(quantity) || 0;
                  if (current > 0.01) setQuantity((current - 0.01).toString());
                }}
              >
                <MinusCircle className="h-4 w-4" />
              </Button>
              <Input
                id="quantity"
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="rounded-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                step="0.01"
                min="0.01"
                required
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-8 w-8 rounded-l-none"
                onClick={() => {
                  const current = parseFloat(quantity) || 0;
                  setQuantity((current + 0.01).toString());
                }}
              >
                <PlusCircle className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Leverage Slider */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="leverage" className="text-sm font-medium flex items-center">
                <CreditCard className="h-4 w-4 mr-1" />
                Leverage
              </Label>
              <span className="text-sm font-medium">{leverage}x</span>
            </div>
            <Slider
              id="leverage"
              min={1}
              max={25}
              step={1}
              value={[leverage]}
              onValueChange={(values) => setLeverage(values[0])}
              className="py-2"
            />
          </div>
          
          {/* Advanced Options Toggle */}
          <div className="flex items-center justify-between">
            <Label htmlFor="advanced-toggle" className="text-sm font-medium cursor-pointer">
              Advanced Options
            </Label>
            <Switch
              id="advanced-toggle"
              checked={showAdvanced}
              onCheckedChange={setShowAdvanced}
            />
          </div>
          
          {/* Advanced Options */}
          {showAdvanced && (
            <div className="space-y-3 border p-3 rounded-md">
              {/* Take Profit */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="take-profit" className="text-sm font-medium flex items-center">
                    <TrendingUp className="h-4 w-4 mr-1 text-green-600" />
                    Take Profit
                  </Label>
                  <Switch
                    id="take-profit-toggle"
                    checked={useTakeProfit}
                    onCheckedChange={setUseTakeProfit}
                  />
                </div>
                
                {useTakeProfit && (
                  <Input
                    id="take-profit"
                    type="number"
                    value={takeProfit}
                    onChange={(e) => setTakeProfit(e.target.value)}
                    className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    step="0.01"
                    min="0"
                  />
                )}
              </div>
              
              {/* Stop Loss */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="stop-loss" className="text-sm font-medium flex items-center">
                    <TrendingDown className="h-4 w-4 mr-1 text-red-600" />
                    Stop Loss
                  </Label>
                  <Switch
                    id="stop-loss-toggle"
                    checked={useStopLoss}
                    onCheckedChange={setUseStopLoss}
                  />
                </div>
                
                {useStopLoss && (
                  <Input
                    id="stop-loss"
                    type="number"
                    value={stopLoss}
                    onChange={(e) => setStopLoss(e.target.value)}
                    className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    step="0.01"
                    min="0"
                  />
                )}
              </div>
            </div>
          )}
          
          {/* Order Summary */}
          <div className="border p-3 rounded-md space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Position Size</span>
              <span className="text-sm font-medium">{formatCurrency(calculatePositionSize())}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Required Margin</span>
              <span className="text-sm font-medium">{formatCurrency(calculatePositionSize() / leverage)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Available Balance</span>
              <span className="text-sm font-medium">{formatCurrency(availableBalance)}</span>
            </div>
            
            {/* Warnings */}
            {orderSide === "buy" && calculatePositionSize() / leverage > availableBalance && (
              <div className="flex items-center mt-2 text-red-500 text-sm">
                <AlertTriangle className="h-4 w-4 mr-1" />
                Insufficient balance for this order
              </div>
            )}
          </div>
          
          {/* Submit Button */}
          <Button
            type="submit"
            className={`w-full ${isBuying ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}
            disabled={placeTradeMutation.isPending}
          >
            {placeTradeMutation.isPending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : isBuying ? (
              <TrendingUp className="h-4 w-4 mr-2" />
            ) : (
              <TrendingDown className="h-4 w-4 mr-2" />
            )}
            {placeTradeMutation.isPending
              ? "Processing..."
              : `${isBuying ? "Buy" : "Sell"} ${selectedAsset.symbol}`}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}