/**
 * useApi Hook
 * 
 * A hook for making API requests with loading state, error handling, and automatic validation.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { z } from 'zod';
import { ApiClient, ApiError, RequestOptions, getApiClient } from '../services/ApiClient';

// API request state
export interface ApiState<T> {
  data: T | null;
  loading: boolean;
  error: ApiError | null;
  loaded: boolean;
}

// API request options
export interface ApiRequestOptions<T> extends RequestOptions {
  onSuccess?: (data: T) => void;
  onError?: (error: ApiError) => void;
  initialData?: T | null;
  skip?: boolean;
}

/**
 * Make an API request and track its state
 * @param apiClient The API client
 * @param method The request method
 * @param endpoint The endpoint
 * @param body The request body
 * @param options The request options
 * @returns The API state and refetch function
 */
function useApiRequest<T>(
  apiClient: ApiClient,
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  endpoint: string,
  body?: any,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newBody?: any, newOptions?: RequestOptions) => Promise<T | null>] {
  // Extract options
  const {
    onSuccess,
    onError,
    initialData = null,
    skip = false,
    ...requestOptions
  } = options;
  
  // API state
  const [state, setState] = useState<ApiState<T>>({
    data: initialData,
    loading: !skip,
    error: null,
    loaded: false,
  });
  
  // Keep track of whether the component is mounted
  const isMounted = useRef(true);
  
  // Current request identifier to handle race conditions
  const requestIdRef = useRef(0);
  
  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);
  
  // Fetch data
  const fetchData = useCallback(
    async (newBody?: any, newOptions?: RequestOptions): Promise<T | null> => {
      // Increment request ID
      const requestId = ++requestIdRef.current;
      
      // Merge options
      const mergedOptions = {
        ...requestOptions,
        ...newOptions,
      };
      
      // Check if request should be skipped
      if (mergedOptions.skip) {
        return state.data;
      }
      
      // Set loading state
      setState(prevState => ({
        ...prevState,
        loading: true,
        error: null,
      }));
      
      try {
        // Make the request
        let result: T;
        
        switch (method) {
          case 'GET':
            result = await apiClient.get<T>(endpoint, mergedOptions);
            break;
          case 'POST':
            result = await apiClient.post<T>(endpoint, newBody ?? body, mergedOptions);
            break;
          case 'PUT':
            result = await apiClient.put<T>(endpoint, newBody ?? body, mergedOptions);
            break;
          case 'PATCH':
            result = await apiClient.patch<T>(endpoint, newBody ?? body, mergedOptions);
            break;
          case 'DELETE':
            result = await apiClient.delete<T>(endpoint, mergedOptions);
            break;
          default:
            throw new Error(`Unsupported method: ${method}`);
        }
        
        // Check if the component is still mounted and this is the latest request
        if (isMounted.current && requestId === requestIdRef.current) {
          // Set success state
          setState({
            data: result,
            loading: false,
            error: null,
            loaded: true,
          });
          
          // Call onSuccess callback
          onSuccess?.(result);
        }
        
        return result;
      } catch (error) {
        // Only update state if this is the latest request and the component is mounted
        if (isMounted.current && requestId === requestIdRef.current) {
          // Normalize error
          const apiError = error instanceof ApiError
            ? error
            : new ApiError('unknown', error?.message || 'Unknown error');
          
          // Set error state
          setState(prevState => ({
            ...prevState,
            loading: false,
            error: apiError,
            loaded: true,
          }));
          
          // Call onError callback
          onError?.(apiError);
        }
        
        return null;
      }
    },
    [apiClient, method, endpoint, body, requestOptions, onSuccess, onError, state.data]
  );
  
  // Initial fetch
  useEffect(() => {
    if (!skip) {
      fetchData();
    }
  }, [fetchData, skip]);
  
  return [state, fetchData];
}

/**
 * Make a GET request and track its state
 * @param endpoint The endpoint
 * @param options The request options
 * @returns The API state and refetch function
 */
export function useApiGet<T>(
  endpoint: string,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newOptions?: RequestOptions) => Promise<T | null>] {
  const apiClient = getApiClient();
  
  return useApiRequest<T>(apiClient, 'GET', endpoint, undefined, options);
}

/**
 * Make a POST request and track its state
 * @param endpoint The endpoint
 * @param body The request body
 * @param options The request options
 * @returns The API state and callback function
 */
export function useApiPost<T>(
  endpoint: string,
  body?: any,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newBody?: any, newOptions?: RequestOptions) => Promise<T | null>] {
  const apiClient = getApiClient();
  
  // Skip initial fetch for mutations
  const mergedOptions = {
    skip: true,
    ...options,
  };
  
  return useApiRequest<T>(apiClient, 'POST', endpoint, body, mergedOptions);
}

/**
 * Make a PUT request and track its state
 * @param endpoint The endpoint
 * @param body The request body
 * @param options The request options
 * @returns The API state and callback function
 */
export function useApiPut<T>(
  endpoint: string,
  body?: any,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newBody?: any, newOptions?: RequestOptions) => Promise<T | null>] {
  const apiClient = getApiClient();
  
  // Skip initial fetch for mutations
  const mergedOptions = {
    skip: true,
    ...options,
  };
  
  return useApiRequest<T>(apiClient, 'PUT', endpoint, body, mergedOptions);
}

/**
 * Make a PATCH request and track its state
 * @param endpoint The endpoint
 * @param body The request body
 * @param options The request options
 * @returns The API state and callback function
 */
export function useApiPatch<T>(
  endpoint: string,
  body?: any,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newBody?: any, newOptions?: RequestOptions) => Promise<T | null>] {
  const apiClient = getApiClient();
  
  // Skip initial fetch for mutations
  const mergedOptions = {
    skip: true,
    ...options,
  };
  
  return useApiRequest<T>(apiClient, 'PATCH', endpoint, body, mergedOptions);
}

/**
 * Make a DELETE request and track its state
 * @param endpoint The endpoint
 * @param options The request options
 * @returns The API state and callback function
 */
export function useApiDelete<T>(
  endpoint: string,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newOptions?: RequestOptions) => Promise<T | null>] {
  const apiClient = getApiClient();
  
  // Skip initial fetch for mutations
  const mergedOptions = {
    skip: true,
    ...options,
  };
  
  return useApiRequest<T>(apiClient, 'DELETE', endpoint, undefined, mergedOptions);
}

/**
 * Make a request with automatic validation
 * @param endpoint The endpoint
 * @param schema The validation schema
 * @param options The request options
 * @returns The API state and refetch function
 */
export function useApiGetValidated<T>(
  endpoint: string,
  schema: z.ZodSchema<T>,
  options: ApiRequestOptions<T> = {}
): [ApiState<T>, (newOptions?: RequestOptions) => Promise<T | null>] {
  // Merge validation options
  const mergedOptions: ApiRequestOptions<T> = {
    ...options,
    validation: {
      ...options.validation,
      schema,
    },
  };
  
  return useApiGet<T>(endpoint, mergedOptions);
} 