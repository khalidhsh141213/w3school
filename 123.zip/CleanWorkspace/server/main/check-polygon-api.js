import 'dotenv/config';
import fetch from 'node-fetch';

const apiKey = process.env.POLYGON_API_KEY;

// URLs to test
const cryptoTickerUrl = `https://api.polygon.io/v2/aggs/ticker/X:BTCUSD/prev?apiKey=${apiKey}`;
const cryptoAggregateUrl = `https://api.polygon.io/v2/aggs/ticker/X:BTCUSD/range/1/minute/2025-03-22/2025-03-23?adjusted=true&sort=desc&limit=10&apiKey=${apiKey}`;

const today = new Date();
const yyyy = today.getFullYear();
const mm = String(today.getMonth() + 1).padStart(2, '0');
const dd = String(today.getDate()).padStart(2, '0');
const formattedDate = `${yyyy}-${mm}-${dd}`;

const realtimeCryptoUrl = `https://api.polygon.io/v2/aggs/ticker/X:BTCUSD/range/1/minute/${formattedDate}/${formattedDate}?adjusted=true&sort=desc&limit=10&apiKey=${apiKey}`;

async function testPolygonApi() {
  console.log('Testing Polygon.io API connectivity...');
  console.log('API Key:', apiKey ? `${apiKey.substring(0, 4)}...` : 'Not set');
  
  try {
    console.log('\n1. Testing crypto ticker endpoint:');
    const tickerResponse = await fetch(cryptoTickerUrl);
    const tickerData = await tickerResponse.json();
    console.log('Status:', tickerResponse.status);
    console.log('Data:', JSON.stringify(tickerData, null, 2));
    
    console.log('\n2. Testing crypto aggregate endpoint:');
    const aggregateResponse = await fetch(cryptoAggregateUrl);
    const aggregateData = await aggregateResponse.json();
    console.log('Status:', aggregateResponse.status);
    console.log('Data:', JSON.stringify(aggregateData, null, 2));
    
    console.log('\n3. Testing crypto realtime data (today):');
    console.log('URL:', realtimeCryptoUrl);
    const realtimeResponse = await fetch(realtimeCryptoUrl);
    const realtimeData = await realtimeResponse.json();
    console.log('Status:', realtimeResponse.status);
    console.log('Data:', JSON.stringify(realtimeData, null, 2));
  } catch (error) {
    console.error('Error testing Polygon API:', error);
  }
}

testPolygonApi(); 