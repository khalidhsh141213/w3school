import postgres from 'postgres';
import 'dotenv/config';

const verifyDatabase = async () => {
  console.log('Verifying database setup...');
  
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is not set');
  }

  // Establish connection
  const sql = postgres(process.env.DATABASE_URL);
  
  try {
    // Check users table
    console.log('Checking users table...');
    const users = await sql`SELECT id, username, email FROM users`;
    console.log(`Users table has ${users.length} records:`);
    users.forEach(user => console.log(`- ${user.username} (${user.email})`));
    
    // Check assets table
    console.log('\nChecking assets table...');
    const assets = await sql`SELECT id, name, symbol, asset_type, price FROM assets`;
    console.log(`Assets table has ${assets.length} records:`);
    assets.forEach(asset => console.log(`- ${asset.symbol}: ${asset.name} (${asset.asset_type}) - $${asset.price}`));
    
    // Check if other tables exist
    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `;
    
    console.log('\nDatabase tables:');
    tables.forEach(table => console.log(`- ${table.table_name}`));
    
    console.log('\nDatabase verification completed successfully');
  } catch (error) {
    console.error('Error verifying database:', error);
  } finally {
    await sql.end();
  }
};

verifyDatabase(); 