# Economic Events Integration Guide

This document outlines the implementation of real-time economic events within the trading application. Economic events include indicators such as interest rate decisions, GDP reports, employment statistics, and other market-moving economic data.

## Architecture Overview

The economic events feature is built using the WebSocket-based architecture, with specialized React hooks for data management and components for display. This architecture enables real-time updates, efficient caching, and robust error handling.

### Core Components

1. **useEconomicEvents Hook**: Manages economic event data with filtering, caching, and WebSocket integration
2. **useEventMarketCorrelation Hook**: Analyzes correlations between economic events and market movements
3. **useEventNotifications Hook**: Manages notification preferences and alerts for economic events
4. **EconomicEventsExample Component**: Demonstrates the hook usage with UI for filtering and displaying events
5. **EventMarketCorrelation Component**: Visualizes how economic events impact different assets
6. **EventNotificationSettings Component**: Manages user notification preferences for economic events
7. **EconomicCalendarPage**: Full calendar page with filtering, correlation analysis, and notification settings
8. **EconomicEventsWidget**: Dashboard widget showing upcoming high-impact economic events

## WebSocket Integration

Economic events use the same WebSocket infrastructure as market data, with a dedicated channel for economic updates. The system supports:

- Real-time event updates when new data is released
- Event status changes (forecast → actual)
- Automatic filtering based on user preferences
- Fallback polling when WebSockets are unavailable
- Real-time notifications for upcoming events
- Real-time market correlation data

## Implementation Details

### useEconomicEvents Hook

This hook is the core of the economic events functionality, providing:

- WebSocket subscription management for real-time updates
- Client-side filtering by category, country, and date range
- Caching with configurable TTL
- Throttled UI updates for high-frequency data
- Fallback polling when WebSocket is disconnected
- Utility functions for common filtering scenarios

```typescript
// Example usage
const {
  events,                // Array of economic events
  isLoading,             // Loading state
  error,                 // Error state
  filterByCategory,      // Filter function for categories
  filterByCountry,       // Filter function for countries
  getUpcomingEvents,     // Get upcoming events
  getHighImpactEvents,   // Get high impact events only
  refresh                // Manual refresh function
} = useEconomicEvents({
  categories: ['interest_rate', 'high_impact'],
  dateRange: {
    start: new Date('2023-01-01'),
    end: new Date('2023-12-31')
  },
  pollingInterval: 60000 // 1 minute fallback polling
});
```

### useEventMarketCorrelation Hook

This specialized hook analyzes the correlation between economic events and asset price movements:

- Real-time correlation data via WebSocket
- Historical impact analysis
- Asset filtering based on correlation strength
- Direction prediction (positive vs negative impact)
- Statistical significance assessment

```typescript
// Example usage
const {
  topImpactedAssets,     // Most impacted assets
  positiveCorrelations,  // Assets with positive correlation
  negativeCorrelations,  // Assets with negative correlation
  recentImpacts,         // Recent event impacts
  isLoading
} = useEventMarketCorrelation('interest_rate', {
  timeFrame: '1d',  
  minSampleSize: 3
});
```

### useEventNotifications Hook

This hook manages economic event notifications and user preferences:

- Real-time notifications via WebSocket
- Customizable notification preferences (categories, countries, impact levels)
- Multiple notification channels (app, email, push, SMS)
- Advance notice settings
- Notification inbox management

```typescript
// Example usage
const {
  settings,
  notifications,
  unreadCount,
  subscribeToCategory,
  unsubscribeFromCategory,
  markAsRead,
  markAllAsRead
} = useEventNotifications({
  autoMarkAsRead: false,
  showToasts: true
});
```

### Components

1. **EconomicEventsExample Component**: UI for interacting with economic events
   - Filters for category, country, and date range
   - Tabs for different views (all events, upcoming, high-impact)
   - Status indicators for WebSocket connection
   - Loading and error states
   - Responsive design for different screen sizes

2. **EventMarketCorrelation Component**: Visualizes correlation between events and markets
   - Bar charts for top impacted assets
   - Tabs for positive and negative correlations
   - Historical impact visualization
   - Time frame selection
   - Category filtering

3. **EventNotificationSettings Component**: Manages notification preferences
   - Category and country subscriptions
   - Impact level filters
   - Notification channel selection
   - Advance notice settings
   - Notification inbox

4. **EconomicCalendarPage**: Comprehensive economic events page
   - Calendar view with date filtering
   - Market correlation analysis
   - Notification settings
   - Trading opportunities (placeholder)
   - Event insights (placeholder)

5. **EconomicEventsWidget**: Dashboard widget for upcoming events
   - High-impact event focus
   - Compact display for dashboards
   - Real-time updates via WebSocket
   - Links to full calendar page

## Data Structures

### Economic Event

```typescript
interface EconomicEvent {
  id: string;              // Unique identifier
  title: string;           // Event title
  description?: string;    // Event description
  country: string;         // Country code (ISO)
  category: string;        // Event category
  impact: 'low' | 'medium' | 'high';  // Market impact level
  date: string;            // Event date (ISO string)
  time?: string;           // Event time
  actual?: string | number; // Actual result
  forecast?: string | number; // Forecasted result
  previous?: string | number; // Previous period result
  unit?: string;           // Unit of measurement
  source?: string;         // Data source
  url?: string;            // Link to more information
  relatedAssets?: string[]; // Assets affected by this event
  createdAt: string;       // Creation timestamp
  updatedAt: string;       // Last update timestamp
}
```

### Asset Correlation

```typescript
interface AssetCorrelation {
  symbol: string;           // Asset symbol
  name: string;             // Asset name
  correlationScore: number; // -1 to 1, where 1 is perfect positive correlation
  averageImpact: number;    // Average % price change after event
  significanceLevel: 'low' | 'medium' | 'high'; // Statistical significance
  sampleSize: number;       // Number of events analyzed
  direction: 'positive' | 'negative' | 'mixed'; // Price movement direction
  timeFrame: string;        // e.g., "1h", "1d", "1w"
}
```

### Event Notification Settings

```typescript
interface EventNotificationSettings {
  id: string;
  userId: string;
  categories: EventCategory[];
  countries: string[];
  impactLevels: ('low' | 'medium' | 'high')[];
  advanceNotice: number; // minutes before event
  channels: NotificationChannel[]; // 'app' | 'email' | 'push' | 'sms'
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}
```

## Category Types

The system supports these economic event categories:

- `interest_rate`: Central bank interest rate decisions
- `gdp`: Gross Domestic Product reports
- `employment`: Employment statistics (NFP, unemployment rate, etc.)
- `inflation`: Inflation metrics (CPI, PPI, etc.)
- `trade`: Trade balance, imports/exports
- `consumer`: Consumer sentiment, retail sales
- `housing`: Housing starts, home sales, building permits
- `central_bank`: Central bank speeches and minutes
- `earnings`: Corporate earnings reports
- `high_impact`: Special filter for high-impact events only
- `all`: All event types

## Best Practices

1. **Filtering Efficiency**: Apply filters at the hook level instead of filtering after data is returned
2. **Error Handling**: Always handle loading and error states in the UI
3. **Caching**: Leverage the built-in caching to reduce API calls
4. **Selective Subscription**: Only subscribe to relevant event categories
5. **Cleanup**: Always clean up subscriptions when components unmount
6. **Correlation Analysis**: Use correlation data to inform trading decisions
7. **Notification Management**: Allow users to customize notification preferences

## Configuration Options

### useEconomicEvents Options

- `pollingInterval`: Fallback polling interval in milliseconds (0 to disable)
- `fetchInitialData`: Whether to fetch initial data via API call
- `throttleUpdates`: Milliseconds to throttle UI updates (0 to disable)
- `cache`: Cache configuration (enabled, maxAge)
- `categories`: Array of event categories to filter by
- `dateRange`: Date range filter with start and end dates
- `limit`: Maximum number of events to fetch/display

### useEventMarketCorrelation Options

- `timeFrame`: Time frame for analyzing price changes after events ('1h', '4h', '1d', '1w')
- `minSampleSize`: Minimum number of events to analyze for correlation
- `useCache`: Whether to use cached correlation data
- `cacheMaxAge`: Maximum age of cached data in milliseconds
- `assetSymbols`: Assets to include in analysis (leave empty for all tracked assets)

### useEventNotifications Options

- `autoMarkAsRead`: Whether to automatically mark notifications as read when received
- `showToasts`: Whether to show toast notifications for new events
- `fetchOnStart`: Whether to fetch notifications when the hook initializes
- `pollInterval`: How often to poll for new notifications (0 to disable)

## Integration with Trading Features

The economic events system is integrated with other trading features:

1. **Dashboard Widget**: Shows upcoming high-impact events on the dashboard
2. **Correlation Analysis**: Shows which assets are most affected by specific event types
3. **Notification System**: Alerts users to upcoming events that may impact their portfolio
4. **Economic Calendar**: Dedicated page for viewing and filtering economic events
5. **Asset Details**: Economic events that may impact specific assets are highlighted

## Conclusion

The economic events system provides a comprehensive solution for tracking, analyzing, and being notified about market-moving economic indicators. By using the WebSocket architecture and specialized hooks, it offers real-time updates, market correlation analysis, and customizable notifications.

This implementation follows the same patterns as other real-time features in the application, ensuring consistency and maintainability across the codebase while adding sophisticated event analysis capabilities.