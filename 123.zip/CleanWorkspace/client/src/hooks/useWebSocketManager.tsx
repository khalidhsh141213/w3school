import { useState, useEffect, useCallback, useRef } from 'react';
// Import WebSocketManagerSingleton directly
import WebSocketManagerSingleton, { ConnectionStatus } from '../services/WebSocketManagerSingleton';

// Function to dynamically construct WebSocket URL based on current environment
export function getWebSocketUrl() {
  const hostname = window.location.hostname;
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  
  // Use specific port handling for different environments
  let port = '';
  
  // In production, we use the same port as the main site
  if (window.location.port) {
    port = `:${window.location.port}`;
  }
  
  // Check for WS_URL environment variable first
  if (window.ENV && window.ENV.WS_URL) {
    console.log("[WebSocketConfig] Using environment WS_URL:", window.ENV.WS_URL);
    return window.ENV.WS_URL;
  }
  
  // Log the construction process for debugging
  const wsUrl = `${protocol}//${hostname}${port}/ws`;
  console.log("[WebSocketConfig] Dynamically constructed WebSocket URL:", wsUrl);
  
  // For development on Replit, we need a fallback to ensure
  // the WebSocket works in all environments
  if (hostname.includes('replit.dev') || hostname.includes('replit.app')) {
    // Extract the base URL without any path
    const baseUrl = `${protocol}//${hostname}${port}`;
    const replicatedUrl = `${baseUrl}/ws`;
    console.log("[WebSocketConfig] Using Replit-specific WebSocket URL:", replicatedUrl);
    return replicatedUrl;
  }
  
  return wsUrl;
}

// Use the singleton pattern
let wsManagerInstance = WebSocketManagerSingleton.getInstance();

export function useWebSocketManager() {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const setupCompleted = useRef(false);

  // Initialize the WebSocket manager on component mount
  useEffect(() => {
    if (setupCompleted.current) return;
    
    try {
      const wsUrl = getWebSocketUrl();
      
      // Get the global WebSocketManagerSingleton instance
      wsManagerInstance = WebSocketManagerSingleton.getInstance();
      
      setupCompleted.current = true;
      
      // Set up status change handler
      wsManagerInstance.onStatusChange((newStatus) => {
        setStatus(newStatus);
      });
      
      // Connect to WebSocket server
      if (!wsManagerInstance.isConnected()) {
        wsManagerInstance.connect(wsUrl);
      }
      
      return () => {
        // No cleanup needed since we're using a singleton instance
      };
    } catch (error) {
      console.error("Error setting up WebSocket manager:", error);
    }
  }, []);

  // Subscribe to a type of message
  const subscribe = useCallback((type: string, handler: (data: any) => void) => {
    const wsUrl = getWebSocketUrl();
    wsManagerInstance.subscribe(wsUrl, handler);
    return () => {
      wsManagerInstance.unsubscribe(wsUrl, handler);
    };
  }, []);

  // Send a message
  const send = useCallback((type: string, data: any, priority?: number) => {
    const wsUrl = getWebSocketUrl();
    // Create a properly formatted message
    const message = {
      type: type,
      data: data,
      timestamp: Date.now(),
      priority: priority || 0
    };
    return wsManagerInstance.send(wsUrl, message);
  }, []);

  // Subscribe to market data
  const subscribeToMarketData = useCallback((symbol: string) => {
    const wsUrl = getWebSocketUrl();
    // Create a message to subscribe to market data
    const message = {
      type: 'subscribe',
      data: { 
        channel: 'market', 
        symbol 
      },
      timestamp: Date.now(),
      priority: 1
    };
    wsManagerInstance.send(wsUrl, message);
    
    // Create a handler for market data updates
    const handler = (data: any) => {
      if (data.type === 'marketUpdate' && data.symbol === symbol) {
        console.log(`[WebSocketManager] Market data for ${symbol}:`, data);
      }
    };
    
    // Subscribe to all messages to filter for this symbol's market data
    wsManagerInstance.subscribe(wsUrl, handler);
    return () => {
      wsManagerInstance.unsubscribe(wsUrl, handler);
      // Send unsubscribe message
      const unsubMessage = {
        type: 'unsubscribe',
        data: { 
          channel: 'market', 
          symbol 
        },
        timestamp: Date.now(),
        priority: 1
      };
      wsManagerInstance.send(wsUrl, unsubMessage);
    };
  }, []);

  // Unsubscribe from market data
  const unsubscribeFromMarketData = useCallback((symbol: string) => {
    const wsUrl = getWebSocketUrl();
    // Send unsubscribe message
    const message = {
      type: 'unsubscribe',
      data: { 
        channel: 'market', 
        symbol 
      },
      timestamp: Date.now(),
      priority: 1
    };
    wsManagerInstance.send(wsUrl, message);
  }, []);

  // Subscribe to economic events
  const subscribeToEconomicEvents = useCallback((categories?: string[]) => {
    const wsUrl = getWebSocketUrl();
    // Create a message to subscribe to economic events
    const message = {
      type: 'subscribe',
      data: { 
        channel: 'economic', 
        categories 
      },
      timestamp: Date.now(),
      priority: 1
    };
    wsManagerInstance.send(wsUrl, message);
    
    // Create a handler for economic event updates
    const handler = (data: any) => {
      if (data.type === 'economicEvent') {
        console.log('[WebSocketManager] Economic event:', data);
      }
    };
    
    // Subscribe to all messages to filter for economic events
    wsManagerInstance.subscribe(wsUrl, handler);
    return () => {
      wsManagerInstance.unsubscribe(wsUrl, handler);
      // Send unsubscribe message
      const unsubMessage = {
        type: 'unsubscribe',
        data: { 
          channel: 'economic', 
          categories 
        },
        timestamp: Date.now(),
        priority: 1
      };
      wsManagerInstance.send(wsUrl, unsubMessage);
    };
  }, []);

  // Subscribe to portfolio updates
  const subscribeToPortfolioUpdates = useCallback((userId: string | number) => {
    const wsUrl = getWebSocketUrl();
    // Create a message to subscribe to portfolio updates
    const message = {
      type: 'subscribe',
      data: { 
        channel: 'portfolio', 
        userId 
      },
      timestamp: Date.now(),
      priority: 1
    };
    wsManagerInstance.send(wsUrl, message);
    
    // Create a handler for portfolio updates
    const handler = (data: any) => {
      if (data.type === 'portfolioUpdate' && data.userId === userId) {
        console.log(`[WebSocketManager] Portfolio update for user ${userId}:`, data);
      }
    };
    
    // Subscribe to all messages to filter for this user's portfolio updates
    wsManagerInstance.subscribe(wsUrl, handler);
    return () => {
      wsManagerInstance.unsubscribe(wsUrl, handler);
      // Send unsubscribe message
      const unsubMessage = {
        type: 'unsubscribe',
        data: { 
          channel: 'portfolio', 
          userId 
        },
        timestamp: Date.now(),
        priority: 1
      };
      wsManagerInstance.send(wsUrl, unsubMessage);
    };
  }, []);

  // Reset the WebSocket connection
  const reset = useCallback(() => {
    const wsUrl = getWebSocketUrl();
    wsManagerInstance.reset(wsUrl);
  }, []);

  // Check if the connection is established
  const isConnected = useCallback(() => {
    return wsManagerInstance.isConnected();
  }, []);

  return {
    status,
    subscribe,
    send,
    subscribeToMarketData,
    unsubscribeFromMarketData,
    subscribeToEconomicEvents,
    subscribeToPortfolioUpdates,
    reset,
    isConnected
  };
}

// Default export for backward compatibility
export default useWebSocketManager;