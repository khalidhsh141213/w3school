import { useState, useEffect } from 'react';

/**
 * Custom hook that returns whether a media query matches
 * @param query The media query to check
 * @returns Whether the media query matches
 */
export function useMediaQuery(query: string): boolean {
  // Initialize state with current match
  const [matches, setMatches] = useState(() => {
    // Check if window exists (browser environment)
    if (typeof window !== 'undefined') {
      return window.matchMedia(query).matches;
    }
    return false;
  });

  useEffect(() => {
    // Ensure we're in browser environment
    if (typeof window === 'undefined') return;

    // Create media query list
    const mediaQueryList = window.matchMedia(query);
    
    // Initial check
    setMatches(mediaQueryList.matches);

    // Create event listener function
    const handleChange = (event: MediaQueryListEvent) => {
      setMatches(event.matches);
    };

    // Modern browsers
    if (mediaQueryList.addEventListener) {
      mediaQueryList.addEventListener('change', handleChange);
      return () => {
        mediaQueryList.removeEventListener('change', handleChange);
      };
    } 
    // Safari and IE legacy support
    else {
      // @ts-ignore - For backwards compatibility
      mediaQueryList.addListener(handleChange);
      return () => {
        // @ts-ignore - For backwards compatibility
        mediaQueryList.removeListener(handleChange);
      };
    }
  }, [query]);

  return matches;
}

/**
 * Convenience hook to check if the screen size is mobile
 */
export function useMobileScreen(): boolean {
  return useMediaQuery('(max-width: 767px)');
}

/**
 * Convenience hook to check if the screen size is tablet
 */
export function useTabletScreen(): boolean {
  return useMediaQuery('(min-width: 768px) and (max-width: 1023px)');
}

/**
 * Convenience hook to check if the screen size is desktop
 */
export function useDesktopScreen(): boolean {
  return useMediaQuery('(min-width: 1024px)');
}

export default useMediaQuery; 