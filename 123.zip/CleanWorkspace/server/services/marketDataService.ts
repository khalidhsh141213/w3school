/**
 * Market Data Service
 * Provides methods for working with market data including caching, 
 * data transformation, and WebSocket broadcasts
 */

import { db } from '../db';
import { marketData, MarketData, marketDataHistory, InsertMarketData } from '../../shared/schema';
import { marketDataCache } from '../cache';
import { eq, desc, and, gte, lte } from 'drizzle-orm';
import { errorHandler, ErrorType, ErrorSeverity } from './errorHandlingService';
import { log } from '../vite';
import { BroadcastFn } from '../websocket';

// Shape of market updates coming from external sources
export interface MarketUpdate {
  symbol: string;
  price: string;
  change?: string;
  changePercent?: string;
  volume?: string;
  high24h?: string | null;
  low24h?: string | null;
  timestamp?: Date | string;
}

export class MarketDataService {
  private static instance: MarketDataService;
  private broadcastFn: BroadcastFn | null = null;

  private constructor() {}

  public static getInstance(): MarketDataService {
    if (!MarketDataService.instance) {
      MarketDataService.instance = new MarketDataService();
    }
    return MarketDataService.instance;
  }

  /**
   * Register WebSocket broadcast function
   */
  public registerBroadcast(broadcastFn: BroadcastFn): void {
    this.broadcastFn = broadcastFn;
  }
  
  /**
   * Get latest market data for a symbol
   */
  public async getMarketData(symbol: string): Promise<MarketData | null> {
    try {
      // Check cache first
      const cachedData = marketDataCache.get<MarketData>(`md_${symbol}`);
      if (cachedData) {
        return cachedData;
      }
      
      // Query the database
      const [data] = await db
        .select()
        .from(marketData)
        .where(eq(marketData.symbol, symbol));
      
      if (data) {
        // Cache the result
        marketDataCache.set(`md_${symbol}`, data);
        return data;
      }
      
      return null;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'market_data',
        { symbol }
      );
      return null;
    }
  }
  
  /**
   * Get market data for multiple symbols efficiently
   */
  public async getMarketDataBatch(symbols: string[]): Promise<Record<string, MarketData>> {
    if (!symbols.length) return {};
    
    try {
      const result: Record<string, MarketData> = {};
      const missingSymbols: string[] = [];
      
      // Check cache first
      symbols.forEach(symbol => {
        const cachedData = marketDataCache.get<MarketData>(`md_${symbol}`);
        if (cachedData) {
          result[symbol] = cachedData;
        } else {
          missingSymbols.push(symbol);
        }
      });
      
      // If everything was in cache, we're done
      if (missingSymbols.length === 0) {
        return result;
      }
      
      // Fetch missing data from database
      const data = await db
        .select()
        .from(marketData)
        .where(
          missingSymbols.length === 1 
            ? eq(marketData.symbol, missingSymbols[0])
            : marketData.symbol.in(missingSymbols)
        );
      
      // Cache results and add to return object
      data.forEach(item => {
        marketDataCache.set(`md_${item.symbol}`, item);
        result[item.symbol] = item;
      });
      
      return result;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT_BATCH',
        'market_data',
        { symbols }
      );
      return {};
    }
  }
  
  /**
   * Update market data for a symbol and broadcast the change
   */
  public async updateMarketData(update: MarketUpdate): Promise<MarketData | null> {
    try {
      // Validate update
      if (!update.symbol || !update.price) {
        errorHandler.logError(
          new Error('Invalid market update'),
          ErrorType.VALIDATION,
          ErrorSeverity.WARNING,
          { update }
        );
        return null;
      }
      
      // Get current market data for the symbol
      const currentData = await this.getMarketData(update.symbol);
      
      // Calculate change and percentChange if not provided
      if (!update.change && currentData) {
        const currentPrice = parseFloat(currentData.price);
        const newPrice = parseFloat(update.price);
        const diff = newPrice - currentPrice;
        update.change = diff.toFixed(2);
        update.changePercent = currentPrice > 0 
          ? ((diff / currentPrice) * 100).toFixed(2) 
          : '0.00';
      }
      
      // Use current values for missing optional fields
      if (currentData) {
        update.volume = update.volume || currentData.volume;
        update.high24h = update.high24h !== undefined ? update.high24h : currentData.high24h;
        update.low24h = update.low24h !== undefined ? update.low24h : currentData.low24h;
      }
      
      // Update the database
      const [updatedData] = await db
        .update(marketData)
        .set({
          price: update.price,
          change: update.change || '0.00',
          changePercent: update.changePercent || '0.00',
          volume: update.volume || '0',
          high24h: update.high24h,
          low24h: update.low24h,
          updatedAt: new Date()
        })
        .where(eq(marketData.symbol, update.symbol))
        .returning();
      
      if (!updatedData) {
        errorHandler.logError(
          new Error(`Failed to update market data for ${update.symbol}`),
          ErrorType.DATABASE,
          ErrorSeverity.WARNING,
          { update }
        );
        return null;
      }
      
      // Record in history table if price changed
      if (currentData && currentData.price !== updatedData.price) {
        await db
          .insert(marketDataHistory)
          .values({
            symbol: updatedData.symbol,
            price: updatedData.price,
            volume: updatedData.volume,
            timestamp: new Date()
          });
      }
      
      // Update cache
      marketDataCache.set(`md_${updatedData.symbol}`, updatedData);
      
      // Broadcast update via WebSocket if available
      if (this.broadcastFn) {
        this.broadcastFn({
          type: 'MARKET_UPDATE',
          data: {
            symbol: updatedData.symbol,
            price: updatedData.price,
            change: updatedData.change,
            changePercent: updatedData.changePercent,
            volume: updatedData.volume,
            high24h: updatedData.high24h,
            low24h: updatedData.low24h,
            timestamp: new Date().toISOString()
          }
        });
      }
      
      return updatedData;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'UPDATE',
        'market_data',
        { symbol: update.symbol }
      );
      return null;
    }
  }
  
  /**
   * Process batch updates efficiently
   */
  public async updateMarketDataBatch(updates: MarketUpdate[]): Promise<number> {
    let successCount = 0;
    
    // Process in small batches to avoid overwhelming the database
    const batchSize = 10;
    for (let i = 0; i < updates.length; i += batchSize) {
      const batch = updates.slice(i, i + batchSize);
      
      // Use Promise.all for parallel processing within each small batch
      const results = await Promise.all(
        batch.map(update => this.updateMarketData(update))
      );
      
      successCount += results.filter(result => result !== null).length;
    }
    
    log(`Updated ${successCount}/${updates.length} market data entries`, 'market');
    return successCount;
  }
  
  /**
   * Get price history for a symbol within a date range
   */
  public async getPriceHistory(
    symbol: string, 
    startDate?: Date, 
    endDate?: Date,
    limit: number = 100
  ): Promise<any[]> {
    try {
      // Build query conditions
      const conditions = [eq(marketDataHistory.symbol, symbol)];
      
      if (startDate) {
        conditions.push(gte(marketDataHistory.timestamp, startDate));
      }
      
      if (endDate) {
        conditions.push(lte(marketDataHistory.timestamp, endDate));
      }
      
      // Run query
      const history = await db
        .select()
        .from(marketDataHistory)
        .where(and(...conditions))
        .orderBy(desc(marketDataHistory.timestamp))
        .limit(limit);
      
      return history;
    } catch (error) {
      errorHandler.logDatabaseError(
        error,
        'SELECT',
        'market_data_history',
        { symbol, startDate, endDate }
      );
      return [];
    }
  }
  
  /**
   * Clear market data cache
   */
  public clearCache(): void {
    marketDataCache.clear();
  }
}

// Export singleton instance
export const marketDataService = MarketDataService.getInstance();