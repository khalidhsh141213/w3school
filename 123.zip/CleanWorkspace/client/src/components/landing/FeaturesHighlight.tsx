import { 
  LineChart, 
  Clock, 
  BarChart3, 
  Coins, 
  Shield, 
  Globe 
} from 'lucide-react';

export default function FeaturesHighlight() {
  const features = [
    {
      icon: <LineChart className="h-10 w-10 text-[#00C06D]" />,
      title: "Real-time Market Data",
      description: "Get instant access to price movements, market depth, and trading volumes across global markets."
    },
    {
      icon: <Clock className="h-10 w-10 text-[#2A5CFF]" />,
      title: "24/7 Trading",
      description: "Trade cryptocurrencies and forex around the clock with our always-on trading platform."
    },
    {
      icon: <BarChart3 className="h-10 w-10 text-[#00C06D]" />,
      title: "Advanced Analytics",
      description: "Powerful tools to analyze market trends and make informed trading decisions."
    },
    {
      icon: <Coins className="h-10 w-10 text-[#2A5CFF]" />,
      title: "Multi-Asset Platform",
      description: "Trade stocks, crypto, forex, and commodities all from a single unified dashboard."
    },
    {
      icon: <Shield className="h-10 w-10 text-[#00C06D]" />,
      title: "Secure Infrastructure",
      description: "Enterprise-grade security protecting your assets and personal information."
    },
    {
      icon: <Globe className="h-10 w-10 text-[#2A5CFF]" />,
      title: "Global Markets",
      description: "Access markets worldwide with multi-currency support and international trading."
    }
  ];

  return (
    <section className="py-20 px-4 bg-[#2A2E39]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Advanced Trading Features
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our platform combines cutting-edge technology with an intuitive interface
            to give you the ultimate trading experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-[#1E2128] p-8 rounded-xl hover:transform hover:scale-105 transition-transform duration-300 border border-gray-800"
            >
              <div className="mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-block p-1 rounded-lg bg-gradient-to-r from-[#00C06D] to-[#2A5CFF]">
            <div className="bg-[#1E2128] px-8 py-4 rounded-md">
              <p className="text-white text-lg font-medium">
                Join over 10,000 traders worldwide who trust our platform
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}