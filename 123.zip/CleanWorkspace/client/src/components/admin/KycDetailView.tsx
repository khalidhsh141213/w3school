import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAdmin } from '../../hooks/useAdmin';
import { useToast } from '@/hooks/use-toast';
import {
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import {
  CheckCircle2,
  XCircle,
  FileText,
  User,
  Loader2,
  Info,
  AlertTriangle,
} from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';

export interface KycRequest {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phoneNumber: string | null;
  submittedAt: string;
  status: string;
  country: string | null;
  city: string | null;
  address: string | null;
  documentType: string | null;
  documentNumber: string | null;
  documentIssueDate: string | null;
  documentExpiryDate: string | null;
  documentFrontUrl: string | null;
  documentBackUrl: string | null;
  selfieUrl: string | null;
  verificationNotes: string | null;
}

export interface KycDetailViewProps {
  requestId: number;
  onClose: () => void;
  onStatusChange: () => void;
}

export const KycDetailView: React.FC<KycDetailViewProps> = ({ 
  requestId, 
  onClose,
  onStatusChange
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { fetchData, updateItem, loading, error } = useAdmin();
  
  const [kycRequests, setKycRequests] = useState<KycRequest[]>([]);
  const [adminNotes, setAdminNotes] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('details');
  
  useEffect(() => {
    loadKycData();
  }, [requestId]);
  
  const loadKycData = async () => {
    try {
      const data = await fetchData('kyc');
      setKycRequests(data);
      
      const request = data.find((item: KycRequest) => item.id === requestId);
      if (request && request.verificationNotes) {
        setAdminNotes(request.verificationNotes);
      }
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.loadFailed'),
      });
    }
  };
  
  const handleApprove = async () => {
    setIsProcessing(true);
    try {
      await updateItem('kyc', requestId, {
        status: 'verified',
        verificationNotes: adminNotes,
      });
      
      toast({
        title: t('admin.kycApproved'),
        description: t('admin.kycApprovedDesc'),
      });
      
      onStatusChange();
      onClose();
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.approveFailed'),
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleReject = async () => {
    if (!adminNotes.trim()) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: t('admin.notesRequired'),
      });
      return;
    }
    
    setIsProcessing(true);
    try {
      await updateItem('kyc', requestId, {
        status: 'rejected',
        verificationNotes: adminNotes,
      });
      
      toast({
        title: t('admin.kycRejected'),
        description: t('admin.kycRejectedDesc'),
      });
      
      onStatusChange();
      onClose();
    } catch (err) {
      toast({
        variant: "destructive",
        title: t('admin.error.title'),
        description: error || t('admin.error.rejectFailed'),
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Find the current KYC request
  const request = kycRequests.find((item: KycRequest) => item.id === requestId);
  
  if (!request) {
    return (
      <div className="flex flex-col items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
        <p>{t('admin.loadingKycData')}</p>
      </div>
    );
  }
  
  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center text-xl">
          <FileText className="h-5 w-5 mr-2" />
          {t('admin.kycRequest')}
          <span className="ml-2">
            {request.status === 'verified' ? (
              <Badge variant="default" className="ml-2">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                {t('admin.verified')}
              </Badge>
            ) : request.status === 'rejected' ? (
              <Badge variant="destructive" className="ml-2">
                <XCircle className="h-3 w-3 mr-1" />
                {t('admin.rejected')}
              </Badge>
            ) : (
              <Badge variant="secondary" className="ml-2">
                <Info className="h-3 w-3 mr-1" />
                {t('admin.pending')}
              </Badge>
            )}
          </span>
        </DialogTitle>
      </DialogHeader>
      
      <div className="mt-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">{t('admin.personalDetails')}</TabsTrigger>
            <TabsTrigger value="documents">{t('admin.documents')}</TabsTrigger>
            <TabsTrigger value="verification">{t('admin.verification')}</TabsTrigger>
          </TabsList>
          
          <TabsContent value="details" className="space-y-4 py-4">
            <div className="flex items-center mb-6">
              <div className="bg-muted rounded-full h-12 w-12 flex items-center justify-center mr-4">
                <User className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-medium">{request.fullName}</h3>
                <p className="text-sm text-muted-foreground">{request.username} | {request.email}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.personalInformation')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableBody>
                      <TableRow>
                        <TableHead className="w-[200px]">{t('admin.fullName')}</TableHead>
                        <TableCell>{request.fullName}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.email')}</TableHead>
                        <TableCell>{request.email}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.username')}</TableHead>
                        <TableCell>{request.username}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.phoneNumber')}</TableHead>
                        <TableCell>{request.phoneNumber || '-'}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.submittedAt')}</TableHead>
                        <TableCell>
                          {request.submittedAt ? format(new Date(request.submittedAt), 'PPpp') : '-'}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{t('admin.addressInformation')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableBody>
                      <TableRow>
                        <TableHead className="w-[200px]">{t('admin.country')}</TableHead>
                        <TableCell>{request.country || '-'}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.city')}</TableHead>
                        <TableCell>{request.city || '-'}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableHead>{t('admin.address')}</TableHead>
                        <TableCell>{request.address || '-'}</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="documents" className="space-y-6 py-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t('admin.documentInformation')}</CardTitle>
                <CardDescription>
                  {t('admin.documentDetails')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableBody>
                    <TableRow>
                      <TableHead className="w-[200px]">{t('admin.documentType')}</TableHead>
                      <TableCell>{request.documentType || '-'}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableHead>{t('admin.documentNumber')}</TableHead>
                      <TableCell>{request.documentNumber || '-'}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableHead>{t('admin.documentIssueDate')}</TableHead>
                      <TableCell>
                        {request.documentIssueDate 
                          ? format(new Date(request.documentIssueDate), 'PP') 
                          : '-'}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableHead>{t('admin.documentExpiryDate')}</TableHead>
                      <TableCell>
                        {request.documentExpiryDate 
                          ? format(new Date(request.documentExpiryDate), 'PP') 
                          : '-'}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">{t('admin.documentFront')}</CardTitle>
                </CardHeader>
                <CardContent>
                  {request.documentFrontUrl ? (
                    <div className="border rounded-md overflow-hidden">
                      <img 
                        src={request.documentFrontUrl} 
                        alt={t('admin.documentFront')} 
                        className="w-full object-contain max-h-[300px]"
                      />
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[200px] border rounded-md bg-muted/20">
                      <AlertTriangle className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">{t('admin.noDocumentUploaded')}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">{t('admin.documentBack')}</CardTitle>
                </CardHeader>
                <CardContent>
                  {request.documentBackUrl ? (
                    <div className="border rounded-md overflow-hidden">
                      <img 
                        src={request.documentBackUrl} 
                        alt={t('admin.documentBack')} 
                        className="w-full object-contain max-h-[300px]"
                      />
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[200px] border rounded-md bg-muted/20">
                      <AlertTriangle className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">{t('admin.noDocumentUploaded')}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t('admin.selfie')}</CardTitle>
                <CardDescription>
                  {t('admin.selfieVerification')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {request.selfieUrl ? (
                  <div className="border rounded-md overflow-hidden">
                    <img 
                      src={request.selfieUrl} 
                      alt={t('admin.selfie')} 
                      className="w-full object-contain max-h-[300px]"
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[200px] border rounded-md bg-muted/20">
                    <AlertTriangle className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">{t('admin.noSelfieUploaded')}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="verification" className="py-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('admin.verificationStatus')}</CardTitle>
                <CardDescription>
                  {t('admin.verificationDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-3 sm:col-span-1">
                    <Card className={`border-l-4 ${
                      request.status === 'verified' 
                        ? 'border-l-green-500' 
                        : request.status === 'rejected'
                        ? 'border-l-red-500'
                        : 'border-l-yellow-500'
                    }`}>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">{t('admin.currentStatus')}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          {request.status === 'verified' ? (
                            <>
                              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                              <span>{t('admin.verified')}</span>
                            </>
                          ) : request.status === 'rejected' ? (
                            <>
                              <XCircle className="h-5 w-5 text-red-500 mr-2" />
                              <span>{t('admin.rejected')}</span>
                            </>
                          ) : (
                            <>
                              <Info className="h-5 w-5 text-yellow-500 mr-2" />
                              <span>{t('admin.pending')}</span>
                            </>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="col-span-3 sm:col-span-2">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">{t('admin.adminNotes')}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {request.status !== 'pending' ? (
                          <p className="text-sm">
                            {request.verificationNotes || t('admin.noNotesProvided')}
                          </p>
                        ) : (
                          <Textarea 
                            placeholder={t('admin.enterVerificationNotes')}
                            value={adminNotes}
                            onChange={(e) => setAdminNotes(e.target.value)}
                            rows={3}
                          />
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                {request.status === 'pending' && (
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={handleReject}
                      disabled={isProcessing}
                    >
                      {isProcessing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <XCircle className="h-4 w-4 mr-2" />}
                      {t('admin.rejectRequest')}
                    </Button>
                    <Button
                      onClick={handleApprove}
                      disabled={isProcessing}
                    >
                      {isProcessing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                      {t('admin.approveRequest')}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <DialogFooter className="mt-6">
        <Button variant="outline" onClick={onClose}>
          {t('admin.close')}
        </Button>
      </DialogFooter>
    </>
  );
};

export default KycDetailView;