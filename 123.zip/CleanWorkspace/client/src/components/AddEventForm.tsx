import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface AddEventFormProps {
  onEventAdded?: () => void;
}

export default function AddEventForm({ onEventAdded }: AddEventFormProps) {
  const [formData, setFormData] = useState({
    event_name: '',
    event_date: '',
    event_time: '00:00',
    country: '',
    description: '',
    importance_level: 'medium',
    asset_impact: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
} 