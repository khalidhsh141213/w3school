import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Check, HelpCircle, MessageSquare, Phone } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Helmet } from "react-helmet";
import { useTranslation } from "react-i18next";
import { useLocation } from 'wouter';
import AiChatBox from "../components/common/AiChatBox";

export default function SupportPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('chat');
  const [submitted, setSubmitted] = useState(false);
  const [, setLocation] = useLocation();

  // Form state
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');

  // Check if user arrived from the old URL (/settings#support)
  useEffect(() => {
    // Check if we're on the settings page with the support hash
    if (window.location.pathname === '/settings' && window.location.hash === '#support') {
      // Redirect to the dedicated support page
      setLocation('/support');
    }
  }, [setLocation]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // In a real application, this would send the form data to a server
    console.log('Support form submitted:', { subject, message, email });

    // Show success message
    setSubmitted(true);

    // Clear form
    setSubject('');
    setMessage('');
    setEmail('');

    // Toast notification
    toast({
      title: t('support.form_submit_success'),
      description: "We'll get back to you as soon as possible.",
      duration: 5000,
    });
  };

  useEffect(() => {
    if (submitted) {
      const timer = setTimeout(() => {
        setSubmitted(false);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [submitted]);

  return (
    <div className="container mx-auto px-4 py-8">
      <Helmet>
        <title>{t('support.title')} | TradePro</title>
      </Helmet>

      <div className="flex items-center mb-6">
        <HelpCircle className="h-6 w-6 mr-2 text-primary" />
        <h1 className="text-2xl font-bold">{t('support.title')}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="chat" className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-2" />
                <span>{t('support.ai_assistant')}</span>
              </TabsTrigger>
              <TabsTrigger value="contact" className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>{t('support.contact_us')}</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="chat" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>{t('ai.chat_title')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <AiChatBox />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contact" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>{t('support.contact_human')}</CardTitle>
                </CardHeader>
                <CardContent>
                  {submitted ? (
                    <Alert className="mb-6 bg-green-50 border-green-200">
                      <Check className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-600">
                        {t('support.form_submit_success')}
                      </AlertDescription>
                    </Alert>
                  ) : null}

                  <form onSubmit={handleFormSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input 
                        id="email" 
                        type="email"
                        placeholder="your.email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="supportSubject">Subject</Label>
                      <Input 
                        id="supportSubject" 
                        placeholder="Briefly describe your issue"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="supportMessage">Message</Label>
                      <textarea 
                        id="supportMessage" 
                        className="w-full min-h-[150px] p-2 border rounded-md"
                        placeholder="Provide details about your issue or question"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full"
                    >
                      Submit Support Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>{t('support.resources')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">{t('support.faq')}</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="#" className="text-blue-600 hover:underline">How to deposit funds?</a>
                  </li>
                  <li>
                    <a href="#" className="text-blue-600 hover:underline">Understanding trading fees</a>
                  </li>
                  <li>
                    <a href="#" className="text-blue-600 hover:underline">Account verification process</a>
                  </li>
                  <li>
                    <a href="#" className="text-blue-600 hover:underline">Withdrawal timelines</a>
                  </li>
                </ul>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">{t('support.trading_hours')}</h3>
                <p className="text-sm text-gray-600">
                  Our platform is available 24/7 for cryptocurrency trading.
                  <br /><br />
                  Stock market hours: Monday to Friday, 9:30 AM - 4:00 PM EST.
                </p>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">{t('support.emergency_contact')}</h3>
                <p className="text-sm text-gray-600">
                  For urgent issues, please contact our emergency support line:
                  <br />
                  <span className="font-semibold">+1 (555) 123-4567</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}