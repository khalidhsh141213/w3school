/**
 * Centralized types for the trading application
 * This file contains all shared types used across components, API clients, and WebSocket connections
 */

// API Response Types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  page: number;
  limit: number;
  totalPages: number;
  totalItems: number;
}

// User and Authentication Types
export interface User {
  id: string;
  username: string;
  email: string;
  fullName?: string;
  role: 'user' | 'admin';
  createdAt: string;
  updatedAt: string;
  preferences?: UserPreferences;
}

export interface UserPreferences {
  theme?: 'light' | 'dark' | 'system';
  language?: string;
  notifications?: {
    email: boolean;
    push: boolean;
    sms: boolean;
  };
  defaultLeverage?: number;
  riskLevel?: 'low' | 'medium' | 'high';
}

export interface LoginCredentials {
  email: string;
  password: string;
  remember?: boolean;
}

export interface RegistrationData {
  username: string;
  email: string;
  password: string;
  fullName?: string;
}

// Asset Types
export interface Asset {
  id: string;
  symbol: string;
  name: string;
  type: 'stock' | 'crypto' | 'forex' | 'commodity' | 'index';
  description?: string;
  imageUrl?: string;
  active: boolean;
  tradable: boolean;
  minTradeAmount?: number;
  maxLeverage?: number;
  createdAt: string;
  updatedAt: string;
}

// Market Data Types
export interface MarketData {
  symbol: string;
  price: number;
  volume: number;
  high: number;
  low: number;
  open: number;
  close: number;
  changePercent: number;
  timestamp: string;
}

export interface HistoricalDataPoint {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface HistoricalData {
  symbol: string;
  interval: string;
  data: HistoricalDataPoint[];
}

// Portfolio Types
export interface Portfolio {
  id: string;
  userId: string;
  totalValue: number;
  availableBalance: number;
  pnl: number;
  pnlPercent: number;
  positions: Position[];
  updatedAt: string;
}

export interface PortfolioSummary {
  totalValue: number;
  availableBalance: number;
  investedValue: number;
  pnl: number;
  pnlPercent: number;
  updatedAt: string;
}

export interface Position {
  id: string;
  portfolioId: string;
  assetId: string;
  symbol: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  leverage: number;
  direction: 'long' | 'short';
  createdAt: string;
  updatedAt: string;
}

// Order Types
export type OrderType = 'market' | 'limit' | 'stop' | 'stop_limit';
export type OrderDirection = 'buy' | 'sell';
export type OrderStatus = 'pending' | 'filled' | 'canceled' | 'rejected' | 'partial';

export interface OrderRequest {
  symbol: string;
  assetId: string;
  type: OrderType;
  direction: OrderDirection;
  quantity: number;
  price?: number;  // Required for limit orders
  stopPrice?: number;  // Required for stop orders
  leverage?: number;  // Default is 1
  timeInForce?: 'GTC' | 'IOC' | 'FOK';  // Default is GTC (Good Till Canceled)
}

export interface Order {
  id: string;
  userId: string;
  symbol: string;
  assetId: string;
  type: OrderType;
  direction: OrderDirection;
  quantity: number;
  price?: number;
  stopPrice?: number;
  leverage: number;
  status: OrderStatus;
  filledQuantity: number;
  filledPrice?: number;
  filledAt?: string;
  rejectionReason?: string;
  timeInForce: 'GTC' | 'IOC' | 'FOK';
  createdAt: string;
  updatedAt: string;
}

// WebSocket Types
export interface WebSocketMessage<T> {
  type: string;
  data: T;
  timestamp: string;
}

export interface WebSocketSubscription {
  channel: string;
  symbols: string[];
}

export interface WebSocketMarketDataMessage {
  symbol: string;
  price: number;
  volume?: number;
  high?: number;
  low?: number;
  open?: number;
  close?: number;
  changePercent?: number;
  timestamp: string;
}

// Error Types
export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, any>;
  status: number;
}

// Filter and Query Types
export interface PaginationParams {
  page?: number;
  limit?: number;
}

export interface AssetFilterParams extends PaginationParams {
  type?: Asset['type'];
  active?: boolean;
  tradable?: boolean;
  search?: string;
}

export interface OrderFilterParams extends PaginationParams {
  status?: OrderStatus;
  type?: OrderType;
  direction?: OrderDirection;
  startDate?: string;
  endDate?: string;
  symbol?: string;
}

// Chart and UI Component Types
export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string;
    borderColor?: string;
    fill?: boolean;
  }[];
}

export interface ChartOptions {
  responsive?: boolean;
  maintainAspectRatio?: boolean;
  scales?: Record<string, any>;
  plugins?: Record<string, any>;
  animation?: boolean | Record<string, any>;
}

export interface AlertOptions {
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
  closable?: boolean;
}

// Common Component Props
export interface WithLoadingProps {
  loading?: boolean;
  loadingText?: string;
}

export interface WithErrorProps {
  error?: string | null;
  onErrorClose?: () => void;
}

export interface WithRefreshProps {
  onRefresh?: () => void;
  lastUpdated?: string;
  refreshInterval?: number;
} 