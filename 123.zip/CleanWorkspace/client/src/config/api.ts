/**
 * API Configuration
 * 
 * Configuration for the API client, including environment-specific settings.
 */

import { getApiClient, RequestOptions } from '../services/ApiClient';

// Environment variables
const ENV = process.env.NODE_ENV || 'development';
const API_ENVIRONMENT = process.env.REACT_APP_API_ENVIRONMENT || ENV;

// API base URLs by environment
const API_BASE_URLS: Record<string, string> = {
  development: 'http://0.0.0.0:3001/api',
  test: 'http://0.0.0.0:3001/api',
  staging: 'https://staging-api.tradingapp.com/api',
  production: 'https://api.tradingapp.com/api',
};

// Get the API base URL for the current environment
export const API_BASE_URL = process.env.REACT_APP_API_URL || API_BASE_URLS[API_ENVIRONMENT] || API_BASE_URLS.development;

// Cache TTL values
export const CACHE_TTL = {
  SHORT: 1 * 60 * 1000, // 1 minute
  MEDIUM: 5 * 60 * 1000, // 5 minutes
  LONG: 30 * 60 * 1000, // 30 minutes
  VERY_LONG: 60 * 60 * 1000, // 60 minutes
};

// Default API client options
export const DEFAULT_API_OPTIONS: RequestOptions = {
  // Default headers
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  
  // Timeout in milliseconds
  timeout: 30000, // 30 seconds
  
  // Retry options
  retry: {
    maxRetries: 3,
    initialDelay: 500,
    maxDelay: 5000,
    backoffFactor: 2,
  },
  
  // Cache options
  cache: {
    enabled: true,
    ttl: CACHE_TTL.MEDIUM,
    burstProtection: true,
  },
};

/**
 * Initialize the API client with the appropriate configuration
 * This should be called once at application startup
 */
export function initializeApiClient(): void {
  // Initialize the API client with the base URL and default options
  getApiClient(API_BASE_URL, DEFAULT_API_OPTIONS);
  
  // Log API initialization
  console.log(`API client initialized with base URL: ${API_BASE_URL}`);
}

/**
 * Get an authentication header value
 * @returns The Authorization header value
 */
export function getAuthHeader(): string | null {
  const token = localStorage.getItem('auth_token');
  return token ? `Bearer ${token}` : null;
}

/**
 * Get default headers with authentication
 * @returns Headers with authentication if available
 */
export function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {};
  
  const authHeader = getAuthHeader();
  if (authHeader) {
    headers['Authorization'] = authHeader;
  }
  
  return headers;
} 