import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
    Check,
    Clock,
    Save,
    Shield,
    Zap
} from "lucide-react";
import { useState } from "react";
import { Badge } from "../ui/badge";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Skeleton } from "../ui/skeleton";

// Types for rate limit configuration
interface RateLimitRule {
  id: string;
  endpoint: string;
  requestsPerMinute: number;
  enabled: boolean;
  whitelisted: boolean;
  userRole: string;
}

export default function RateLimitControl() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [currentTab, setCurrentTab] = useState("general");
  
  // Sample rate limit data
  const [rateLimitEnabled, setRateLimitEnabled] = useState(true);
  const [globalRateLimit, setGlobalRateLimit] = useState(120);
  const [ipBasedRateLimiting, setIpBasedRateLimiting] = useState(true);
  const [userBasedRateLimiting, setUserBasedRateLimiting] = useState(true);
  const [whitelistedIPs, setWhitelistedIPs] = useState("127.0.0.1, 192.168.1.1");
  
  // Rules for specific endpoints
  const [endpointRules, setEndpointRules] = useState<RateLimitRule[]>([
    { 
      id: "1", 
      endpoint: "/api/trading/orders", 
      requestsPerMinute: 30, 
      enabled: true,
      whitelisted: false,
      userRole: "all"
    },
    { 
      id: "2", 
      endpoint: "/api/users/profile", 
      requestsPerMinute: 60, 
      enabled: true,
      whitelisted: false,
      userRole: "all"
    },
    { 
      id: "3", 
      endpoint: "/api/assets/prices", 
      requestsPerMinute: 200, 
      enabled: true,
      whitelisted: false,
      userRole: "all"
    },
    { 
      id: "4", 
      endpoint: "/api/admin/*", 
      requestsPerMinute: 100, 
      enabled: true,
      whitelisted: false,
      userRole: "admin"
    },
  ]);
  
  // Handle adding a new rule
  const [newEndpoint, setNewEndpoint] = useState("");
  const [newLimit, setNewLimit] = useState(60);
  const [newRole, setNewRole] = useState("all");
  
  const handleAddRule = () => {
    if (!newEndpoint) {
      toast({
        title: "خطأ",
        description: "الرجاء إدخال مسار نقطة النهاية",
        variant: "destructive"
      });
      return;
    }
    
    const newRule: RateLimitRule = {
      id: Date.now().toString(),
      endpoint: newEndpoint,
      requestsPerMinute: newLimit,
      enabled: true,
      whitelisted: false,
      userRole: newRole
    };
    
    setEndpointRules([...endpointRules, newRule]);
    setNewEndpoint("");
    setNewLimit(60);
    setNewRole("all");
    
    toast({
      title: "تمت الإضافة",
      description: "تمت إضافة قاعدة حد معدل جديدة",
    });
  };
  
  // Handle updating rule
  const handleUpdateRule = (id: string, field: keyof RateLimitRule, value: any) => {
    const updatedRules = endpointRules.map(rule => {
      if (rule.id === id) {
        return { ...rule, [field]: value };
      }
      return rule;
    });
    
    setEndpointRules(updatedRules);
  };
  
  // Handle deleting rule
  const handleDeleteRule = (id: string) => {
    const updatedRules = endpointRules.filter(rule => rule.id !== id);
    setEndpointRules(updatedRules);
    
    toast({
      title: "تم الحذف",
      description: "تم حذف قاعدة الحد من المعدل",
    });
  };
  
  // Save all changes
  const handleSaveChanges = () => {
    setIsLoading(true);
    
    // Simulating API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "تم الحفظ",
        description: "تم حفظ تكوين حد المعدل",
      });
    }, 1000);
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-80 mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-10 w-full mb-6" />
          <div className="space-y-4 mt-6">
            {Array(4).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>إعدادات حدود معدل API</CardTitle>
            <CardDescription>تكوين حدود الطلب لواجهة برمجة التطبيقات لمنع إساءة الاستخدام</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={handleSaveChanges}>
            <Save className="h-4 w-4 mr-2" />
            حفظ التغييرات
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={currentTab} onValueChange={setCurrentTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="general">
              <Shield className="h-4 w-4 mr-2" />
              الإعدادات العامة
            </TabsTrigger>
            <TabsTrigger value="endpoints">
              <Zap className="h-4 w-4 mr-2" />
              قواعد نقاط النهاية
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="general" className="mt-4 space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <h3 className="font-medium">تمكين حد المعدل</h3>
                <p className="text-sm text-muted-foreground">تمكين أو تعطيل حد المعدل على مستوى النظام</p>
              </div>
              <Switch 
                checked={rateLimitEnabled} 
                onCheckedChange={setRateLimitEnabled} 
              />
            </div>
            
            <div className="p-4 border rounded-lg space-y-4">
              <h3 className="font-medium">حد المعدل العام</h3>
              <p className="text-sm text-muted-foreground">الحد الأقصى لعدد الطلبات المسموح بها لكل دقيقة لكل مستخدم أو عنوان IP</p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="globalLimit">حد الطلبات العام (في الدقيقة)</Label>
                  <Input 
                    id="globalLimit"
                    type="number" 
                    value={globalRateLimit} 
                    onChange={(e) => setGlobalRateLimit(parseInt(e.target.value))}
                    min={1}
                  />
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="ipBasedLimiting" 
                      checked={ipBasedRateLimiting} 
                      onCheckedChange={setIpBasedRateLimiting} 
                    />
                    <Label htmlFor="ipBasedLimiting">تمكين الحد المستند إلى عنوان IP</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="userBasedLimiting" 
                      checked={userBasedRateLimiting} 
                      onCheckedChange={setUserBasedRateLimiting} 
                    />
                    <Label htmlFor="userBasedLimiting">تمكين الحد المستند إلى المستخدم</Label>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 border rounded-lg space-y-4">
              <h3 className="font-medium">عناوين IP المسموح بها</h3>
              <p className="text-sm text-muted-foreground">عناوين IP التي لا تخضع لحدود المعدل (مفصولة بفواصل)</p>
              
              <div className="space-y-2">
                <Label htmlFor="whitelistedIPs">عناوين IP المسموح بها</Label>
                <Input 
                  id="whitelistedIPs"
                  value={whitelistedIPs} 
                  onChange={(e) => setWhitelistedIPs(e.target.value)}
                  placeholder="مثال: 127.0.0.1, 192.168.1.1"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="endpoints" className="mt-4 space-y-4">
            <div className="p-4 border rounded-lg space-y-4">
              <h3 className="font-medium">إضافة قاعدة نقطة نهاية جديدة</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="newEndpoint">مسار نقطة النهاية</Label>
                  <Input 
                    id="newEndpoint"
                    value={newEndpoint} 
                    onChange={(e) => setNewEndpoint(e.target.value)}
                    placeholder="/api/your-endpoint"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newLimit">حد الطلبات (في الدقيقة)</Label>
                  <Input 
                    id="newLimit"
                    type="number" 
                    value={newLimit} 
                    onChange={(e) => setNewLimit(parseInt(e.target.value))}
                    min={1}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="userRole">دور المستخدم</Label>
                  <Select value={newRole} onValueChange={setNewRole}>
                    <SelectTrigger id="userRole">
                      <SelectValue placeholder="اختر دور المستخدم" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="all">جميع المستخدمين</SelectItem>
                        <SelectItem value="authenticated">المستخدمين المصادق عليهم فقط</SelectItem>
                        <SelectItem value="admin">المشرفين فقط</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button onClick={handleAddRule}>
                <Check className="h-4 w-4 mr-2" />
                إضافة قاعدة
              </Button>
            </div>
            
            <div className="border rounded-lg">
              <div className="p-4 border-b bg-muted/50">
                <h3 className="font-medium">قواعد نقاط النهاية</h3>
                <p className="text-sm text-muted-foreground">قواعد معدل محددة لنقاط نهاية API المختلفة</p>
              </div>
              
              <div className="divide-y">
                {endpointRules.map((rule) => (
                  <div key={rule.id} className="p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <code className="bg-muted p-1 rounded text-sm">{rule.endpoint}</code>
                        <Badge className="ml-2 bg-primary/10 text-primary text-xs">
                          {rule.userRole === "all" ? "جميع المستخدمين" : 
                           rule.userRole === "authenticated" ? "مصادق عليه" : "مشرف"}
                        </Badge>
                      </div>
                      <div className="flex items-center mt-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground ml-1">
                          {rule.requestsPerMinute} طلبًا في الدقيقة
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-2 mr-4">
                        <Switch 
                          checked={rule.enabled} 
                          onCheckedChange={(value) => handleUpdateRule(rule.id, "enabled", value)} 
                          size="sm"
                        />
                        <Label className="text-sm">مفعل</Label>
                      </div>
                      
                      <Input 
                        type="number" 
                        value={rule.requestsPerMinute} 
                        onChange={(e) => handleUpdateRule(rule.id, "requestsPerMinute", parseInt(e.target.value))}
                        className="w-20 h-8"
                        min={1}
                      />
                      
                      <Button 
                        variant="destructive" 
                        size="sm" 
                        onClick={() => handleDeleteRule(rule.id)}
                      >
                        حذف
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
} 